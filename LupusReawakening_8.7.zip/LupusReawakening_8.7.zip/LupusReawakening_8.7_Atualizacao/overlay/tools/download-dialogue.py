#!/usr/bin/env python3
"""Download already-generated recordings and package them for Android.

The input JSON is deliberately temporary: it contains expiring signed URLs.
This helper does not call a generation API or spend credits.
"""
import argparse
import concurrent.futures
import json
import pathlib
import re
import subprocess
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
GAME = ROOT / 'src/LupusReawakening-Android/app/src/main/assets/game'


def run(media, cache, language='pt-BR', force=False):
    key = media['key']
    if not re.fullmatch(r'[a-z0-9_]+', key):
        return {'key': key, 'ok': False, 'error': 'Invalid key'}
    output_dir = GAME / 'assets/voice/dialogue'
    if language == 'en':
        output_dir /= 'en'
    output = output_dir / (key + '.ogg')
    raw = cache / (key + '.mp3')
    try:
        if not raw.exists():
            # Retrying a transfer is safe; never submit another generation.
            last = None
            for attempt in range(2):
                try:
                    with urllib.request.urlopen(media['url'], timeout=45) as response:
                        data = response.read()
                    if len(data) < 100:
                        raise ValueError('Empty audio response')
                    raw.write_bytes(data)
                    break
                except Exception as error:
                    last = error
            else:
                raise last
        if force or not output.exists():
            partial = output.with_suffix('.part.ogg')
            command = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', str(raw),
                       '-vn', '-map_metadata', '-1', '-ac', '1', '-ar', '44100',
                       '-af', 'loudnorm=I=-18:TP=-2:LRA=8', '-c:a', 'libvorbis', '-q:a', '4', str(partial)]
            result = subprocess.run(command, capture_output=True, text=True)
            if result.returncode:
                raise ValueError(result.stderr[-300:])
            partial.replace(output)
        return {'key': key, 'ok': True, 'bytes': output.stat().st_size}
    except Exception as error:
        # Do not print the signed URL present in urllib's exception object.
        return {'key': key, 'ok': False, 'error': type(error).__name__}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('media_json', type=pathlib.Path)
    parser.add_argument('--cache', type=pathlib.Path, required=True)
    parser.add_argument('--workers', type=int, default=8)
    parser.add_argument('--lang', choices=['pt-BR', 'en'], default='pt-BR')
    parser.add_argument('--force', action='store_true', help='Replace only the keys explicitly listed in the input JSON.')
    args = parser.parse_args()
    args.cache.mkdir(parents=True, exist_ok=True)
    output_dir = GAME / 'assets/voice/dialogue'
    if args.lang == 'en':
        output_dir /= 'en'
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = json.loads(args.media_json.read_text())
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(run, row, args.cache, args.lang, args.force) for row in rows]
        for future in concurrent.futures.as_completed(futures):
            results.append(future.result())
            if len(results) % 25 == 0:
                print(json.dumps({'processed': len(results), 'total': len(rows), 'failed': sum(not x['ok'] for x in results)}), flush=True)
    args.media_json.with_name('dialogue-download-report.' + args.lang + '.json').write_text(json.dumps(results, indent=2))
    failed = [row for row in results if not row['ok']]
    print(json.dumps({'downloaded': len(rows) - len(failed), 'failed': failed, 'bytes': sum(x.get('bytes', 0) for x in results)}))
    return bool(failed)


if __name__ == '__main__':
    raise SystemExit(main())
