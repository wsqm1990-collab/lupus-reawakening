'use strict';
/* Shared production assets and localization for the connected 9.0 campaign. */
(function () {
  const keys = ['electric'];
  const Q = window.Q90 = window.Q90 || {};
  Q.version = '9.0'; Q.art = Q.art || {}; Q.paths = Q.paths || {};
  for (const key of keys) if (!Q.paths[key]) Q.paths[key] = 'assets/v90/' + key + '.webp';
  Q.lang = () => /^pt/i.test(SAVE.lang || '') ? 'pt' : 'en';
  Q.t = Q.text = (pt, en) => Q.lang() === 'pt' ? pt : en;
  Q.image = Q.asset = function (key, path) {
    const url = path || Q.paths[key];
    if (!url) return null;
    let im = Q.art[key];
    if (im && im._q90src === url) return im;
    im = new Image(); im._q90src = url;
    im.onload = () => { im.ok = true; im.bad = false; };
    im.onerror = () => { im.ok = false; im.bad = true; };
    Q.art[key] = im; im.src = url;
    return im;
  };
  Q.hasArt = key => !!(Q.art[key] && Q.art[key].ok);
  Q.ready = names => names.every(key => { const im = Q.image(key); return !!(im && im.ok); });
  Q.frame = function (ctx, source, index, cols, rows, x, y, w, h) {
    const im = typeof source === 'string' ? Q.image(source) : source;
    if (!im || !im.ok || !im.width || !im.height) return false;
    const cw = im.width / cols, ch = im.height / rows;
    const f = Math.max(0, Math.min(cols * rows - 1, index | 0));
    ctx.drawImage(im, f % cols * cw, Math.floor(f / cols) * ch, cw, ch, x, y, w, h);
    return true;
  };
  Q.blocked = () => !G || !!(G.over || G.panel || G.choice || G.paused || G.nachtBeat90 || G.rpgScene || document.hidden || Scene.cur !== Scenes.play || Scenes.play.menu);
  Q.resetInput = () => { Inp.reset(); };
})();
