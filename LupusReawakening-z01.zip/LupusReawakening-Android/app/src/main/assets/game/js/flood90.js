'use strict';
/* Authored cable/splash/arc sprites follow one contact clock. Only the depicted
 * electrified patch hurts; warning, falling and dissipating water are safe. */
(function () {
  const TIMING = { warning: 0.9, fall: 0.45, live: 1.5, fade: 0.4 };
  let path = 'assets/v90/electric.webp', image = null, pausedGame = null;
  function art() {
    if (!image) { image = new Image(); image.onload = () => { image.ok = true; measureCable(image); }; image.onerror = () => { image.bad = true; }; image.src = path; }
    return image;
  }
  const isStage = () => G && G.stage === 4 && G.mech === 'flood';
  function measureCable(im) {
    const c = document.createElement('canvas'); c.width = im.width; c.height = Math.floor(im.height / 2);
    try {
      const g = c.getContext('2d'); g.drawImage(im, 0, 0);
      const px = g.getImageData(0, 0, c.width, c.height).data; let top = c.height, bottom = -1;
      for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) if (px[(y * c.width + x) * 4 + 3] > 40) { top = Math.min(top, y); bottom = Math.max(bottom, y); }
      if (bottom > top) im._cable90 = { y: top, h: bottom - top + 1 };
    } catch (_) {}
    c.width = c.height = 0;
  }
  const contains = (h, e) => Math.hypot(e.x - h.x, (e.y - h.y) * 3.2) < h.r && e.z < 30;
  function phase(h) {
    if (h.t < TIMING.warning) return 'warning';
    if (h.t < h.warn) return 'fall';
    if (h.t < h.warn + h.live) return 'live';
    return 'fade';
  }
  const spawn0 = spawnHazard;
  spawnHazard = function (kind) {
    if (kind !== 'shock' || !isStage()) return spawn0.apply(this, arguments);
    const p = G.player; if (!p || p.dead) return;
    // A hazard may only become damaging when its authored visual is available.
    // Slow or failed decoding must never produce an invisible electric patch.
    const im = art(); if (!im.ok) return null;
    const x = clamp(p.x + rnd(-80, 110), G.camX + 46, G.camX + VW - 86);
    const y = clamp(p.y + rnd(-12, 12), LANE_T + 8, LANE_B - 8);
    const h = { kind: 'shock', flood90: true, x, y, r: 40, t: 0,
      warn: TIMING.warning + TIMING.fall, live: TIMING.live, dmg: 44,
      contacts: 0, pulse: -1, impact: false };
    G.hz.push(h); storySnd('zap'); return h;
  };
  const update0 = updHazards;
  updHazards = function (dt) {
    if (!G) return;
    const game = G, custom = G.hz.filter(h => h.flood90);
    G.hz = G.hz.filter(h => !h.flood90);
    update0.apply(this, arguments);
    if (G !== game) return;
    const survivors = [];
    for (const h of custom) {
      if (pausedGame === game) { survivors.push(h); continue; }
      const before = h.t; h.t += dt;
      if (before < TIMING.warning && h.t >= TIMING.warning) storySnd('fall');
      if (before < h.warn && h.t >= h.warn) {
        h.impact = true; storySnd('splash'); storySnd('zap'); h.contacts++;
      }
      if (h.t >= h.warn && h.t < h.warn + h.live) {
        const pulse = Math.floor((h.t - h.warn) * 3);
        if (pulse !== h.pulse) {
          h.pulse = pulse;
          for (const e of G.heroes.concat(G.enemies)) {
            if (e.dead || !contains(h, e)) continue;
            hurt({ x: h.x, y: h.y, team: e.team === 'p' ? 'e' : 'n' }, e,
              h.dmg * (e.team === 'p' ? DF().dmg : 1.4) * 0.5,
              { ignoreInv: false, stun: 0.25 });
          }
        }
      }
      if (h.t < h.warn + h.live + TIMING.fade) survivors.push(h);
    }
    G.hz.push(...survivors);
  };
  function cell(g, im, col, row, x, y, w, h, alpha) {
    if (!im || !im.ok || !im.width || !im.height) return false;
    const cw = im.width / 4, ch = im.height / 2;
    const sy = row ? ch : im._cable90 ? im._cable90.y : 0;
    const sh = row ? ch : im._cable90 ? im._cable90.h : ch;
    g.save(); g.imageSmoothingEnabled = false; g.globalAlpha = alpha == null ? 1 : alpha;
    g.drawImage(im, col * cw, sy, cw, sh, Math.round(x), Math.round(y), w, h); g.restore(); return true;
  }
  function drawHazard(g, h, cam) {
    if (!h.flood90) return false;
    const im = art(); if (!im.ok) return true;
    const ph = phase(h), x = h.x - cam, height = Math.max(40, h.y), width = 82;
    let cord = 0, alpha = 1;
    if (ph === 'fall') cord = 1 + Math.min(1, Math.floor((h.t - TIMING.warning) / TIMING.fall * 2));
    else if (ph === 'live' || ph === 'fade') cord = 3;
    if (ph === 'fade') alpha = clamp((h.warn + h.live + TIMING.fade - h.t) / TIMING.fade, 0, 1);
    // Every cable cell shares its ceiling attachment and water-contact baseline.
    cell(g, im, cord, 0, x - width / 2, 0, width, height, alpha);
    if (ph === 'live') {
      const age = h.t - h.warn;
      const frame = age < 0.18 ? 0 : 1 + Math.floor(age * 12) % 2;
      cell(g, im, frame, 1, x - h.r * 1.2, h.y - h.r * 0.78, h.r * 2.4, h.r * 1.1, alpha);
    } else if (ph === 'fade') {
      cell(g, im, 3, 1, x - h.r * 1.2, h.y - h.r * 0.78, h.r * 2.4, h.r * 1.1, alpha);
    }
    return true;
  }
  const init0 = MECH.flood.init;
  MECH.flood.init = function () { pausedGame = null; art(); return init0.apply(this, arguments); };
  window.Flood90 = {
    drawHazard, phase, contains, timing: TIMING,
    pause() { if (G) pausedGame = G; },
    resume(options) {
      pausedGame = null;
      if (isStage() && options && options.rearm) { G.hz = G.hz.filter(h => !h.flood90 && h.kind !== 'shock'); G.hzT = Math.max(G.hzT || 0, 1.4); }
    },
    clear() { if (G) G.hz = G.hz.filter(h => !h.flood90 && h.kind !== 'shock'); pausedGame = null; },
    get active() { return !!isStage() && pausedGame !== G; },
    configureAsset(next) { if (next && next !== path) { if (image) image.src = ''; image = null; path = next; } },
    preload: art,
    snapshot() { return G ? G.hz.filter(h => h.flood90).map(h => ({ t: h.t, phase: phase(h), x: h.x, y: h.y, r: h.r, impact: h.impact, contacts: h.contacts })) : []; }
  };
})();
