'use strict';
/* =====================================================================
   9.6 / 9.7 — heroes drawn frame by frame: Thorne's human form
   (js/atlas96h.js), feral werewolf (js/atlas96f.js) and alpha
   (js/atlas96a.js), and the partners (js/atlas97*.js). Every atlas
   marked v96 is played with these rules:
   - the frame where each blow lands comes from the atlas (imp);
   - the hit reaction plays its three frames, a throw shows rising /
     falling / hitting the floor, getting up plays all its frames, a
     landing shows the drawn crouch and the victory pose holds;
   - attacks whose trails are drawn in the frames do not get the generic
     slash effect on top.
   Fenrir Awakened (js/atlas97x.js), Thorne's last form, keeps the burning
   claw trails drawn in his frames, his X-slash dive included.
   Per hero: the human Thorne's chain special reaches exactly as far as
   the drawn chain; the feral dash is a wolf's lunge on all fours (the
   drive, the flight and the strike of the drawn gallop); Vespera's blood
   spiral leaves her hands as the very ball drawn in her frames; Triton's
   tidal wave is drawn apart (anim 'wave': the burst, rising, three looping
   frames of the full wave, collapsing) and erupts where his prongs strike
   the ground; Malakor's bolts and the skull of his finisher are drawn apart
   too (anims 'bolt' and 'skull') and leave from the hand of each cast; Echo's plasma rounds (anim 'round') fly
   out of the tip of her drawn cannon and her railgun beam (anim 'beam': igniting, full power, breaking up) shoots
   out of it and stays on it through the recoil; the two shockwaves of Brann's stone quake are drawn as the stone
   spikes of his 'shock' frames, bursting out where his fists strike the ground.
   ===================================================================== */
(function () {
  const drawnKey = e => {
    if (!(e && e.kind === 'hero')) return null;
    const k = heroKey(e), A = window.ATLAS[k];
    return A && A.v96 ? k : null;
  };
  const floorOf = e => (typeof heroFloor === 'function' ? heroFloor(e) : 0);

  /* the frame where each blow lands: from the atlas of the frames actually drawn */
  const imp0 = window.impactOf;
  window.impactOf = function (key, an) {
    const k2 = ART.extKey(key, an), B = window.ATLAS[k2 || key];
    if (B && B.v96 && B.imp && B.imp[an] != null) return B.imp[an];
    return imp0(key, an);
  };

  /* feral dash (2242 and 1944): the lunge of the gallop - hind legs drive, flight, front paws reach and strike */
  const LUNGE = [5, 6, 7, 0, 1];

  function frame96(e, KEY) {
    const A = window.ATLAS[KEY], n = an => ART.frameCount(KEY, an);
    switch (e.st) {
      case 'spec': return ['spec', phased(n('spec'), e.t / e.specDur, 0.45, A.imp.spec), false];
      case 'hurt': { const p = e.ct / Math.max(0.05, e.ct + Math.max(0, e.t)); return ['hurt', Math.min(n('hurt') - 1, Math.floor(p * n('hurt'))), false]; }
      case 'knock': return ['knock', knockFrame(e), false];
      case 'getup': { const p = e.ct / Math.max(0.05, e.ct + Math.max(0, e.t)); return ['getup', Math.min(n('getup') - 1, Math.floor(p * n('getup'))), false]; }
      case 'dead': return e.z - floorOf(e) > 1 ? ['knock', knockFrame(e), false] : ['down', 0];
      case 'air': if (e.vz > 0 && e.z - floorOf(e) < 5 && e.ct < 0.08) return ['crouch', 0]; return null;
      case 'dash': if ((KEY === 'lupus_f' || KEY === 'lupus44_f') && n('run') >= 8) return ['run', LUNGE[Math.min(LUNGE.length - 1, Math.floor(e.ct * 22))], false]; return null;
      case 'walk': case 'tagin': case 'xform': case 'atk': case 'guard': case 'down': return null;
    }
    /* idle and the other standing states */
    if (e.landT > 0) return ['land', 0, false];
    if (e.taunt) { if (e._win96 == null) e._win96 = G.time; return ['win', Math.floor((G.time - e._win96) * 8), false]; }
    e._win96 = null;
    return null;
  }
  function knockFrame(e) {
    const hz = e.z - floorOf(e);
    if (e.ct < 0.12 || (e.vz > 60 && hz > 10)) return 0;
    return hz > 14 ? 1 : 2;
  }

  const ef0 = window.entFrame;
  window.entFrame = function (e) {
    const k = drawnKey(e);
    if (k) { const r = frame96(e, k); if (r) return r; }
    return ef0(e);
  };

  /* attacks with their trails drawn in the frames: no generic slash effect on top (the human John's punches, 2242 and
     1944, have none drawn: they keep it). The feral and Vespera's
     air attacks keep it (those frames have no trail); the alpha's X-slash dive has its trails drawn, and so has
     Triton's plunge (the crackling prongs). */
  const TRAIL_AIR = { lupus_a: true, triton: true, fenrir: true };
  const hit0 = window.heroHit, slash0 = window.slashFx;
  let drawnTrail = false;
  window.heroHit = function (h) {
    const k = drawnKey(h);
    drawnTrail = !!k && k !== 'lupus_h' && k !== 'lupus44' && (!h.air || !!TRAIL_AIR[k]);
    const n0 = G.proj.length, np0 = G.parts.length;
    try { return hit0.apply(this, arguments); } finally { drawnTrail = false; shotsOf(h, k, n0, np0); }
  };
  /* Malakor's casts: the bolts the game fires (same start, speed, damage) are drawn from his 'bolt' frames - the
     finisher's piercing one as the flaming skull - and start where the drawn hand is on the impact frame.
     Echo's shots: the plasma rounds the game fires (same start, speed, damage) are drawn from her 'round' frames and
     fly out of the tip of the drawn cannon, at its height. The sparks of each shot leave from the drawn muzzle too. */
  function shotsOf(h, k, n0, np0) {
    const M = k === 'malakor' && window.ATLAS.malakor, E = k === 'echo' && window.ATLAS.echo;
    const an = h.air ? 'air' : 'atk' + h.idx;
    let mz = null, sx = 0, sz = 0;
    if (M && M.bolt && M.a.bolt) {
      mz = (M.bolt.muzzle && M.bolt.muzzle[an]) || [22, 30]; sx = 22; sz = 30;
      for (let i = n0; i < G.proj.length; i++) {
        const p = G.proj[i]; if (p.owner !== 'malakor' || p.fx96) continue;
        p.fx96 = 'malakor'; p.fxAn = p.pierce && M.a.skull ? 'skull' : 'bolt';
        /* the bolt flies at the old height (its hits are unchanged) but is drawn a little higher, at the height of a
           body's chest; it leaves the drawn hand and settles on that line within a fifth of a second */
        p.off96 = Math.max(0, mz[0] - 32); p.lift96 = mz[1] - 30; p.liftEnd96 = 14; p.ease96 = 0.2;
        if (p.fxAn === 'skull') { p.fps96 = 10; p.glow96 = 34; }
      }
    } else if (E && E.round && E.a.round) {
      mz = (E.round.muzzle && E.round.muzzle[an]) || [30, 50]; sx = 24; sz = 32;
      for (let i = n0; i < G.proj.length; i++) {
        const p = G.proj[i]; if (p.owner !== 'echo' || p.fx96) continue;
        /* a round flies straight: drawn at the cannon's height all the way (its hits are unchanged) */
        p.fx96 = 'echo'; p.fxAn = 'round'; p.fps96 = 18; p.glow96 = 13; p.raw96 = true; p.hold96 = true;
        p.off96 = mz[0] - 24; p.lift96 = mz[1] - 32;
      }
    }
    if (!mz) return;
    const ds = depthScale(h.y);
    for (let i = np0; i < G.parts.length; i++) { const q = G.parts[i]; q.x += h.face * (mz[0] * ds - sx); q.z += mz[1] * ds - sz; }
  }
  /* where a drawn projectile is seen: ahead of and above the line it flies on (world units, at its depth) */
  function fxOff(p) {
    const k = p.hold96 ? 1 : Math.max(0, 1 - p.t / (p.ease96 || 0.12)), le = p.liftEnd96 || 0, ds = depthScale(p.y);
    return [(p.off96 || 0) * k * ds, (le + ((p.lift96 || 0) - le) * k) * ds];
  }
  /* the sparks of a drawn projectile's hit (or of its end) burst where it is drawn */
  const upd0 = window.updProj;
  window.updProj = function (p, dt) {
    if (!p.fx96) return upd0.apply(this, arguments);
    const np0 = G.parts.length, r = upd0.apply(this, arguments);
    if (G.parts.length > np0) { const [dx, dz] = fxOff(p), s = Math.sign(p.vx) || 1; for (let i = np0; i < G.parts.length; i++) { G.parts[i].x += s * dx; G.parts[i].z += dz; } }
    return r;
  };
  window.slashFx = function () { if (drawnTrail) return; return slash0.apply(this, arguments); };

  const spec0 = window.heroSpecFire;
  window.heroSpecFire = function (h) {
    const k = drawnKey(h);
    /* the human chain special: same damage, launch and stagger as before, along the drawn chain */
    const H = window.ATLAS.lupus_h;
    if (k === 'lupus_h' && h.form === 'h' && !humanPulse(h) && H.reach && H.reach.spec) {
      const len = H.reach.spec, dm = hs(h).dmg;
      for (const e of foes()) { if (e.dead) continue; const dx = (e.x - h.x) * h.face; if (dx < -6 || dx > len || Math.abs(e.y - h.y) > 15) continue; hurt(h, e, dm * 2.2, { launch: true, kx: 170, kz: 230, brk: true }); }
      shake(5);
      return;
    }
    /* Vespera's blood spiral: the same projectile as before (start, speed, damage, reach), drawn as the
       ball of her frames; it leaves from where the ball is drawn on the release frame and spins */
    const V = k === 'vespera' && window.ATLAS.vespera;
    if (V && V.ball && h.id === 'vespera') {
      const dm = hs(h).dmg;
      const p = shoot({ x: h.x + h.face * 20, y: h.y, z: 36 + h.z, vx: h.face * 180, dmg: dm * 2.6, team: 'p', owner: 'vespera', r: 22, life: 1.5, type: 'orb', col: '#ff2a40', pierce: true, launch: true, kx: 120, wob: true, brk: true, big: true });
      p.img96 = 'vespera'; p.off96 = Math.max(0, V.ball.dx - 20); p.lift96 = Math.max(0, V.ball.dz + h.z - 30);
      ringFx(h.x, h.y, 30, 50, '#ff2a40', 0.3);
      return;
    }
    /* Triton's tidal wave: the same wave as before (start, speed, damage, reach, the shield it gives him), drawn
       from his 'wave' frames; it erupts where the prongs strike the ground and rolls on */
    const TR = k === 'triton' && window.ATLAS.triton;
    if (TR && TR.wave && h.id === 'triton') {
      const dm = hs(h).dmg;
      const p = shoot({ x: h.x + h.face * 20, y: h.y, z: 8, vx: h.face * 200, dmg: dm * 1.7, team: 'p', owner: 'triton', r: 30, life: 1.15, type: 'wave', col: '#3af0ff', pierce: true, launch: true, kx: 150, brk: true });
      p.wave96 = 'triton'; p.off96 = Math.max(0, (TR.wave.dx || 0) - 20);
      h.shieldHP = Math.max(h.shieldHP, 180); h.shieldT = 4; ringFx(h.x + h.face * (20 + p.off96), h.y, 20, 55, '#3af0ff', 0.4); shake(4);
      return;
    }
    /* Echo's railgun: the same shot as before (reach, damage, launch), its beam drawn from her 'beam' frames out of
       the tip of the drawn cannon; the ring and the sparks of the shot go where the beam is */
    const E = k === 'echo' && window.ATLAS.echo;
    if (E && E.beam && E.a.beam && h.id === 'echo') {
      const nl = G.lines.length, nr = G.rings.length, np = G.parts.length, r = spec0.apply(this, arguments);
      const mz = (E.beam.muzzle && E.beam.muzzle[E.imp.spec]) || [37, 57], ds = depthScale(h.y), up = h.z + mz[1] * ds;
      for (let i = nl; i < G.lines.length; i++) { const l = G.lines[i]; if (l.draw96) continue; l.draw96 = drawRail; l.h96 = h; l.hz96 = h.z; l.mz96 = mz.slice(); }
      for (let i = nr; i < G.rings.length; i++) { const q = G.rings[i]; q.x += h.face * (mz[0] * ds - 24); q.z = up; }
      for (let i = np; i < G.parts.length; i++) G.parts[i].z += up - 32;
      return r;
    }
    /* Brann's stone quake: the same two shockwaves as before (start, speed, damage, reach), drawn as the stone spikes
       of his 'shock' frames; they burst out where his fists strike the ground and rush along it, one each way */
    const BR = k === 'brann' && window.ATLAS.brann;
    if (BR && BR.shock && BR.a.shock && h.id === 'brann') {
      const n0 = G.proj.length, r = spec0.apply(this, arguments);
      for (let i = n0; i < G.proj.length; i++) { const p = G.proj[i]; if (p.owner !== 'brann' || p.type !== 'shock' || p.shock96) continue; p.shock96 = 'brann'; p.off96 = Math.max(0, (BR.shock.dx || 40) - 20); }
      return r;
    }
    return spec0.apply(this, arguments);
  };
  /* the railgun beam: ignites thin, two crackling frames of full power, breaks up into sparks as it fades. It shoots
     out of the cannon in a few hundredths of a second and stays on its tip while the frames show the recoil */
  function drawRail(g, l, cam) {
    const E = window.ATLAS.echo, im = ART.img.c_echo;
    if (!E || !E.a.beam || !im || !im.ok) return false;
    const h = l.h96, M = E.beam.muzzle, n = E.a.beam.length, k = Math.min(1, l.t / l.dur);
    if (h && h.st === 'spec' && Math.abs(h.x - l.x) < 1) {
      const ef = window.entFrame(h), m = ef && ef[0] === 'spec' && M[ef[1]];
      if (m) { const a = Math.min(1, Math.max(0, l.t - (l.lt96 || 0)) * 25); l.mz96[0] += (m[0] - l.mz96[0]) * a; l.mz96[1] += (m[1] - l.mz96[1]) * a; }
    }
    l.lt96 = l.t;
    const ds = depthScale(l.y), x = l.x - cam + l.face * l.mz96[0] * ds, y = l.y - (l.hz96 || 0) - l.mz96[1] * ds;
    const fi = l.t < 0.05 ? 0 : k > 0.78 ? n - 1 : 1 + (Math.floor(l.t * 20) % 2);
    RD.glow(g, x, y, 30 * (1 - 0.6 * k), l.col, 0.55);
    ART.draw(g, ART.frame('echo', 'beam', fi, false), x, y, { face: l.face, sc: ds, sx: Math.min(1, 0.2 + l.t / 0.06), alpha: k > 0.8 ? (1 - k) / 0.2 : 1, raw: true });
    return true;
  }

  /* projectiles drawn from a hero's own frames (anim 'proj'): at first where the frame drew them, then flying */
  /* a wave drawn frame by frame: bursts up (0), rises (1), rolls on in its looping frames, collapses as it ends */
  function waveFrame(p, A, an) {
    an = an || 'wave';
    const n = A.a[an].length, L = (A[an] && A[an].loop) || [2, 3, 4];
    if (p.life < 0.16) return n - 1;
    if (p.t < 0.07) return 0;
    if (p.t < 0.15) return 1;
    return L[Math.floor((p.t - 0.15) * 12) % L.length];
  }
  const proj0 = window.drawProj;
  window.drawProj = function (g, p, cam) {
    if (p.fx96) {
      const A = window.ATLAS[p.fx96], im = ART.img['c_' + p.fx96];
      if (A && A.a[p.fxAn] && im && im.ok) {
        const s = Math.sign(p.vx) || 1, n = A.a[p.fxAn].length, [dx, dz] = fxOff(p);
        const x = p.x - cam + s * dx, y = p.y - p.z - dz;
        RD.glow(g, x, y, p.glow96 || 20, p.col, 0.35);
        ART.draw(g, ART.frame(p.fx96, p.fxAn, Math.floor(p.t * (p.fps96 || 16)) % n), x, y, { face: s, raw: !!p.raw96 });
        return;
      }
    }
    if (p.wave96) {
      const A = window.ATLAS[p.wave96], im = ART.img['c_' + p.wave96];
      if (A && A.a.wave && im && im.ok) {
        const s = Math.sign(p.vx) || 1, k = Math.max(0, 1 - p.t / 0.3), x = p.x - cam + s * (p.off96 || 0) * k;
        RD.glow(g, x, p.y - 24, 46, p.col, 0.22);
        ART.draw(g, ART.frame(p.wave96, 'wave', waveFrame(p, A), false), x, p.y, { face: s, sc: depthScale(p.y) });
        return;
      }
    }
    if (p.shock96) {
      const A = window.ATLAS[p.shock96], im = ART.img['c_' + p.shock96];
      if (A && A.a.shock && im && im.ok) {
        const s = Math.sign(p.vx) || 1, ds = depthScale(p.y), x = p.x - cam + s * (p.off96 || 0) * ds;
        RD.glow(g, x, p.y - 14, 40, p.col, 0.18);
        ART.draw(g, ART.frame(p.shock96, 'shock', waveFrame(p, A, 'shock'), false), x, p.y, { face: s, sc: ds });
        return;
      }
    }
    if (p.img96) {
      const fr = ART.frame(p.img96, 'proj', 0), im = ART.img['c_' + p.img96];
      if (fr && im && im.ok) {
        const s = Math.sign(p.vx) || 1, k = Math.max(0, 1 - p.t / 0.3);
        ART.draw(g, fr, p.x - cam + s * (p.off96 || 0) * k, p.y - p.z - (p.lift96 || 0) * k, { rot: p.t * 10 * s, face: s, sc: 1.1 });
        return;
      }
    }
    return proj0.apply(this, arguments);
  };
})();
