'use strict';
/* =====================================================================
   AMBIENCE + COMIC SOUND EFFECTS
   Every comic page names an ambience loop (rain, lab machines, battle...)
   and beats can fire one-shot sounds (gunshot, keys, howl...).
   Real recordings live in assets/sfx/ (listed in SFX_FILES once they
   exist); anything missing is synthesised on the fly so the scene is
   never silent or wrong.
   ===================================================================== */
const SFX_FILES = new Set(["amb_battle", "amb_biolab", "amb_cell", "amb_chaos", "amb_chapel", "amb_citadel", "amb_crypt", "amb_dawn", "amb_docks", "amb_fire", "amb_lab44", "amb_london", "amb_metro", "amb_necropolis", "amb_office", "amb_rain_city", "amb_redrain", "amb_refuge", "amb_rooftop", "amb_siege", "amb_snow", "amb_storm", "amb_tanks", "amb_train", "beep", "cannon", "crowd", "crows", "door", "engine", "explosion", "fall", "glass", "gunfire", "gunshot", "heartbeat", "heartstop", "holo", "howl", "keys", "laser", "rip", "roar", "rumble", "scream", "searoar", "splash", "stone", "strap", "thunder", "wings", "zap"]);
const AMB = { cur: null, el: null, nodes: [], timers: [], vol: 0.55 };
const ambVol = () => (SAVE.sfx ? AMB.vol : 0);

/* ---------- synthesised building blocks ---------- */
function ambNoise(fType, fq, q, gain, lfo) {
  const c = AU.c, s = c.createBufferSource(); s.buffer = AU.nbuf; s.loop = true;
  const f = c.createBiquadFilter(); f.type = fType; f.frequency.value = fq; if (q) f.Q.value = q;
  const g = c.createGain(); g.gain.value = gain;
  s.connect(f); f.connect(g); g.connect(AMB.bus); s.start(0, Math.random());
  const out = [s, f, g];
  if (lfo) { const o = c.createOscillator(), og = c.createGain(); o.frequency.value = lfo[0]; og.gain.value = lfo[1]; o.connect(og); og.connect(lfo[2] === 'f' ? f.frequency : g.gain); o.start(); out.push(o, og); }
  AMB.nodes.push(...out);
}
function ambHum(fq, gain, type) {
  const c = AU.c, o = c.createOscillator(), f = c.createBiquadFilter(), g = c.createGain();
  o.type = type || 'sawtooth'; o.frequency.value = fq; f.type = 'lowpass'; f.frequency.value = fq * 3; g.gain.value = gain;
  o.connect(f); f.connect(g); g.connect(AMB.bus); o.start(); AMB.nodes.push(o, f, g);
}
/* repeat a one-shot at random intervals */
function ambEvery(min, max, fn) {
  const loop = () => { if (!AMB.bus) return; try { fn(); } catch (e) { } AMB.timers.push(setTimeout(loop, (min + Math.random() * (max - min)) * 1000)); };
  AMB.timers.push(setTimeout(loop, Math.random() * min * 1000));
}
const now = () => AU.c.currentTime;
function bz(d, v, fq, type, when) { noise(d, v, fq, AMB.bus, when, type); }
function tn(f, d, type, v, slide, when) { tone(f, d, type, v, slide, AMB.bus, when); }
const AMB_FX = {
  boom: () => { bz(1.4, 0.5, 220); tn(45, 1.2, 'sine', 0.35, -15); },
  gunfire: () => { const n = 2 + (Math.random() * 5 | 0); for (let i = 0; i < n; i++) bz(0.07, 0.35, 2600, 'bandpass', now() + i * (0.09 + Math.random() * 0.05)); },
  crackle: () => { for (let i = 0; i < 4; i++) bz(0.03, 0.18, 3000, 'highpass', now() + Math.random() * 0.4); },
  drip: () => tn(1400 + Math.random() * 900, 0.12, 'sine', 0.12, -600),
  bubble: () => tn(300 + Math.random() * 300, 0.18, 'sine', 0.1, 500),
  thunder: () => { bz(3.2, 0.45, 160); bz(0.4, 0.35, 900, 'lowpass', now() + 0.05); },
  siren: () => { const o = AU.c.createOscillator(), g = AU.c.createGain(); o.type = 'triangle'; o.frequency.setValueAtTime(520, now()); o.frequency.linearRampToValueAtTime(760, now() + 1.6); o.frequency.linearRampToValueAtTime(520, now() + 3.2); g.gain.setValueAtTime(0.0001, now()); g.gain.linearRampToValueAtTime(0.035, now() + 0.6); g.gain.linearRampToValueAtTime(0.0001, now() + 3.2); o.connect(g); g.connect(AMB.bus); o.start(); o.stop(now() + 3.3); },
  bell: () => { [1, 2.4, 3.9, 5.4].forEach((m, i) => tn(110 * m, 4 - i * 0.6, 'sine', 0.12 / (i + 1))); },
  crow: () => { for (let i = 0; i < 2; i++) { bz(0.16, 0.2, 1400, 'bandpass', now() + i * 0.25); tn(700, 0.16, 'sawtooth', 0.04, -200, now() + i * 0.25); } },
  chain: () => { for (let i = 0; i < 3; i++) tn(2200 + Math.random() * 800, 0.08, 'square', 0.03, 0, now() + i * 0.07); },
  step: () => { bz(0.08, 0.2, 500); },
  wave: () => { bz(2.6, 0.22, 700); },
  beep: () => tn(1800, 0.06, 'sine', 0.05),
  heart: () => { tn(58, 0.14, 'sine', 0.45, -18); tn(52, 0.16, 'sine', 0.35, -18, now() + 0.22); },
  tick: () => tn(3200, 0.02, 'square', 0.04),
  scream: () => { tn(700 + Math.random() * 300, 0.6, 'sawtooth', 0.025, -250); },
  cannon: () => { bz(1.6, 0.6, 180); tn(38, 1.2, 'sine', 0.4, -10); },
  drum: () => { tn(70, 0.25, 'sine', 0.3, -30); tn(70, 0.25, 'sine', 0.25, -30, now() + 0.3); },
  zap: () => { bz(0.15, 0.2, 5000, 'highpass'); tn(120, 0.15, 'square', 0.05, 60); },
  horse: () => { for (let i = 0; i < 4; i++) bz(0.05, 0.18, 900, 'bandpass', now() + i * 0.22); },
  murmur: () => { for (let i = 0; i < 3; i++) tn(160 + Math.random() * 120, 0.5, 'triangle', 0.015, Math.random() * 40 - 20, now() + i * 0.3); }
};
/* each ambience = list of layers */
const AMB_RECIPE = {
  battle: () => { ambNoise('lowpass', 500, 0, 0.05); ambNoise('highpass', 3000, 0, 0.012); ambEvery(1.2, 3.5, AMB_FX.boom); ambEvery(0.4, 1.6, AMB_FX.gunfire); ambEvery(0.3, 0.9, AMB_FX.crackle); },
  lab44: () => { ambHum(50, 0.05); ambHum(100, 0.02, 'square'); ambNoise('bandpass', 1200, 4, 0.01); ambEvery(0.5, 1.5, AMB_FX.bubble); ambEvery(2, 5, AMB_FX.zap); ambEvery(3, 6, AMB_FX.drip); },
  cell: () => { ambNoise('lowpass', 300, 0, 0.03); ambEvery(1.2, 3, AMB_FX.drip); ambEvery(4, 9, AMB_FX.chain); ambEvery(5, 10, AMB_FX.step); },
  fire: () => { ambNoise('lowpass', 700, 0, 0.12, [0.3, 0.04]); ambEvery(0.15, 0.5, AMB_FX.crackle); ambEvery(2.5, 5, AMB_FX.boom); ambEvery(3, 6, AMB_FX.siren); },
  snow: () => { ambNoise('bandpass', 500, 1.5, 0.08, [0.12, 250, 'f']); ambNoise('highpass', 4000, 0, 0.01); ambEvery(5, 9, () => bz(2, 0.15, 220)); },
  rain_city: () => { ambNoise('highpass', 1600, 0, 0.06); ambNoise('lowpass', 400, 0, 0.03); ambEvery(6, 14, AMB_FX.siren); ambEvery(3, 7, AMB_FX.zap); },
  rooftop: () => { ambNoise('highpass', 1500, 0, 0.07); ambNoise('bandpass', 450, 1.2, 0.06, [0.15, 200, 'f']); ambEvery(8, 16, AMB_FX.thunder); },
  storm: () => { ambNoise('highpass', 1300, 0, 0.09); ambNoise('bandpass', 380, 1, 0.06, [0.2, 180, 'f']); ambEvery(3.5, 8, AMB_FX.thunder); },
  refuge: () => { ambNoise('lowpass', 350, 0, 0.03); ambEvery(0.6, 1.4, AMB_FX.murmur); ambEvery(1.5, 4, AMB_FX.drip); },
  chaos: () => { ambNoise('highpass', 1600, 0, 0.05); ambEvery(0.6, 1.6, AMB_FX.scream); ambEvery(1.5, 3.5, AMB_FX.boom); ambEvery(1, 2.5, AMB_FX.gunfire); ambEvery(5, 9, AMB_FX.siren); },
  metro: () => { ambNoise('lowpass', 600, 0, 0.07, [0.2, 0.04]); ambEvery(1.5, 4, AMB_FX.zap); ambEvery(1, 2.5, AMB_FX.drip); ambEvery(3, 6, AMB_FX.wave); },
  biolab: () => { ambHum(60, 0.04); ambHum(180, 0.012, 'square'); ambEvery(0.4, 1.2, AMB_FX.bubble); ambEvery(2, 4, AMB_FX.beep); ambEvery(6, 12, AMB_FX.siren); },
  dawn: () => { ambNoise('bandpass', 600, 0.8, 0.035, [0.1, 150, 'f']); ambEvery(2, 5, () => tn(2400 + Math.random() * 1200, 0.12, 'sine', 0.02, 600)); },
  necropolis: () => { ambNoise('bandpass', 420, 1.2, 0.06, [0.12, 180, 'f']); ambHum(110, 0.008, 'triangle'); ambEvery(3, 7, AMB_FX.crow); ambNoise('highpass', 2000, 0, 0.02); },
  london: () => { ambNoise('lowpass', 500, 0, 0.04); ambEvery(3, 6, AMB_FX.horse); ambEvery(4, 8, AMB_FX.crow); ambEvery(1, 3, AMB_FX.drip); },
  crypt: () => { ambHum(55, 0.025, 'sine'); ambNoise('lowpass', 250, 0, 0.03); ambEvery(6, 12, AMB_FX.bell); ambEvery(2, 5, AMB_FX.drip); },
  docks: () => { ambNoise('lowpass', 700, 0, 0.06, [0.15, 0.05]); ambEvery(2.5, 5, AMB_FX.wave); ambNoise('highpass', 1800, 0, 0.03); ambEvery(9, 16, () => tn(98, 2.2, 'sawtooth', 0.04)); },
  tanks: () => { ambNoise('lowpass', 300, 0, 0.06); ambEvery(0.2, 0.7, AMB_FX.bubble); ambHum(70, 0.02, 'sine'); },
  train: () => { ambNoise('lowpass', 1400, 0, 0.16); ambNoise('highpass', 4000, 0, 0.04); ambHum(45, 0.06); ambEvery(0.6, 0.9, () => bz(0.06, 0.15, 900)); },
  redrain: () => { ambNoise('highpass', 1300, 0, 0.09); ambNoise('lowpass', 300, 0, 0.04); ambEvery(4, 9, AMB_FX.thunder); ambEvery(6, 12, AMB_FX.siren); },
  chapel: () => { ambHum(70, 0.015, 'sine'); ambNoise('highpass', 1800, 0, 0.025); ambEvery(0.8, 2, AMB_FX.bubble); ambEvery(5, 10, AMB_FX.drip); },
  siege: () => { ambNoise('lowpass', 500, 0, 0.06); ambEvery(1.5, 3.5, AMB_FX.cannon); ambEvery(0.8, 1.6, AMB_FX.drum); ambEvery(1, 3, AMB_FX.gunfire); },
  citadel: () => { ambHum(41, 0.06); ambHum(82, 0.02, 'square'); ambNoise('bandpass', 900, 3, 0.012); ambEvery(1.4, 1.6, AMB_FX.heart); ambEvery(3, 6, AMB_FX.zap); },
  office: () => { ambNoise('highpass', 2200, 0, 0.03); ambEvery(1, 1, AMB_FX.tick); ambEvery(10, 18, AMB_FX.siren); }
};

/* level-matched so every place sits at a similar loudness under the music */
const AMB_GAIN = {battle: 0.66, lab44: 0.69, cell: 4, fire: 1.3, snow: 3.14, rain_city: 0.88, rooftop: 0.76, storm: 0.84, refuge: 4, chaos: 0.89, metro: 1.69, biolab: 1.1, dawn: 4, necropolis: 2.2, london: 3.14, crypt: 1.57, docks: 1.38, tanks: 1.57, train: 0.94, redrain: 0.59, chapel: 1.57, siege: 0.9, citadel: 0.79, office: 1.83};
/* ---------- play / stop ---------- */
function ambStopSynth() { AMB.timers.forEach(clearTimeout); AMB.timers = []; const old = AMB.bus, nodes = AMB.nodes; AMB.nodes = []; AMB.bus = null;
  if (old) { try { old.gain.setTargetAtTime(0, AU.c.currentTime, 0.25); } catch (e) { } setTimeout(() => { nodes.forEach(n => { try { n.stop && n.stop(); } catch (e) { } try { n.disconnect(); } catch (e) { } }); try { old.disconnect(); } catch (e) { } }, 1200); } }
function ambStopFile() { const a = AMB.el; AMB.el = null; if (a) { const id = setInterval(() => { a.volume = Math.max(0, a.volume - 0.05); if (a.volume <= 0) { clearInterval(id); a.pause(); } }, 50); } }
const AMB_FILE_GAIN = 1.6;
const SBUF = {};
/* load + decode a sound once (XHR works on file:// inside the app) */
function sndBuf(n, cb) {
  const e = SBUF[n]; if (e && e.buf !== undefined) { cb(e.buf); return; } if (e) { e.cbs.push(cb); return; }
  const r = SBUF[n] = { cbs: [cb] }; const done = b => { r.buf = b || null; r.cbs.forEach(f => { try { f(r.buf); } catch (x) { } }); r.cbs = []; };
  try { const x = new XMLHttpRequest(); x.open('GET', 'assets/sfx/' + n + '.ogg'); x.responseType = 'arraybuffer';
    x.onload = () => { if (!x.response || !x.response.byteLength) return done(null); AU.c.decodeAudioData(x.response, b => done(b), () => done(null)); };
    x.onerror = () => done(null); x.send(); } catch (err) { done(null); }
}
function ambFileEl(name) {
  const a = new Audio('assets/sfx/amb_' + name + '.ogg'); a.loop = true; a.volume = 0; AMB.el = a;
  const p = a.play(); if (p && p.catch) p.catch(() => { });
  const id = setInterval(() => { if (AMB.el !== a) { clearInterval(id); return; } a.volume = Math.min(ambVol(), a.volume + 0.04); if (a.volume >= ambVol()) clearInterval(id); }, 50);
}
function ambient(name) {
  if (AMB.cur === name) return; AMB.cur = name;
  ambStopSynth(); ambStopFile();
  if (!name || !SAVE.sfx) return;
  if (SFX_FILES.has('amb_' + name)) {
    /* gapless loop through WebAudio; plain <audio> loop if the file cannot be decoded */
    if (AU.c) { sndBuf('amb_' + name, buf => {
        if (AMB.cur !== name || AMB.bus) return;
        if (!buf) { ambFileEl(name); return; }
        AMB.bus = AU.c.createGain(); AMB.bus.gain.value = 0; AMB.bus.connect(AU.sfx);
        const s = AU.c.createBufferSource(); s.buffer = buf; s.loop = true; s.connect(AMB.bus); s.start(); AMB.nodes.push(s);
        AMB.bus.gain.setTargetAtTime(AMB_FILE_GAIN, AU.c.currentTime, 0.5);
      }); return; }
    ambFileEl(name); return;
  }
  if (!AU.c || !AMB_RECIPE[name]) return;
  AMB.bus = AU.c.createGain(); AMB.bus.gain.value = 0; AMB.bus.connect(AU.sfx);
  AMB.bus.gain.setTargetAtTime(AMB_GAIN[name] || 1, AU.c.currentTime, 0.4);
  try { AMB_RECIPE[name](); } catch (e) { }
}
function ambientStop() { ambient(null); }

/* ---------- one-shot story sounds ---------- */
const SND_SYNTH = {
  gunshot: () => { sfx('shot'); noise(0.25, 0.6, 1800); },
  gunfire: () => AMB_FX.gunfire && (AMB.bus ? AMB_FX.gunfire() : (sfx('shot'), noise(0.2, 0.5, 2000))),
  explosion: () => sfx('boom'),
  keys: () => { for (let i = 0; i < 5; i++) tone(2600 + Math.random() * 1400, 0.07, 'square', 0.05, 0, null, AU.c.currentTime + i * 0.06); },
  strap: () => { tone(300, 0.12, 'square', 0.12, -150); noise(0.1, 0.3, 2500); },
  scream: () => { tone(620, 0.8, 'sawtooth', 0.12, -200); noise(0.6, 0.15, 1500, null, null, 'bandpass'); },
  howl: () => sfx('howl'), roar: () => sfx('roar'),
  claws: () => { noise(0.2, 0.3, 7000, null, null, 'highpass'); tone(2400, 0.25, 'sawtooth', 0.06, 800); },
  glass: () => { noise(0.4, 0.4, 6000, null, null, 'highpass'); for (let i = 0; i < 4; i++) tone(3000 + Math.random() * 2000, 0.15, 'sine', 0.05, 0, null, AU.c.currentTime + i * 0.05); },
  crows: () => { for (let i = 0; i < 4; i++) { noise(0.18, 0.3, 1400, null, AU.c.currentTime + i * 0.2, 'bandpass'); } },
  bell: () => { [1, 2.4, 3.9].forEach((m, i) => tone(98 * m, 3 - i * 0.5, 'sine', 0.25 / (i + 1))); },
  thunder: () => { noise(2.5, 0.8, 200); noise(0.3, 0.6, 1200); },
  stone: () => { noise(0.5, 0.5, 600); tone(90, 0.4, 'square', 0.1, -40); },
  searoar: () => { tone(70, 1.6, 'sawtooth', 0.4, 40); noise(1.4, 0.5, 500); },
  splash: () => { noise(0.6, 0.5, 1500); },
  holo: () => { tone(1200, 0.08, 'sine', 0.12); tone(1600, 0.12, 'sine', 0.12, 0, null, AU.c.currentTime + 0.1); },
  zap: () => { noise(0.2, 0.4, 5000, null, null, 'highpass'); tone(90, 0.2, 'square', 0.15, 50); },
  heartbeat: () => sfx('heart'),
  heartstop: () => { sfx('heart'); tone(40, 1.5, 'sine', 0.3, -15, null, AU.c.currentTime + 0.6); },
  engine: () => { noise(1.2, 0.4, 900); tone(80, 1.2, 'sawtooth', 0.15, 60); },
  wings: () => { for (let i = 0; i < 3; i++) noise(0.15, 0.3, 700, null, AU.c.currentTime + i * 0.18); },
  screech: () => { tone(2400, 0.9, 'sawtooth', 0.06, -800); noise(0.8, 0.3, 4000, null, null, 'highpass'); },
  crowd: () => { for (let i = 0; i < 5; i++) tone(500 + Math.random() * 400, 0.7, 'sawtooth', 0.03, -200, null, AU.c.currentTime + i * 0.1); },
  cannon: () => { noise(1.2, 0.8, 180); tone(40, 1, 'sine', 0.4, -10); },
  rumble: () => { noise(3, 0.7, 150); },
  laser: () => tone(2200, 0.25, 'sine', 0.08),
  beep: () => { for (let i = 0; i < 3; i++) tone(1900, 0.07, 'square', 0.06, 0, null, AU.c.currentTime + i * 0.12); },
  rip: () => { noise(0.3, 0.4, 3000, null, null, 'bandpass'); tone(200, 0.3, 'sawtooth', 0.12, -120); },
  punch: () => sfx('hit2'), door: () => { noise(0.4, 0.5, 300); tone(60, 0.3, 'square', 0.15, -20); },
  fall: () => { tone(500, 1.2, 'sine', 0.08, -420); }
};
const SND_EL = {};
function storySnd(n) {
  if (!n || !SAVE.sfx) return;
  if (SFX_FILES.has(n)) {
    const el = () => { let a = SND_EL[n]; if (!a) a = SND_EL[n] = new Audio('assets/sfx/' + n + '.ogg'); try { a.currentTime = 0; a.volume = 0.9; const p = a.play(); if (p && p.catch) p.catch(() => { }); } catch (e) { } };
    if (!AU.c) { el(); return; }
    sndBuf(n, buf => { if (!buf) { el(); return; } const s = AU.c.createBufferSource(), g = AU.c.createGain(); g.gain.value = 1.1; s.buffer = buf; s.connect(g); g.connect(AU.sfx); s.start(); });
    return;
  }
  if (AU.c && SND_SYNTH[n]) try { SND_SYNTH[n](); } catch (e) { }
}

/* ---------- hook into the comic player ---------- */
(function () {
  const C = Scenes.comic, sp = C.startPage, nb = C.nextBeat, dn = C.done, init = C.init;
  /* a page may name a stand-in image (alt) while its final art is not in the game yet */
  C.init = function () { for (const pg of this.pg0) for (const p of pg) { const im = COMIC.img[p.img]; if (p.alt && !(im && im.ok)) { p.img = p.alt; if (p.altMood) p.mood = p.altMood; if (p.altAmb) p.amb = p.altAmb; } } return init.call(this); };
  C.enter = function (arg) {
    this.id = arg.id; this.then = arg.then; this.pages = null; this.wait = 0; this.t = 0; this.ready = false;
    this.skipBtn = null; if (arg.music != null) musicStart(arg.music);
    this.pg0 = COMIC.pages(this.id); const imgs = [].concat(...this.pg0.map(pg => [].concat(...pg.map(p => p.alt ? [p.img, p.alt] : [p.img]))));
    COMIC.free(imgs); COMIC.need(imgs, () => { this.ready = true; }); this.preSnd();
  };
  C.preSnd = function () { if (!AU.c) return; const want = new Set(); for (const pg of this.pg0) for (const p of pg) { if (p.amb) want.add('amb_' + p.amb); for (const b of p.beats) if (b.snd) want.add(b.snd); } want.forEach(n => SFX_FILES.has(n) && sndBuf(n, () => { })); };
  C.startPage = function () { sp.call(this); const a = this.pg.find(p => p.amb); ambient(a ? a.amb : null); };
  C.nextBeat = function () { nb.call(this); const p = this.pg && this.pg[this.ci], b = p && p.beats[this.bi]; if (b && b.snd) storySnd(b.snd); };
  C.done = function () { ambientStop(); return dn.call(this); };
})();
/* leaving the comic by any route silences its ambience */
(function () { const go = Scene.go; Scene.go = function (n) { if (n !== 'comic') ambientStop(); return go.apply(this, arguments); }; })();
