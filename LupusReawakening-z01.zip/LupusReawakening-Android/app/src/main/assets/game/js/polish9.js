'use strict';
/* v9.0: clean overlays and speech-aware tutorial. Save reset, first-launch flow (Intro Comic -> Stage 1 with integrated tutorial,
   subsequent launches -> Title Menu), preventing out-of-place Stage 3 tutorial,
   Full HD Pause Menu renderer (PauseUI.drawHD), and Street Fighter Boss K.O. overlay. */
(function () {
  const PT = () => /^pt/.test(SAVE.lang || '');
  const words = (p, e) => PT() ? p : (window.TR9 ? TR9(e) : e);   /* v9.2: other languages come from tr92.js */

  window.resetProgress = function () {
    const preferences = {};
    for (const k of ['lang', 'langSet', 'langV5', 'langV9', 'music', 'sfx', 'vib', 'comicAuto', 'controls', 'perfLow', 'diff']) {
      if (SAVE[k] != null) preferences[k] = JSON.parse(JSON.stringify(SAVE[k]));
    }
    SAVE = Object.assign({
      unlocked: 1, hero: 'lupus', ally: 'vespera', up: { dmg: 0, hp: 0, fury: 0, cd: 0 }, seenIntro: false,
      diff: 'normal', shards: 0, stars: {}, xp: {}, owned: {}, pal: {}, lang: 'en', langV5: true, langV9: true,
      music: true, sfx: true, vib: true, best: {}
    }, preferences);
    Inp.reset(); saveGame(); applyLang(); return SAVE;
  };

  /* 1. First-Launch Flow:
     - First time opening the game (!SAVE.seenIntro): Studio Splash -> Intro Comic -> Directly into Stage 1 (Prologue) with integrated tutorial!
     - Next times opening the game (SAVE.seenIntro === true): Studio Splash -> Directly to Title Menu! */
  if (Scenes.studio) {
    Scenes.studio.finish = function () {
      this.done = true;
      if (!SAVE.seenIntro) {
        SAVE.seenIntro = true;
        SAVE.tutDone = true;
        saveGame();
        playCut('intro', () => Scene.go('play', { stage: 0 }), (STAGES[0] && STAGES[0].music) || 5);
      } else {
        Scene.go('title');
      }
    };
  }

  /* 2. Prevent standalone dummy tutorial from hijacking Stage 3 partner selection */
  if (Scenes.select) {
    const selDown = Scenes.select.onDown;
    Scenes.select.onDown = function (id, x, y) {
      if (!SAVE.pendingMode) SAVE.tutDone = true;
      return selDown.call(this, id, x, y);
    };
  }

  const title = Scenes.title, layout = title.layout, down = title.onDown;
  title.layout = function () {
    layout.call(this);
    if (!this.opts || this.langPick) return;
    for (const b of this.btns) if (b.id === 'reset' || b.id === 'close') b.y += 22;
    this.btns.push(btn('controls', VW / 2 - 90, 174, 87, 18, words('CONTROLES', 'CONTROLS'), COLR.cyan));
    this.btns.push(btn('backup', VW / 2 + 3, 174, 87, 18, words('BACKUP', 'BACKUP'), '#ffcf3a'));
  };
  title.onDown = function (id, x, y) {
    if (this.opts && !this.langPick) {
      const b = hitB(this.btns, x, y);
      if (b && b.id === 'controls' && window.ControlsUI) { sfx('ok'); ControlsUI.open(); return; }
      if (b && b.id === 'backup' && window.Backup9) { if (Backup9.open('export')) sfx('ok'); return; }
      if (b && b.id === 'reset') { sfx('ui'); Scene.go('confirmReset'); return; }
    }
    return down.call(this, id, x, y);
  };
  Scenes.confirmReset = {
    enter() { this.t = 0; },
    update(dt) {
      this.t += dt;
      this.btns = [
        btn('cancel', VW / 2 - 156, 174, 148, 26, words('CANCELAR', 'CANCEL'), COLR.cyan),
        btn('erase', VW / 2 + 8, 174, 148, 26, words('APAGAR PROGRESSO', 'ERASE PROGRESS'), COLR.red)
      ];
    },
    draw(g) {
      g.fillStyle = '#07040d'; g.fillRect(0, 0, VW, VH);
      PIX.text(g, words('RECOMEÇAR A HISTÓRIA?', 'RESTART THE STORY?'), VW / 2, 70, { s: 2, align: 'c', col: COLR.red });
      const text = words('Fases, melhorias, arquivos e desbloqueios serão apagados. Suas configurações serão mantidas.', 'Stages, upgrades, archives and unlocks will be erased. Your settings will be kept.');
      PIX.wrap(text, Math.min(340, VW - 60), 1).forEach((l, i) => PIX.text(g, l, VW / 2, 110 + i * 12, { align: 'c', col: COLR.white }));
      for (const b of this.btns || []) drawBtn(g, b);
    },
    onDown(id, x, y) { const b = hitB(this.btns || [], x, y); if (!b) return; if (b.id === 'erase') resetProgress(); sfx('ok'); Scene.go('title'); },
    onKey(k) { if (k === 'pause') Scene.go('title'); }
  };

  /* 3. Integrated Stage 1 Guided Tutorial & Stage 3 Partner Introduction */
  const TUT1_PT = {
    move: 'Arraste o ANALÓGICO à esquerda para mover Lupus',
    attack: 'Toque ou segure ATACAR para golpear em combo',
    jump: 'Toque em PULO para saltar sobre ataques',
    dash: 'Toque em DASH para esquivar (esquivar de golpes dá CONTRA-ATAQUE!)',
    block: 'Segure BLOQ para defender (no instante do golpe gera PARRY!)',
    spec: 'Toque em URRO para atordoar os inimigos ao redor',
    form: 'FÚRIA PRONTA! Toque em FORMA para virar LOBISOMEM (Feral)!'
  };
  const TUT1_EN = {
    move: 'Drag the left JOYSTICK to move Lupus',
    attack: 'Tap or hold ATTACK to strike in combos',
    jump: 'Tap JUMP to leap over attacks',
    dash: 'Tap DASH to dodge (dodging through attacks triggers COUNTER!)',
    block: 'Hold BLOCK to guard (blocking right on impact triggers PARRY!)',
    spec: 'Tap ROAR to stun nearby enemies',
    form: 'FURY READY! Tap FORM to transform into FERAL WEREWOLF!'
  };
  const TUT1_PAD_PT = {
    move: 'Use o ANALÓGICO ESQUERDO ou DIRECIONAL para mover Lupus',
    attack: 'Pressione ou segure X para atacar em combo',
    jump: 'Pressione A para saltar sobre ataques',
    dash: 'Pressione B para esquivar (atravesse golpes para CONTRA-ATACAR!)',
    block: 'Segure LB para defender (no instante do golpe gera PARRY!)',
    spec: 'Pressione Y para usar URRO e atordoar inimigos próximos',
    form: 'FÚRIA PRONTA! Pressione RT para virar LOBISOMEM (Feral)!'
  };
  const TUT1_PAD_EN = {
    move: 'Move Lupus with the LEFT STICK or D-PAD',
    attack: 'Press or hold X to attack in combos',
    jump: 'Press A to leap over attacks',
    dash: 'Press B to dodge (dodge through attacks to COUNTER!)',
    block: 'Hold LB to guard (block right on impact to PARRY!)',
    spec: 'Press Y to ROAR and stun nearby enemies',
    form: 'FURY READY! Press RT to transform into FERAL WEREWOLF!'
  };
  function usingPad() {
    if (!window.ControlsUI) return false;
    const state = ControlsUI.state();
    return state.input === 'pad' && state.connected;
  }
  function tutorialInstruction(step) {
    if (usingPad()) return PT() ? TUT1_PAD_PT[step] || '' : words('', TUT1_PAD_EN[step] || '');
    if (step === 'move') {
      // Custom layouts can move the stick independently of the handedness preset.
      const right = window.ControlsUI ? ControlsUI.joystick().x > VW / 2 : !!(SAVE.controls && SAVE.controls.left);
      return right ? words('Arraste o ANALÓGICO à direita para mover Lupus', 'Drag the right JOYSTICK to move Lupus') :
        words('Arraste o ANALÓGICO à esquerda para mover Lupus', 'Drag the left JOYSTICK to move Lupus');
    }
    /* 9.4: with the HUD pictures in charge, Form is the wolf at the top */
    if (step === 'form' && portraitsOn()) return words('FÚRIA PRONTA! Toque no LOBO lá em cima para virar LOBISOMEM!', 'FURY READY! Tap the WOLF at the top to turn into the WEREWOLF!');
    return PT() ? TUT1_PT[step] || '' : words('', TUT1_EN[step] || '');
  }
  const portraitsOn = () => !!(window.ControlsUI && ControlsUI.portraits && ControlsUI.portraits());
  function partnerInstruction() {
    if (usingPad()) return words('PARCEIRA: VESPERA — RB: AJUDA · BACK/SELECT: TROCA', 'PARTNER: VESPERA — RB: ASSIST · BACK/SELECT: SWAP');
    if (portraitsOn()) return words('PARCEIRA: VESPERA — Toque na foto dela (no alto, à esquerda) para TROCAR · AJUDA chama um golpe dela', 'PARTNER: VESPERA — Tap her picture (top left) to SWAP · ASSIST calls in her strike');
    return words('PARCEIRA: VESPERA — Use AJUDA (suporte) ou TROCA (assumir controle)!', 'PARTNER: VESPERA — Use ASSIST (support) or SWAP (switch hero)!');
  }

  /* Only authored story/radio speech pauses the tutorial. Short combat shouts
     (the roar's own cry, attack grunts) must not hide the move being taught. */
  const storySpeaking = () => !!(window.Dialogue9 && Dialogue9.busy() && Dialogue9.state.active && Dialogue9.state.active.authored);
  /* Moves that only last a moment are latched when they start, so they still
     count if the check runs a little later. */
  function tutLatch(kind) { const T1 = G && G.stage1Tut; if (T1 && !T1.done) (T1.did || (T1.did = {}))[kind] = true; }
  if (typeof startSpec === 'function') { const s0 = startSpec; startSpec = function (h) { const r = s0.apply(this, arguments); if (h && h.isPlayer) tutLatch('spec'); return r; }; }
  if (typeof startDash === 'function') { const d0 = startDash; startDash = function (h) { const r = d0.apply(this, arguments); if (h && h.isPlayer) tutLatch('dash'); return r; }; }

  function updateStage1Tut(dt) {
    if (!G || G.mode || G.over > 0 || G.clearT > 0 || G.panel || G.choice || G.title > 0.3 || G.cine || G.superFx || G.nachtBeat90) return;
    if ((G.talkQ && G.talkQ.length) || storySpeaking()) {
      if (G.stage1Tut) { G.stage1Tut.lastX = G.player.x; G.stage1Tut.lastY = G.player.y; }
      return;
    }
    // Stage 3 contextual partner hint when Vespera joins for the first time
    if (G.stage === 2 && G.ally && !SAVE.stage3TagHintDone) {
      if (G.stage3HintT == null) G.stage3HintT = 8.5;
      // Let the story/radio subtitle finish before spending the partner hint's
      // reading time. Both banners otherwise occupy the same part of the screen.
      if (!G.talkQ.length && !storySpeaking()) G.stage3HintT -= dt;
      if (G.tags >= 1 || G.ally.assist || G.stage3HintT <= 0) {
        G.stage3HintT = 0;
        SAVE.stage3TagHintDone = true;
      }
    }
    if (G.stage !== 0 || SAVE.stage1TutDone) return;
    if (!G.stage1Tut) {
      G.stage1Tut = {
        i: 0, t: 0, flash: 0, moved: 0, lastX: G.player.x, lastY: G.player.y,
        steps: ['move', 'attack', 'jump', 'dash', 'block', 'spec', 'form'],
        done: false
      };
    }
    const T1 = G.stage1Tut;
    if (T1.done) return;
    T1.t += dt;
    if (T1.flash > 0) T1.flash = Math.max(0, T1.flash - dt);
    const p = G.player, step = T1.steps[T1.i];
    let ok = false;
    if (step === 'move') {
      T1.moved += Math.abs(p.x - T1.lastX) + Math.abs(p.y - T1.lastY);
      T1.lastX = p.x; T1.lastY = p.y;
      ok = T1.moved > 95;
    } else if (step === 'attack') {
      ok = G.combo >= 2 || p.st === 'atk' && p.hitDone;
    } else if (step === 'jump') {
      ok = p.z > 14;
    } else if (step === 'dash') {
      ok = p.st === 'dash' || !!(T1.did && T1.did.dash);
    } else if (step === 'block') {
      ok = p.st === 'guard' && G.time - (p.guardT0 || 0) > 0.25;
    } else if (step === 'spec') {
      ok = p.st === 'spec' || !!(T1.did && T1.did.spec);
    } else if (step === 'form') {
      if (p.form === 'h' && p.fury < 105) p.fury = 110;
      ok = p.form !== 'h' || p.st === 'xform';
    }
    if (ok && T1.t > 0.35) {
      T1.i++; T1.did = {};
      T1.t = 0;
      T1.flash = 0.7;
      sfx('pick');
      if (T1.i >= T1.steps.length) {
        T1.done = true;
        SAVE.stage1TutDone = true;
        SAVE.tutDone = true;
        saveGame();
        sfx('ok');
      }
    }
  }

  /* Pause Menu Layout & Model (100% compatible with PauseUI.snapshot() tests) */
  const play = Scenes.play, playEnter = play.enter, playDown = play.onDown, playMove = play.onMove, playUp = play.onUp, playKey = play.onKey, playUpdate = play.update;
  play.enter = function (arg) {
    const r = playEnter.apply(this, arguments);
    if (G && !G.mode && G.stage === 0) {
      SAVE.tutDone = true;
      G.hintT = 0; // replaced by interactive step-by-step Stage 1 tutorial
      if (!SAVE.stage1TutDone) {
        G.stage1Tut = {
          i: 0, t: 0, flash: 0, moved: 0, lastX: G.player.x, lastY: G.player.y,
          steps: ["move", "attack", "jump", "dash", "block", "spec", "form"],
          done: false
        };
      }
    }
    return r;
  };

  const inside = (r, x, y) => x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h;
  function pauseLayout() {
    const m = window.ControlsUI ? ControlsUI.metrics() : { l: 8, r: 8, t: 5, b: 5, scale: SCALE / (cv._dpr || 1) };
    const edgeL = Math.max(10, m.l), edgeR = Math.max(10, m.r), gap = 12;
    const menuW = Math.min(212, Math.max(192, (VW - edgeL - edgeR) * 0.43));
    const top = Math.max(42, m.t + 34), bottom = Math.min(VH - 10, VH - m.b);
    const menu = { x: VW - edgeR - menuW, y: top, w: menuW, h: bottom - top };
    const mission = { x: edgeL, y: top, w: menu.x - gap - edgeL, h: bottom - top };
    const content = { x: mission.x + 13, y: mission.y + 27, w: mission.w - 30, h: mission.h - 53 };
    const buttonGap = Math.max(6, Math.ceil(8 / m.scale)), buttonH = Math.max(32, Math.ceil(48 / m.scale));
    const buttonY = menu.y + 24, buttonX = menu.x + 10, buttonW = menu.w - 20;
    return { mission, menu, content, buttonGap, buttonH, buttonY, buttonX, buttonW, scale: m.scale, headingY: top - 27 };
  }
  function wrapped(text, width, scale) {
    const out = [];
    for (const line of PIX.wrap(String(text || ''), width, scale)) {
      if (PIX.textW(line, scale) <= width) { out.push(line); continue; }
      let chunk = '';
      for (const ch of Array.from(line)) {
        if (chunk && PIX.textW(chunk + ch, scale) > width) { out.push(chunk); chunk = ch; } else chunk += ch;
      }
      if (chunk) out.push(chunk);
    }
    return out;
  }
  function phaseInstructions() {
    if (G.mode === 'tutorial' && G.tut) return T(tutKey94(G.tut.steps[G.tut.i]));
    if (G.mode === 'endless') return words('Derrote cada onda para continuar. A cada dez ondas, enfrente um chefe.', 'Defeat each wave to continue. Face a boss every ten waves.');
    if (G.mode === 'rush') return words('Derrote os chefes em sequência. Sua vida é mantida entre as lutas.', 'Defeat the bosses in sequence. Your health carries over between fights.');
    const keys = { escape: ['r01c'], investigate: ['r02a'], chase: ['r03a'], defend: ['r04a'], flood: ['r05a'], sabotage: ['r06a'], fog: ['r07a'], ritual: ['r08a'], giant: ['r10a'], train: ['r11a', 'r11b'], rescue: ['r12a'], brew: ['r13a'], siege: ['r14a'], reactors: ['r15a'] };
    if (G.mech === 'climb') return words('Segure a plataforma e derrote os inimigos enquanto ela sobe. Evite o fogo dos drones.', 'Hold the platform and defeat enemies as it rises. Avoid drone fire.');
    if (G.mech === 'final') return G.player.form === 'x' ? CT('m16c') : T('hint2');
    return (keys[G.mech] || []).map(CT).filter(Boolean).join(' ') || T('hint1');
  }
  function missionModel(layout) {
    const lines = [], width = layout.content.w; let y = 0;
    const paragraph = (text, scale, color, spacing) => {
      const height = Math.max(11, Math.ceil(scale * 10));
      for (const textLine of wrapped(text, width, scale)) { lines.push({ text: textLine, y, scale, color, height }); y += height; }
      y += spacing || 0;
    };
    const heading = text => paragraph(text, 1, COLR.cyan, 3);
    const name = G.mode === 'tutorial' ? T('training') : G.mode === 'endless' ? T('mode_endless') : G.mode === 'rush' ? T('mode_rush') : G.st.name[SAVE.lang] || G.st.name.en || '';
    paragraph(name, 1.6, COLR.white, 9);
    heading(T('objective'));
    const objective = G.mode === 'tutorial' ? T(tutKey94(G.tut.steps[G.tut.i])) : G.mode ? phaseInstructions() : G.st.obj[SAVE.lang] || G.st.obj.en || '';
    paragraph(objective, 1.35, COLR.white, 10);
    if (!G.mode) {
      heading(words('COMO AVANÇAR', 'HOW TO PROCEED'));
      paragraph(phaseInstructions(), 1.35, '#f7d18d', 12);
      if (window.Duel90 && Duel90.active() && Duel90.instructions) { heading(words('DUELO', 'DUEL')); paragraph(Duel90.instructions(), 1.15, '#e8d790', 12); }
      const challenges = CHAL[G.st.id] || [];
      if (challenges.length) {
        heading(words('DESAFIOS DA FASE', 'STAGE CHALLENGES'));
        for (const c of challenges) {
          const ok = c.k === 'clear' ? false : c.k === 'combo' ? G.maxCombo >= c.n : c.k === 'tags' ? G.tags >= c.n : c.k === 'nohit' ? G.hurtCount <= c.n : c.k === 'noko' ? G.koCount === 0 : c.k === 'time' ? G.time <= c.n : false;
          paragraph((ok ? '* ' : '- ') + chalText(c), 1.1, ok ? '#9fffc3' : '#c7c0d8', 4);
        }
      }
      const context = G.st.sub[SAVE.lang] || G.st.sub.en;
      if (context) { y += 5; paragraph(context, 1.05, '#a8a0bb', 0); }
    }
    return { name, objective, instruction: phaseInstructions(), lines, height: y, maxScroll: Math.max(0, y - layout.content.h) };
  }
  function scrollPause(delta) {
    const model = missionModel(pauseLayout()); play.pauseScroll = clamp((play.pauseScroll || 0) + delta, 0, model.maxScroll);
  }
  play.pauseMenu = function () {
    const q = pauseLayout(), cols = (q.buttonW - q.buttonGap) / 2;
    const make = (id, label, row, col, full, color) => btn(id, q.buttonX + (col || 0) * (cols + q.buttonGap), q.buttonY + row * (q.buttonH + q.buttonGap), full ? q.buttonW : cols, q.buttonH, label, color || COLR.cyan);
    if (this.pauseTab === 'world' && window.World90) {
      this.btns = [make('refuge90', words('REFÚGIO', 'REFUGE'), 0, 0, true, '#8ee2cc'), make('district90', words('MAPA DOS DISTRITOS', 'DISTRICT MAP'), 1, 0, true, '#b3bcff'), make('pauseBack', T('back'), 2, 0, true)];
    } else if (this.pauseTab === 'settings') {
      this.btns = [
        make('music', T('music') + ': ' + (SAVE.music ? T('on') : T('off')), 0, 0),
        make('sfx', T('sfx') + ': ' + (SAVE.sfx ? T('on') : T('off')), 0, 1),
        make('vib', T('vibration') + ': ' + (SAVE.vib !== false ? T('on') : T('off')), 1, 0),
        make('lang', T('lang') + ': ' + I18N[SAVE.lang].native, 1, 1),
        make('pauseBack', T('back'), 2, window.World90 && World90.canHub() ? 1 : 0, !(window.World90 && World90.canHub()))
      ];
      if (window.World90 && World90.canHub()) this.btns.push(make('pauseWorld', words('EXPLORAR', 'EXPLORE'), 2, 0));
    } else {
      this.btns = [
        make('resume', T('resume'), 0, 0, true, COLR.red),
        make('restart', T('restart'), 1, 0, false, '#bfb2d2'), make('quit', T('quit'), 1, 1, false, COLR.gold),
        make('controls', words('CONTROLES', 'CONTROLS'), 2, 0), make('pauseOptions', T('options'), 2, 1)
      ];
    }
    this.pauseLayout9 = q;
  };
  function drawPauseButton(g, b) {
    PIX.panel(g, b.x, b.y, b.w, b.h, { edge: b.col, bg: b.id === 'resume' ? '#531529' : '#141020' });
    const scale = b.id === 'resume' ? 1.7 : 1.2, textLines = wrapped(b.label, b.w - 16, scale), lineHeight = Math.ceil(scale * 10);
    const top = b.y + (b.h - textLines.length * lineHeight) / 2 + 2;
    textLines.forEach((text, i) => PIX.text(g, text, b.x + b.w / 2, top + i * lineHeight, { s: scale, align: 'c', col: COLR.white, out: null }));
  }
  function drawPause(g) {
    play.pauseMenu(); const q = play.pauseLayout9, model = missionModel(q), c = q.content;
    play.pauseScroll = clamp(play.pauseScroll || 0, 0, model.maxScroll);
    BG.back(g, G.camX, 0); dim(g, 0.88);
    PIX.text(g, T('paused'), VW / 2, q.headingY, { s: 2.4, align: 'c', col: COLR.red });
    PIX.panel(g, q.mission.x, q.mission.y, q.mission.w, q.mission.h, { edge: '#76618b', bg: '#100d1deb' });
    PIX.panel(g, q.menu.x, q.menu.y, q.menu.w, q.menu.h, { edge: '#493952', bg: '#0e0b18eb' });
    PIX.text(g, G.mode ? words('SEU OBJETIVO', 'YOUR OBJECTIVE') : T('stage') + ' ' + String(G.st.id).padStart(2, '0'), q.mission.x + 13, q.mission.y + 10, { col: COLR.cyan });
    PIX.text(g, play.pauseTab === 'world' ? words('EXPLORAÇÃO', 'EXPLORATION') : play.pauseTab === 'settings' ? T('options') : words('MENU', 'MENU'), q.menu.x + q.menu.w / 2, q.menu.y + 9, { align: 'c', col: '#bcb1ce' });
    g.save(); g.beginPath(); g.rect(c.x - 1, c.y - 2, c.w + 2, c.h + 3); g.clip();
    for (const l of model.lines) {
      const y = c.y + l.y - play.pauseScroll;
      if (y + l.height < c.y || y > c.y + c.h) continue;
      PIX.text(g, l.text, c.x, y, { s: l.scale, col: l.color, out: null });
    }
    g.restore();
    if (model.maxScroll > 0) {
      const trackX = q.mission.x + q.mission.w - 9, trackY = c.y, thumbH = Math.max(18, c.h * c.h / model.height);
      g.fillStyle = '#2c223b'; g.fillRect(trackX, trackY, 2, c.h);
      g.fillStyle = '#9c88b8'; g.fillRect(trackX, trackY + (c.h - thumbH) * play.pauseScroll / model.maxScroll, 2, thumbH);
      const note = play.pauseScroll >= model.maxScroll - 1 ? words('ARRASTE PARA VOLTAR', 'DRAG TO SCROLL UP') : words('ARRASTE PARA LER MAIS', 'DRAG TO READ MORE');
      PIX.text(g, note, q.mission.x + q.mission.w / 2, q.mission.y + q.mission.h - 13, { align: 'c', col: '#ab9cbd' });
    }
    for (const b of play.btns) drawPauseButton(g, b);
    const last = Math.max(...play.btns.map(b => b.y + b.h));
    if (q.menu.y + q.menu.h - last > 34) {
      const hint = window.ControlsUI && ControlsUI.state().input === 'pad' ? words('LB / RB: LER MISSÃO', 'LB / RB: READ MISSION') : words('LEIA A MISSÃO AO LADO', 'READ THE MISSION AT LEFT');
      wrapped(hint, q.menu.w - 28, 1).forEach((s, i) => PIX.text(g, s, q.menu.x + q.menu.w / 2, last + 18 + i * 11, { align: 'c', col: '#93859f' }));
    }
  }

  /* ===== NATIVE FULL-HD PAUSE MENU & OVERLAY RENDERER (Point 3) ===== */
  function roundRectHD(c, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    c.beginPath();
    c.moveTo(x + r, y);
    c.lineTo(x + w - r, y);
    c.quadraticCurveTo(x + w, y, x + w, y + r);
    c.lineTo(x + w, y + h - r);
    c.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    c.lineTo(x + r, y + h);
    c.quadraticCurveTo(x, y + h, x, y + h - r);
    c.lineTo(x, y + r);
    c.quadraticCurveTo(x, y, x + r, y);
    c.closePath();
  }

  function drawPauseHD(c) {
    if (Scene.name !== 'play' || !play.menu || !G) return;
    play.pauseMenu();
    const q = play.pauseLayout9, model = missionModel(q), mc = q.content;
    play.pauseScroll = clamp(play.pauseScroll || 0, 0, model.maxScroll);
    const sx = x => OX + x * SCALE, sy = y => OY + y * SCALE, sw = w => w * SCALE, sh = h => h * SCALE;

    c.save();
    // 1. Clean high-res backdrop dim over the low-res pixel buffer
    c.fillStyle = 'rgba(7, 4, 15, 0.88)';
    c.fillRect(sx(0), sy(0), sw(VW), sh(VH));

    // 2. Crisp HD Header Title ("PAUSADO" / "PAUSED")
    c.font = '800 ' + Math.round(16 * SCALE) + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'top';
    c.fillStyle = '#ff2a48';
    c.fillText(T('paused'), sx(VW / 2), sy(q.headingY));

    // 3. Left Mission Card (Glassmorphism + Crisp Neon Border)
    roundRectHD(c, sx(q.mission.x), sy(q.mission.y), sw(q.mission.w), sh(q.mission.h), 8 * SCALE);
    c.fillStyle = 'rgba(18, 13, 32, 0.96)';
    c.fill();
    c.lineWidth = Math.max(1.5, 1.6 * SCALE);
    c.strokeStyle = '#866ca3';
    c.stroke();

    // Left Mission Header Bar
    c.fillStyle = 'rgba(58, 240, 255, 0.10)';
    roundRectHD(c, sx(q.mission.x + 2), sy(q.mission.y + 2), sw(q.mission.w - 4), sh(21), 6 * SCALE);
    c.fill();
    c.font = '700 ' + Math.round(8.2 * SCALE) + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    c.textAlign = 'left';
    c.textBaseline = 'middle';
    c.fillStyle = '#4ce8ff';
    c.fillText(G.mode ? words('SEU OBJETIVO', 'YOUR OBJECTIVE') : T('stage') + ' ' + String(G.st.id).padStart(2, '0'), sx(q.mission.x + 12), sy(q.mission.y + 12.5));

    // Scrollable High-Resolution Mission Lines
    c.save();
    c.beginPath();
    c.rect(sx(mc.x - 2), sy(mc.y - 2), sw(mc.w + 4), sh(mc.h + 4));
    c.clip();
    for (const l of model.lines) {
      const ly = mc.y + l.y - play.pauseScroll;
      if (ly + l.height < mc.y || ly > mc.y + mc.h) continue;
      const isHeading = l.color === COLR.cyan;
      const isTitle = l.scale >= 1.5;
      const pxSize = Math.max(10, Math.round((isTitle ? 11.2 : isHeading ? 7.8 : l.scale >= 1.3 ? 9.4 : 8.4) * SCALE));
      c.font = (isTitle || isHeading ? '700 ' : '500 ') + pxSize + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
      c.textAlign = 'left';
      c.textBaseline = 'top';
      c.fillStyle = l.color === COLR.white ? '#f6f3ff' : l.color;
      c.fillText(l.text, sx(mc.x), sy(ly));
    }
    c.restore();

    // Scrollbar & Footer Hint
    if (model.maxScroll > 0) {
      const trackX = sx(q.mission.x + q.mission.w - 8), trackY = sy(mc.y), trackH = sh(mc.h);
      const thumbH = Math.max(18 * SCALE, trackH * mc.h / model.height);
      const thumbY = trackY + (trackH - thumbH) * (play.pauseScroll / model.maxScroll);
      c.fillStyle = 'rgba(54, 42, 74, 0.85)';
      roundRectHD(c, trackX, trackY, 3 * SCALE, trackH, 1.5 * SCALE);
      c.fill();
      c.fillStyle = '#b49ce0';
      roundRectHD(c, trackX, thumbY, 3 * SCALE, thumbH, 1.5 * SCALE);
      c.fill();

      const note = play.pauseScroll >= model.maxScroll - 1 ? words('ARRASTE PARA VOLTAR ↑', 'DRAG TO SCROLL UP ↑') : words('ARRASTE PARA LER MAIS ↓', 'DRAG TO READ MORE ↓');
      c.font = '600 ' + Math.round(7.2 * SCALE) + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
      c.textAlign = 'center';
      c.textBaseline = 'middle';
      c.fillStyle = '#b8aad0';
      c.fillText(note, sx(q.mission.x + q.mission.w / 2), sy(q.mission.y + q.mission.h - 10));
    }

    // 4. Right Menu Card
    roundRectHD(c, sx(q.menu.x), sy(q.menu.y), sw(q.menu.w), sh(q.menu.h), 8 * SCALE);
    c.fillStyle = 'rgba(15, 11, 26, 0.96)';
    c.fill();
    c.lineWidth = Math.max(1.5, 1.6 * SCALE);
    c.strokeStyle = '#5e496e';
    c.stroke();

    c.font = '700 ' + Math.round(8.2 * SCALE) + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillStyle = '#cfc4e4';
    c.fillText(play.pauseTab === 'world' ? words('EXPLORAÇÃO', 'EXPLORATION') : play.pauseTab === 'settings' ? T('options') : words('MENU', 'MENU'), sx(q.menu.x + q.menu.w / 2), sy(q.menu.y + 12.5));

    // 5. Crisp High-Resolution Buttons
    for (const b of play.btns) {
      const isResume = b.id === 'resume';
      roundRectHD(c, sx(b.x), sy(b.y), sw(b.w), sh(b.h), 6 * SCALE);
      const grad = c.createLinearGradient(0, sy(b.y), 0, sy(b.y + b.h));
      if (isResume) {
        grad.addColorStop(0, '#7a1b38');
        grad.addColorStop(1, '#481022');
      } else {
        grad.addColorStop(0, '#241c38');
        grad.addColorStop(1, '#151022');
      }
      c.fillStyle = grad;
      c.fill();
      c.lineWidth = Math.max(1.3, (isResume ? 2.0 : 1.4) * SCALE);
      c.strokeStyle = b.col || '#4ce8ff';
      c.stroke();

      const fSize = Math.max(10, Math.round((isResume ? 11.2 : 8.6) * SCALE));
      c.font = '700 ' + fSize + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
      c.textAlign = 'center';
      c.textBaseline = 'middle';
      c.fillStyle = '#ffffff';
      c.fillText(b.label, sx(b.x + b.w / 2), sy(b.y + b.h / 2), sw(b.w - 10));
    }
    // The native HD menu covers the pixel-buffer selection ring. Draw the
    // current controller focus last, using the same logical target as confirm.
    const focus = window.ControlsUI && ControlsUI.focusRect && ControlsUI.focusRect();
    if (focus) {
      roundRectHD(c, sx(focus.x - 2), sy(focus.y - 2), sw(focus.w + 4), sh(focus.h + 4), 8 * SCALE);
      c.strokeStyle = '#ffe58a';
      c.lineWidth = Math.max(2, 2 * SCALE);
      c.stroke();
      c.fillStyle = '#ffe58a';
      roundRectHD(c, sx(focus.x + 3), sy(focus.y + 5), sw(3), sh(focus.h - 10), 1.5 * SCALE);
      c.fill();
    }
    c.restore();
  }

  /* ===== NATIVE FULL-HD STAGE 1 GUIDED TUTORIAL & BOSS K.O. OVERLAY ===== */
  function drawOverlaysHD(c) {
    if (Scene.name !== 'play' || !G || play.menu || G.panel || G.choice) return;
    const sx = x => OX + x * SCALE, sy = y => OY + y * SCALE, sw = w => w * SCALE, sh = h => h * SCALE;

    if (window.Duel90 && Duel90.drawHD) Duel90.drawHD(c);

    // A. Street Fighter K.O. Dramatic Slow-Motion Callout when Boss is defeated
    if (G.clearT > 0 && G.clearT < 1.35 && G.boss && G.boss.dead && !G.boss.fleeing) {
      const k = G.clearT / 1.35;
      const alpha = k < 0.12 ? k / 0.12 : k > 0.75 ? (1 - k) / 0.25 : 1;
      c.save();
      c.globalAlpha = clamp(alpha, 0, 1);
      // Dramatic diagonal speed-slash bars
      if (G.clearT < 0.45) {
        c.fillStyle = 'rgba(255, 38, 72, ' + ((1 - G.clearT / 0.45) * 0.35).toFixed(3) + ')';
        c.fillRect(sx(0), sy(VH * 0.36), sw(VW), sh(28));
      }
      const scalePop = k < 0.18 ? 1.45 - (k / 0.18) * 0.45 : 1 + Math.sin(k * 10) * 0.03;
      c.translate(sx(VW / 2), sy(VH * 0.34));
      c.scale(scalePop, scalePop);
      c.font = '900 ' + Math.round(34 * SCALE) + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
      c.textAlign = 'center';
      c.textBaseline = 'middle';
      c.lineWidth = Math.max(4, 5 * SCALE);
      c.strokeStyle = '#16040a';
      c.strokeText('K.O.!', 0, 0);
      const gr = c.createLinearGradient(0, -18 * SCALE, 0, 18 * SCALE);
      gr.addColorStop(0, '#ffffff');
      gr.addColorStop(0.45, '#ffe168');
      gr.addColorStop(1, '#ff2442');
      c.fillStyle = gr;
      c.fillText('K.O.!', 0, 0);
      c.restore();
    }

    // B. Stage 1 Integrated Step-by-Step Tutorial Banner + Pointer Arrow
    if (G.stage === 0 && !G.mode && G.stage1Tut && !G.stage1Tut.done && G.title <= 0.3 && G.over <= 0 && !G.clearT && !G.cine && !G.superFx && !(G.talkQ && G.talkQ.length) && !storySpeaking()) {
      const T1 = G.stage1Tut, step = T1.steps[T1.i], total = T1.steps.length;
      const text = tutorialInstruction(step);
      const bw = Math.min(330, VW - 140), bx = VW / 2 - bw / 2, by = 62, bh = 30;
      c.save();
      roundRectHD(c, sx(bx), sy(by), sw(bw), sh(bh), 7 * SCALE);
      c.fillStyle = 'rgba(12, 9, 24, 0.90)';
      c.fill();
      c.lineWidth = Math.max(1.4, 1.6 * SCALE);
      c.strokeStyle = T1.flash > 0 ? '#7dff9a' : '#4ce8ff';
      c.stroke();

      c.font = '700 ' + Math.round(6.8 * SCALE) + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
      c.textAlign = 'left';
      c.textBaseline = 'top';
      c.fillStyle = '#4ce8ff';
      c.fillText(words('TUTORIAL DE COMBATE  ', 'COMBAT TUTORIAL  ') + (T1.i + 1) + '/' + total, sx(bx + 10), sy(by + 4));

      // Skip pill button on top right of banner
      if (!usingPad()) {
        c.textAlign = 'right';
        c.fillStyle = '#a89ec0';
        c.fillText(words('[Pular ✕]', '[Skip ✕]'), sx(bx + bw - 8), sy(by + 4));
      }

      c.font = '600 ' + Math.round(8.2 * SCALE) + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
      c.textAlign = 'center';
      c.fillStyle = '#ffffff';
      c.fillText(text, sx(VW / 2), sy(by + 15), sw(bw - 16));

      // Animated pointer arrow above the target control
      if (window.ControlsUI && !usingPad()) {
        const map = { attack: 'atk', jump: 'jump', dash: 'dash', block: 'block', spec: 'spec', form: 'form' };
        /* 9.4: the Form step points up at the wolf picture in the HUD */
        const tile = step === 'form' && portraitsOn();
        const target = tile ? { x: VW / 2, y: 46, r: 0, up: true } : step === 'move' ? ControlsUI.joystick() : ControlsUI.buttons()[map[step]];
        if (target && target.up) {
          const bounce = Math.sin(G.time * 8) * 3, ax = sx(target.x), ay = sy(target.y + bounce);
          c.fillStyle = '#7dff9a'; c.strokeStyle = '#080510'; c.lineWidth = Math.max(1.5, 1.8 * SCALE);
          c.beginPath(); c.moveTo(ax - 7 * SCALE, ay + 8 * SCALE); c.lineTo(ax + 7 * SCALE, ay + 8 * SCALE); c.lineTo(ax, ay - 2 * SCALE); c.closePath(); c.fill(); c.stroke();
        } else if (target) {
          const bounce = Math.sin(G.time * 8) * 4;
          const ax = sx(target.x), ay = sy(target.y - target.r - 8 + bounce);
          c.fillStyle = '#7dff9a';
          c.strokeStyle = '#080510';
          c.lineWidth = Math.max(1.5, 1.8 * SCALE);
          c.beginPath();
          c.moveTo(ax - 7 * SCALE, ay - 8 * SCALE);
          c.lineTo(ax + 7 * SCALE, ay - 8 * SCALE);
          c.lineTo(ax, ay + 2 * SCALE);
          c.closePath();
          c.fill();
          c.stroke();
        }
      }
      c.restore();
    }

    // C. Stage 3 Non-Intrusive Partner Tag/Assist Introduction Banner
    if (G.stage === 2 && !G.mode && (G.stage3HintT || 0) > 0 && G.ally && G.title <= 0.3 && !G.talkQ.length && !storySpeaking()) {
      const bw = Math.min(340, VW - 130), bx = VW / 2 - bw / 2, by = 62, bh = 28;
      c.save();
      roundRectHD(c, sx(bx), sy(by), sw(bw), sh(bh), 7 * SCALE);
      c.fillStyle = 'rgba(16, 10, 28, 0.88)';
      c.fill();
      c.lineWidth = Math.max(1.4, 1.5 * SCALE);
      c.strokeStyle = '#ff3ad0';
      c.stroke();
      c.font = '700 ' + Math.round(7.6 * SCALE) + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
      c.textAlign = 'center';
      c.textBaseline = 'middle';
      c.fillStyle = '#ff7be2';
      c.fillText(partnerInstruction(), sx(VW / 2), sy(by + bh / 2), sw(bw - 14));
      c.restore();
    }
    if (window.Traversal90 && Traversal90.hint && !G.cine && !G.superFx && !G.nachtBeat90 && !(G.talkQ && G.talkQ.length) && !(window.Dialogue9 && Dialogue9.busy())) {
      const h = Traversal90.hint();
      if (h && h.ready && h.text) { const x = clamp(h.x - G.camX, 70, VW - 70), y = clamp(h.y, 78, VH - 82); c.save(); c.font = '700 ' + Math.round(7.2 * SCALE) + 'px system-ui,sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineWidth = 3 * SCALE; c.strokeStyle = '#090713'; c.fillStyle = '#b2f5ff'; c.strokeText(h.text, sx(x), sy(y), sw(156)); c.fillText(h.text, sx(x), sy(y), sw(156)); c.restore(); }
    }
  }

  play.onDown = function (id, x, y) {
    if (this.menu) {
      this.pauseMenu(); const b = hitB(this.btns, x, y);
      if (b && b.id === 'controls' && window.ControlsUI) { ControlsUI.open(); return; }
      if (b && b.id === 'pauseOptions') { this.pauseTab = 'settings'; this.pauseMenu(); sfx('ui'); return; }
      if (b && b.id === 'pauseWorld' && window.World90 && World90.canHub()) { this.pauseTab = 'world'; this.pauseMenu(); sfx('ui'); return; }
      if (b && (b.id === 'refuge90' || b.id === 'district90') && window.World90) { const ok = b.id === 'refuge90' ? World90.openHub() : World90.openMap(); if (ok) sfx('ok'); return; }
      if (b && b.id === 'pauseBack') { this.pauseTab = 'actions'; this.pauseMenu(); sfx('ui'); return; }
      if (!b && inside(this.pauseLayout9.mission, x, y)) { this.pauseDrag9 = { id, y }; return; }
    }
    return playDown.call(this, id, x, y);
  };
  play.onMove = function (id, x, y) {
    if (this.menu && this.pauseDrag9 && this.pauseDrag9.id === id) { scrollPause(this.pauseDrag9.y - y); this.pauseDrag9.y = y; return; }
    return playMove.call(this, id, x, y);
  };
  play.onUp = function (id) { if (this.pauseDrag9 && this.pauseDrag9.id === id) this.pauseDrag9 = null; return playUp.apply(this, arguments); };
  play.onKey = function (key) {
    const was = this.menu; const r = playKey.call(this, key);
    if (this.menu && !was) { this.pauseTab = 'actions'; this.pauseScroll = 0; this.pauseMenu(); }
    if (!this.menu) this.pauseDrag9 = null;
    return r;
  };
  play.update = function (dt) {
    const r = playUpdate.call(this, dt);
    if (Scene.cur === this && !this.menu) updateStage1Tut(dt);
    if (Scene.cur === this && this.menu && window.ControlsUI) {
      const state = ControlsUI.state(); if (state.input === 'pad') scrollPause(((state.held.assist ? 1 : 0) - (state.held.block ? 1 : 0)) * dt * 100);
    }
    return r;
  };
  cv.addEventListener('wheel', e => {
    if (Scene.name !== 'play' || !play.menu) return;
    const p = toLogical(e), q = pauseLayout(); if (!inside(q.mission, p.x, p.y)) return;
    e.preventDefault(); const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? window.innerHeight * 0.8 : 1; scrollPause(e.deltaY * unit / q.scale);
  }, { passive: false });
  window.addEventListener('keydown', e => {
    if (Scene.name !== 'play' || !play.menu || !['PageDown', 'PageUp', 'Home', 'End'].includes(e.key)) return;
    e.preventDefault(); scrollPause(e.key === 'Home' ? -1e6 : e.key === 'End' ? 1e6 : (e.key === 'PageDown' ? 1 : -1) * pauseLayout().content.h * 0.8);
  });
  window.PauseUI = {
    draw: drawPause, drawHD: drawPauseHD, drawOverlaysHD, layout: pauseLayout, scroll: scrollPause,
    snapshot() { const layout = pauseLayout(), model = missionModel(layout); return { layout, model, scroll: play.pauseScroll || 0, tab: play.pauseTab || 'actions' }; }
  };
})();
