const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../src/LupusReawakening-Android/app/src/main/assets/game/js/dialogue9.js'), 'utf8');
function fixture(useNative = true) {
  let playing = false, starts = [], stops = 0;
  const handlers = {}, context = {
    SAVE: { lang: 'pt', sfx: true, comicAuto: true }, VOX: { pool: {}, last: {}, ok: {} },
    VOX_FILES: new Set(['lupus_atk1', 'lupus_atk2']),
    LUPUS_DIALOGUE: { a: { file: 'assets/voice/dialogue/a.ogg', duration: 5 }, b: { file: 'assets/voice/dialogue/b.ogg', duration: 2 } },
    LUPUS_DIALOGUE_EN: { a: { file: 'assets/voice/dialogue/en/a.ogg', duration: 7 }, b: { file: 'assets/voice/dialogue/en/b.ogg', duration: 3 } },
    performance: { now: () => 1000 }, document: { hidden: false, addEventListener: (n, f) => { handlers[n] = f; } },
    addEventListener: (n, f) => { handlers[n] = f; }, setInterval: () => 1,
    CT: () => 'Um texto curto.', musDuck: () => {},
    Scenes: { comic: {
      enter() { this.pg0 = [[{ beats: [{ k: 'a', vo: 'legacy' }] }]]; },
      nextBeat() { this.bi = (this.bi == null ? -1 : this.bi) + 1; this.bt = 0; this.mode = 'panel'; this.autoT = 1; const b = this.pg[0].beats[this.bi]; if (b && b.vo) context.voice(b.vo, 0); },
      update(dt) { this.bt += dt; if (this.bt > this.autoT) this.nextBeat(); },
      done() {}, turn() {},
    }, play: { onKey() { this.menu = !this.menu; }, update() {} } },
    Scene: { go() {} }, showPanel() {}, panelAdvance() { context.G.panel = null; }, panelStep() {},
    talk(spk, k, opts) { context.G.talkQ.push({ spk, k, t: 0, dur: 1, ...opts }); },
    setAudioOpts() {}, G: { talkQ: [], title: 0, banner: null },
    Audio: class {
      constructor() { this.paused = true; this.ended = false; }
      play() { starts.push(this.src); this.paused = false; this.ended = false; return Promise.resolve(); }
      pause() { this.paused = true; }
    },
  };
  if (useNative) context.LupusAudio = {
    playVoice(file) { starts.push(file); playing = true; return true; },
    stopVoices() { stops++; playing = false; }, isVoicePlaying: () => playing,
    pauseVoices() {}, resumeVoices() {},
  };
  context.window = context; vm.createContext(context); vm.runInContext(source, context);
  return { c: context, starts, handlers, end() { playing = false; if (context.Dialogue9.state.audio) { context.Dialogue9.state.audio.ended = true; context.Dialogue9.state.audio.onended(); } }, stops: () => stops };
}
for (const useNative of [true, false]) {
  const f = fixture(useNative), c = f.c;
  c.Dialogue9.play('a', 'story'); assert.equal(f.starts.length, 1);
  c.voice('lupus_atk1', 0); assert.equal(f.starts.length, 1, 'combat must not interrupt authored dialogue');
  c.Dialogue9.play('b', 'story'); assert.equal(f.starts.at(-1), 'assets/voice/dialogue/b.ogg');
  c.Scene.go('title'); assert.equal(c.Dialogue9.busy(), false, 'scene exit must stop speech');
  c.voice('lupus_atk1', 0); c.voice('lupus_atk2', 0); assert.equal(f.starts.at(-1), 'assets/voice/lupus_atk2.ogg', 'zero gap must not swallow a line from the same speaker');
  c.talk('lupus_h', 'a'); c.talkStep(0.1); c.talkStep(20);
  assert.equal(c.G.talkQ.length, 1, 'radio subtitle must remain until its recording ends');
  f.end(); c.talkStep(0.1); assert.equal(c.G.talkQ.length, 0);
  const comic = c.Scenes.comic; comic.enter(); comic.pg = comic.pg0[0]; comic.ci = 0; comic.bi = -1; comic.nextBeat(); comic.update(8);
  assert.equal(comic.bi, 0, 'automatic comic cannot skip unfinished speech');
  comic.done(); assert.equal(c.Dialogue9.busy(), false);
  c.Dialogue9.play('a', 'story'); c.SAVE.sfx = false; c.setAudioOpts(); assert.equal(c.Dialogue9.busy(), false, 'muting SFX stops ongoing voices');
  c.SAVE.sfx = true; c.Dialogue9.play('a', 'story'); c.document.hidden = true; f.handlers.visibilitychange(); assert.equal(c.Dialogue9.busy(), false, 'backgrounding stops speech');

  c.document.hidden = false; c.SAVE.lang = 'en'; c.Dialogue9.languageChanged('pt');
  assert.equal(c.Dialogue9.busy(), false, 'language selection must stop the previous recording');
  assert.equal(c.Dialogue9.language, 'en'); assert.equal(c.Dialogue9.lines.a.duration, 7);
  c.Dialogue9.play('a', 'story'); assert.equal(f.starts.at(-1), 'assets/voice/dialogue/en/a.ogg');
  c.Dialogue9.stop(); c.SAVE.lang = 'es'; c.Dialogue9.play('b', 'story');
  assert.equal(f.starts.at(-1), 'assets/voice/dialogue/en/b.ogg', 'other subtitle languages use English narration');
  c.Dialogue9.stop(); c.SAVE.lang = 'pt'; c.Dialogue9.play('a', 'story');
  assert.equal(f.starts.at(-1), 'assets/voice/dialogue/a.ogg', 'Portuguese selection must restore PT-BR narration');
  c.Dialogue9.stop(); c.SAVE.lang = 'en'; delete c.LUPUS_DIALOGUE_EN.b; const before = f.starts.length;
  assert.equal(c.Dialogue9.play('b', 'story'), false);
  assert.equal(f.starts.length, before, 'missing English audio must never fall back to Portuguese');
  c.voice('lupus_atk1', 0); assert.equal(f.starts.at(-1), 'assets/voice/lupus_atk1.ogg', 'legacy English combat voices are preserved');

  c.Dialogue9.stop(); c.SAVE.lang = 'pt'; c.G.talkQ = []; c.talk('lupus_h', 'a'); c.talkStep(0.1);
  assert.equal(f.starts.at(-1), 'assets/voice/dialogue/a.ogg');
  c.SAVE.lang = 'en'; c.Dialogue9.languageChanged('pt'); c.talkStep(0.1);
  assert.equal(f.starts.at(-1), 'assets/voice/dialogue/en/a.ogg', 'the current radio subtitle restarts in the new language');
  c.SAVE.lang = 'pt'; c.Scene.name = 'comic'; comic.enter(); comic.pg = comic.pg0[0]; comic.ci = 0; comic.bi = -1; comic.nextBeat();
  assert.equal(f.starts.at(-1), 'assets/voice/dialogue/a.ogg');
  c.SAVE.lang = 'en'; c.Dialogue9.languageChanged('pt');
  assert.equal(f.starts.at(-1), 'assets/voice/dialogue/en/a.ogg', 'a visible comic beat restarts in the newly selected language');
  assert.ok(comic.autoT >= 7.35, 'comic timing must use the English recording duration');
}
console.log('Dialogue channel and language regression checks passed (native and HTMLAudio).');
