# Game regression checks

Run from the repository root with Node.js 20 or newer:

```sh
npm install --no-save --package-lock=false @napi-rs/canvas@0.1.100
node tests/regression.cjs
node tests/campaign.cjs
node tests/progress-gates.cjs
node tests/arena-access.cjs
node tests/story-continuity.cjs
node tests/chains.cjs
node tests/special-render.cjs
node tests/pause-menu.cjs
node tests/dialogue-timing.cjs
node tools/test-languages.cjs
node tools/test-dialogue9.cjs
python3 tools/test_package_update.py
```

The Codex runtime can instead use the installed package through
`CODEX_PRIMARY_RUNTIME_NODE_MODULES`; no install is necessary there.

The suite executes the JavaScript files in the order declared in the real
`index.html`. It uses real image decoding and canvas rendering, a reproducible
random seed, an explicit simulation clock, and in-memory local storage. It is
intended to catch gameplay and input regressions without requiring the Android
SDK. Assertions cover observed outcomes, including releasing a duel after
lethal damage, collecting archives through valid player bounds, and preserving
preferences when campaign progress is reset.

Useful optional environment variables:

- `LUPUS_GAME_ROOT`: test another extracted or built game directory.
- `LUPUS_RENDER_DIR`: write a startup screenshot for every campaign stage.
- `LUPUS_TEST_REPORT`: write a machine-readable JSON result file.
- `LUPUS_CAMPAIGN_REPORT`: write the campaign integration results as JSON.

`campaign.cjs` completes all 16 stages and the epilogue through real game
updates, damage, waves, objectives, boss phases, and scene transitions. Its bot
has unlimited health, repositions between encounters, and accelerates the long
ritual, antidote and elevator timers. It does not call stage completion directly
or clear combat locks. This checks progression; it does not evaluate difficulty,
combat balance or the experience of playing the campaign by hand.

`progress-gates.cjs` checks that combat-door props are removed while wave,
incubator, ritual and duel requirements still control progression and the GO
indicator. Encounters outside a wave must not advance checkpoints or heal the
player. `arena-access.cjs` uses real keyboard movement and ordinary attacks to
reach and damage enemies at both arena edges across different widths and depths,
while the camera and wave remain locked until the fight is complete.

`story-continuity.cjs` checks the restraint, injection, cell and breakout order,
the cell-wall wording, the chronology after the escape, and the actual
first-launch transition into stage one. It also checks that English is the
initial language and that an explicitly saved language is preserved. These
checks complement visual inspection of the chains in the illustrations.

`chains.cjs` verifies that procedural wrist equipment is retired and unloaded,
that the modern special uses the original atlas art with reach 84, and that the
1944 human and appearance use the short stun pulse with reach 70. It also checks
button labels and progression after mandatory boss escape or surrender.

`special-render.cjs` compares 192 renderings with the native sprite reference
across poses, facings, depth and landing scale, plus 36 exits from the special.
It detects accessory pixels and lingering special frames while retaining
ordinary animation crossfades. This is headless canvas verification, not an
Android device test.

`pause-menu.cjs` covers objectives and instructions for all stages, scrolling,
settings, controller input and menu layout at small and large resolutions.
`dialogue-timing.cjs` checks that a long recorded line keeps its subtitle visible
through the recording and pauses its timer cleanly. The language checks cover
saved preferences and the PT/EN voice selection; the Python fixtures cover
applying source-update packages safely.

Audio playback and Android bridges are mocked. These checks do not measure
speaker timing, sound quality, real touch latency, device memory, frame rate,
Bluetooth pairing, or Android lifecycle behavior. Before a release, install the
APK on a phone and exercise multitouch combat, suspend/resume, control editing,
and a paired physical controller. Listen to cutscenes while advancing quickly
and while using automatic progression to verify interruption behavior.

`runtime.cjs` is also reusable for targeted checks. `createRuntime()` exposes
`run`, `json`, `tick`, `play`, `resize`, `dispatch`, `settle`, and `snapshot`.
Pointer events can be dispatched through the canvas listener namespace
(`runtime.dispatch('pointerdown', event, 'canvas:')`). `runtime.gamepads` is the
array returned by the mock `navigator.getGamepads()`.
