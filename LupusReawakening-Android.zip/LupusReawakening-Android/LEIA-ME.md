# LUPUS: REAWAKENING — Projeto Android

Beat 'em up / Action RPG 2D feito em HTML5 Canvas, empacotado num app Android nativo (WebView), 100% offline.
O jogo fica em `app/src/main/assets/game/`, com as artes do pacote #1–#77 já recortadas, alinhadas e convertidas em atlas WebP.

## Gerar o APK — opção 1: Android Studio (mais simples)
1. Instale o Android Studio (Koala ou mais novo).
2. File ▸ Open ▸ selecione esta pasta `LupusReawakening-Android`.
3. Aguarde o Gradle sincronizar (ele baixa o SDK/plugins na primeira vez).
4. Build ▸ Build App Bundle(s) / APK(s) ▸ **Build APK(s)**.
5. O APK sai em `app/build/outputs/apk/debug/app-debug.apk` — copie para o celular e instale
   (habilite "Instalar apps de fontes desconhecidas").

## Gerar o APK — opção 2: linha de comando
Com JDK 17 e o Android SDK instalados (variável `ANDROID_HOME` ou arquivo `local.properties` com `sdk.dir=...`):
```
./gradlew assembleDebug      # APK de teste
./gradlew assembleRelease    # APK "release" (assinado com a chave de debug, para sideload)
```

## Gerar o APK — opção 3: GitHub (sem instalar nada)
1. Crie um repositório no GitHub e envie esta pasta.
2. A aba **Actions** roda o workflow `Build APK` automaticamente.
3. Baixe o APK em Actions ▸ (execução mais recente) ▸ Artifacts ▸ `LupusReawakening-apk`.

## Publicar na Play Store
Troque `signingConfig signingConfigs.debug` em `app/build.gradle` por uma chave própria
(Build ▸ Generate Signed Bundle) e gere um `.aab`.

## Controles
- Analógico virtual (lado esquerdo), ATK, ▲ pular, » esquiva, ESPECIAL, FORMA (só Lupus).
- Segure ATK para combo automático. Esquivar através de um golpe com o Lupus = CONTRA-ATAQUE (+Fúria).
- Teclado (emulador/Chromebook): setas/WASD, J ataque, K pulo, L especial, Espaço esquiva, E forma, P pausa.

## Sistema de transformação (Lupus)
- **Humano**: rápido, combos e Corrente (especial de longo alcance). Acumula Fúria ao bater/apanhar.
- **Feral** (Fúria ≥ 1/3): mais dano, 25% de armadura, regeneração, Urro Sangrento (atordoa em área). Gasta Fúria devagar.
- **Ascendido** (Fúria ≥ 2/3): golpes velozes com sangramento, 50% de armadura, sem recuo,
  Dilaceração (dispara espinhos em área). Consome a Fúria rápido.
