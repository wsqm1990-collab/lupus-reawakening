'use strict';
/* Authored 9.0 dialogue. English is primary; other UI languages fall back to it. */
(function () {
  const lines = {
  "i01a": {
    "speaker": "narrator",
    "en": "1944. A secret war erased from the history books.",
    "pt": "1944. Uma guerra secreta apagada dos livros de história."
  },
  "n05a": {
    "speaker": "nacht",
    "en": "The experiment is not over. Neither am I.",
    "pt": "O experimento não acabou. Nem eu."
  },
  "n05b": {
    "speaker": "nacht",
    "en": "Now... try to stop me.",
    "pt": "Agora... tente me parar."
  }
};
  for (const key in lines) {
    I18N.en.comic[key] = lines[key].en;
    I18N.pt.comic[key] = lines[key].pt;
  }
  window.LUPUS_STORY90_LINES = lines;
})();
