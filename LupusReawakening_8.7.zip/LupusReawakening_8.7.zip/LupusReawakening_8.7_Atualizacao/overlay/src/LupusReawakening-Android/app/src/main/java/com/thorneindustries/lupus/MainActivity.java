package com.thorneindustries.lupus;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.media.MediaPlayer;
import android.hardware.input.InputManager;
import android.os.Handler;
import android.os.Looper;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Lupus: Reawakening — o jogo roda em HTML5 Canvas dentro de um WebView,
 * 100% offline a partir de app/src/main/assets/game/.
 */
public class MainActivity extends Activity implements InputManager.InputDeviceListener {

    private WebView web;
    private NativeAudio audio;
    private InputManager inputs;
    private int controllerId = -1;
    private final boolean[] controllerButtons = new boolean[17];
    private final boolean[] controllerAxisButtons = new boolean[17];
    private float controllerX, controllerY;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setFocusableInTouchMode(true);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);              // salva progresso (localStorage)
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        web.addJavascriptInterface(new Haptics(this), "LupusNative");
        audio = new NativeAudio(this);
        web.addJavascriptInterface(audio, "LupusAudio");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.requestFocus();
        inputs = (InputManager) getSystemService(Context.INPUT_SERVICE);
        if (inputs != null) inputs.registerInputDeviceListener(this, null);
        hideSystemUi();
        web.loadUrl("file:///android_asset/game/index.html");
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            clearController();
            web.evaluateJavascript("window.dispatchEvent(new Event('lupus:pause'));if(typeof Scene!=='undefined'&&Scene.cur&&Scene.cur.onKey)Scene.cur.onKey('hide')", null);
            web.onPause();
        }
        if (audio != null) audio.pauseAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        if (audio != null) audio.resumeAll();
        hideSystemUi();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.androidBack ? window.androidBack() : 'exit'", value -> {
            if (value != null && value.contains("exit")) finish();
        });
    }

    @Override
    protected void onDestroy() {
        if (inputs != null) inputs.unregisterInputDeviceListener(this);
        if (web != null) { web.destroy(); web = null; }
        if (audio != null) { audio.release(); audio = null; }
        super.onDestroy();
    }

    private boolean isController(int source) {
        return (source & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                || (source & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK;
    }

    private int buttonIndex(int key) {
        switch (key) {
            case KeyEvent.KEYCODE_BUTTON_A: return 0;
            case KeyEvent.KEYCODE_BUTTON_B: return 1;
            case KeyEvent.KEYCODE_BUTTON_X: return 2;
            case KeyEvent.KEYCODE_BUTTON_Y: return 3;
            case KeyEvent.KEYCODE_BUTTON_L1: return 4;
            case KeyEvent.KEYCODE_BUTTON_R1: return 5;
            case KeyEvent.KEYCODE_BUTTON_L2: return 6;
            case KeyEvent.KEYCODE_BUTTON_R2: return 7;
            case KeyEvent.KEYCODE_BUTTON_SELECT:
            case KeyEvent.KEYCODE_BACK: return 8;
            case KeyEvent.KEYCODE_BUTTON_START: return 9;
            case KeyEvent.KEYCODE_BUTTON_THUMBL: return 10;
            case KeyEvent.KEYCODE_BUTTON_THUMBR: return 11;
            case KeyEvent.KEYCODE_DPAD_UP: return 12;
            case KeyEvent.KEYCODE_DPAD_DOWN: return 13;
            case KeyEvent.KEYCODE_DPAD_LEFT: return 14;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return 15;
            case KeyEvent.KEYCODE_BUTTON_MODE: return 16;
            default: return -1;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        InputDevice device = event.getDevice();
        if (isController(event.getSource()) || (device != null && isController(device.getSources()))) {
            int index = buttonIndex(event.getKeyCode());
            if (index >= 0 && (event.getAction() == KeyEvent.ACTION_DOWN || event.getAction() == KeyEvent.ACTION_UP)) {
                if (event.getRepeatCount() == 0) {
                    selectController(event.getDeviceId());
                    controllerButtons[index] = event.getAction() == KeyEvent.ACTION_DOWN;
                    sendController(true);
                }
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private float axis(MotionEvent event, int axis) {
        InputDevice device = event.getDevice();
        InputDevice.MotionRange range = device == null ? null : device.getMotionRange(axis, event.getSource());
        float value = event.getAxisValue(axis);
        float deadZone = range == null ? 0.15f : Math.max(0.15f, range.getFlat());
        return Math.abs(value) > deadZone ? Math.max(-1f, Math.min(1f, value)) : 0f;
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if (isController(event.getSource()) && event.getAction() == MotionEvent.ACTION_MOVE) {
            selectController(event.getDeviceId());
            controllerX = axis(event, MotionEvent.AXIS_X);
            controllerY = axis(event, MotionEvent.AXIS_Y);
            float hatX = axis(event, MotionEvent.AXIS_HAT_X), hatY = axis(event, MotionEvent.AXIS_HAT_Y);
            controllerAxisButtons[12] = hatY < -0.5f;
            controllerAxisButtons[13] = hatY > 0.5f;
            controllerAxisButtons[14] = hatX < -0.5f;
            controllerAxisButtons[15] = hatX > 0.5f;
            controllerAxisButtons[6] = Math.max(event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_BRAKE)) > 0.5f;
            controllerAxisButtons[7] = Math.max(event.getAxisValue(MotionEvent.AXIS_RTRIGGER), event.getAxisValue(MotionEvent.AXIS_GAS)) > 0.5f;
            sendController(true);
            return true;
        }
        return super.dispatchGenericMotionEvent(event);
    }

    private void sendController(boolean connected) {
        if (web == null) return;
        InputDevice device = InputDevice.getDevice(controllerId);
        String name = device == null ? "Controle Android" : device.getName();
        StringBuilder buttons = new StringBuilder("[");
        for (int i = 0; i < controllerButtons.length; i++) {
            if (i > 0) buttons.append(',');
            buttons.append(controllerButtons[i] || controllerAxisButtons[i]);
        }
        buttons.append(']');
        String state = "{connected:" + connected + ",id:" + JSONObject.quote(name)
                + ",axes:[" + controllerX + "," + controllerY + "],buttons:" + buttons + "}";
        web.evaluateJavascript("window.LupusGamepad&&window.LupusGamepad.update(" + state + ")", null);
    }

    private void clearController() {
        java.util.Arrays.fill(controllerButtons, false);
        java.util.Arrays.fill(controllerAxisButtons, false);
        controllerX = controllerY = 0;
        sendController(false);
        controllerId = -1;
    }

    private void selectController(int id) {
        if (controllerId != id) {
            java.util.Arrays.fill(controllerButtons, false);
            java.util.Arrays.fill(controllerAxisButtons, false);
            controllerX = controllerY = 0;
            controllerId = id;
        }
    }

    @Override public void onInputDeviceAdded(int id) { }
    @Override public void onInputDeviceChanged(int id) { }
    @Override public void onInputDeviceRemoved(int id) { if (id == controllerId) clearController(); }

    /**
     * Efeitos e vinhetas curtos usam SoundPool de baixa latência. Vozes usam um
     * MediaPlayer exclusivo, com interrupção e estado de reprodução consultável.
     * Se um efeito ainda não carregou, play() devolve false para o fallback WebView.
     */
    static class NativeAudio {
        private final SoundPool pool;
        private final AssetManager assets;
        private final Map<String, Integer> ids = new HashMap<>();
        private final Set<Integer> ready = new HashSet<>();
        private final Handler main = new Handler(Looper.getMainLooper());
        private MediaPlayer voice;
        private volatile int voiceGeneration;
        private volatile boolean released;
        private volatile boolean voiceActive;
        private boolean voicePaused;

        NativeAudio(Context c) {
            assets = c.getAssets();
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            pool = new SoundPool.Builder().setMaxStreams(16).setAudioAttributes(aa).build();
            pool.setOnLoadCompleteListener((sp, id, status) -> { if (status == 0) synchronized (ready) { ready.add(id); } });
        }

        @JavascriptInterface
        public void preload(String csv) {
            if (csv == null || released) return;
            for (String p : csv.split(",")) {
                p = p.trim();
                if (!validAsset(p) || p.startsWith("assets/voice/")) continue;
                synchronized (ids) { if (ids.containsKey(p)) continue; }
                int id = -1;
                try (AssetFileDescriptor fd = assets.openFd("game/" + p)) { id = pool.load(fd, 1); } catch (Exception e) { id = -1; }
                synchronized (ids) { ids.put(p, id); }
            }
        }

        @JavascriptInterface
        public boolean play(String p, float vol, float rate) {
            if (!validAsset(p) || released) return false;
            if (p.startsWith("assets/voice/")) return playVoice(p, vol);
            Integer id;
            synchronized (ids) { id = ids.get(p); }
            if (id == null) { preload(p); return false; }
            if (id < 0) return false;
            synchronized (ready) { if (!ready.contains(id)) return false; }
            vol = Math.max(0f, Math.min(1f, vol));
            rate = Math.max(0.5f, Math.min(2f, rate));
            return pool.play(id, vol, vol, 1, 0, rate) != 0;
        }

        private boolean validAsset(String path) {
            return path != null && path.startsWith("assets/") && !path.contains("..") && !path.contains("\\");
        }

        /** One interruptible speech channel; MediaPlayer also supports long narration. */
        @JavascriptInterface
        public synchronized boolean playVoice(String path, float volume) {
            if (!validAsset(path) || released) return false;
            final AssetFileDescriptor fd;
            try { fd = assets.openFd("game/" + path); } catch (Exception e) { return false; }
            final float gain = Math.max(0f, Math.min(1f, volume));
            final int generation = ++voiceGeneration;
            voiceActive = true;
            main.post(() -> {
                if (released || generation != voiceGeneration) { try { fd.close(); } catch (Exception ignored) { } return; }
                releaseVoice();
                voiceActive = true;
                voicePaused = false;
                try {
                    MediaPlayer player = new MediaPlayer();
                    voice = player;
                    player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                    player.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
                    fd.close();
                    player.setVolume(gain, gain);
                    player.setOnPreparedListener(mp -> {
                        if (!released && !voicePaused && generation == voiceGeneration && voice == mp) mp.start();
                    });
                    player.setOnCompletionListener(mp -> {
                        if (voice == mp) { if (generation == voiceGeneration) voiceActive = false; releaseVoice(); }
                    });
                    player.setOnErrorListener((mp, what, extra) -> {
                        if (voice == mp) { if (generation == voiceGeneration) voiceActive = false; releaseVoice(); }
                        return true;
                    });
                    player.prepareAsync();
                } catch (Exception e) {
                    try { fd.close(); } catch (Exception ignored) { }
                    if (generation == voiceGeneration) voiceActive = false;
                    releaseVoice();
                }
            });
            return true;
        }

        @JavascriptInterface
        public synchronized void stopVoices() {
            ++voiceGeneration;
            voiceActive = false;
            main.post(this::releaseVoice);
        }

        @JavascriptInterface
        public boolean isVoicePlaying() { return voiceActive; }

        @JavascriptInterface
        public void pauseVoices() {
            main.post(() -> {
                voicePaused = true;
                try { if (voice != null && voice.isPlaying()) voice.pause(); } catch (IllegalStateException ignored) { }
            });
        }

        @JavascriptInterface
        public void resumeVoices() {
            main.post(() -> {
                voicePaused = false;
                try { if (voice != null && voiceActive) voice.start(); } catch (IllegalStateException ignored) { }
            });
        }

        private void releaseVoice() {
            if (voice != null) {
                voice.setOnPreparedListener(null);
                voice.setOnCompletionListener(null);
                voice.setOnErrorListener(null);
                voice.release();
                voice = null;
            }
        }

        @JavascriptInterface
        public void unload(String csv) {
            if (csv == null) return;
            for (String p : csv.split(",")) {
                Integer id;
                synchronized (ids) { id = ids.remove(p.trim()); }
                if (id != null && id >= 0) { pool.unload(id); synchronized (ready) { ready.remove(id); } }
            }
        }

        void pauseAll() { stopVoices(); pool.autoPause(); }
        void resumeAll() { pool.autoResume(); }
        void release() { released = true; stopVoices(); pool.release(); }
    }

    /** vibração chamada pelo jogo: window.LupusNative.vibrate(ms, força 1-255) */
    static class Haptics {
        private final Vibrator vib;
        Haptics(Context c) { vib = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE); }
        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public void vibrate(int ms, int amp) {
            if (vib == null || !vib.hasVibrator()) return;
            ms = Math.max(5, Math.min(ms, 600)); amp = Math.max(1, Math.min(amp, 255));
            if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createOneShot(ms, amp));
            else vib.vibrate(ms);
        }
    }
}
