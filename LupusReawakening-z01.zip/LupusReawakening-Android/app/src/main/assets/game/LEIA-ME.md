# CYBERCLAWS 9.5

Jogo de ação offline em HTML5 Canvas, incluído no aplicativo Android CyberClaws.
O herói é John Thorne. Inglês é o idioma principal; português brasileiro e outros
dez idiomas podem ser escolhidos nas opções.

Esta pasta contém o jogo e todos os recursos utilizados. Para compilar o Android,
abra `src/LupusReawakening-Android` (veja o LEIA-ME de lá).

O APK usa o ID `com.thorneindustries.lupus.preview`, o mesmo desde a 9.0, então a
9.5 instala por cima das versões anteriores e mantém o progresso.

## Jogar

- Movimento: analógico virtual, setas/WASD ou controle compatível.
- Ataque: segure para encadear golpes; use salto, esquiva, defesa e especial.
- Troca de parceiro e transformação: toque nos retratos no alto da tela (ou ative
  os botões TROCA e FORMA em Controles).
- Duelos: bloqueie no impacto para abrir um contra-ataque, salte golpes baixos
  e esquive ataques que quebram a guarda. As instruções completas ficam na pausa.
- O preset Arcade é opcional e pode ser escolhido nas opções de controles.

As HQs, vozes e efeitos estão incluídos no APK e funcionam sem conexão.
