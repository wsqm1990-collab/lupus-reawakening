'use strict';
/* Three authored, optional field investigations. Every room owns its input,
 * camera, dialogue and clock; returning restores the exact parked street. */
(function () {
  const tr = (pt,en) => Q90.t(pt,en);
  const box = () => ({ x: (VW - 480) / 2, y: 0, w: 480, h: 270 });
  const clampN = (v,a,b,d=a) => Number.isFinite(+v) ? clamp(+v,a,b) : d;
  const clone = o => JSON.parse(JSON.stringify(o));
  // The authored sheet has deliberately varied strides and uneven gutters.
  // Crop each complete pose, rather than leaking the neighbouring row through
  // a guessed grid, and keep its feet and body height stable during the loop.
  const JOHN_FRAMES = [[141,38,141,269],[410,41,134,270],[691,38,144,274],[995,42,142,270],[140,330,146,269],[405,330,140,274],[692,330,150,274],[994,331,156,269],[116,637,177,266],[391,638,189,266],[672,637,196,265],[978,638,189,265],[111,929,186,267],[382,931,183,262],[666,930,196,263],[978,928,181,268]];
  const DOOR_FRAMES = [[49,248,519,586],[613,269,551,536],[1222,72,516,737]];
  const names = { lupus_h: () => 'JOHN THORNE', informant: () => tr('TESTEMUNHA', 'WITNESS') };
  let touch = { joy: null, ax: 0, ay: 0, action: false }, prior = {}, navDirection = '', navTimer = 0;
  const actionRect = () => ({ x: VW-126,y:VH-48,w:110,h:32 });
  const pauseRect = () => ({ x:VW-42,y:9,w:30,h:28 });
  function inside(b,x,y) { if(!b)return false;const d=Math.max(0,(48/Math.max(.5,SCALE)-b.h)/2);return !!b&&x>=b.x-d&&x<=b.x+b.w+d&&y>=b.y-d&&y<=b.y+b.h+d; }
  const joyPos = () => ({ x: 56, y: VH-48, r: 27 });
  const input = window.RoomInput90 = {
    reset() { touch={joy:null,ax:0,ay:0,action:false};const h=window.ControlsUI?ControlsUI.state().held||{}:{};prior={act:!!(h.atk||h.jump||h.spec),back:!!h.dash,scan:!!h.sense};navDirection='';navTimer=0;Inp.reset(); },
    down(id,x,y) { const a=actionRect();if(inside(a,x,y)){touch.action=true;return;}if(x<VW*.45&&y>55&&touch.joy==null){touch.joy={id,ox:x,oy:y,x,y};touch.ax=touch.ay=0;} },
    move(id,x,y) { const j=touch.joy;if(!j||j.id!==id)return;let dx=x-j.ox,dy=y-j.oy,d=Math.hypot(dx,dy);if(d>27){dx=dx/d*27;dy=dy/d*27;}j.x=j.ox+dx;j.y=j.oy+dy;touch.ax=dx/27;touch.ay=dy/27; },
    up(id) { if(touch.joy&&touch.joy.id===id){touch.joy=null;touch.ax=touch.ay=0;} },
    sample(dt) {
      const s=window.ControlsUI?ControlsUI.state():{held:{},axes:[0,0]}, h=s.held||{}, k=Inp.keys||{}, e=Inp.edge||{};
      let x=(k.r?1:0)-(k.l?1:0),y=(k.d?1:0)-(k.u?1:0);
      if(touch.joy){x=touch.ax;y=touch.ay;}else if(!x&&!y&&s.input==='pad'){x=s.axes[0]||0;y=s.axes[1]||0;}
      const mag=Math.hypot(x,y);if(mag<.15)x=y=0;else if(mag>1){x/=mag;y/=mag;}
      const actHeld=!!(h.atk||h.jump||h.spec),backHeld=!!h.dash,scanHeld=!!h.sense;
      const act=touch.action||!!(e.atk||e.jump||e.spec)||actHeld&&!prior.act;
      const back=backHeld&&!prior.back,scan=!!e.sense||scanHeld&&!prior.scan;
      prior={act:actHeld,back:backHeld,scan:scanHeld};touch.action=false;Inp.edge={};
      const d=Math.abs(x)>Math.abs(y)?x>.55?'r':x<-.55?'l':'':y>.55?'d':y<-.55?'u':'';
      if(d!==navDirection){navDirection=d;navTimer=0;}navTimer-=dt;
      let navX=0,navY=0;if(d&&navTimer<=0){if(d==='r')navX=1;if(d==='l')navX=-1;if(d==='d')navY=1;if(d==='u')navY=-1;navTimer=.22;}
      return {x,y,act,back,scan,navX,navY,pad:s.input==='pad'&&s.connected};
    },
    state:()=>touch
  };

  function round(c,x,y,w,h,r=5){c.beginPath();c.moveTo(x+r,y);c.lineTo(x+w-r,y);c.quadraticCurveTo(x+w,y,x+w,y+r);c.lineTo(x+w,y+h-r);c.quadraticCurveTo(x+w,y+h,x+w-r,y+h);c.lineTo(x+r,y+h);c.quadraticCurveTo(x,y+h,x,y+h-r);c.lineTo(x,y+r);c.quadraticCurveTo(x,y,x+r,y);c.closePath();}
  function wrap(c,text,width) { const out=[];for(const p of String(text||'').split('\n')){let line='';for(const word of p.split(/\s+/)){const n=line?line+' '+word:word;if(line&&c.measureText(n).width>width){out.push(line);line=word;}else line=n;}out.push(line);}return out; }
  const U = window.RoomUI90 = {
    mapBox:box,inside,
    begin(c){c.save();c.setTransform(SCALE,0,0,SCALE,OX,OY);c.imageSmoothingEnabled=false;c.textBaseline='top';},end(c){c.restore();},
    text(c,s,x,y,w,size=9,color='#eaf4ff',max=20){c.font='600 '+size+'px system-ui,-apple-system,Segoe UI,Roboto,sans-serif';c.fillStyle=color;c.textAlign='left';const ls=wrap(c,s,w);ls.slice(0,max).forEach((l,i)=>c.fillText(l,x,y+i*(size+3)));return ls.length*(size+3);},
    button(c,b,selected){round(c,b.x,b.y,b.w,b.h,5);c.fillStyle=b.disabled?'rgba(20,25,36,.93)':selected?'rgba(36,75,82,.97)':'rgba(14,30,46,.96)';c.fill();c.strokeStyle=b.disabled?'#40525f':selected?'#fff1b3':'#59ddcf';c.lineWidth=selected?1.8:1;c.stroke();c.font='800 '+(b.font||8.2)+'px system-ui,-apple-system,Segoe UI,Roboto,sans-serif';c.fillStyle=b.disabled?'#79909d':'#eaf7ff';c.textBaseline='middle';c.textAlign='center';let label=String(b.label||'');while(label.length>8&&c.measureText(label).width>b.w-16)label=label.slice(0,-2);if(label!==b.label)label+='…';c.fillText(label,b.x+b.w/2,b.y+b.h/2);c.textBaseline='top';},
    header(c,title,sub){round(c,12,9,Math.min(298,VW-66),37,6);c.fillStyle='rgba(3,10,21,.91)';c.fill();U.text(c,title,21,15,Math.min(278,VW-86),9.8,'#76f0d7',1);if(sub)U.text(c,sub,21,29,Math.min(278,VW-86),7,'#c2d5e4',1);},
    pauseHit(x,y){return inside(pauseRect(),x,y);},
    pauseButton(c){const b=pauseRect();U.button(c,Object.assign({label:''},b),false);c.fillStyle='#eaf7ff';c.fillRect(b.x+10,b.y+8,3,12);c.fillRect(b.x+17,b.y+8,3,12);},
    modal(c,title){c.fillStyle='rgba(1,5,12,.83)';c.fillRect(0,0,VW,VH);round(c,30,33,VW-60,225,8);c.fillStyle='#091423';c.fill();c.strokeStyle='#5be4cc';c.lineWidth=1.2;c.stroke();U.text(c,title,44,41,VW-88,10,'#8af6dc',1);},
    toast(c,text){const w=Math.min(VW-48,370);round(c,VW/2-w/2,58,w,40,6);c.fillStyle='rgba(8,22,38,.97)';c.fill();c.strokeStyle='#ffdd83';c.stroke();U.text(c,text,VW/2-w/2+10,66,w-20,8.7,'#f4edcc',2);},
    controls(c,label){const st=window.ControlsUI?ControlsUI.state():{input:'touch'};if(st.input!=='pad'){
      const j=joyPos(),s=touch.joy,x=s?s.ox:j.x,y=s?s.oy:j.y;c.save();c.globalAlpha=.68;c.beginPath();c.arc(x,y,j.r,0,7);c.fillStyle='#071528';c.fill();c.strokeStyle='#87e9db';c.lineWidth=1.4;c.stroke();c.beginPath();c.arc(s?s.x:x,s?s.y:y,11,0,7);c.fillStyle='#4a8d94';c.fill();c.stroke();c.restore();
      U.button(c,Object.assign({label:label||tr('INTERAGIR','INTERACT')},actionRect()),false);
    }else U.text(c,'X / A  '+(label||tr('INTERAGIR','INTERACT'))+'     B  '+tr('VOLTAR','BACK'),VW/2-140,VH-25,280,8,'#e9f5ed',1);},
    marker(g,x,y,color,t,near){g.save();g.globalAlpha=near?.85:.38;g.strokeStyle=color;g.lineWidth=near?1.8:1;g.beginPath();g.ellipse(x,y,near?17:12,near?6:4,0,0,7);g.stroke();if(near){g.fillStyle=color;g.beginPath();g.moveTo(x-3,y-13-Math.sin(t*4));g.lineTo(x+3,y-13-Math.sin(t*4));g.lineTo(x,y-9-Math.sin(t*4));g.fill();}g.restore();},
    actor(g,x,y,dir,walk){g.save();g.fillStyle='rgba(0,0,0,.5)';g.beginPath();g.ellipse(x,y+1,11,4,0,0,7);g.fill();const fr=dir*4+(walk>0?Math.floor(walk)%4:0),im=Q90.image('rpg_john'),a=JOHN_FRAMES[fr];if(im&&im.ok&&a){const h=47,w=h*a[2]/a[3];g.drawImage(im,a[0],a[1],a[2],a[3],x-w/2,y-h,w,h);}g.restore();},
    duration(key){const lines=window.Dialogue9&&Dialogue9.lines||{};const line=lines[key];return Math.max(1.1,line&&+line.duration||String(CT(key)||'').length*.046);},
    speak(key){if(window.Dialogue9)Dialogue9.play(key,'room90:'+key);},
    dialog(c,d,choices){const body=CT(d.key)||d.text||'';const height=choices&&choices.length?123:100,y=VH-height-12;round(c,24,y,VW-48,height,8);c.fillStyle='rgba(5,12,25,.97)';c.fill();c.strokeStyle='#e6bd65';c.lineWidth=1.3;c.stroke();const sp=window.LUPUS_STORY90_LINES&&LUPUS_STORY90_LINES[d.key];U.text(c,sp&&names[sp.speaker]?names[sp.speaker]():tr('INVESTIGAÇÃO','INVESTIGATION'),36,y+9,VW-72,8.3,'#ffda83',1);U.text(c,body,36,y+25,VW-72,9,'#f1f4ef',4);if(!choices||!choices.length)U.text(c,tr('TOQUE / ENTER / A PARA CONTINUAR','TAP / ENTER / A TO CONTINUE'),36,VH-32,VW-72,7.3,'#8eebcc',1);},
    loading(c,keys){const bad=keys.some(k=>Q90.art[k]&&Q90.art[k].bad);U.modal(c,bad?tr('ARTE INDISPONÍVEL','ART UNAVAILABLE'):tr('CARREGANDO LOCAL','LOADING LOCATION'));U.text(c,bad?tr('O arquivo deste local não pôde ser aberto. Volte e tente novamente.','This location could not be loaded. Return and try again.'):tr('Preparando o cenário e os personagens…','Preparing the location and characters…'),55,100,VW-110,10,'#e5edf5',4);U.button(c,{id:'cancelLoad',x:VW/2-80,y:192,w:160,h:30,label:tr('VOLTAR','RETURN')},false);}
  };

  const POINTS = {
    alley:[{id:'blood',x:135,y:180,label:()=>tr('EXAMINAR SANGUE','EXAMINE BLOOD')},{id:'witness',x:340,y:125,label:()=>tr('OUVIR TESTEMUNHA','HEAR WITNESS')},{id:'case',x:240,y:125,label:()=>tr('EXAMINAR MALETA','EXAMINE CASE')},{id:'exit',x:240,y:246,label:()=>tr('VOLTAR','RETURN')}],
    cistern:[{id:'plate',x:343,y:82,label:()=>tr('LER PLACA','READ PLATE')},{id:'valve0',x:136,y:148,label:()=>tr('VÁLVULA ESQUERDA','LEFT VALVE')},{id:'valve1',x:240,y:123,label:()=>tr('VÁLVULA CENTRAL','CENTRE VALVE')},{id:'valve2',x:343,y:148,label:()=>tr('VÁLVULA DIREITA','RIGHT VALVE')},{id:'exit',x:240,y:246,label:()=>tr('VOLTAR','RETURN')}],
    relay:[{id:'record',x:120,y:132,label:()=>tr('OUVIR GRAVAÇÃO','HEAR RECORDING')},{id:'tune',x:240,y:95,label:()=>tr('ALINHAR SINAL','ALIGN SIGNAL')},{id:'archive',x:370,y:146,label:()=>tr('RECUPERAR ARQUIVO','RECOVER FILE')},{id:'exit',x:240,y:246,label:()=>tr('VOLTAR','RETURN')}]
  };
  function canStreet() {
    return Scene.name==='play'&&G&&!Scenes.play.menu&&!G.mode&&!G.st.l44&&!G.locked&&enemiesAlive()===0&&!(G.spawnQ&&G.spawnQ.length)&&!G.bossPending&&!G.bossSpawned&&!G.over&&!G.clearT&&!G.panel&&!G.choice&&!G.cine&&!G.superFx&&!G.vesperaBeat&&!G.nachtBeat90&&G.player&&!G.player.dead&&G.player.z<1&&['idle','walk','guard'].includes(G.player.st)&&G.title<=.3;
  }
  function stageRoom(){return World90.roomDefs().find(d=>G&&d.stage===G.stage&&World90.canEnter(d.id));}
  function doorNear(){const d=stageRoom();return canStreet()&&d&&Math.abs(G.player.x-d.x)<65&&Math.abs(G.player.y-d.y)<42?d:null;}
  function humanReady(){return G.player.id==='lupus'&&G.player.form==='h';}
  function entryHelp(){return G.player.id!=='lupus'?tr('TROQUE PARA LUPUS PARA INVESTIGAR','SWAP TO LUPUS TO INVESTIGATE'):tr('VOLTE À FORMA HUMANA PARA INVESTIGAR','RETURN TO HUMAN FORM TO INVESTIGATE');}
  function open(id,options={}) {
    const d=World90.room(id);if(!d||!World90.canEnter(id)||Scene.name==='investigation90')return false;
    if(Scene.name==='play'&&(!canStreet()||!humanReady()))return false;
    const origin=World90.capture();
    if(origin.name==='play'){World90.checkpoint();if(G.talkQ&&G.talkQ[0]){G.talkQ[0]._speechStarted=false;G.talkQ[0].t=0;}}
    World90.ensure().rooms[id].visited=true;saveGame();
    Scene.go('investigation90',{id,origin,source:options.source||origin.name});return true;
  }
  function close() {
    const s=Scenes.investigation90;if(Scene.name!=='investigation90')return false;
    s.save();const origin=s.origin;if(window.Dialogue9)Dialogue9.stop();World90.restore(origin);return true;
  }
  window.Investigation90 = { open,close,canStreet,doorNear,state:()=>Scene.name==='investigation90'?Scenes.investigation90.snapshot():null,points:id=>POINTS[id]||[] };
  Scenes.investigation90 = {
    freeInput90:true, btns:[], paused:false, dialog:null, modal:null, focus:0,
    enter(o) {
      this.id=o.id;this.origin=o.origin;this.source=o.source;this.d=World90.room(this.id);this.t=0;this.walk=0;this.dir=1;this.x=240;this.y=195;this.paused=false;this.dialog=null;this.queue=[];this.modal=null;this.focus=0;this.toast='';this.toastT=0;this.scan=0;
      const state=World90.ensure().rooms[this.id],p=state.progress||{};
      this.progress={introSeen:!!p.introSeen,blood:!!p.blood,witness:!!p.witness,witnessChoice:['protect','press'].includes(p.witnessChoice)?p.witnessChoice:'',caseOpened:!!p.caseOpened,plate:!!p.plate,valves:Array.isArray(p.valves)?p.valves.filter(n=>[0,1,2].includes(n)).slice(0,3):[],drained:!!p.drained,recorded:!!p.recorded,frequency:clampN(p.frequency,0,6,0)|0,aligned:!!p.aligned};
      this.complete=!!state.completed;
      if(p.position){this.x=clampN(p.position.x,45,435,240);this.y=clampN(p.position.y,75,246,195);this.dir=clampN(p.position.dir,0,3,1)|0;}
      if(this.collide(this.x,this.y)){this.x=240;this.y=195;}
      World90.releaseRoomArt([this.d.art,this.origin&&this.origin.name==='world90'?'hub':'']);Q90.image(this.d.art);Q90.image('rpg_john');input.reset();
      if(!this.progress.introSeen)this.show('w90_'+this.id+'_entry');
      this.save();
    },
    save(){if(!this.id)return;this.progress.position={x:this.x,y:this.y,dir:this.dir};World90.updateRoom(this.id,this.progress);},
    snapshot(){return {id:this.id,x:this.x,y:this.y,dir:this.dir,paused:this.paused,complete:this.complete,progress:clone(this.progress),dialog:this.dialog?{key:this.dialog.key,choices:(this.dialog.choices||[]).map(c=>c.id),t:this.dialog.t}:null,modal:this.modal,focus:this.focus,origin:this.origin&&this.origin.name};},
    show(key,choices,then){const d={key,choices:choices||[],then:then||null,t:0,started:false};if(this.dialog)this.queue.push(d);else{this.dialog=d;this.focus=0;}input.reset();},
    advance(choice) {
      const d=this.dialog;if(!d||d.t<.25)return;
      if(d.choices.length){const ch=d.choices.find(v=>v.id===choice)||d.choices[this.focus];if(!ch)return;if(ch.run)ch.run();}
      if(window.Dialogue9)Dialogue9.stop();
      this.dialog=this.queue.shift()||null;this.focus=0;if(d.then)d.then();input.reset();
    },
    notice(text){this.toast=text;this.toastT=3.5;sfx('ui');},
    finish(outcome,key) {
      const result=World90.completeRoom(this.id,outcome,this.origin&&this.origin.name==='play'?this.origin.game:null);this.complete=true;this.save();
      if(result.fresh){this.reward=result;this.show(key,null,()=>{this.modal='complete';this.focus=0;});sfx('pick');}
      else this.notice(tr('Este caso já foi concluído. A recompensa foi preservada.','This case is already complete. Its reward is preserved.'));
    },
    nearest(){let best=null,d=43;for(const p of POINTS[this.id]||[]){const n=Math.hypot(this.x-p.x,this.y-p.y);if(n<d){d=n;best=p;}}return best;},
    collide(x,y){if(x<45||x>435||y<75||y>247)return true;
      if(y>233&&(x<198||x>282))return true;
      if(this.id==='alley'&&((x<73&&y>143&&y<226)||(x>401&&y>119&&y<227)))return true;
      if(this.id==='cistern'&&y>94&&y<226&&(x<96||x>384))return true;
      if(this.id==='relay'){const rs=[{x:88,y:79,w:54,h:51},{x:334,y:98,w:83,h:48},{x:209,y:61,w:64,h:31}];if(rs.some(o=>x+8>o.x&&x-8<o.x+o.w&&y+4>o.y&&y-4<o.y+o.h))return true;}
      for(const p of POINTS[this.id]){if(p.id==='exit'||p.id==='blood'||p.id==='plate')continue;const r=p.id==='witness'?11:this.id==='cistern'?23:15;if(Math.hypot(x-p.x,y-p.y)<r)return true;}return false;},
    interact(point) {
      const id=typeof point==='string'?point:point&&point.id,p=this.progress;if(!id)return;
      if(id==='exit'){if(this.complete&&this.origin&&this.origin.name==='play'){this.modal='exitRoutes';this.focus=0;input.reset();}else close();return;}
      if(this.complete){this.notice(tr('Caso concluído. Consulte a prova no diário do refúgio.','Case complete. Review the evidence at the refuge.'));return;}
      this.scan=.8;
      if(this.id==='alley'){
        if(id==='blood'){p.blood=true;this.save();this.show('w90_alley_blood');}
        if(id==='witness')this.show('w90_alley_witness',[
          {id:'protect',label:tr('PROTEGER TESTEMUNHA • PISTA DE MANUTENÇÃO','PROTECT WITNESS • MAINTENANCE HINT'),run:()=>{p.witness=true;p.witnessChoice='protect';this.save();}},
          {id:'press',label:tr('ARQUIVAR DEPOIMENTO • +2 FRAGMENTOS','FILE STATEMENT • +2 SHARDS'),run:()=>{p.witness=true;p.witnessChoice='press';this.save();}}
        ]);
        if(id==='case'){
          if(!p.blood||!p.witness){this.notice(tr('Cruze o sangue com o depoimento antes de concluir.','Compare the blood and the witness before concluding.'));return;}
          this.show('w90_alley_case',[
            {id:'courier',label:tr('SEGUIR O MENSAGEIRO DA CABALA','FOLLOW THE CABALA COURIER'),run:()=>{p.caseOpened=true;this.save();this.finish(p.witnessChoice==='protect'?'witness-protected':'statement-recorded','w90_alley_done');}},
            {id:'random',label:tr('ENCERRAR COMO ATAQUES ALEATÓRIOS','CLOSE AS RANDOM ATTACKS'),run:()=>this.notice(tr('O selo e o mercúrio ligam as mortes à mesma rota.','The seal and mercury connect the deaths to one route.'))}
          ]);
        }
      } else if(this.id==='cistern') {
        if(id==='plate'){p.plate=true;this.save();this.show('w90_cistern_hint',null,()=>{this.modal='plate';this.focus=0;});}
        else if(id.startsWith('valve')){
          const v=+id.slice(5),order=[0,2,1],n=p.valves.length;
          if(v===order[n]){p.valves.push(v);sfx('ok');this.notice(tr('PRESSÃO ESTÁVEL • ','PRESSURE STABLE • ')+p.valves.length+'/3');if(p.valves.length===3){p.drained=true;this.save();this.finish('conduit-drained','w90_cistern_done');}}
          else{p.valves=[];this.notice(tr('PRESSÃO INSTÁVEL. Consulte a placa: ESQUERDA → DIREITA → CENTRO.','PRESSURE UNSTABLE. Check the plate: LEFT → RIGHT → CENTRE.'));}
          this.save();
        }
      } else if(this.id==='relay') {
        if(id==='record'){p.recorded=true;this.save();this.show('w90_relay_hint',null,()=>{this.modal='pulse';this.focus=0;});}
        if(id==='tune'){
          if(!p.recorded){this.notice(tr('Ouça a gravação no terminal antes de alinhar o sinal.','Hear the recording at the terminal before aligning the signal.'));return;}
          this.modal='tuner';this.focus=2;input.reset();
        }
        if(id==='archive'){
          if(!p.aligned){this.notice(tr('O arquivo está cifrado. Alinhe a transmissão primeiro.','The file is encrypted. Align the transmission first.'));return;}
          this.finish('signal-masked','w90_relay_done');
        }
      }
    },
    layout() {
      const x=VW/2-166,list=[];
      const add=(id,label,y,w=332,xx=x)=>list.push({id,label,x:xx,y,w,h:27});
      if(this.paused){add('resume',tr('CONTINUAR','RESUME'),76);add('exit',tr('SAIR • PROGRESSO DO CASO SERÁ GUARDADO','LEAVE • CASE PROGRESS WILL BE KEPT'),111);add('refuge',tr('IR AO REFÚGIO','GO TO REFUGE'),146);}
      else if(this.dialog&&this.dialog.choices.length){const y=VH-67;this.dialog.choices.forEach((ch,i)=>add('choice:'+ch.id,ch.label,y+i*30));}
      else if(this.modal==='complete'){add('exit',tr('VOLTAR À ORIGEM','RETURN TO ORIGIN'),154);add('keep',tr('CONTINUAR EXPLORANDO','KEEP EXPLORING'),190);}
      else if(this.modal==='exitRoutes'){add('exit',tr('VOLTAR À RUA','RETURN TO STREET'),115);add('refuge',tr('PASSAGEM LIBERADA • REFÚGIO','OPEN PASSAGE • REFUGE'),153);add('keep',tr('CONTINUAR EXPLORANDO','KEEP EXPLORING'),191);}
      else if(this.modal==='tuner'){add('minus','−',151,54,VW/2-92);add('plus','+',151,54,VW/2+38);add('lock',tr('CONFIRMAR SINAL','LOCK SIGNAL'),190);add('close',tr('VOLTAR','BACK'),225);}
      else if(this.modal)add('close',tr('CONTINUAR','CONTINUE'),216);
      this.btns=list;this.focus=clamp(this.focus,0,Math.max(0,list.length-1));return list;
    },
    choose(b) {
      if(!b)return;const id=b.id;
      if(id.startsWith('choice:')){this.advance(id.slice(7));return;}
      if(id==='resume'){this.setPaused(false);return;}
      if(id==='exit'){close();return;}
      if(id==='refuge'){
        this.save();const field=this.origin;close();if(Scene.name==='play'&&World90.canHub())World90.openHub();else if(Scene.name==='world90')return;else{World90.restore(field);World90.openHub();}return;
      }
      if(id==='keep'||id==='close'){this.modal=null;input.reset();return;}
      if(id==='minus'||id==='plus'){this.progress.frequency=clamp(this.progress.frequency+(id==='plus'?1:-1),0,6);this.save();sfx('ui');return;}
      if(id==='lock'){
        if(this.progress.frequency===3){this.progress.aligned=true;this.save();this.modal=null;this.notice(tr('SINAL ALINHADO. O arquivo à direita pode ser recuperado.','SIGNAL ALIGNED. Recover the file on the right.'));sfx('ok');}
        else this.notice(tr('Os pulsos não coincidem. A gravação contém três batidas.','The pulses do not match. The recording contains three beats.'));
      }
    },
    update(dt) {
      if(document.hidden||World90.isBackupOpen())return;
      this.moving=false;const c=input.sample(dt);
      if(this.paused){this.layout();if(c.back){this.setPaused(false);return;}if(c.navY)this.focus=(this.focus+c.navY+this.btns.length)%this.btns.length;if(c.act)this.choose(this.btns[this.focus]);return;}
      this.t+=dt;this.toastT=Math.max(0,this.toastT-dt);
      if(!Q90.ready([this.d.art,'rpg_john'])){if(c.back)close();return;}
      if(this.dialog){const d=this.dialog;if(!d.started){d.started=true;U.speak(d.key);if(d.key==='w90_'+this.id+'_entry'){this.progress.introSeen=true;this.save();}}d.t+=dt;this.layout();if(d.choices.length&&c.navY)this.focus=(this.focus+c.navY+d.choices.length)%d.choices.length;if(c.act)this.advance();if(c.back)this.setPaused(true);return;}
      if(this.modal){this.layout();if(c.back){this.modal=null;input.reset();return;}if(this.modal==='tuner'&&c.navX){this.progress.frequency=clamp(this.progress.frequency+c.navX,0,6);this.save();}if(c.navY)this.focus=(this.focus+c.navY+this.btns.length)%this.btns.length;if(c.act)this.choose(this.btns[this.focus]);return;}
      if(c.back){this.setPaused(true);return;}
      this.scan=Math.max(0,this.scan-dt);
      if(Math.abs(c.x)+Math.abs(c.y)>.1){this.moving=true;this.walk+=dt*7;this.dir=Math.abs(c.x)>Math.abs(c.y)?c.x>0?2:3:c.y>0?0:1;const nx=this.x+c.x*80*dt,ny=this.y+c.y*80*dt;if(!this.collide(nx,this.y))this.x=nx;if(!this.collide(this.x,ny))this.y=ny;}
      const p=this.nearest();if(c.act&&p)this.interact(p);if(c.scan){this.scan=1.2;this.notice(this.id==='alley'?tr('Siga o sangue, ouça a testemunha e examine a maleta.','Follow the blood, hear the witness and examine the case.'):this.id==='cistern'?(World90.state().rooms.alley.outcome==='witness-protected'?tr('A testemunha indicou: ESQUERDA → DIREITA → CENTRO.','The witness marked: LEFT → RIGHT → CENTRE.'):tr('Leia a placa de manutenção na parede ao fundo.','Read the maintenance plate on the rear wall.')):tr('A gravação possui três batidas. Alinhe o dial em III.','The recording has three beats. Align the dial with III.'));}
    },
    draw(g) {
      const b=box();g.fillStyle='#020711';g.fillRect(0,0,VW,VH);const im=Q90.image(this.d.art);if(im&&im.ok)g.drawImage(im,b.x,b.y,480,270);
      if(this.id==='cistern'&&!this.progress.drained){g.save();g.globalAlpha=.10;g.fillStyle='#3a9eac';g.fillRect(b.x+45,166,390,80);g.restore();}
      const near=this.nearest();for(const p of POINTS[this.id])U.marker(g,b.x+p.x,p.y,p.id==='exit'?'#dbb7fb':this.complete?'#73df9e':'#63dfd9',this.t,near===p);
      if(this.id==='alley'){const spr=window.MODES_ART&&MODES_ART.rpg_sprites;if(spr&&spr.ok){g.drawImage(spr,4*160,0,160,220,b.x+340-18,125-46,36,52);}}
      if(this.scan>0){g.save();g.strokeStyle='rgba(120,246,216,'+Math.min(.7,this.scan)+')';g.lineWidth=1;g.beginPath();g.ellipse(b.x+this.x,this.y,(1.3-this.scan)*48,(1.3-this.scan)*21,0,0,7);g.stroke();g.restore();}
      U.actor(g,b.x+this.x,this.y,this.dir,this.moving?this.walk:0);
    },
    drawHD(c) {
      U.begin(c);U.header(c,this.d.name(),this.complete?tr('CASO CONCLUÍDO • RECOMPENSA GUARDADA','CASE COMPLETE • REWARD KEPT'):this.d.district());
      if(!Q90.ready([this.d.art,'rpg_john']))U.loading(c,[this.d.art,'rpg_john']);
      else if(this.paused){U.modal(c,tr('INVESTIGAÇÃO PAUSADA','INVESTIGATION PAUSED'));this.layout();this.btns.forEach((b,i)=>U.button(c,b,i===this.focus));}
      else if(this.dialog){this.layout();U.dialog(c,this.dialog,this.dialog.choices);this.btns.forEach((b,i)=>U.button(c,b,i===this.focus));}
      else if(this.modal){
        const title=this.modal==='complete'?tr('PROVA RECUPERADA','EVIDENCE RECOVERED'):this.modal==='exitRoutes'?tr('PASSAGEM DE RETORNO LIBERADA','RETURN PASSAGE OPENED'):this.modal==='plate'?tr('PLACA DE MANUTENÇÃO','MAINTENANCE PLATE'):this.modal==='pulse'?tr('PULSO GRAVADO','RECORDED PULSE'):tr('TRANSMISSOR DA CABALA','CABALA TRANSMITTER');U.modal(c,title);
        if(this.modal==='complete'){const r=this.reward||{};U.text(c,tr('O arquivo foi guardado no diário do refúgio.','The file was stored in the refuge journal.'),52,80,VW-104,10,'#f0f5ec',3);U.text(c,'+'+(r.shards||0)+' '+tr('FRAGMENTOS','SHARDS')+'  •  '+tr('ATALHO LIBERADO','ROUTE OPENED'),52,122,VW-104,9,'#88efc9',2);}
        else if(this.modal==='plate'){U.text(c,tr('Feche a admissão, abra o desvio e estabilize a coluna central.','Close the intake, open the bypass and stabilize the centre column.'),54,82,VW-108,10,'#eef4ef',3);U.text(c,tr('ESQUERDA  →  DIREITA  →  CENTRO','LEFT  →  RIGHT  →  CENTRE'),54,137,VW-108,12,'#ffdb83',2);}
        else if(this.modal==='pulse'){U.text(c,tr('Três batidas por ciclo. O dial romano precisa repetir esse pulso.','Three beats per cycle. The Roman dial must repeat that pulse.'),54,82,VW-108,10,'#eef4ef',3);U.text(c,'●     ●     ●   =   III',VW/2-100,143,220,18,'#83efd6',2);}
        else if(this.modal==='tuner'){
          const n=this.progress.frequency;U.text(c,tr('REFERÊNCIA: III  •  GRAVAÇÃO COM TRÊS BATIDAS','REFERENCE: III  •  THREE RECORDED BEATS'),52,77,VW-104,9,'#c4d8e6',2);
          const labels=['0','I','II','III','IV','V','VI'];U.text(c,labels[n],VW/2-15,113,100,21,n===3?'#80f2c6':'#ffce81',1);
          c.strokeStyle=n===3?'#78eac4':'#7eacb8';c.lineWidth=1.2;c.beginPath();for(let i=0;i<=160;i++){const x=VW/2-140+i*1.75,y=102+Math.sin(i/160*Math.PI*2*n)*7;i?c.lineTo(x,y):c.moveTo(x,y);}c.stroke();
        }
        this.layout();this.btns.forEach((b,i)=>U.button(c,b,i===this.focus));
      } else {const near=this.nearest();U.controls(c,near?near.label():tr('EXPLORAR','EXPLORE'));U.pauseButton(c);}
      if(this.toastT>0)U.toast(c,this.toast);U.end(c);
    },
    onDown(id,x,y) {
      if(World90.isBackupOpen())return;
      if(!Q90.ready([this.d.art,'rpg_john'])){if(inside({x:VW/2-80,y:192,w:160,h:30},x,y))close();return;}
      if(this.paused||this.modal||this.dialog){this.layout();const b=this.btns.find(v=>inside(v,x,y));if(b)this.choose(b);else if(this.dialog&&!this.dialog.choices.length)this.advance();return;}
      if(U.pauseHit(x,y)){this.setPaused(true);return;}
      input.down(id,x,y);
    },
    onMove(id,x,y){input.move(id,x,y);},onUp(id){input.up(id);},
    setPaused(value){this.paused=!!value;this.focus=0;if(window.Dialogue9){if(this.paused)Dialogue9.pause();else if(this.dialog){if(Dialogue9.state.active&&Dialogue9.state.active.key===this.dialog.key)Dialogue9.resume();else{this.dialog.started=false;this.dialog.t=0;}}}input.reset();},
    onKey(key){if(key==='hide'){this.setPaused(true);return;}if(key==='pause'){this.setPaused(!this.paused);return;}if(key==='ok'){if(this.paused||this.modal){this.layout();this.choose(this.btns[this.focus]);}else if(this.dialog)this.advance();else{const p=this.nearest();if(p)this.interact(p);}}}
  };

  // Physical side entrances use the same world coordinates as their touch zones.
  // No standing HUD button is added to the combat screen.
  Q90.paths.room_doors=Q90.paths.room_doors||'assets/v90/room_doors.png';
  function doorBox(d,cam) {const a=DOOR_FRAMES[['alley','cistern','relay'].indexOf(d.id)],w=74,h=w*a[3]/a[2];return {x:d.x-cam-w/2,y:d.y-h,w,h};}
  function drawDoor(g,cam) {
    const d=stageRoom();if(!d||G.mode)return;const x=d.x-cam;if(x<-80||x>VW+80)return;
    const idx=['alley','cistern','relay'].indexOf(d.id),a=DOOR_FRAMES[idx],b=doorBox(d,cam),im=Q90.image('room_doors');if(im&&im.ok)g.drawImage(im,a[0],a[1],a[2],a[3],b.x,b.y,b.w,b.h);
    U.marker(g,x,d.y,World90.ensure().rooms[d.id].completed?'#9bdc88':'#55e9d3',G.time,!!doorNear());
  }
  for(const name of ['investigate','flood','fog']){const M=MECH[name],old=M.drawBack;M.drawBack=function(g,cam){if(old)old.apply(this,arguments);drawDoor(g,cam);};}
  const ctl=playerCtl;playerCtl=function(){const c=ctl.apply(this,arguments),d=doorNear(),s=window.ControlsUI&&ControlsUI.state();if(d&&s&&s.input==='pad'&&c.atk&&humanReady()){G._doorRequest90=d.id;c.atk=c.atkHeld=false;}return c;};
  const up=Scenes.play.update;Scenes.play.update=function(dt){const r=up.apply(this,arguments);if(Scene.cur!==this||!G)return r;const d=doorNear();
    if(G._doorRequest90){const id=G._doorRequest90;G._doorRequest90=null;if(d&&d.id===id)open(id);return r;}
    if(d&&!World90.ensure().seenDoors[d.id]){World90.ensure().seenDoors[d.id]=true;saveGame();G._doorHint90=4;}
    G._doorHint90=Math.max(0,(G._doorHint90||0)-dt);if(G._roomToast90T>0)G._roomToast90T-=dt;return r;};
  const down=Scenes.play.onDown;Scenes.play.onDown=function(id,x,y){const d=doorNear();if(d&&inside(doorBox(d,G.camX),x,y)){if(humanReady())open(d.id);else{G._roomToast90=entryHelp();G._roomToast90T=3;sfx('ui');}return;}return down.apply(this,arguments);};
  const key=Scenes.play.onKey;Scenes.play.onKey=function(k){const d=doorNear();if(k==='ok'&&d){if(humanReady())open(d.id);else{G._roomToast90=entryHelp();G._roomToast90T=3;}return;}return key.apply(this,arguments);};
  const overlays=PauseUI.drawOverlaysHD;PauseUI.drawOverlaysHD=function(c){if(overlays)overlays.apply(this,arguments);
    if(Scene.cur&&Scene.cur.freeInput90&&Scene.cur.drawHD){Scene.cur.drawHD(c);return;}
    if(Scene.name!=='play'||!G||Scenes.play.menu)return;
    const d=doorNear();if(d){const x=clamp(d.x-G.camX-85,16,VW-186),y=Math.max(76,doorBox(d,G.camX).y-31);U.begin(c);round(c,x,y,170,25,5);c.fillStyle='rgba(3,19,28,.94)';c.fill();c.strokeStyle='#83edd0';c.lineWidth=1;c.stroke();const s=window.ControlsUI?ControlsUI.state():{};U.text(c,humanReady()?(s.input==='pad'?'X • ':tr('TOQUE / ENTER • ','TAP / ENTER • '))+tr('INVESTIGAR','INVESTIGATE'):entryHelp(),x+8,y+7,154,8,'#baf5df',1);if(G._doorHint90>0)U.text(c,d.name(),x+8,y+30,154,8,'#f6ebc8',1);U.end(c);}
    if(G._roomToast90T>0){U.begin(c);U.toast(c,G._roomToast90);U.end(c);}
  };
  const back=window.androidBack;window.androidBack=function(){if(Scene.cur&&Scene.cur.freeInput90&&Scene.cur.onKey){Scene.cur.onKey('pause');return'ok';}return back?back():'exit';};
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&Scene.cur&&Scene.cur.freeInput90){Scene.cur.onKey('hide');}});
})();
