# LUPUS: REAWAKENING

Beat 'em up / action RPG 2D para Android, com campanha de 16 fases, três formas de John “Lupus” Thorne e cinco parceiros. O jogo e suas mídias funcionam offline.

O projeto editável fica em [`src/LupusReawakening-Android`](src/LupusReawakening-Android). Os arquivos `LupusReawakening-z*.zip` são a importação original e não sobrescrevem o código editável durante a compilação.

## Versão 8.7

- **Fluxo de primeira abertura e tutorial integrado na Fase 1:** Na primeira vez que o jogo é aberto, após a vinheta do estúdio e a HQ de introdução, a partida começa direto na Fase 1 com instruções passo a passo integradas à ação. Nas aberturas seguintes, o jogo vai direto ao menu principal.
- **Correção do tutorial fora de hora na Fase 3:** A seleção de parceiro na Fase 3 não desvia mais a campanha para a sala de treino isolada, exibindo uma dica contextual rápida quando Vespera entra na equipe.
- **Menu de Pausa em Alta Definição (Full HD):** Os textos, cartões de missão, desafios e botões do menu de pausa agora são renderizados diretamente na resolução nativa da tela (`PauseUI.drawHD`), eliminando o aspecto borrado/pixelado.
- **Botões Translúcidos, Ícones Vetoriais e Visibilidade Contextual:** Novo design em vidro escuro translúcido com aro neon duplo, ícones vetoriais exclusivos para cada ação (`ControlsUI.drawHD`) e transparência padrão suave (`48%` de opacidade / `52%` de transparência). Botões secundários (`FORMA`, `SENTIDOS`, `TROCA`, `AJUDA`, `SUPER`) aparecem apenas quando estão prontos ou relevantes (como pistas ou Arquivos Thule próximos), e **Opções → Controles** ganhou controle deslizante de **Visibilidade Geral (Transparência)** + presets rápidos (`28%`, `48%`, `78%`) além da opacidade individual por botão.
- **Novo Mensageiro da Cabala na Fase 3 (`MECH.chase`):** Personagem exclusivo com capa escarlate/dourada e maleta de relíquia Thule neon nas costas, que corre e sai totalmente pela direita da tela em cada bloco, reaparecendo mais à frente conforme cada onda de inimigos é derrotada.
- **Câmera Lenta de Nocaute (`K.O.`) nos Chefes:** Derrotar um chefe aciona câmera lenta dramática estilo *Street Fighter* (`0.15x`), zoom sutil de câmera, rastro de pós-imagem no ar e quique de impacto no chão antes do retorno à velocidade normal.

## Correções anteriores — 8.6

- Atualiza a fala de Lupus ao se libertar: “Ninguém vai fazer isso comigo de novo.” / “No one will ever do this to me again.”
- Regrava essa fala em inglês e português brasileiro, mantendo as demais falas e as correções anteriores.

## Correções anteriores — 8.5

- Retira os blocos e portões visíveis usados como barreiras de combate.
- Mantém a trava de avanço da área até eliminar os inimigos e cumprir os objetivos exigidos.
- Exibe **GO** quando a próxima área é liberada.

## Correções anteriores — 8.4

- Retira algemas, elos e extensões de corrente desenhados por cima dos sprites na 8.3. O Lupus moderno mantém a corrente que já faz parte da animação original do seu ataque especial.
- O alcance de dano desse especial acompanha a corrente desenhada no atlas, evitando acertos além da animação.
- O Lupus humano de 1944, inclusive quando essa aparência é usada em outras fases, passa a usar um Urro de curto alcance que atordoa inimigos próximos.
- A explicação das correntes deixa de repetir 1944; o ano permanece na abertura. Essa fala foi regravada em inglês e português brasileiro.
- Mantém as duas narrações offline, as correções de progressão e a pausa com texto rolável.

## Recursos mantidos da 8.3

- Inglês como idioma inicial, com 296 falas narrativas em inglês e as 296 gravações em português brasileiro preservadas offline. **Settings → Language → Português** muda a interface e a narração para português; os demais idiomas de interface usam a narração inglesa. Escolhas explícitas de idioma são preservadas.
- Pausa com áreas separadas para ações e instruções da fase, rolagem do texto e configurações em um subpainel para telas pequenas.
- Abertura revisada para manter a continuidade entre correntes, experimento, cela e libertação.
- Legendas permanecem visíveis durante a gravação da fala, inclusive em diálogos longos.
- Mantém as correções de progressão, o editor de controles e o suporte a controle físico da 8.2.

## Correções anteriores — 8.2

- Corrige checkpoints solo, rendições obrigatórias, comportamento do Leviatã e acesso aos arquivos Thule das arenas.
- Novo editor de controles: posição, tamanho, opacidade, analógico fixo/flutuante e modo canhoto. Abra em **Opções → Controles**, ou pelo menu de pausa.
- Controle físico via Gamepad API e ponte Android, com navegação de menus, zonas mortas e liberação de entradas ao desconectar.
- Novas ilustrações para a aliança com Vespera, origem das correntes, abertura do Ato III e final secreto.
- Dublagem narrativa em português brasileiro, com uma única fala por vez e interrupção ao avançar/pular cenas.
- Galeria com rolagem e carregamento por demanda; caches de desenho com limites de memória.
- Reiniciar a história exige confirmação e apaga todos os desbloqueios, mantendo as preferências do jogador.

## Testes

Com Node.js 20 ou posterior:

```sh
npm install --no-save --package-lock=false @napi-rs/canvas@0.1.100
node tests/regression.cjs
node tests/campaign.cjs
node tests/progress-gates.cjs
node tests/arena-access.cjs
node tests/story-continuity.cjs
node tests/pause-menu.cjs
node tests/chains.cjs
node tests/special-render.cjs
node tests/dialogue-timing.cjs
node tools/test-dialogue9.cjs
node tools/test-languages.cjs
python3 tools/test_package_update.py
```

Veja [`tests/README.md`](tests/README.md) para escopo e limitações. Os testes executam a ordem real de scripts, desenham com canvas e percorrem a progressão das 16 fases. O percurso automatizado usa invulnerabilidade, reposicionamento e aceleração de temporizadores; não mede dificuldade ou habilidade humana.

## Compilar no Android

Use Java 17, Android SDK 34 e o Gradle Wrapper incluído. Consulte as instruções de assinatura em [`src/LupusReawakening-Android/LEIA-ME.md`](src/LupusReawakening-Android/LEIA-ME.md).

```sh
cd src/LupusReawakening-Android
python3 tools/restore_signing.py --project . --archives ../..
chmod +x gradlew
./gradlew assembleRelease lintRelease
```

Um APK `release` precisa da configuração local de assinatura ou das variáveis `LUPUS_*`. As credenciais e chaves locais ficam fora do Git. A atualização sobre uma instalação existente exige a mesma assinatura e uma versão maior.

A versão 8.7 usa `versionCode 23`, mantendo o identificador do aplicativo e a assinatura das versões anteriores. O APK release fica em `app/build/outputs/apk/release/app-release.apk`; `assembleDebug lintDebug` continua disponível para desenvolvimento.

O workflow do GitHub usa o projeto editável, executa as verificações e disponibiliza o APK como artefato. Publicar uma Release é uma ação manual separada.

Os testes de lógica usam áudio e pontes Android simulados. Eles não comprovam latência de toque, reprodução de som, desempenho ou pareamento Bluetooth em um aparelho real.

## Pacote de atualização dos fontes

O pacote padrão é cumulativo sobre os ZIPs originais do repositório: a atualização 8.7 inclui as mídias e correções anteriores que continuam em uso, além das mudanças atuais. Não é preciso aplicar a 8.6 antes. A versão é lida do Gradle, sem edição manual do empacotador.

```sh
python3 tools/package_update.py --output /caminho/LupusReawakening_8.7_Atualizacao.zip
```

Para produzir um delta menor exclusivamente para quem já aplicou o pacote anterior, use `--base-manifest` com o ZIP de atualização anterior ou seu `manifest.json`. O aplicador confere os arquivos da base que não estão no delta antes de escrever, salva cópias dos arquivos substituídos e não baixa nada da internet.

```sh
python3 tools/package_update.py --base-manifest /caminho/LupusReawakening_8.6_Atualizacao.zip --output /caminho/LupusReawakening_8.7_Delta.zip
```
