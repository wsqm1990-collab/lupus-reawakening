'use strict';
/* v9 / v8.8: configurable translucent glass touch controls, contextual smart
   visibility, global + per-button transparency controls, HUD touch shortcuts,
   native HD vector rendering pass, and unified browser/native gamepad input. */
(function () {
  const ACTIONS = ['atk', 'jump', 'dash', 'block', 'spec', 'form', 'tag', 'assist', 'super', 'sense'];
  const MAP = { 0: 'jump', 1: 'dash', 2: 'atk', 3: 'spec', 4: 'block', 5: 'assist', 6: 'sense', 7: 'form', 8: 'tag', 10: 'super' };
  const COLORS = {
    atk: '#ff3d58',
    jump: '#4ce8ff',
    dash: '#dcd6f7',
    block: '#7eb0ff',
    spec: '#ffcf58',
    form: '#ff9d42',
    tag: '#c49bff',
    assist: '#7effbd',
    super: '#ffe47a',
    sense: '#ff6ca8'
  };
  const SHORT_PT = { atk: 'ATACAR', jump: 'PULO', dash: 'DASH', block: 'BLOQ', spec: 'ESP', form: 'FORMA', tag: 'TROCA', assist: 'AJUDA', super: 'SUPER', sense: 'SENT' };
  const SHORT_EN = { atk: 'ATTACK', jump: 'JUMP', dash: 'DASH', block: 'BLOCK', spec: 'SKILL', form: 'FORM', tag: 'SWAP', assist: 'ASSIST', super: 'SUPER', sense: 'SENSE' };
  const FULL_PT = { atk: 'Ataque', jump: 'Pulo', dash: 'Esquiva (Dash)', block: 'Bloqueio / agachar', spec: 'Especial', form: 'Transformação (segure p/ humano)', tag: 'Trocar parceiro (Swap)', assist: 'Assistência (Ajuda)', super: 'Super Duplo', sense: 'Sentidos de Lobo', joy: 'Analógico (Movimento)' };
  const FULL_EN = { atk: 'Attack', jump: 'Jump', dash: 'Dodge (Dash)', block: 'Block / crouch', spec: 'Special', form: 'Form (hold to revert)', tag: 'Swap partner', assist: 'Assist', super: 'Duo Super', sense: 'Wolf Senses', joy: 'Joystick (Movement)' };
  const PT = () => /^pt/.test(SAVE.lang || '');
  const tr = (p, e) => PT() ? p : (window.TR9 ? TR9(e) : e);   /* v9.2: other languages come from tr92.js */
  const finite = (n, d) => Number.isFinite(Number(n)) ? Number(n) : d;
  const PRESETS = {
    standard: { spacing: 1, radius: 1, joy: 1 },
    compact: { spacing: 0.94, radius: 0.9, joy: 0.9 },
    large: { spacing: 1.13, radius: 1.12, joy: 1.12 },
    tablet: { spacing: 1.08, radius: 1.14, joy: 1.15 },
    arcade: { spacing: 1.03, radius: 1.06, joy: 1 }
  };
  /* Default global opacity is 0.48 (52% transparency) so controls never obscure combat */
  const defaults = () => ({ version: 2, preset: 'standard', left: false, joystick: 'floating', opacity: 0.48, contextual: true, buttons: {}, joy: {} });
  function normalize(raw) {
    const out = defaults();
    if (!raw || typeof raw !== 'object') return out;
    out.preset = Object.prototype.hasOwnProperty.call(PRESETS, raw.preset) ? raw.preset : 'standard';
    out.left = !!raw.left;
    out.joystick = raw.joystick === 'fixed' ? 'fixed' : 'floating';
    out.opacity = clamp(finite(raw.opacity, 0.48), 0.15, 1);
    out.contextual = raw.contextual !== false;
    for (const name of ACTIONS.concat('joy')) {
      const src = name === 'joy' ? raw.joy : raw.buttons && raw.buttons[name];
      if (!src || typeof src !== 'object') continue;
      const dst = { size: clamp(finite(src.size, 1), 0.8, 1.5), opacity: clamp(finite(src.opacity, 1), 0.15, 4) };
      if (Number.isFinite(src.x) && Number.isFinite(src.y)) { dst.x = clamp(src.x, 0, 1); dst.y = clamp(src.y, 0, 1); }
      if (name === 'joy') out.joy = dst; else out.buttons[name] = dst;
    }
    return out;
  }
  SAVE.controls = normalize(SAVE.controls);
  let editor = null, safeProbe = null, safeCache = null;
  const mode = { input: 'touch', padHint: 0 };
  const pad = { connected: false, id: '', axes: [0, 0], buttons: [], held: {}, edges: {}, prior: [], native: null, pending: [], nativePrior: [], focus: '', menuKey: '', repeat: 0, direction: '', suspended: false };
  const config = () => editor ? editor.draft : (SAVE.controls || (SAVE.controls = defaults()));

  function metrics() {
    const cssScale = Math.max(0.1, SCALE / (cv._dpr || 1));
    if (!safeCache) {
      let l = 0, r = 0, t = 0, b = 0;
      try {
        if (!safeProbe) {
          safeProbe = document.createElement('div');
          safeProbe.style.cssText = 'position:fixed;visibility:hidden;pointer-events:none;padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)';
          document.body.appendChild(safeProbe);
        }
        const s = getComputedStyle(safeProbe); l = parseFloat(s.paddingLeft) || 0; r = parseFloat(s.paddingRight) || 0; t = parseFloat(s.paddingTop) || 0; b = parseFloat(s.paddingBottom) || 0;
      } catch (_) { }
      safeCache = { l, r, t, b };
    }
    const cssOX = OX / (cv._dpr || 1), cssOY = OY / (cv._dpr || 1);
    return {
      scale: cssScale, minR: 24 / cssScale, gap: 8 / cssScale,
      l: Math.max(5, (safeCache.l + 8 - cssOX) / cssScale), r: Math.max(5, (safeCache.r + 8 - cssOX) / cssScale),
      t: Math.max(5, (safeCache.t + 8 - cssOY) / cssScale), b: Math.max(5, (safeCache.b + 8 - cssOY) / cssScale)
    };
  }
  window.addEventListener('resize', () => { safeCache = null; });
  window.addEventListener('orientationchange', () => { safeCache = null; });

  function position(name, x, y, r, m) {
    const cfg = config(), it = name === 'joy' ? cfg.joy : cfg.buttons[name] || {}, size = it.size || 1;
    r = Math.round(r * size);
    const hit = Math.max(r, m.minR), margin = Math.max(r + 4, hit);
    if (Number.isFinite(it.x)) { x = it.x * VW; y = it.y * VH; }
    else if (cfg.left) x = VW - x;
    return {
      name,
      x: Math.round(clamp(x, m.l + margin, VW - m.r - margin)),
      y: Math.round(clamp(y, m.t + margin, VH - m.b - margin)),
      r,
      hit,
      opacity: clamp(cfg.opacity * (it.opacity || 1), 0.12, 1)
    };
  }
  function buttons() {
    const m = metrics(), preset = PRESETS[config().preset] || PRESETS.standard, k = Math.max(1, m.minR / 18), spacing = k * preset.spacing, right = Math.max(m.r, 6), bottom = Math.max(m.b, 6);
    const defs = {
      /* v9.1: Special right above Attack and the Duo Super in the ring next to it,
         where the thumb already rests; Block moves to the outer row. */
      atk: [48, 48, 31], jump: [112, 27, 20], dash: [116, 79, 21], spec: [48, 116, 21], block: [178, 30, 21],
      super: [116, 135, 20], form: [48, 172, 18], tag: [180, 89, 18], assist: [180, 147, 18], sense: [116, 187, 18]
    }, out = {};
    for (const n of ACTIONS) { const d = defs[n]; out[n] = position(n, VW - right - d[0] * spacing, VH - bottom - d[1] * spacing, d[2] * k * preset.radius, m); }
    const custom = ACTIONS.some(n => Number.isFinite((config().buttons[n] || {}).x));
    const crowd = !custom && ACTIONS.some((n, i) => ACTIONS.slice(i + 1).some(q => Math.hypot(out[n].x - out[q].x, out[n].y - out[q].y) < out[n].hit + out[q].hit + m.gap - 0.5));
    if (crowd) {
      const other = ['jump', 'dash', 'spec', 'block', 'super', 'form', 'tag', 'assist', 'sense'];
      const limit = Math.max(m.minR, (VH - m.t - m.b - m.gap * 2) / 6 - 2);
      for (const n of other) { out[n].r = Math.max(12, Math.min(out[n].r, Math.floor(limit))); out[n].hit = Math.max(out[n].r, m.minR); }
      const cellR = Math.max(...other.map(n => out[n].hit)), step = cellR * 2 + m.gap;
      const atk = out.atk; atk.x = config().left ? m.l + atk.hit + 4 : VW - m.r - atk.hit - 4; atk.y = VH - m.b - atk.hit - 4;
      other.forEach((n, i) => { const col = Math.floor(i / 3), row = i % 3, off = atk.hit + m.gap + cellR + col * step; out[n].x = Math.round(atk.x + (config().left ? off : -off)); out[n].y = Math.round(VH - m.b - cellR - row * step); });
    }
    return out;
  }
  function joystick() {
    const m = metrics(), k = Math.max(1, m.minR / 18), preset = PRESETS[config().preset] || PRESETS.standard;
    return position('joy', m.l + 54 * k, VH - m.b - 52 * k, 31 * k * preset.joy, m);
  }
  function nearest(x, y, edit) {
    const B = buttons(), candidates = ACTIONS.filter(n => edit || visible(n)).map(n => B[n]); if (edit) candidates.push(joystick());
    let best = null, distance = Infinity;
    for (const b of candidates) {
      const d = Math.hypot(x - b.x, y - b.y);
      if (d <= b.hit + Math.min(5, metrics().gap / 2) && d < distance) { best = b; distance = d; }
    }
    return best;
  }

  /* Detect when Wolf Senses is relevant nearby (Clues, Thule Archives, Darkness, or Stealth Ghosts) */
  function senseRelevant() {
    if (!G || !G.player || !senseOk()) return false;
    if (G.sensing || (G.senseTapT || 0) > 0 || (G.senseGrace || 0) > 0) return true;
    const px = G.player.x;
    if ((G.clues || []).some(c => !c.got && Math.abs(c.x - px) < 260)) return true;
    if ((G.archs || []).some(a => !a.got && Math.abs(a.x - px) < 220)) return true;
    if (G.dark > 0) return true;
    if ((G.enemies || []).some(e => !e.dead && e.type === 'P' && Math.abs(e.x - px) < 260)) return true;
    return false;
  }

  /* Smart Contextual Visibility:
     - Core combat buttons (atk, jump, dash, block, spec) are always visible.
     - Secondary buttons (form, sense, tag, assist, super) only appear when ready or relevant
       (unless the player disables contextual mode in the Control Editor).
     - Preserves empty-fury revert when Lupus is already transformed (p.form !== 'h'). */
  function visible(n) {
    if (editor || !G || !G.player) return true;
    const ctxOn = config().contextual !== false;
    const tutStep = G.tut && G.tut.steps && G.tut.steps[G.tut.i];
    const s1Step = G.stage1Tut && !G.stage1Tut.done && G.stage1Tut.steps[G.stage1Tut.i];
    if (n === 'tag') {
      if (!G.ally || G.ally.dead) return false;
      return !ctxOn || canTag() || tutStep === 'tag' || (G.stage3HintT || 0) > 0;
    }
    if (n === 'assist') {
      if (!G.ally || G.ally.dead) return false;
      return !ctxOn || canAssist() || tutStep === 'assist' || (G.stage3HintT || 0) > 0;
    }
    if (n === 'form') {
      if (G.player.id !== 'lupus') return false;
      if (!ctxOn) return true;
      const p44 = G.st && G.st.l44 && !G.mode;
      const canUp = G.player.form === 'h' ? G.player.fury >= 100 : G.player.form === 'f' ? (!p44 && G.player.fury >= 200) : false;
      return G.player.form !== 'h' || canUp || tutStep === 'form' || s1Step === 'form';
    }
    if (n === 'sense') {
      if (!senseOk()) return false;
      return !ctxOn || senseRelevant() || tutStep === 'sense' || s1Step === 'sense';
    }
    if (n === 'super') return (!ctxOn && !!G.ally && !G.ally.dead && G.player.form !== 'x') || !!canSuper() || tutStep === 'super';
    return true;
  }

  function info(n) {
    if (!G || !G.player || editor) return { ok: true, progress: 1, alert: false };
    const p = G.player;
    if (n === 'spec') return { ok: p.spCd <= 0, progress: 1 - clamp(p.spCd / Math.max(0.01, hs(p).cd), 0, 1), alert: false };
    if (n === 'dash') return { ok: p.dashCd <= 0, progress: p.dashCd > 0 ? 1 - clamp(p.dashCd / 0.7, 0, 1) : 1, alert: false };
    if (n === 'form') {
      const has = p.id === 'lupus';
      const p44 = G.st && G.st.l44 && !G.mode;
      const canUp = p.form === 'h' ? p.fury >= 100 : p.form === 'f' ? (!p44 && p.fury >= 200) : false;
      const ready = p.form !== 'h' || canUp;
      return { ok: has && ready, progress: has ? clamp(p.fury / (p.form === 'h' ? 100 : 200), 0, 1) : 0, alert: canUp };
    }
    if (n === 'super') return { ok: !!canSuper(), progress: clamp((G.syn || 0) / 100, 0, 1), alert: !!canSuper() };
    if (n === 'sense') {
      const ok = senseOk() && (G.sense == null || G.sense > 2);
      return { ok, progress: senseOk() ? clamp((G.sense == null ? 100 : G.sense) / 100, 0, 1) : 0, alert: ok && senseRelevant() && !G.sensing };
    }
    if (n === 'tag') return { ok: !!canTag(), progress: G.ally && !G.ally.dead ? 1 - clamp((G.tagCd || 0) / TAG_CD, 0, 1) : 0, alert: false };
    if (n === 'assist') return { ok: !!canAssist(), progress: G.ally && !G.ally.dead ? 1 - clamp((G.assistCd || 0) / ASSIST_CD, 0, 1) : 0, alert: false };
    return { ok: true, progress: 1, alert: false };
  }
  function touches(n) { return Object.keys(Inp.btnIds).some(id => Inp.btnIds[id] === n); }
  function held(n) {
    if (n === 'sense' && G && (G.senseTapT || 0) > 0) return true;
    return !!Inp.keys[n] || touches(n) || !!pad.held[n];
  }
  function resetTouch() {
    Inp.joy.id = null; Inp.joy.ax = Inp.joy.ay = 0; Inp.btnIds = {};
    for (const n of ACTIONS) Inp.held[n] = !!Inp.keys[n];
    Inp.edge = {};
  }
  function takeTouch() { mode.input = 'touch'; mode.padHint = 0; }
  const originalReset = Inp.reset;
  Inp.reset = function () { originalReset.call(this); pad.edges = {}; };
  const originalCtl = playerCtl;
  playerCtl = function () {
    const c = originalCtl();
    for (const n of ACTIONS) if (pad.edges[n]) c[n] = true;
    c.atkHeld = held('atk'); c.jumpHeld = held('jump'); c.formHeld = held('form'); c.block = held('block'); c.sense = held('sense');
    if (Inp.joy.id == null && !(Inp.keys.l || Inp.keys.r || Inp.keys.u || Inp.keys.d)) { c.mx = pad.axes[0]; c.my = pad.axes[1]; }
    pad.edges = {};
    if (G && G.superFx && G.superFx.v90) { for (const n in c) c[n] = n === 'mx' || n === 'my' ? 0 : false; }
    return c;
  };

  /* Portrait shortcuts request a form by identity, never the next form in the
     cycle. Story Fenrir is deliberately unavailable through touch shortcuts. */
  function hudInputReady() {
    return !!(G && G.player && Scene.name === 'play' && !Scenes.play.menu && !PORTRAIT && !document.hidden &&
      !G.player.dead && !G.over && !G.clearT && !G.panel && !G.choice && !G.cine && !G.superFx &&
      !G.vesperaBeat && !G.nachtBeat90 && !(G.cineBar > 0.5) && !(G.autoTag > 0) && !(G.hitstop > 0));
  }
  function requestForm(to) {
    if (!hudInputReady()) return false;
    const p = G.player;
    if (p.id !== 'lupus' || p.form === 'x' || G.fenrirT || !['h', 'f', 'a'].includes(to)) return false;
    if (p.form === to) return false;
    if (!['idle', 'walk', 'guard'].includes(p.st) || !(window.Traversal90 ? Traversal90.grounded(p) : p.z <= 0 && p.vz === 0)) return false;
    if (to === 'f' && !(p.form === 'a' ? p.fury > 0 : p.fury >= 100)) return false;
    if (to === 'a' && ((G.st && G.st.l44 && !G.mode) || p.fury < 200)) return false;
    p.formPress = null;
    startXform(p, to); vibe(20, 90); return true;
  }
  function toggleSenseBurst() {
    if (!hudInputReady() || !senseOk()) return false;
    if ((G.senseTapT || 0) > 0) G.senseTapT = 0;
    else {
      if (G.sense != null && G.sense <= 2) return false;
      G.senseTapT = 3.8;
    }
    // Keep the contextual button reachable briefly after cancellation.
    G.senseGrace = 4.5;
    return true;
  }

  /* HUD top-bar touch shortcuts (tap portraits/bars directly in addition to buttons) */
  function tryHudShortcut(x, y) {
    if (!hudInputReady()) return false;
    // Use the same tile geometry as the HUD, including the fourth Fenrir tile.
    if (G.player.id === 'lupus' && y >= 5 && y <= 33) {
      const forms = G.fenrirT ? ['h', 'f', 'a', 'x'] : ['h', 'f', 'a'];
      const x0 = VW / 2 - forms.length * 16 + 2;
      const index = forms.findIndex((_, i) => x >= x0 + i * 32 && x <= x0 + i * 32 + 28);
      if (index >= 0) { requestForm(forms[index]); return true; }
    }
    // Top-left Lupus portrait: the same toggle as the combat Senses button.
    if (senseOk() && x >= 4 && x <= 42 && y >= 4 && y <= 42) {
      if (toggleSenseBurst()) vibe(15, 70);
      return true;
    }
    // Partner card halves have fixed meanings, including during cooldown.
    if (G.ally && !G.ally.dead && x >= 4 && x <= 114 && y >= 43 && y <= 71) {
      const action = x > 72 ? 'assist' : 'tag';
      if (action === 'assist' ? canAssist() : canTag()) { Inp.edge[action] = true; vibe(18, 80); }
      return true;
    }
    // Top-left Synergy bar: tap when full to unleash Duo Super
    if (canSuper() && x >= 4 && x <= 116 && y >= 72 && y <= 94) {
      Inp.edge.super = true; vibe(30, 140); return true;
    }
    return false;
  }

  const play = Scenes.play, oldDown = play.onDown, oldKey = play.onKey;
  play.onDown = function (id, x, y) {
    if (id !== -99) takeTouch();
    if (this.menu || G.choice || G.panel) { oldDown.call(this, id, x, y); return; }
    if (G && G.stage1Tut && !G.stage1Tut.done && x >= VW / 2 + 95 && x <= VW / 2 + 165 && y >= 62 && y <= 88) {
      G.stage1Tut.done = true; SAVE.stage1TutDone = true; saveGame(); sfx('ui'); return;
    }
    if (Math.hypot(x - (VW - 14), y - 14) < 18) { resetTouch(); this.menu = true; sfx('ui'); return; }
    if (G.superFx && G.superFx.v90) { resetTouch(); return; }
    if (G.over > 0 || G.clearT > 0) return;
    const b = nearest(x, y, false);
    if (b) {
      if (b.name === 'sense') {
        // A touch toggles a timed burst; holding the finger never re-enables it.
        if (toggleSenseBurst()) vibe(10, 55);
        return;
      }
      Inp.btnIds[id] = b.name; Inp.held[b.name] = true; Inp.edge[b.name] = true;
      if (info(b.name).ok) vibe(10, 55);
      return;
    }
    if (tryHudShortcut(x, y)) return;
    const cfg = config(), j = Inp.joy, base = joystick();
    const inHalf = cfg.left ? x > VW * 0.56 : x < VW * 0.44;
    const inFixed = Math.hypot(x - base.x, y - base.y) <= base.r + metrics().minR;
    if (j.id == null && y > 56 && (cfg.joystick === 'fixed' ? inFixed : inHalf)) {
      j.id = id; j.ox = cfg.joystick === 'fixed' ? base.x : clamp(x, metrics().l + base.r, VW - metrics().r - base.r);
      j.oy = cfg.joystick === 'fixed' ? base.y : clamp(y, metrics().t + base.r, VH - metrics().b - base.r);
      j.x = x; j.y = y; j.ax = j.ay = 0;
      this.onMove(id, x, y);
    }
  };
  play.onMove = function (id, x, y) {
    if (G && G.superFx && G.superFx.v90) { resetTouch(); return; }
    const j = Inp.joy; if (j.id !== id) return;
    const r = joystick().r; let dx = x - j.ox, dy = y - j.oy, d = Math.hypot(dx, dy);
    if (config().joystick === 'floating' && d > r * 1.8) {
      const extra = d - r * 1.8, m = metrics(); j.ox = clamp(j.ox + dx / d * extra, m.l + r, VW - m.r - r); j.oy = clamp(j.oy + dy / d * extra, m.t + r, VH - m.b - r); dx = x - j.ox; dy = y - j.oy; d = Math.hypot(dx, dy);
    }
    j.x = j.ox + dx / Math.max(1, d) * Math.min(r, d); j.y = j.oy + dy / Math.max(1, d) * Math.min(r, d);
    j.ax = dx / Math.max(r, d); j.ay = dy / Math.max(r, d);
  };
  play.onUp = function (id) {
    if (Inp.joy.id === id) { Inp.joy.id = null; Inp.joy.ax = Inp.joy.ay = 0; }
    const name = Inp.btnIds[id]; delete Inp.btnIds[id];
    if (name) Inp.held[name] = touches(name) || !!Inp.keys[name];
  };
  play.onKey = function (key) {
    if (key === 'pause' || key === 'hide') { resetTouch(); pad.edges = {}; }
    oldKey.call(this, key);
  };
  cv.addEventListener('pointerdown', takeTouch);
  window.addEventListener('keydown', () => { mode.input = 'keyboard'; });
  window.addEventListener('blur', () => { Inp.reset(); pad.held = {}; pad.axes = [0, 0]; pad.suspended = true; });
  document.addEventListener('visibilitychange', () => { pad.suspended = !!document.hidden; if (document.hidden) { Inp.reset(); pad.held = {}; pad.axes = [0, 0]; } });
  window.addEventListener('focus', () => { pad.suspended = false; });

  function buttonLabel(b, edit) {
    const baseLabel = tr(SHORT_PT[b.name], SHORT_EN[b.name]);
    /* the label sits under the icon and may run a little past the circle */
    const fits = s => PIX.textW(s, 1) <= b.r * 2 + 14;
    if (!edit && b.name === 'spec' && G && humanPulse(G.player)) { const roar = heroSpecLabel(G.player); if (fits(roar)) return roar; }
    return fits(baseLabel) || b.name !== 'spec' ? baseLabel : (PT() ? 'ESP' : 'SP');
  }

  function ring(g, b, progress, color) {
    if (progress >= 1) return;
    g.lineWidth = 1.5; g.strokeStyle = 'rgba(33,29,48,0.65)'; g.beginPath(); g.arc(b.x, b.y, b.r + 1, 0, Math.PI * 2); g.stroke();
    if (progress > 0) { g.strokeStyle = color; g.beginPath(); g.arc(b.x, b.y, b.r + 1, -Math.PI / 2, -Math.PI / 2 + progress * Math.PI * 2); g.stroke(); }
  }
  function drawButton(g, b, edit) {
    const st = edit ? { ok: true, progress: 1, alert: false } : info(b.name), down = !edit && held(b.name), col = COLORS[b.name];
    const revertOnly = !edit && b.name === 'form' && G && G.player && G.player.form !== 'h' && !st.alert;
    const baseAlpha = edit ? Math.max(0.55, b.opacity) : down ? Math.min(0.95, b.opacity + 0.32) : b.opacity * (st.ok ? (revertOnly ? 0.62 : 1) : 0.42);
    g.save();
    g.globalAlpha = baseAlpha * 0.48;
    g.fillStyle = '#090813'; pixCircle(g, b.x, b.y, b.r + 1);
    g.globalAlpha = baseAlpha * 0.72;
    g.strokeStyle = st.ok ? col : '#6c6478'; g.lineWidth = down ? 2 : 1.5;
    g.beginPath(); g.arc(b.x, b.y, b.r, 0, Math.PI * 2); g.stroke();
    if (down) { g.strokeStyle = col; g.lineWidth = 1.5; g.beginPath(); g.arc(b.x, b.y, b.r + 3.5, 0, Math.PI * 2); g.stroke(); }
    g.globalAlpha = Math.min(1, baseAlpha * 1.15);
    const ic = ['atk', 'jump', 'dash', 'block', 'sense', 'spec'].includes(b.name) ? b.name : b.name === 'super' ? 'spec' : null;
    if (ic) icon(g, ic, b.x, b.y - 5, down ? '#ffffff' : st.ok ? col : '#a49bad');
    else if (!edit && G && G.player && (b.name === 'tag' || b.name === 'assist') && G.ally) {
      g.save(); g.beginPath(); g.arc(b.x, b.y - 4, Math.max(7, b.r - 8), 0, 7); g.clip(); drawFace(g, heroKey(G.ally), b.x - b.r + 7, b.y - b.r + 3, (b.r - 7) * 2); g.restore();
    } else {
      PIX.text(g, b.name === 'form' ? 'F' : b.name === 'tag' ? '<>' : '+', b.x, b.y - 10, { align: 'c', s: 2, col: st.ok ? col : '#a49bad' });
    }
    const label = buttonLabel(b, edit);
    PIX.text(g, label, b.x, b.y + 8, { align: 'c', col: down ? '#ffffff' : st.ok ? '#f0ecf7' : '#a49bad', out: '#090813' });
    ring(g, b, st.progress, col);
    g.restore();
    if (edit && editor.selected === b.name) { g.save(); g.strokeStyle = '#ffffff'; g.lineWidth = 1; g.setLineDash([3, 3]); g.beginPath(); g.arc(b.x, b.y, b.hit + 5, 0, 7); g.stroke(); g.restore(); }
  }
  function drawJoystick(g, edit) {
    const b = joystick(), j = Inp.joy, active = !edit && j.id != null, x = active ? j.ox : b.x, y = active ? j.oy : b.y;
    const baseAlpha = edit ? Math.max(0.5, b.opacity) : active ? Math.min(0.88, b.opacity + 0.22) : b.opacity * 0.62;
    g.save();
    g.globalAlpha = baseAlpha * 0.38;
    g.fillStyle = '#0d0b18'; pixCircle(g, Math.round(x), Math.round(y), b.r + 1);
    g.globalAlpha = baseAlpha * 0.75;
    g.strokeStyle = active ? '#67e8ff' : '#9b94b8'; g.lineWidth = 1.5;
    g.beginPath(); g.arc(Math.round(x), Math.round(y), b.r, 0, Math.PI * 2); g.stroke();
    g.globalAlpha = Math.min(1, baseAlpha * 1.1);
    g.fillStyle = active ? '#f2efff' : '#9b97b0'; pixCircle(g, Math.round(active ? j.x : x), Math.round(active ? j.y : y), Math.round(b.r * 0.36));
    g.restore();
    if (edit && editor.selected === 'joy') { g.save(); g.strokeStyle = '#ffffff'; g.setLineDash([3, 3]); g.beginPath(); g.arc(b.x, b.y, b.r + 5, 0, 7); g.stroke(); g.restore(); }
  }
  drawControls = function (g) {
    if (!G || G.over > 0 || Scenes.play.menu) return;
    if (mode.input === 'pad' && pad.connected) {
      if (mode.padHint > 0) PIX.text(g, tr('CONTROLE: X ATACA / A PULA / START PAUSA', 'CONTROLLER: X ATTACK / A JUMP / START PAUSE'), VW / 2, VH - 11, { align: 'c', col: '#b9b3ca', out: '#080610' });
      return;
    }
    /* When inside the live main loop (window.__inFrameDraw), skip low-res pixel
       drawing on BUF because ControlsUI.drawHD(ctx) renders crisp Full HD glass
       controls directly onto the native display canvas. Direct calls to
       drawControls(bg) from tests still execute in full. */
    if (window.__inFrameDraw && window.ControlsUI && ControlsUI.drawHD) return;
    drawJoystick(g, false); const B = buttons(); for (const n of ACTIONS) if (visible(n)) drawButton(g, B[n], false);
  };

  /* ===== NATIVE HIGH-RESOLUTION GLASS & VECTOR ICON RENDERER ===== */
  function drawVectorIcon(c, name, cx, cy, r, col, down) {
    c.save();
    c.translate(cx, cy - r * 0.14);
    c.strokeStyle = down ? '#ffffff' : col;
    c.fillStyle = down ? '#ffffff' : col;
    c.lineCap = 'round';
    c.lineJoin = 'round';
    const u = r * 0.44;
    if (name === 'atk') {
      // Three curved diagonal wolf claw slashes
      c.lineWidth = Math.max(2, r * 0.11);
      for (const off of [-0.62, 0, 0.62]) {
        c.beginPath();
        c.moveTo((-0.55 + off * 0.55) * u, -0.75 * u);
        c.quadraticCurveTo((0.05 + off * 0.55) * u, -0.05 * u, (0.45 + off * 0.55) * u, 0.72 * u);
        c.stroke();
      }
    } else if (name === 'jump') {
      // Winged double upward chevron
      c.lineWidth = Math.max(2, r * 0.11);
      c.beginPath();
      c.moveTo(-0.75 * u, 0.15 * u); c.lineTo(0, -0.68 * u); c.lineTo(0.75 * u, 0.15 * u);
      c.moveTo(-0.48 * u, 0.62 * u); c.lineTo(0, 0.02 * u); c.lineTo(0.48 * u, 0.62 * u);
      c.stroke();
    } else if (name === 'dash') {
      // Twin aerodynamic speed chevrons + motion lines
      c.lineWidth = Math.max(2, r * 0.11);
      c.beginPath();
      c.moveTo(-0.22 * u, -0.58 * u); c.lineTo(0.42 * u, 0); c.lineTo(-0.22 * u, 0.58 * u);
      c.moveTo(0.26 * u, -0.58 * u); c.lineTo(0.88 * u, 0); c.lineTo(0.26 * u, 0.58 * u);
      c.moveTo(-0.88 * u, -0.28 * u); c.lineTo(-0.42 * u, -0.28 * u);
      c.moveTo(-0.98 * u, 0.28 * u); c.lineTo(-0.42 * u, 0.28 * u);
      c.stroke();
    } else if (name === 'block') {
      // Heraldic Gothic shield with inner crest
      c.lineWidth = Math.max(2, r * 0.1);
      c.beginPath();
      c.moveTo(0, -0.78 * u);
      c.lineTo(0.68 * u, -0.52 * u);
      c.lineTo(0.62 * u, 0.12 * u);
      c.quadraticCurveTo(0.45 * u, 0.62 * u, 0, 0.85 * u);
      c.quadraticCurveTo(-0.45 * u, 0.62 * u, -0.62 * u, 0.12 * u);
      c.lineTo(-0.68 * u, -0.52 * u);
      c.closePath();
      c.stroke();
      c.globalAlpha *= 0.28;
      c.fill();
      c.globalAlpha /= 0.28;
      c.beginPath();
      c.moveTo(0, -0.45 * u); c.lineTo(0, 0.52 * u);
      c.moveTo(-0.32 * u, -0.08 * u); c.lineTo(0.32 * u, -0.08 * u);
      c.stroke();
    } else if (name === 'spec') {
      const pulse = G && G.player && humanPulse(G.player);
      c.lineWidth = Math.max(1.8, r * 0.095);
      if (pulse) {
        // 1944 Sonic Roar waves
        c.beginPath();
        c.arc(-0.35 * u, 0, 0.22 * u, -Math.PI * 0.45, Math.PI * 0.45);
        c.stroke();
        c.beginPath();
        c.arc(-0.35 * u, 0, 0.62 * u, -Math.PI * 0.45, Math.PI * 0.45);
        c.stroke();
        c.beginPath();
        c.arc(-0.35 * u, 0, 1.02 * u, -Math.PI * 0.45, Math.PI * 0.45);
        c.stroke();
      } else {
        // 8-point arcane energy star
        c.beginPath();
        for (let i = 0; i < 8; i++) {
          const a = i * Math.PI / 4, rad = i % 2 === 0 ? 0.85 * u : 0.34 * u;
          if (i === 0) c.moveTo(Math.cos(a) * rad, Math.sin(a) * rad);
          else c.lineTo(Math.cos(a) * rad, Math.sin(a) * rad);
        }
        c.closePath();
        c.stroke();
        c.globalAlpha *= 0.35; c.fill();
      }
    } else if (name === 'sense') {
      // Glowing Lupine Eye with vertical slit pupil & sonar arcs
      c.lineWidth = Math.max(1.8, r * 0.095);
      c.beginPath();
      c.moveTo(-0.85 * u, 0);
      c.quadraticCurveTo(0, -0.68 * u, 0.85 * u, 0);
      c.quadraticCurveTo(0, 0.68 * u, -0.85 * u, 0);
      c.closePath();
      c.stroke();
      c.beginPath();
      c.ellipse(0, 0, 0.16 * u, 0.42 * u, 0, 0, Math.PI * 2);
      c.fill();
    } else if (name === 'super') {
      // Twin synergy starburst + crescent moon
      c.lineWidth = Math.max(1.8, r * 0.095);
      c.beginPath();
      for (let i = 0; i < 8; i++) {
        const a = i * Math.PI / 4, rad = i % 2 === 0 ? 0.9 * u : 0.36 * u;
        if (i === 0) c.moveTo(Math.cos(a) * rad, Math.sin(a) * rad);
        else c.lineTo(Math.cos(a) * rad, Math.sin(a) * rad);
      }
      c.closePath();
      c.fill();
    } else if (name === 'form') {
      // Lupine transformation crest (wolf fangs + inner portrait if available)
      c.lineWidth = Math.max(2, r * 0.1);
      c.beginPath();
      c.moveTo(-0.68 * u, -0.45 * u); c.lineTo(-0.36 * u, 0.52 * u); c.lineTo(-0.08 * u, -0.15 * u);
      c.moveTo(0.68 * u, -0.45 * u); c.lineTo(0.36 * u, 0.52 * u); c.lineTo(0.08 * u, -0.15 * u);
      c.stroke();
    } else if (name === 'tag') {
      // Dual swap arrows
      c.lineWidth = Math.max(1.8, r * 0.095);
      c.beginPath();
      c.moveTo(-0.65 * u, -0.22 * u); c.lineTo(0.55 * u, -0.22 * u); c.lineTo(0.25 * u, -0.52 * u);
      c.moveTo(0.65 * u, 0.22 * u); c.lineTo(-0.55 * u, 0.22 * u); c.lineTo(-0.25 * u, 0.52 * u);
      c.stroke();
    } else if (name === 'assist') {
      // Lightning support strike
      c.beginPath();
      c.moveTo(0.15 * u, -0.82 * u);
      c.lineTo(-0.52 * u, 0.08 * u);
      c.lineTo(-0.04 * u, 0.08 * u);
      c.lineTo(-0.22 * u, 0.82 * u);
      c.lineTo(0.52 * u, -0.12 * u);
      c.lineTo(0.04 * u, -0.12 * u);
      c.closePath();
      c.fill();
    }
    c.restore();
  }

  function drawPortraitMedallion(c, key, cx, cy, r, alpha) {
    if (!ART || !ART.img || !ART.img.items || !window.ITEMS) return false;
    const m = window.ITEMS[faceOf(key)];
    if (!m) return false;
    const ir = r * 0.56, iy = cy - r * 0.14;
    c.save();
    c.globalAlpha = alpha;
    c.beginPath();
    c.arc(cx, iy, ir, 0, Math.PI * 2);
    c.clip();
    c.imageSmoothingEnabled = true;
    c.drawImage(ART.img.items, m[0], m[1], m[2], m[3], cx - ir, iy - ir, ir * 2, ir * 2);
    c.restore();
    return true;
  }

  function drawButtonHD(c, b, edit) {
    const st = edit ? { ok: true, progress: 1, alert: false } : info(b.name);
    const down = !edit && held(b.name);
    const col = COLORS[b.name];
    const revertOnly = !edit && b.name === 'form' && G && G.player && G.player.form !== 'h' && !st.alert;
    const rawAlpha = edit ? Math.max(0.6, b.opacity) : down ? Math.min(0.96, b.opacity + 0.35) : b.opacity * (st.ok ? (revertOnly ? 0.58 : 1) : 0.42);
    const cx = OX + b.x * SCALE, cy = OY + b.y * SCALE, cr = b.r * SCALE;
    const t = typeof G !== 'undefined' && G ? G.time : performance.now() / 1000;

    c.save();
    // 1. Contextual pulse halo when ability/sense/transformation is newly ready
    if (!edit && st.alert) {
      const pulse = 0.5 + 0.5 * Math.sin(t * 7.5);
      c.save();
      c.globalAlpha = rawAlpha * (0.25 + 0.35 * pulse);
      c.strokeStyle = col;
      c.lineWidth = Math.max(1.5, 2.2 * SCALE);
      c.beginPath();
      c.arc(cx, cy, cr + (3 + pulse * 4.5) * SCALE, 0, Math.PI * 2);
      c.stroke();
      c.restore();
    }

    // 2. Translucent dark-glass lens body (preserves background visibility!)
    const grad = c.createRadialGradient(cx - cr * 0.28, cy - cr * 0.32, cr * 0.08, cx, cy, cr);
    grad.addColorStop(0, 'rgba(34, 26, 56, ' + (rawAlpha * 0.38).toFixed(3) + ')');
    grad.addColorStop(0.7, 'rgba(12, 9, 24, ' + (rawAlpha * 0.50).toFixed(3) + ')');
    grad.addColorStop(1, 'rgba(6, 4, 14, ' + (rawAlpha * 0.64).toFixed(3) + ')');
    c.fillStyle = grad;
    c.beginPath();
    c.arc(cx, cy, cr, 0, Math.PI * 2);
    c.fill();

    // 3. Top glass specular highlight arc
    c.strokeStyle = 'rgba(255, 255, 255, ' + (rawAlpha * 0.22).toFixed(3) + ')';
    c.lineWidth = Math.max(1, 1.2 * SCALE);
    c.beginPath();
    c.arc(cx, cy, cr * 0.86, -Math.PI * 0.82, -Math.PI * 0.18);
    c.stroke();

    // 4. Outer neon ring + cooldown progress arc
    c.strokeStyle = st.ok ? col : 'rgba(116, 106, 136, 0.55)';
    c.globalAlpha = down ? 0.98 : rawAlpha * (st.ok ? 0.88 : 0.45);
    c.lineWidth = Math.max(1.5, (down ? 2.6 : 1.8) * SCALE);
    c.beginPath();
    c.arc(cx, cy, cr, 0, Math.PI * 2);
    c.stroke();

    if (st.progress < 1 && st.progress > 0) {
      c.strokeStyle = col;
      c.globalAlpha = Math.min(1, rawAlpha * 1.15);
      c.lineWidth = Math.max(2, 2.4 * SCALE);
      c.beginPath();
      c.arc(cx, cy, cr + 1.5 * SCALE, -Math.PI / 2, -Math.PI / 2 + st.progress * Math.PI * 2);
      c.stroke();
    }

    if (down) {
      c.strokeStyle = '#ffffff';
      c.globalAlpha = 0.85;
      c.lineWidth = Math.max(1.5, 1.8 * SCALE);
      c.beginPath();
      c.arc(cx, cy, cr + 3.2 * SCALE, 0, Math.PI * 2);
      c.stroke();
    }

    // 5. Icon or Partner/Form Portrait + Badge
    const iconAlpha = Math.min(1, rawAlpha * 1.28);
    c.globalAlpha = iconAlpha;
    let drewPortrait = false;
    if (!edit && G && G.player && (b.name === 'tag' || b.name === 'assist') && G.ally) {
      drewPortrait = drawPortraitMedallion(c, heroKey(G.ally), cx, cy, cr, iconAlpha * (st.ok ? 0.92 : 0.5));
      // Small corner action badge so Swap and Assist are unmistakably distinct
      const bx = cx + cr * 0.52, by = cy - cr * 0.48, br = Math.max(6, cr * 0.28);
      c.fillStyle = '#0c0818';
      c.beginPath(); c.arc(bx, by, br + 1.5, 0, Math.PI * 2); c.fill();
      c.strokeStyle = col; c.lineWidth = Math.max(1, 1.2 * SCALE);
      c.beginPath(); c.arc(bx, by, br, 0, Math.PI * 2); c.stroke();
      drawVectorIcon(c, b.name, bx, by + br * 0.14, br * 1.1, col, down);
    } else if (!edit && G && G.player && b.name === 'form' && G.player.id === 'lupus') {
      const nextKey = G.player.form === 'h' ? 'lupus_f' : G.player.form === 'f' && G.player.fury >= 200 ? 'lupus_a' : 'lupus_h';
      drewPortrait = drawPortraitMedallion(c, nextKey, cx, cy, cr, iconAlpha * 0.88);
    }
    if (!drewPortrait) {
      drawVectorIcon(c, b.name, cx, cy, cr, st.ok ? col : '#a49bad', down);
    }

    // 6. Crisp Vector Label at bottom of button
    const label = buttonLabel(b, edit);
    const fontSize = Math.max(8, Math.round(Math.min(cr * 0.34, 6.2 * SCALE)));
    c.font = '700 ' + fontSize + 'px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    const ly = cy + cr * 0.56;
    c.lineWidth = Math.max(2, 2.6 * SCALE);
    c.strokeStyle = 'rgba(6, 4, 14, 0.92)';
    c.strokeText(label, cx, ly);
    c.fillStyle = down ? '#ffffff' : st.ok ? '#f6f2ff' : '#a8a0b8';
    c.fillText(label, cx, ly);
    c.restore();

    if (edit && editor && editor.selected === b.name) {
      c.save();
      c.strokeStyle = '#ffffff';
      c.lineWidth = Math.max(1.5, 1.8 * SCALE);
      if (c.setLineDash) c.setLineDash([4 * SCALE, 3 * SCALE]);
      c.beginPath();
      c.arc(cx, cy, (b.hit + 5) * SCALE, 0, Math.PI * 2);
      c.stroke();
      c.restore();
    }
  }

  function drawJoystickHD(c, edit) {
    const b = joystick(), j = Inp.joy, active = !edit && j.id != null;
    const ox = active ? j.ox : b.x, oy = active ? j.oy : b.y;
    const kx = active ? j.x : ox, ky = active ? j.y : oy;
    const rawAlpha = edit ? Math.max(0.55, b.opacity) : active ? Math.min(0.90, b.opacity + 0.24) : b.opacity * 0.65;
    const cx = OX + ox * SCALE, cy = OY + oy * SCALE, cr = b.r * SCALE;
    const ncx = OX + kx * SCALE, ncy = OY + ky * SCALE, nr = cr * 0.38;

    c.save();
    // Translucent glass base
    const grad = c.createRadialGradient(cx, cy, cr * 0.1, cx, cy, cr);
    grad.addColorStop(0, 'rgba(20, 16, 36, ' + (rawAlpha * 0.22).toFixed(3) + ')');
    grad.addColorStop(1, 'rgba(10, 8, 22, ' + (rawAlpha * 0.45).toFixed(3) + ')');
    c.fillStyle = grad;
    c.beginPath();
    c.arc(cx, cy, cr, 0, Math.PI * 2);
    c.fill();

    // Outer bezel + 4 cardinal ticks
    c.strokeStyle = active ? 'rgba(103, 232, 255, ' + (rawAlpha * 0.85).toFixed(3) + ')' : 'rgba(170, 160, 205, ' + (rawAlpha * 0.55).toFixed(3) + ')';
    c.lineWidth = Math.max(1.5, 1.8 * SCALE);
    c.beginPath();
    c.arc(cx, cy, cr, 0, Math.PI * 2);
    c.stroke();

    c.strokeStyle = 'rgba(220, 215, 245, ' + (rawAlpha * 0.35).toFixed(3) + ')';
    c.lineWidth = Math.max(1, 1.3 * SCALE);
    for (let i = 0; i < 4; i++) {
      const a = i * Math.PI / 2;
      c.beginPath();
      c.moveTo(cx + Math.cos(a) * cr * 0.72, cy + Math.sin(a) * cr * 0.72);
      c.lineTo(cx + Math.cos(a) * cr * 0.88, cy + Math.sin(a) * cr * 0.88);
      c.stroke();
    }

    // Stem line when displaced
    if (active && Math.hypot(ncx - cx, ncy - cy) > 2) {
      c.strokeStyle = 'rgba(103, 232, 255, ' + (rawAlpha * 0.55).toFixed(3) + ')';
      c.lineWidth = Math.max(2, 2.5 * SCALE);
      c.beginPath();
      c.moveTo(cx, cy);
      c.lineTo(ncx, ncy);
      c.stroke();
    }

    // Glowing crystal thumb stick
    const nGrad = c.createRadialGradient(ncx - nr * 0.25, ncy - nr * 0.25, nr * 0.1, ncx, ncy, nr);
    nGrad.addColorStop(0, active ? 'rgba(235, 250, 255, ' + Math.min(0.95, rawAlpha * 1.2).toFixed(3) + ')' : 'rgba(205, 198, 230, ' + (rawAlpha * 0.75).toFixed(3) + ')');
    nGrad.addColorStop(1, active ? 'rgba(76, 232, 255, ' + (rawAlpha * 0.85).toFixed(3) + ')' : 'rgba(110, 102, 145, ' + (rawAlpha * 0.58).toFixed(3) + ')');
    c.fillStyle = nGrad;
    c.beginPath();
    c.arc(ncx, ncy, nr, 0, Math.PI * 2);
    c.fill();
    c.strokeStyle = active ? '#ffffff' : 'rgba(230, 225, 250, ' + (rawAlpha * 0.65).toFixed(3) + ')';
    c.lineWidth = Math.max(1.2, 1.5 * SCALE);
    c.stroke();
    c.restore();

    if (edit && editor && editor.selected === 'joy') {
      c.save();
      c.strokeStyle = '#ffffff';
      c.lineWidth = Math.max(1.5, 1.8 * SCALE);
      if (c.setLineDash) c.setLineDash([4 * SCALE, 3 * SCALE]);
      c.beginPath();
      c.arc(cx, cy, (b.r + 5) * SCALE, 0, Math.PI * 2);
      c.stroke();
      c.restore();
    }
  }

  function drawHD(c) {
    if (Scene.name === 'controls' && editor) {
      drawJoystickHD(c, true);
      const B = buttons();
      for (const n of ACTIONS) drawButtonHD(c, B[n], true);
      return;
    }
    if (Scene.name !== 'play' || !G || G.over > 0 || Scenes.play.menu || G.panel || G.choice || G.nachtBeat90 || (G.superFx && (G.superFx.v90 || G.superFx.t < 1.05)) || (G.cineBar || 0) > 0.5) return;
    if (mode.input === 'pad' && pad.connected) return;
    drawJoystickHD(c, false);
    const B = buttons();
    for (const n of ACTIONS) if (visible(n)) drawButtonHD(c, B[n], false);
  }

  function menuTargets() {
    const s = Scene.cur, name = Scene.name, out = [];
    if (!s) return out;
    const add = (b, prefix) => { if (b && Number.isFinite(b.x) && Number.isFinite(b.y) && b.w > 0 && b.h > 0 && b.y + b.h > 3 && b.y < VH - 3) out.push(Object.assign({}, b, { key: prefix + (b.id == null ? out.length : b.id) })); };
    if (name === 'play') { if (G && G.choice) return choiceRects().map((b, i) => Object.assign({ key: 'choice' + i }, b)); if (s.menu) (s.btns || []).forEach(b => add(b, 'pause')); return out; }
    if (name === 'title' && !s.opts) { (s.items || []).forEach(b => add(b, 'title')); return out; }
    if (name === 'lair' && s.view >= 0) return [{ key: 'previous', x: 0, y: 30, w: VW * 0.24, h: VH - 40 }, { key: 'close', x: VW * 0.4, y: 30, w: VW * 0.2, h: VH - 40 }, { key: 'next', x: VW * 0.76, y: 30, w: VW * 0.24, h: VH - 40 }];
    (s.cards || []).forEach((b, i) => { if (name === 'stages' && b.i + 1 > SAVE.unlocked) return; if (name === 'select' && s.avail && !s.avail.includes(b.id)) return; add(Object.assign({ id: i }, b), 'card'); });
    (s.tabs || []).forEach(b => add(b, 'tab'));
    (s.btns || []).forEach(b => add(b, 'btn'));
    for (const it of s.items || []) {
      if (it.b) add(it.b, 'item'); if (it.skB) add(it.skB, 'skin');
      if ((it.kind === 'gal' || it.kind === 'arch') && it.y + it.h >= 52 && it.y < VH - 12) add(Object.assign({ id: it.i }, it), 'item');
      if (it.sw) it.sw.forEach((b, i) => add(Object.assign({ id: String(it.id) + i }, b), 'swatch'));
    }
    if (s.back && !(s.btns || []).includes(s.back)) add(s.back, 'back');
    if (s.goB) add(s.goB, 'go'); if (s.ngpB) add(s.ngpB, 'ngp'); if (s.btn) add(s.btn, 'continue');
    if (name === 'clear') (s.opts || []).forEach((b, i) => add(Object.assign({ id: i }, b), 'option'));
    return out;
  }
  function focusTarget() { const list = menuTargets(); return list.find(b => b.key === pad.focus) || list[0] || null; }
  function menuMove(dx, dy) {
    const list = menuTargets(); if (!list.length) return;
    const cur = list.find(b => b.key === pad.focus) || list[0], cx = cur.x + cur.w / 2, cy = cur.y + cur.h / 2;
    let next = null, score = Infinity;
    for (const b of list) {
      if (b.key === cur.key) continue;
      const x = b.x + b.w / 2 - cx, y = b.y + b.h / 2 - cy, along = x * dx + y * dy, cross = Math.abs(x * dy - y * dx);
      if (along < 4) continue;
      const cost = along + cross * 2.4;
      if (cost < score) { score = cost; next = b; }
    }
    if (!next && Scene.name === 'lair' && dy && typeof Scene.cur.scroll === 'number') {
      if (Scene.cur.onWheel) Scene.cur.onWheel(dy * 54); else { Scene.cur.scroll = Math.max(0, Scene.cur.scroll + dy * 54); Scene.cur.layout(); }
      const after = menuTargets().filter(b => b.key.startsWith('item')); next = dy > 0 ? after[after.length - 1] : after[0];
    }
    if (!next) next = list.reduce((a, b) => ((b.x + b.w / 2) * dx + (b.y + b.h / 2) * dy) < ((a.x + a.w / 2) * dx + (a.y + a.h / 2) * dy) ? b : a, cur);
    pad.focus = next.key;
    if (Scene.name === 'title' && !Scene.cur.opts) { const i = Scene.cur.items.findIndex(b => 'title' + b.id === next.key); if (i >= 0) Scene.cur.sel = i; }
    sfx('ui');
  }
  function clickFocus() {
    const s = Scene.cur; if (s && s.layout) s.layout();
    if (Scene.name === 'play' && G && G.panel) { panelAdvance(); return; }
    const b = focusTarget();
    if (!b) {
      if (['load', 'prep', 'title', 'stages', 'select', 'lair', 'over', 'modeEnd', 'clear'].includes(Scene.name)) return;
      if (s && s.onKey) s.onKey('ok'); else if (s && s.onDown) s.onDown(-99, VW / 2, VH / 2); return;
    }
    const x = b.x + b.w / 2, y = b.y + b.h / 2;
    if (s.onDown) s.onDown(-99, x, y);
    if (Scene.cur === s && s.onUp) s.onUp(-99, x, y);
  }
  function menuBack() {
    if (editor) { closeEditor(false); return; }
    if (Scene.name === 'play') { if (Scenes.play.menu) Scenes.play.onKey('pause'); return; }
    if (Scene.name === 'comic' || Scene.name === 'intro') { if (Scene.cur.onKey) Scene.cur.onKey('ok'); return; }
    const list = menuTargets(), b = list.find(it => /back|close/i.test(it.key));
    if (b && Scene.cur.onDown) { const s = Scene.cur, x = b.x + b.w / 2, y = b.y + b.h / 2; s.onDown(-99, x, y); if (Scene.cur === s && s.onUp) s.onUp(-99, x, y); return; }
    if (Scene.name === 'title') { if (Scene.cur.langPick) Scene.cur.langPick = false; else Scene.cur.opts = false; return; }
    if (!['load', 'clear', 'prep'].includes(Scene.name)) Scene.go('title');
  }
  function sample() {
    if (pad.native && pad.native.connected) return pad.native;
    try { const p = navigator.getGamepads && Array.from(navigator.getGamepads() || []).find(g => g && g.connected !== false); if (p) return p; } catch (_) { }
    return null;
  }
  const pressed = b => typeof b === 'object' && b ? !!b.pressed || b.value > 0.45 : typeof b === 'number' ? b > 0.45 : !!b;
  function readPad(dt) {
    if (typeof G !== 'undefined' && G) {
      if ((G.senseTapT || 0) > 0) G.senseTapT = Math.max(0, G.senseTapT - dt);
      if ((G.senseGrace || 0) > 0) G.senseGrace = Math.max(0, G.senseGrace - dt);
      if (G.sensing) G.senseGrace = Math.max(G.senseGrace || 0, 3.5);
    }
    mode.padHint = Math.max(0, mode.padHint - dt);
    if (Scene.cur && Scene.cur.freeInput90) pad.edges = {};
    const s = sample();
    if (!s || pad.suspended) {
      if (pad.connected && !s && mode.input === 'pad') mode.input = 'touch';
      pad.connected = !!s; pad.held = {}; pad.edges = {}; pad.axes = [0, 0]; pad.prior = []; return;
    }
    pad.connected = true; pad.id = String(s.id || 'Controller');
    const raw = Array.from({ length: 16 }, (_, i) => pressed((s.buttons || [])[i])), edge = raw.map((b, i) => b && !pad.prior[i] || !!pad.pending[i]); pad.pending = []; pad.prior = raw;
    let x = clamp(finite(s.axes && s.axes[0], 0), -1, 1), y = clamp(finite(s.axes && s.axes[1], 0), -1, 1), mag = Math.hypot(x, y);
    if (mag < 0.2) x = y = 0; else { const v = Math.min(1, (mag - 0.2) / 0.8); x = x / mag * v; y = y / mag * v; }
    if (raw[14] || raw[15]) x = (raw[15] ? 1 : 0) - (raw[14] ? 1 : 0);
    if (raw[12] || raw[13]) y = (raw[13] ? 1 : 0) - (raw[12] ? 1 : 0);
    pad.axes = [x, y];
    if (edge.some(Boolean) || Math.hypot(x, y) > 0.25) { if (mode.input !== 'pad') { mode.padHint = 4; resetTouch(); } mode.input = 'pad'; audioInit(); }
    pad.held = {}; for (const index in MAP) { const n = MAP[index]; pad.held[n] = raw[index]; if (edge[index]) pad.edges[n] = true; }
    if (edge[9]) {
      if (Scene.cur && Scene.cur.freeInput90 && Scene.cur.onKey) Scene.cur.onKey('pause'); else if (Scene.name === 'play') Scenes.play.onKey('pause'); else if (editor) closeEditor(true); else clickFocus();
      pad.edges = {}; return;
    }
    const navigating = !(Scene.cur && Scene.cur.freeInput90) && (Scene.name !== 'play' || Scenes.play.menu || G && (G.choice || G.panel));
    if (navigating) {
      pad.edges = {};
      if (editor) {
        if (edge[1]) { closeEditor(false); return; }
        if (edge[0]) { const names = ACTIONS.concat('joy'); editor.selected = names[(names.indexOf(editor.selected) + 1) % names.length]; syncEditor(); }
        if (edge[4] || edge[5]) changeSelected('size', (edge[5] ? 1 : -1) * 0.05);
        if (Math.abs(x) + Math.abs(y) > 0.1) moveSelected(x * dt * 95, y * dt * 95);
        return;
      }
      const dir = Math.abs(x) > Math.abs(y) ? (x > 0.5 ? 'r' : x < -0.5 ? 'l' : '') : (y > 0.5 ? 'd' : y < -0.5 ? 'u' : '');
      if (dir !== pad.direction) { pad.direction = dir; pad.repeat = 0; }
      pad.repeat -= dt;
      if (dir && pad.repeat <= 0) { menuMove(dir === 'r' ? 1 : dir === 'l' ? -1 : 0, dir === 'd' ? 1 : dir === 'u' ? -1 : 0); pad.repeat = pad.repeat < -0.06 ? 0.32 : 0.16; }
      if (edge[0] || edge[2]) clickFocus();
      else if (edge[1] || edge[8]) menuBack();
    }
  }
  window.LupusGamepad = {
    update(value) {
      let s = value; if (typeof s === 'string') { try { s = JSON.parse(s); } catch (_) { return; } }
      if (!s || !s.connected) { pad.native = null; pad.nativePrior = []; pad.pending = []; pad.axes = [0, 0]; pad.held = {}; pad.edges = {}; return; }
      const b = Array.from({ length: 16 }, (_, i) => pressed((s.buttons || [])[i]));
      b.forEach((down, i) => { if (down && !pad.nativePrior[i]) pad.pending[i] = true; }); pad.nativePrior = b;
      pad.native = { connected: true, id: String(s.id || 'Android controller'), axes: Array.from(s.axes || [0, 0]), buttons: b };
    }
  };
  function installScene(s) {
    if (!s || s.__controls9) return;
    Object.defineProperty(s, '__controls9', { value: true });
    const update = s.update, draw = s.draw;
    s.update = function (dt) { readPad(dt); if (Scene.cur !== this) return; if (update) update.call(this, dt); };
    s.draw = function (g) {
      if (Scene.cur !== this) return;
      if (draw) draw.call(this, g);
      if (Scene.cur !== this || this.freeInput90 || mode.input !== 'pad' || editor || Scene.name === 'play' && !this.menu && !(G && G.choice)) return;
      const b = focusTarget(); if (!b) return;
      g.save(); g.strokeStyle = '#f1e09b'; g.lineWidth = 1; g.strokeRect(b.x - 2, b.y - 2, b.w + 4, b.h + 4); g.restore();
    };
  }
  const immediateGo = Scene._go;
  if (immediateGo) Scene._go = function () { const r = immediateGo.apply(this, arguments); installScene(Scene.cur); return r; };
  for (const s of Object.values(Scenes)) installScene(s);
  const sceneGo = Scene.go;
  Scene.go = function (name, arg) {
    if (editor && name !== 'controls') removeEditor();
    pad.focus = ''; pad.edges = {}; pad.direction = ''; pad.repeat = 0;
    const result = sceneGo.call(this, name, arg); installScene(Scene.cur); return result;
  };

  function selectedSettings() {
    const name = editor.selected;
    if (name === 'joy') return editor.draft.joy;
    if (!editor.draft.buttons[name]) editor.draft.buttons[name] = {};
    return editor.draft.buttons[name];
  }
  function syncEditor() {
    if (!editor || !editor.dom) return;
    const it = selectedSettings(), dom = editor.dom;
    const gOp = Math.round(clamp(editor.draft.opacity, 0.15, 1) * 100);
    const bOp = Math.round(clamp(editor.draft.opacity * (it.opacity || 1), 0.15, 1) * 100);
    dom.querySelector('[data-control="selection"]').value = editor.selected;
    dom.querySelector('[data-control="preset"]').value = editor.draft.preset;
    dom.querySelector('[data-control="size"]').value = Math.round((it.size || 1) * 100);
    dom.querySelector('[data-control="opacity"]').value = bOp;
    dom.querySelector('[data-control="mode"]').value = editor.draft.joystick;
    dom.querySelector('[data-control="hand"]').textContent = editor.draft.left ? tr('Canhoto', 'Left-handed') : tr('Destro', 'Right-handed');
    dom.querySelector('[data-control="size-value"]').textContent = Math.round((it.size || 1) * 100) + '%';
    dom.querySelector('[data-control="opacity-value"]').textContent = bOp + '%';
    const gSlider = dom.querySelector('[data-control="global-opacity"]');
    if (gSlider) gSlider.value = gOp;
    const gVal = dom.querySelector('[data-control="global-opacity-value"]');
    if (gVal) gVal.textContent = gOp + '% (' + (100 - gOp) + '% ' + tr('transp.', 'transp.') + ')';
    const ctxSel = dom.querySelector('[data-control="contextual"]');
    if (ctxSel) ctxSel.value = editor.draft.contextual === false ? 'all' : 'smart';
  }
  function changeSelected(field, value, absolute) {
    if (!editor) return;
    const it = selectedSettings();
    it[field] = clamp(absolute ? value : (it[field] || 1) + value, field === 'size' ? 0.8 : 0.15, field === 'size' ? 1.5 : 4);
    syncEditor();
  }
  function setGlobalOpacity(alpha) {
    if (!editor) { SAVE.controls.opacity = clamp(finite(alpha, 0.48), 0.15, 1); saveGame(); return; }
    editor.draft.opacity = clamp(finite(alpha, 0.48), 0.15, 1);
    syncEditor();
  }
  function moveSelected(dx, dy) {
    const name = editor.selected, b = name === 'joy' ? joystick() : buttons()[name], it = selectedSettings(), m = metrics(), r = Math.max(b.r + 4, b.hit);
    it.x = clamp(b.x + dx, m.l + r, VW - m.r - r) / VW; it.y = clamp(b.y + dy, m.t + r, VH - m.b - r) / VH;
  }
  function applyPreset(name) {
    if (!Object.prototype.hasOwnProperty.call(PRESETS, name)) return false;
    const old = config(), next = defaults();
    next.preset = name; next.left = old.left; next.joystick = old.joystick; next.opacity = old.opacity; next.contextual = old.contextual !== false;
    for (const n of ACTIONS) if (old.buttons[n] && Number.isFinite(old.buttons[n].opacity)) next.buttons[n] = { opacity: old.buttons[n].opacity };
    if (Number.isFinite(old.joy.opacity)) next.joy.opacity = old.joy.opacity;
    if (editor) { editor.draft = next; syncEditor(); } else { SAVE.controls = next; saveGame(); }
    return true;
  }
  function flipHandedness() {
    const cfg = config(); cfg.left = !cfg.left;
    for (const n of ACTIONS.concat('joy')) { const it = n === 'joy' ? cfg.joy : cfg.buttons[n]; if (it && Number.isFinite(it.x)) it.x = 1 - it.x; }
    if (editor) syncEditor(); else saveGame();
    return cfg.left;
  }
  function editorDOM() {
    const host = document.createElement('div'); host.id = 'lupus-control-editor';
    host.style.cssText = 'position:fixed;inset:0;z-index:40;pointer-events:none;color:#f0edf8;font:14px system-ui,sans-serif';
    host.innerHTML = '<style>#lupus-control-editor *{box-sizing:border-box}#lupus-control-editor button,#lupus-control-editor select{min-width:48px;min-height:48px;font:600 13px system-ui,sans-serif;color:#eeeaf7;background:#211a30;border:1px solid #645676;border-radius:9px;padding:7px 11px;touch-action:manipulation}#lupus-control-editor button:focus-visible,#lupus-control-editor select:focus-visible{outline:3px solid #8be8ef}#lupus-control-editor label{display:block;margin:8px 0 4px;color:#c6bed5;font-weight:600;font-size:12.5px}#lupus-control-editor input{width:100%;min-width:48px;min-height:48px;accent-color:#ff4866;touch-action:pan-x}#lupus-control-editor select{width:100%}#lupus-control-editor .c9-bar{pointer-events:auto;position:absolute;left:max(8px,env(safe-area-inset-left));right:max(8px,env(safe-area-inset-right));top:max(6px,env(safe-area-inset-top));display:flex;align-items:center;gap:8px;padding:6px 10px;background:#100d1ceb;border:1px solid #54425e;border-radius:12px}#lupus-control-editor .c9-bar strong{flex:1;min-width:0;font-size:15px;line-height:1.15}#lupus-control-editor .c9-bar button{flex-shrink:0}#lupus-control-editor .c9-tools{pointer-events:auto;position:absolute;top:68px;left:max(8px,env(safe-area-inset-left));width:min(326px,46vw);max-height:calc(100% - 82px);overflow:auto;overscroll-behavior:contain;touch-action:pan-y;background:#100d1cf2;border:1px solid #644d73;border-radius:12px;padding:12px;box-shadow:0 8px 28px rgba(0,0,0,0.65)}#lupus-control-editor .c9-row{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:6px}#lupus-control-editor .c9-row button{flex:1 1 78px;min-height:48px;font-size:12px;padding:5px 8px}#lupus-control-editor p{font-size:12px;line-height:1.4;color:#b8afc9;margin:8px 0 0}@media(max-height:400px){#lupus-control-editor .c9-tools{max-height:calc(100% - 76px);width:min(310px,48vw);padding:10px}#lupus-control-editor label{margin-top:6px}}</style>';
    const bar = document.createElement('div'); bar.className = 'c9-bar';
    const cancel = document.createElement('button'); cancel.textContent = tr('Voltar', 'Back'); cancel.onclick = () => closeEditor(false);
    const title = document.createElement('strong'); title.textContent = tr('Personalizar Controles e Transparência', 'Customize Controls & Transparency');
    const toggle = document.createElement('button'); toggle.textContent = tr('Ajustes', 'Settings');
    const save = document.createElement('button'); save.textContent = tr('Salvar', 'Save'); save.style.background = '#963048'; save.onclick = () => closeEditor(true);
    bar.append(cancel, title, toggle, save); host.appendChild(bar);
    const panel = document.createElement('div'); panel.className = 'c9-tools';
    const label = (text, el) => { const lab = document.createElement('label'); lab.textContent = text; panel.appendChild(lab); panel.appendChild(el); };

    /* 1. Global Transparency / Opacity slider + Quick Presets */
    const gLab = document.createElement('label');
    gLab.textContent = tr('Visibilidade Geral (Transparência): ', 'Global Visibility (Transparency): ');
    const gVal = document.createElement('span'); gVal.dataset.control = 'global-opacity-value'; gLab.appendChild(gVal);
    panel.appendChild(gLab);
    const gSlider = document.createElement('input');
    gSlider.type = 'range'; gSlider.min = 15; gSlider.max = 100; gSlider.step = 5;
    gSlider.dataset.control = 'global-opacity';
    gSlider.setAttribute('aria-label', tr('Visibilidade geral dos botões', 'Global button visibility'));
    gSlider.oninput = () => setGlobalOpacity(Number(gSlider.value) / 100);
    panel.appendChild(gSlider);

    const tRow = document.createElement('div'); tRow.className = 'c9-row';
    for (const [val, txt] of [[0.28, tr('Muito Suave (28%)', 'Ultra Light (28%)')], [0.48, tr('Padrão (48%)', 'Default (48%)')], [0.78, tr('Forte (78%)', 'Solid (78%)')]]) {
      const tb = document.createElement('button'); tb.textContent = txt;
      tb.onclick = () => setGlobalOpacity(val);
      tRow.appendChild(tb);
    }
    panel.appendChild(tRow);

    /* 2. Contextual Smart Buttons Toggle */
    const ctxSelect = document.createElement('select'); ctxSelect.dataset.control = 'contextual';
    for (const [id, text] of [['smart', tr('Inteligente (Só mostra Forma/Sentidos/Super prontos)', 'Smart (Show Form/Senses/Super when ready)')], ['all', tr('Mostrar todos os botões sempre', 'Always show all buttons')]]) {
      const op = document.createElement('option'); op.value = id; op.textContent = text; ctxSelect.appendChild(op);
    }
    ctxSelect.onchange = () => { editor.draft.contextual = ctxSelect.value !== 'all'; syncEditor(); };
    label(tr('Botões Secundários na Tela', 'Secondary Screen Buttons'), ctxSelect);

    /* 3. Layout Preset */
    const presets = document.createElement('select'); presets.dataset.control = 'preset'; presets.setAttribute('aria-label', tr('Preset de controles', 'Control preset'));
    for (const [id, text] of [['standard', tr('Padrão', 'Standard')], ['compact', tr('Compacto', 'Compact')], ['large', tr('Grande', 'Large')], ['tablet', tr('Tablet', 'Tablet')], ['arcade', tr('Arcade (combos direcionais)', 'Arcade (directional combos)')]]) {
      const op = document.createElement('option'); op.value = id; op.textContent = text; presets.appendChild(op);
    }
    presets.onchange = () => applyPreset(presets.value); label(tr('Tamanho do Layout', 'Layout Preset'), presets);

    /* 4. Individual Control Selection + Size + Individual Opacity */
    const selection = document.createElement('select'); selection.dataset.control = 'selection'; selection.setAttribute('aria-label', tr('Controle selecionado', 'Selected control'));
    for (const n of ACTIONS.concat('joy')) {
      const option = document.createElement('option'); option.value = n; option.textContent = tr(FULL_PT[n], FULL_EN[n]); selection.appendChild(option);
    }
    selection.onchange = () => { editor.selected = selection.value; syncEditor(); };
    label(tr('Botão Selecionado (ou arraste na tela)', 'Selected Button (or drag on screen)'), selection);

    for (const [key, text, min, max] of [['size', tr('Tamanho deste Botão', 'Selected Button Size'), 80, 150], ['opacity', tr('Opacidade deste Botão', 'Selected Button Opacity'), 15, 100]]) {
      const lab = document.createElement('label'); lab.textContent = text + ': '; const value = document.createElement('span'); value.dataset.control = key + '-value'; lab.appendChild(value); panel.appendChild(lab);
      const slider = document.createElement('input'); slider.type = 'range'; slider.min = min; slider.max = max; slider.step = 5; slider.dataset.control = key; slider.setAttribute('aria-label', text);
      slider.oninput = () => { const v = Number(slider.value) / 100; changeSelected(key, key === 'opacity' ? v / editor.draft.opacity : v, true); }; panel.appendChild(slider);
    }

    const joy = document.createElement('select'); joy.dataset.control = 'mode'; joy.setAttribute('aria-label', tr('Modo do analógico', 'Joystick mode'));
    for (const [id, text] of [['floating', tr('Flutuante', 'Floating')], ['fixed', tr('Fixo', 'Fixed')]]) {
      const op = document.createElement('option'); op.value = id; op.textContent = text; joy.appendChild(op);
    }
    joy.onchange = () => { editor.draft.joystick = joy.value; syncEditor(); }; label(tr('Modo do Analógico', 'Joystick Mode'), joy);

    const row = document.createElement('div'); row.className = 'c9-row';
    const hand = document.createElement('button'); hand.dataset.control = 'hand'; hand.onclick = flipHandedness;
    const reset = document.createElement('button'); reset.textContent = tr('Restaurar Padrão', 'Reset Default'); reset.onclick = () => { editor.draft = defaults(); syncEditor(); };
    row.append(hand, reset); panel.appendChild(row);

    const hint = document.createElement('p');
    hint.textContent = tr('Feche Ajustes para arrastar os botões. Duelos: combo com ATACAR, bloqueio no impacto para contra-atacar, DASH cancela o golpe. Arcade: cima + ATACAR dá um finalizador forte; baixo + ATACAR varre. Chefes permanecem no chão.', 'Close Settings to drag buttons. Duels: ATTACK chains, block on impact to counter, DASH cancels a strike. Arcade: up + ATTACK is a heavy finisher; down + ATTACK sweeps. Bosses stay grounded.');
    panel.appendChild(hint);
    toggle.onclick = () => { panel.hidden = !panel.hidden; toggle.setAttribute('aria-expanded', String(!panel.hidden)); };
    host.appendChild(panel); document.body.appendChild(host); editor.dom = host; syncEditor();
    if (window.innerHeight < 480) panel.hidden = true;
    toggle.setAttribute('aria-expanded', String(!panel.hidden));
  }
  function removeEditor() { if (editor && editor.dom) editor.dom.remove(); editor = null; }
  function closeEditor(save) {
    if (!editor) return;
    const prev = editor.previous;
    if (save) { SAVE.controls = normalize(editor.draft); saveGame(); sfx('ok'); }
    removeEditor(); Inp.reset(); pad.focus = ''; pad.edges = {}; mode.input = 'touch';
    Scene.cur = prev.scene; Scene.name = prev.name; Scene.fade = 0.6; installScene(Scene.cur);
  }
  Scenes.controls = {
    enter(arg) { editor = { previous: arg.previous, draft: normalize(SAVE.controls), selected: 'atk', drag: null, dom: null, t: 0 }; editorDOM(); },
    update(dt) { if (editor) editor.t += dt; },
    draw(g) {
      g.fillStyle = '#0b0912'; g.fillRect(0, 0, VW, VH);
      g.strokeStyle = '#1e192b'; g.lineWidth = 1;
      for (let x = 0; x < VW; x += 24) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, VH); g.stroke(); }
      for (let y = 0; y < VH; y += 24) { g.beginPath(); g.moveTo(0, y); g.lineTo(VW, y); g.stroke(); }
      const m = metrics(); g.strokeStyle = '#564167'; g.strokeRect(m.l, m.t, VW - m.l - m.r, VH - m.t - m.b);
      if (window.__inFrameDraw && window.ControlsUI && ControlsUI.drawHD) return;
      drawJoystick(g, true); const B = buttons(); for (const n of ACTIONS) drawButton(g, B[n], true);
    },
    onDown(id, x, y) {
      const b = nearest(x, y, true); if (!b) return;
      editor.selected = b.name; editor.drag = { id, dx: x - b.x, dy: y - b.y }; syncEditor();
    },
    onMove(id, x, y) {
      if (!editor || !editor.drag || editor.drag.id !== id) return;
      const b = editor.selected === 'joy' ? joystick() : buttons()[editor.selected]; moveSelected(x - editor.drag.dx - b.x, y - editor.drag.dy - b.y);
    },
    onUp(id) { if (editor && editor.drag && editor.drag.id === id) editor.drag = null; },
    onKey(key) { if (key === 'pause') closeEditor(false); else if (key === 'ok') closeEditor(true); }
  };
  window.ControlsUI = {
    open() { if (editor) return; const previous = { name: Scene.name, scene: Scene.cur }; resetTouch(); Scene.go('controls', { previous }); },
    close: closeEditor, buttons, joystick, metrics, visible, drawHD, setGlobalOpacity, focusTarget,
    focusRect: () => mode.input === 'pad' && pad.connected ? focusTarget() : null,
    state: () => ({ input: mode.input, connected: pad.connected, id: pad.id, held: Object.assign({}, pad.held), edges: Object.assign({}, pad.edges), axes: pad.axes.slice(), editing: !!editor, focus: pad.focus }),
    normalize, applyPreset, flipHandedness, reset() { SAVE.controls = defaults(); saveGame(); }
  };
}());
