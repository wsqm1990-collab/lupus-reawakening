'use strict';
/* =====================================================================
   GAME: entities, physics, combat, AI, bosses, projectiles, particles
   World units = low-res pixels. Lane depth y in [LANE_T, LANE_B].
   ===================================================================== */
const GRAV = 820;
let G = null;

function newE(o) {
  return Object.assign({ x: 0, y: 230, z: 0, vx: 0, vy: 0, vz: 0, face: 1, hp: 100, maxhp: 100, st: 'idle', t: 0, ct: 0, inv: 0, flash: 0, dead: false, deadT: 0, poise: 0, team: 'e', shieldHP: 0, shieldT: 0, bleedT: 0, bleedD: 0, cd: 0.5, jug: 0, hr: 11 }, o);
}
const upMul = () => 1 + 0.15 * SAVE.up.dmg;
function setSt(e, st, t) { if (e.st !== st) e.ct = 0; e.st = st; if (t != null) e.t = t; }

function makeHero(id, isPlayer, x, y) {
  const d = HERO[id], maxhp = Math.round(d.hp * (1 + 0.2 * SAVE.up.hp));
  return newE({ kind: 'hero', id, team: 'p', isPlayer, x, y, hp: maxhp, maxhp, fury: 0, form: 'h', spCd: 0, dashCd: 0, chainT: 0, idx: 0, atkT: 0, atkDur: 0.25, hitDone: false, queued: false, air: false, aiT: 0, lastHurt: 9, hr: 10 });
}
function hs(h) {
  const m = upMul(), cdm = 1 - 0.2 * SAVE.up.cd;
  if (h.id === 'lupus') { const f = FORM[h.form]; return { dmg: f.dmg * m, reach: f.reach, dur: f.dur, armor: f.armor, regen: f.regen, spd: f.spd, cd: f.cd * cdm }; }
  const d = HERO[h.id]; return { dmg: d.dmg * m, reach: d.reach, dur: d.dur, armor: d.armor || 0, regen: 0, spd: d.spd, cd: d.cd * cdm };
}
const heroKey = h => h.id === 'lupus' ? FORM[h.form].key : HERO[h.id].key;

/* ---------- world ---------- */
function newGame(si) {
  const st = STAGES[si];
  G = {
    stage: si, st, heroes: [], enemies: [], props: [], proj: [], parts: [], slashes: [], rings: [], texts: [], drops: [], lines: [], flashes: [],
    camX: 0, locked: false, waveIdx: 0, spawnQ: [], score: 0, combo: 0, comboT: 0, maxCombo: 0, time: 0, shake: 0, hitstop: 0, flashScr: 0,
    tok: 0, banner: null, title: 2.8, say: null, sayT: 0, bossSpawned: false, bossPending: false, boss: null, over: 0, clearT: 0, slow: 1, goT: 0, hintT: si === 0 ? 11 : 0, kills: 0, lastE: null, lastET: 0,
    leaving: [], tagCd: 0, assistCd: 0, autoTag: 0, lastHitT: -9
  };
  const p = makeHero(SAVE.hero, true, 70, 232), a = makeHero(SAVE.ally, false, 40, 250);
  /* tag team: only the active hero is on the field; the partner waits off-screen (G.ally) */
  a.bench = true; G.player = p; G.ally = a; G.team = [p, a]; G.heroes = [p];
  for (const x of st.props || []) G.props.push(newE({ kind: 'prop', team: 'n', key: Math.random() < 0.5 ? 'crate' : 'barrel', x, y: rnd(LANE_T + 6, LANE_B - 6), hp: 60, maxhp: 60, hr: 10 }));
  if (st.say) { G.sayQ = st.say; G.sayDelay = 2.8; }
  return G;
}
const aliveHeroes = () => G.heroes.filter(h => !h.dead);
function nearestHero(e) { let b = null, bd = 1e9; for (const h of G.heroes) { if (h.dead || h.st === 'down') continue; let d = dist(e, h); if (h.isPlayer) d *= 0.8; if (d < bd) { bd = d; b = h; } } return b || G.player; }
function nearestEnemy(a, maxd) { let b = null, bd = maxd || 1e9; for (const e of G.enemies) { if (e.dead) continue; const d = dist(a, e); if (d < bd) { bd = d; b = e; } } return b; }
const enemiesAlive = () => G.enemies.filter(e => !e.dead).length;

function spawnEnemy(type, side) {
  const def = ENEMY[type]; const sc = 1 + 0.14 * G.stage;
  const x = side < 0 ? G.camX - 30 : G.camX + VW + 30, y = rnd(LANE_T + 4, LANE_B - 2);
  const e = newE({ kind: 'enemy', type, def, key: def.key, x, y, face: side < 0 ? 1 : -1, hp: def.hp * sc, maxhp: def.hp * sc, ai: 'move', aiT: rnd(0, 0.5), cd: rnd(0.3, 1.4), hr: def.hr, poiseMax: def.heavy ? def.hp * 0.4 : 1, blocking: false, arrive: true, dm: sc });
  G.enemies.push(e); return e;
}
function spawnBoss(id) {
  const def = BOSS[id];
  const e = newE({ kind: 'boss', type: id, def, key: def.key, x: G.camX + VW + 70, y: 232, face: -1, hp: def.hp, maxhp: def.hp, pat: null, pi: 0, cd: 1.2, hr: def.hr, poiseMax: def.hp * 0.12, p2: false, frame: 'idle', dm: 1 + 0.12 * G.stage, bossIn: 1.6, fade: 1 });
  G.enemies.push(e); G.boss = e; G.bossSpawned = true; return e;
}

/* ---------- fx ---------- */
function blood(x, y, z, n, col) { for (let i = 0; i < n; i++) G.parts.push({ x, y, z, vx: rnd(-90, 90), vy: rnd(-12, 12), vz: rnd(40, 170), life: rnd(0.4, 0.9), t: 0, col: col || (Math.random() < 0.7 ? '#b0001c' : '#ff2a44'), size: Math.random() < 0.3 ? 2 : 1, grav: 520, stick: true }); }
function sparks(x, y, z, n, col) { for (let i = 0; i < n; i++) { const a = rnd(0, 6.28), s = rnd(60, 190); G.parts.push({ x, y, z, vx: Math.cos(a) * s, vy: 0, vz: Math.sin(a) * s * 0.7 + 30, life: rnd(0.12, 0.3), t: 0, col: col || '#fff', size: 1, grav: 160 }); } }
function dust(x, y, n, col) { for (let i = 0; i < n; i++) G.parts.push({ x: x + rnd(-6, 6), y: y + rnd(-2, 2), z: 1, vx: rnd(-40, 40), vy: 0, vz: rnd(10, 40), life: rnd(0.25, 0.5), t: 0, col: col || '#8a8098', size: Math.random() < 0.4 ? 2 : 1, grav: 60, dust: true }); }
function debris(x, y, tag, n) { const pcs = Object.keys(window.ITEMS).filter(k => k.startsWith(tag)); for (let i = 0; i < n; i++) G.parts.push({ x, y, z: rnd(4, 20), vx: rnd(-110, 110), vy: rnd(-20, 20), vz: rnd(80, 220), life: rnd(1.6, 2.4), t: 0, img: pcs[i % pcs.length], rot: rnd(0, 6), vr: rnd(-12, 12), col: '#000', size: 1, grav: 620, bounce: 0.4 }); }
function slashFx(x, y, z, face, col, size, ang, dur) { G.slashes.push({ x, y, z, face, col: col || '#ff2a40', size: size || 30, ang: ang || 0, t: 0, dur: dur || 0.18 }); }
function ringFx(x, y, z, rmax, col, dur) { G.rings.push({ x, y, z: z || 0, rmax, col: col || '#ff2a40', t: 0, dur: dur || 0.4 }); }
function hitFlash(x, y, z, big, col) { G.flashes.push({ x, y, z, t: 0, dur: big ? 0.16 : 0.1, big, col: col || '#ffffff' }); }
function textFx(x, y, s, col, size) { G.texts.push({ x, y, s, col: col || '#fff', size: size || 1, t: 0, vy: -26 }); }
const shake = v => { G.shake = Math.max(G.shake, v); };
const freeze = t => { G.hitstop = Math.max(G.hitstop, t); };

/* ---------- damage ---------- */
const facingTo = (tg, att) => (att.x - tg.x) * tg.face >= 0;
function hurt(att, tg, dmg, o) {
  o = o || {};
  if (tg.dead) return false;
  if (tg.kind === 'prop') { tg.hp -= dmg; tg.flash = 1; tg.vx += (att.x < tg.x ? 1 : -1) * 30; sparks(tg.x, tg.y, 12, 5, '#d8b070'); sfx('hit'); shake(2); if (tg.hp <= 0) breakProp(tg); return true; }
  if (tg.inv > 0 && !o.ignoreInv) {
    if (tg.isPlayer && tg.st === 'dash' && tg.id === 'lupus' && !tg.cDone) { tg.cDone = true; tg.fury = Math.min(300, tg.fury + 22); textFx(tg.x, tg.y - 80, T('counter'), '#3af0ff', 1); sfx('pick'); }
    return false;
  }
  if (tg.team === 'e') {
    if (tg.kind === 'boss' && tg.bossIn > 0) return false;
    if (tg.st === 'down' && !o.ground) return false;
    const guarding = (tg.def.shield && tg.blocking) || tg.guard;
    if (guarding && !o.brk && facingTo(tg, att)) {
      dmg *= 0.12; sparks(tg.x + tg.face * 14, tg.y, 30, 8, '#9cf'); sfx('hit'); tg.flash = 0.4; tg.guardHit = (tg.guardHit || 0) + 1;
      if (!tg.blkT || G.time - tg.blkT > 0.6) { tg.blkT = G.time; textFx(tg.x, tg.y - 70, T('block'), '#9ca0b0', 1); } if (att.team === 'p' && att.st === 'atk') att.vx = -att.face * 70;
    }
  }
  let d = dmg * (o.mult || 1);
  if (tg.team === 'p') { d *= (1 - (tg.kind === 'hero' ? hs(tg).armor : 0)); if (tg.shieldHP > 0) { const ab = Math.min(tg.shieldHP, d); tg.shieldHP -= ab; d -= ab; sparks(tg.x, tg.y, 36, 6, '#a7ff1a'); } }
  d = Math.max(1, Math.round(d));
  tg.hp -= d; tg.flash = 1;
  const big = d > 60 || o.launch;
  sfx(big ? 'hit2' : 'hit');
  const hz = 28 + tg.z;
  blood(tg.x + (att.x < tg.x ? -3 : 3), tg.y, hz, big ? 10 : 5);
  hitFlash(tg.x + (att.x < tg.x ? -5 : 5), tg.y, hz, big, tg.team === 'e' ? '#ffffff' : '#ff6070');
  if (att.team === 'p' && tg.team === 'e') {
    G.combo++; G.comboT = 2.4; G.lastHitT = G.time; G.maxCombo = Math.max(G.maxCombo, G.combo); G.lastE = tg; G.lastET = 2.5;
    textFx(tg.x + rnd(-5, 5), tg.y - (tg.kind === 'boss' ? 110 : 76), '' + d, big ? '#ffd23a' : '#ffffff', big ? 2 : 1);
    if (att.id === 'lupus' && att.form !== 'a') att.fury = Math.min(300, att.fury + d * 0.13 * (1 + 0.25 * SAVE.up.fury));
    if (att.id === 'vespera') att.hp = Math.min(att.maxhp, att.hp + d * 0.08);
    G.score += Math.round(d * 0.5);
    if (o.bleed) { tg.bleedT = 3; tg.bleedD = Math.max(tg.bleedD, 16 * upMul()); }
    freeze(big ? 0.08 : 0.045); shake(big ? 4 : 1.5);
  } else if (tg.team === 'p') {
    textFx(tg.x, tg.y - 74, '' + d, '#ff4060', 1);
    if (tg.id === 'lupus') tg.fury = Math.min(300, tg.fury + d * 0.1 * (1 + 0.25 * SAVE.up.fury));
    tg.lastHurt = 0; sfx('hurt'); shake(big ? 5 : 2); G.flashScr = Math.max(G.flashScr, big ? 0.3 : 0.12);
  }
  const dir = att.x <= tg.x ? 1 : -1;
  if (tg.hp <= 0) { kill(tg, dir, att); return true; }
  if (tg.team === 'e') {
    if (tg.hasTok) { G.tok--; tg.hasTok = false; }
    const heavy = tg.def.heavy || tg.kind === 'boss';
    if (heavy) tg.poise += d;
    const airborne = tg.st === 'knock' && tg.z > 0;
    if (airborne && tg.kind !== 'boss') { /* juggle */ tg.jug++; tg.vz = Math.max(tg.vz, 150 * Math.pow(0.78, tg.jug)); tg.vx = dir * (o.kx || 60) * 0.6; tg.t = 0.6; }
    else if (o.launch && tg.kind !== 'boss') { if (heavy && tg.poise < tg.poiseMax) tg.vx += dir * 40; else { launch(tg, dir, o.kx || 120, o.kz || 210); tg.poise = 0; } }
    else if (!heavy || tg.poise >= tg.poiseMax || o.stun) {
      if (tg.kind === 'boss') { if (tg.poise >= tg.poiseMax) { tg.poise = 0; if (tg.pat && tg.pat.n !== 'charge') { setSt(tg, 'hurt', 0.3); tg.pat = null; tg.cd = 0.5; tg.vx = dir * 50; } } }
      else { setSt(tg, 'hurt', o.stun || 0.32); tg.vx = dir * (o.kx || 50); tg.ai = 'move'; tg.aiT = 0.3; if (tg.def.ai === 'lunge') tg.vz = 0; }
    } else tg.vx += dir * 12;
  } else if (tg.kind === 'hero') {
    if (o.launch) launch(tg, dir, o.kx || 120, o.kz || 210);
    else if (!(tg.form === 'a') && !(tg.form === 'f' && d < 30)) { if (tg.st !== 'down' && tg.st !== 'knock') { setSt(tg, 'hurt', 0.28); tg.vx = dir * 50; } }
    tg.inv = Math.max(tg.inv, o.launch ? 1.0 : 0.55);
  }
  return true;
}
function launch(f, dir, kx, kz) { setSt(f, 'knock', 0.6); f.vx = dir * kx; f.vz = kz; f.z = Math.max(f.z, 1); f.jug = 0; f.ai = 'move'; if (f.hasTok) { G.tok--; f.hasTok = false; } if (f.kind === 'hero') { f.inv = 1.0; f.cDone = false; } }
function kill(f, dir, att) {
  f.dead = true; f.hp = 0; setSt(f, 'dead'); f.deadT = 0; f.vx = dir * 110; f.vz = 200; f.z = Math.max(f.z, 1);
  if (f.hasTok) { G.tok--; f.hasTok = false; }
  sfx('die'); blood(f.x, f.y, 30, 18);
  if (f.team === 'e') {
    G.kills++; G.score += (f.def.pts || 100) * (1 + Math.min(G.combo, 50) * 0.02) | 0;
    if (f.kind === 'boss') { shake(14); G.slow = 0.3; G.clearT = 0.001; ringFx(f.x, f.y, 30, 200, '#ffffff', 0.9); ringFx(f.x, f.y, 30, 150, '#ff2a40', 1.2); sfx('boom'); G.drops.push({ x: f.x, y: f.y, type: 'vial', t: 0, z: 30, vz: 120 }); musicStop(); }
    else { const r = Math.random(); if (r < 0.13) G.drops.push({ x: f.x, y: f.y, type: 'vial', t: 0, z: 10, vz: 90 }); else if (r < 0.26) G.drops.push({ x: f.x, y: f.y, type: 'fury', t: 0, z: 10, vz: 90 }); }
  } else if (f.isPlayer) { if (G.ally && !G.ally.dead) { G.autoTag = 1.1; textFx(f.x, f.y - 70, T('ko'), '#ff2a40', 2); } else { G.over = 0.001; musicStop(); } }
  else { textFx(f.x, f.y - 70, T('down'), '#ff2a40', 1); }
}
function breakProp(p) {
  p.dead = true; sfx('boom'); shake(4); debris(p.x, p.y, p.key === 'crate' ? 'dc' : 'db', 9); dust(p.x, p.y, 8);
  const r = Math.random(); G.drops.push({ x: p.x, y: p.y, type: r < 0.45 ? 'vial' : r < 0.8 ? 'fury' : 'coin', t: 0, z: 14, vz: 120 });
}

/* ---------- projectiles ---------- */
function shoot(o) { const p = Object.assign({ x: 0, y: 230, z: 26, vx: 0, vy: 0, dmg: 20, team: 'e', r: 7, life: 2, type: 'bolt', pierce: false, hit: new Set(), col: '#ff2a40', launch: false, kx: 70, low: false, t: 0, brk: false }, o); G.proj.push(p); return p; }
function updProj(p, dt) {
  p.t += dt; p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt;
  if (p.type === 'orb' && p.wob) p.z = 30 + Math.sin(p.t * 9) * 6;
  const targets = p.team === 'p' ? G.enemies.concat(G.props) : G.heroes;
  for (const f of targets) {
    if (f.dead || p.hit.has(f)) continue;
    if (Math.abs(p.y - f.y) > 12 + (p.type === 'wave' ? 6 : 0)) continue;
    if (Math.abs(p.x - f.x) > p.r + (f.hr || 10)) continue;
    if (p.low) { if (f.z > 16) continue; } else if (Math.abs(p.z - (f.z + 22)) > 34) continue;
    p.hit.add(f);
    hurt({ x: p.x - Math.sign(p.vx || 1) * 10, y: p.y, team: p.team, id: p.owner || '' }, f, p.dmg, { launch: p.launch, kx: p.kx, brk: p.brk, bleed: p.bleed });
    if (!p.pierce) { p.life = 0; sparks(p.x, p.y, p.z, 6, p.col); }
  }
  if (p.life <= 0 && (p.type === 'bolt' || p.type === 'orb')) sparks(p.x, p.y, p.z, 4, p.col);
}

/* ---------- physics ---------- */
function phys(f, dt) {
  if (f.z > 0 || f.vz !== 0) {
    f.vz -= GRAV * dt * (f.glide ? 0.35 : 1); if (f.glide && f.vz < -50) f.vz = -50;
    f.z += f.vz * dt;
    if (f.z <= 0) {
      f.z = 0;
      if (f.st === 'knock' || f.st === 'dead') {
        if (f.vz < -150) { f.vz = -f.vz * 0.33; f.z = 0.5; dust(f.x, f.y, 6); shake(2); sfx('land'); f.vx *= 0.6; return; }
        if (f.st === 'knock') { setSt(f, 'down', f.kind === 'hero' ? 0.5 : 0.7); dust(f.x, f.y, 4); }
      } else if (f.vz < -180) { sfx('land'); dust(f.x, f.y, 4); f.landT = 0.08; }
      f.vz = 0;
    }
  }
  f.glide = false;
}
function friction(f, dt, k) { f.vx *= Math.exp(-(k || 8) * dt); }
function bounds(f) {
  const lo = f.team === 'p' ? G.camX + 12 : 0, hi = f.team === 'p' ? (G.locked ? G.camX + VW - 96 : WORLD_W - 14) : WORLD_W;
  if (f.team === 'e' && f.kind === 'enemy' && !f.arrive && !f.dead) {
    const L = G.camX + 14, R = G.camX + VW - 135;
    if ((f.x < L || f.x > R) && f.st === 'knock' && Math.abs(f.vx) > 80) { f.vx = -f.vx * 0.45; sparks(f.x, f.y, 20, 8, '#fff'); shake(3); f.hp -= 8; dust(f.x, f.y, 5); }
    f.x = clamp(f.x, L, R);
  }
  if (f.kind === 'boss' && f.bossIn <= 0) f.x = clamp(f.x, G.camX + 40 + (f.def.wide ? 50 : 0), G.camX + VW - 150 - (f.def.wide ? 50 : 0));
  if (f.team === 'p') f.x = clamp(f.x, lo, hi);
  f.y = clamp(f.y, LANE_T, LANE_B);
}
/* soft body separation (bodies push each other, props block) */
function separate(dt) {
  const bodies = G.enemies.filter(e => !e.dead && e.z < 20 && !e.arrive);
  for (let i = 0; i < bodies.length; i++) for (let j = i + 1; j < bodies.length; j++) {
    const a = bodies[i], b = bodies[j]; const dx = b.x - a.x, dy = (b.y - a.y) * 2; const d = Math.hypot(dx, dy) || 0.01; const m = (a.hr + b.hr) * 0.9;
    if (d < m) { const push = (m - d) * 0.5 * Math.min(1, dt * 12); const ux = dx / d, uy = dy / d; if (a.kind !== 'boss') { a.x -= ux * push; a.y -= uy * push * 0.5; } if (b.kind !== 'boss') { b.x += ux * push; b.y += uy * push * 0.5; } }
  }
  for (const pr of G.props) {
    if (pr.dead) continue;
    for (const f of G.heroes.concat(bodies)) { if (f.dead || f.z > 18) continue; const dx = f.x - pr.x, dy = (f.y - pr.y) * 2; const d = Math.hypot(dx, dy) || 0.01, m = pr.hr + f.hr * 0.7; if (d < m) { f.x += dx / d * (m - d); f.y += dy / d * (m - d) * 0.4; } }
  }
}

/* ---------- hero logic ---------- */
function setForm(h, f, silent) {
  if (h.form === f) return; h.form = f; h.inv = Math.max(h.inv, 0.9); setSt(h, 'idle');
  if (!silent) { sfx('transform'); shake(7); freeze(0.14); ringFx(h.x, h.y, 26, 120, f === 'a' ? '#ff1a3a' : '#ff8a30', 0.6); ringFx(h.x, h.y, 26, 80, '#ffffff', 0.35); G.flashScr = 0.5; blood(h.x, h.y, 30, 16); if (!G.cine) textFx(h.x, h.y - 96, T(FORM[f].label) + '!', f === 'a' ? '#ff2a40' : '#ff9a40', 2); }
  if (f !== 'h') h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.08);
}
function startXform(h, to) {
  if (h.dead || h.st === 'xform' || h.form === to) return;
  const up = to === 'a' || (to === 'f' && h.form === 'h');
  setSt(h, 'xform'); h.xt = 0; h.xto = to; h.xup = up; h.xdur = up ? 1.35 : 0.6; h.xswap = false; h.vx = h.vy = 0; h.inv = Math.max(h.inv, h.xdur + 0.3);
  if (up) sfx('howl');
  if (h.isPlayer && up) G.cine = { h, t: 0, dur: h.xdur };
}
function updXform(h, dt) {
  h.xt += dt; phys(h, dt); const mid = h.xdur * (h.xup ? 0.52 : 0.4), to = h.xto;
  if (!h.xswap) {
    const col = to === 'a' ? '#ff1030' : to === 'f' ? '#ffb040' : '#9ab4ff';
    if (h.xup) for (let i = 0; i < 2; i++) { const a = rnd(0, 6.28), r = rnd(45, 80); G.parts.push({ x: h.x + Math.cos(a) * r, y: h.y + rnd(-6, 6), z: 45 + Math.sin(a) * r * 0.7, vx: -Math.cos(a) * r * 2.4, vy: 0, vz: -Math.sin(a) * r * 1.7, life: 0.4, t: 0, col, size: 2, grav: 0, glowP: true }); }
    shake(0.5 + h.xt * (h.xup ? 3 : 1));
    if (h.xt >= mid) {
      h.xswap = true; setForm(h, to, !h.xup); setSt(h, 'xform'); h.xsw = h.xt;
      if (h.xup) {
        freeze(0.06); shake(12); G.flashScr = 0.7; ringFx(h.x, h.y, 10, 150, col, 0.7); ringFx(h.x, h.y, 10, 100, '#ffffff', 0.45);
        for (let i = 0; i < 26; i++) { const a = rnd(0, 6.28), s = rnd(120, 300); G.parts.push({ x: h.x, y: h.y, z: 50, vx: Math.cos(a) * s, vy: rnd(-20, 20), vz: Math.sin(a) * s * 0.6 + 80, life: rnd(0.5, 1), t: 0, col: i % 3 ? '#4a3020' : (to === 'a' ? '#e8e4dc' : '#b0001c'), size: rndi(2, 3), grav: 500, bounce: 0.3 }); }
        for (const e of G.enemies) { if (e.dead || dist(e, h) > 120) continue; hurt(h, e, 25 * upMul(), { launch: e.kind !== 'boss', kx: 200, kz: 220, brk: true, ignoreInv: true }); }
      } else { ringFx(h.x, h.y, 10, 60, col, 0.4); sfx('transform'); }
    }
  }
  if (h.xt >= h.xdur) { setSt(h, 'idle'); }
  bounds(h);
}
function tryTransform(h) {
  if (h.id !== 'lupus' || h.dead) return;
  if (h.st === 'xform') return;
  if (h.form === 'h') { if (h.fury >= 100) startXform(h, 'f'); else { textFx(h.x, h.y - 96, T('fury') + ' 1/3', '#ffb02a', 1); sfx('ui'); } }
  else if (h.form === 'f') { if (h.fury >= 200) startXform(h, 'a'); else startXform(h, 'h'); }
  else startXform(h, 'f');
}
function startDash(h, mx, my) {
  let dx = mx, dy = my; if (!dx && !dy) dx = h.face; const l = Math.hypot(dx, dy) || 1;
  setSt(h, 'dash', 0.2); h.vx = dx / l * 250; h.vy = dy / l * 120; if (dx) h.face = dx > 0 ? 1 : -1; h.inv = Math.max(h.inv, 0.3); h.dashCd = 0.7; h.cDone = false; sfx('dash'); dust(h.x, h.y, 5);
}
function startAtk(h) {
  const s = hs(h); h.hitDone = false; h.queued = false; h.air = h.z > 0;
  h.idx = h.air ? 1 : (h.chainT > 0 ? (h.idx % 3) + 1 : 1);
  h.atkDur = s.dur * (h.idx === 3 ? 1.4 : 1); h.atkT = h.atkDur; h.vx = 0; setSt(h, 'atk'); h.ct = 0; sfx('slash');
}
function heroHit(h) {
  const s = hs(h); const idx = h.idx, last = idx === 3 && !h.air;
  if (h.id === 'malakor') { shoot({ x: h.x + h.face * 22, y: h.y, z: 30 + h.z, vx: h.face * 230, dmg: s.dmg * (last ? 1.6 : 1), team: 'p', owner: 'malakor', r: 7, life: 1.3, type: 'orb', col: '#a7ff1a', pierce: last, launch: last, kx: 90 }); sfx('shot'); sparks(h.x + h.face * 22, h.y, 30 + h.z, 6, '#a7ff1a'); return; }
  const mult = last ? 1.55 : 1, reach = s.reach * (last ? 1.15 : 1);
  const col = h.id === 'lupus' ? (h.form === 'h' ? '#ff3a4a' : h.form === 'f' ? '#ff6a30' : '#ff1030') : h.id === 'vespera' ? '#ff3ad0' : '#3af0ff';
  slashFx(h.x + h.face * reach * 0.5, h.y, 30 + h.z, h.face, col, reach * 0.8, idx === 1 ? -0.4 : idx === 2 ? 0.45 : -1.1, 0.18);
  for (const e of G.enemies.concat(G.props)) {
    if (e.dead) continue; const dx = (e.x - h.x) * h.face;
    if (dx < -8 || dx > reach + (e.hr || 10)) continue; if (Math.abs(e.y - h.y) > 13) continue; if (Math.abs(e.z - h.z) > 36) continue;
    const brk = h.id === 'triton' || h.form === 'f' || h.form === 'a' || last;
    hurt(h, e, s.dmg * mult, { launch: last || (h.air && e.z > 0), kx: last ? 140 : 45, kz: 220, brk: brk && !(e.type === 'K' && !last), bleed: h.form === 'a' });
  }
}
function startSpec(h) {
  const s = hs(h); setSt(h, 'spec'); h.hitDone = false; h.spCd = s.cd; h.t = 0; h.vx = 0;
  h.specDur = h.id === 'lupus' ? (h.form === 'f' ? 0.8 : h.form === 'a' ? 0.7 : 0.55) : h.id === 'malakor' ? 0.6 : 0.55; h.specAt = h.specDur * 0.45;
  sfx(h.id === 'lupus' && h.form === 'f' ? 'howl' : 'special'); h.inv = Math.max(h.inv, 0.25);
}
function heroSpecFire(h) {
  const s = hs(h), dm = s.dmg;
  if (h.id === 'lupus') {
    if (h.form === 'h') {
      const len = 140; G.lines.push({ x: h.x, y: h.y, z: 30, len, face: h.face, t: 0, dur: 0.32 });
      slashFx(h.x + h.face * len * 0.85, h.y, 34, h.face, '#ff1a40', 40, -0.4, 0.3);
      for (const e of G.enemies.concat(G.props)) { if (e.dead) continue; const dx = (e.x - h.x) * h.face; if (dx < -6 || dx > len || Math.abs(e.y - h.y) > 15) continue; hurt(h, e, dm * 2.2, { launch: true, kx: 170, kz: 230, brk: true }); }
      shake(5);
    } else if (h.form === 'f') {
      ringFx(h.x, h.y, 4, 120, '#ff2a40', 0.6); ringFx(h.x, h.y, 4, 80, '#ffffff', 0.35); shake(10); freeze(0.12); G.flashScr = 0.3;
      for (const e of G.enemies.concat(G.props)) { if (e.dead) continue; if (dist(e, h) > 120) continue; hurt(h, e, dm * 1.2, { stun: 1.5, kx: 140, brk: true, launch: e.kind === 'prop' ? false : !(e.def && e.def.heavy) && e.kind !== 'boss', kz: 170 }); }
    } else {
      ringFx(h.x, h.y, 4, 90, '#ff0033', 0.5); shake(12); freeze(0.12); G.flashScr = 0.35;
      for (let i = 0; i < 12; i++) { const dx = i % 2 ? 1 : -1; shoot({ x: h.x + dx * 14, y: clamp(h.y + rnd(-30, 30), LANE_T, LANE_B), z: rnd(10, 56), vx: dx * rnd(260, 340), dmg: dm * 1.5, team: 'p', owner: 'lupus', r: 9, life: 0.9, type: 'spike', col: '#ffffff', pierce: true, bleed: true, kx: 70 }); }
      for (const e of G.enemies.concat(G.props)) { if (e.dead) continue; if (dist(e, h) > 90) continue; hurt(h, e, dm * 1.3, { launch: true, kx: 140, kz: 230, brk: true, bleed: true }); }
    }
  } else if (h.id === 'vespera') { shoot({ x: h.x + h.face * 20, y: h.y, z: 36 + h.z, vx: h.face * 180, dmg: dm * 2.6, team: 'p', owner: 'vespera', r: 22, life: 1.5, type: 'orb', col: '#ff3ad0', pierce: true, launch: true, kx: 120, wob: true, brk: true, big: true }); ringFx(h.x, h.y, 30, 50, '#ff3ad0', 0.3); }
  else if (h.id === 'triton') { shoot({ x: h.x + h.face * 20, y: h.y, z: 8, vx: h.face * 200, dmg: dm * 1.7, team: 'p', owner: 'triton', r: 30, life: 1.15, type: 'wave', col: '#3af0ff', pierce: true, launch: true, kx: 150, brk: true }); h.shieldHP = Math.max(h.shieldHP, 180); h.shieldT = 4; ringFx(h.x, h.y, 20, 55, '#3af0ff', 0.4); shake(4); }
  else if (h.id === 'malakor') {
    sfx('heal'); ringFx(h.x, h.y, 4, 100, '#a7ff1a', 0.6);
    { const b = G.ally; if (b && b.bench && b !== h) { if (b.dead) { b.dead = false; b.hp = b.maxhp * 0.35; setSt(b, 'idle'); textFx(h.x, h.y - 100, T('partner') + ' ^', '#a7ff1a', 1); } else b.hp = Math.min(b.maxhp, b.hp + b.maxhp * 0.22); } }
    for (const a of G.heroes) { if (a.dead) continue; a.hp = Math.min(a.maxhp, a.hp + a.maxhp * 0.22); a.shieldHP = Math.max(a.shieldHP, 200); a.shieldT = 6; textFx(a.x, a.y - 80, '+' + T('heal'), '#a7ff1a', 1); ringFx(a.x, a.y, 10, 36, '#a7ff1a', 0.4); }
    for (const e of G.enemies) { if (e.dead || dist(e, h) > 100) continue; hurt(h, e, dm * 1.6, { kx: 120, launch: true, kz: 150 }); }
  }
}
function updHero(h, dt, c) {
  h.ct += dt; h.inv = Math.max(0, h.inv - dt); h.flash = Math.max(0, h.flash - dt * 5); h.spCd = Math.max(0, h.spCd - dt); h.dashCd = Math.max(0, h.dashCd - dt); h.chainT = Math.max(0, h.chainT - dt); h.lastHurt += dt; if (h.landT) h.landT -= dt;
  if (h.shieldT > 0) { h.shieldT -= dt; if (h.shieldT <= 0) h.shieldHP = 0; }
  if (h.dead) { h.deadT += dt; h.x += h.vx * dt; friction(h, dt, 4); phys(h, dt); return; }
  const s = hs(h);
  if (s.regen) h.hp = Math.min(h.maxhp, h.hp + s.regen * dt);
  if (h.st === 'xform') { updXform(h, dt); return; }
  if (h.id === 'lupus') { if (h.form === 'f') h.fury -= 3.2 * dt; else if (h.form === 'a') h.fury -= 27 * dt; if (h.fury <= 0) { h.fury = 0; if (h.form !== 'h') startXform(h, 'h'); } else if (h.form === 'a' && h.fury < 70) startXform(h, 'f'); }
  if (c.form) tryTransform(h);
  if (h.st === 'xform') return;
  const grounded = h.z <= 0 && h.vz === 0;
  switch (h.st) {
    case 'hurt': h.t -= dt; h.x += h.vx * dt; friction(h, dt); phys(h, dt); if (h.t <= 0) setSt(h, h.z > 0 ? 'air' : 'idle'); break;
    case 'knock': h.x += h.vx * dt; friction(h, dt, 1.5); phys(h, dt); break;
    case 'down': h.t -= dt; h.x += h.vx * dt; friction(h, dt, 10); if (h.t <= 0) { setSt(h, 'getup', 0.3); } break;
    case 'getup': h.t -= dt; if (h.t <= 0) { setSt(h, 'idle'); h.inv = Math.max(h.inv, 0.6); } break;
    case 'dash': h.t -= dt; h.x += h.vx * dt; h.y += h.vy * dt; phys(h, dt); if (Math.random() < 0.5) dust(h.x - h.face * 6, h.y, 1); if (c.atk && h.t < 0.12) { setSt(h, 'idle'); startAtk(h); } else if (h.t <= 0) { setSt(h, h.z > 0 ? 'air' : 'idle'); h.vx = 0; h.vy = 0; } break;
    case 'atk': {
      h.atkT -= dt; const p = 1 - h.atkT / h.atkDur; phys(h, dt);
      if (!h.hitDone && p >= 0.4) { h.hitDone = true; heroHit(h); }
      if (!h.air && p < 0.45) h.x += h.face * 50 * dt;
      if (c.atk || (c.atkHeld && p > 0.5)) h.queued = true;
      if (c.spec && h.spCd <= 0) { startSpec(h); break; }
      if (c.dash && h.dashCd <= 0 && p > 0.45) { startDash(h, c.mx, c.my); break; }
      if (h.atkT <= 0) { h.chainT = 0.5; setSt(h, h.z > 0 ? 'air' : 'idle'); if (h.queued) startAtk(h); }
      break;
    }
    case 'tagin': h.x += h.vx * dt; friction(h, dt, 2); phys(h, dt); if (h.z <= 0) { h.z = 0; h.vz = 0; shake(5); dust(h.x, h.y, 10); sfx('land'); ringFx(h.x, h.y, 4, 70, HERO[h.id].color, 0.4); for (const e of G.enemies) if (!e.dead && dist(e, h) < 70) hurt(h, e, hs(h).dmg * 1.2, { launch: e.kind !== 'boss', kx: 150, kz: 200, brk: true }); setSt(h, 'idle'); } break;
    case 'spec': h.t += dt; phys(h, dt); if (!h.hitDone && h.t >= h.specAt) { h.hitDone = true; heroSpecFire(h); } if (h.t >= h.specDur) setSt(h, h.z > 0 ? 'air' : 'idle'); break;
    default: {
      if (c.dash && h.dashCd <= 0) { startDash(h, c.mx, c.my); break; }
      if (c.spec && h.spCd <= 0 && grounded) { startSpec(h); break; }
      if (c.atk || (c.atkHeld && h.chainT > 0.2)) { startAtk(h); break; }
      if (c.jump && grounded) { h.vz = HERO[h.id].jump; h.z = 1; setSt(h, 'air'); sfx('jump'); dust(h.x, h.y, 4); }
      /* momentum: accelerate toward target velocity */
      const tvx = c.mx * s.spd, tvy = c.my * s.spd * 0.6, acc = grounded ? 14 : 5;
      h.vx += (tvx - h.vx) * Math.min(1, acc * dt); h.vy += (tvy - h.vy) * Math.min(1, acc * dt);
      h.x += h.vx * dt; h.y += h.vy * dt;
      if (c.mx) h.face = c.mx > 0 ? 1 : -1;
      if (h.id === 'vespera' && h.z > 0 && c.jumpHeld && h.vz < 0) h.glide = true;
      const was = h.z > 0; phys(h, dt);
      if (h.z > 0) setSt(h, 'air'); else setSt(h, (Math.abs(h.vx) > 12 || Math.abs(h.vy) > 8) ? 'walk' : 'idle');
      if (h.st === 'walk') h.wph = (h.wph || 0) + dt * 12 * Math.max(0.55, Math.min(1.35, Math.hypot(h.vx, h.vy / 0.6) / s.spd));
    }
  }
  bounds(h);
}

/* ---------- tag team (Marvel vs Capcom / Cosmic Invasion style) ---------- */
const TAG_CD = 1.6, ASSIST_CD = 8;
function canTag() {
  const p = G.player, a = G.ally;
  return G.tagCd <= 0 && a && !a.dead && !a.assist && !G.cine && G.over <= 0 && !G.clearT && !p.dead && ['idle', 'walk', 'air', 'atk', 'spec', 'dash', 'hurt'].includes(p.st);
}
function canAssist() { const p = G.player, a = G.ally; return G.assistCd <= 0 && a && !a.dead && !a.assist && !G.cine && G.over <= 0 && !G.clearT && !p.dead && p.st !== 'xform'; }
function jumpOut(h) { /* hero leaps off the screen */ G.heroes = G.heroes.filter(x => x !== h); h.leaveT = 0; if (!h.dead) { setSt(h, 'air'); h.vx = -h.face * 170; h.vz = 320; h.z = Math.max(h.z, 1); } G.leaving.push(h); }
function tagSwap(forced) {
  const out = G.player, inn = G.ally;
  const combo = !forced && G.time - G.lastHitT < 0.8 && G.lastE && !G.lastE.dead;
  out.isPlayer = false; out.shieldHP = 0; jumpOut(out);
  inn.bench = false; inn.assist = false; inn.isPlayer = true; inn.hitDone = false; inn.queued = false; inn.chainT = 0; inn.vy = 0; inn.flash = 0; inn._trail = [];
  inn.face = out.face; inn.y = clamp(out.y, LANE_T, LANE_B);
  if (combo) {
    const e = G.lastE; inn.face = e.x >= out.x ? 1 : -1; inn.x = clamp(e.x - inn.face * 34, G.camX + 20, G.camX + VW - 100); inn.y = clamp(e.y, LANE_T, LANE_B); inn.z = 30; inn.vz = 0; inn.vx = 0;
    inn.spCd = 0; startSpec(inn); inn.specAt *= 0.5; G.comboT = 2.6; freeze(0.08); G.flashScr = 0.25;
    textFx(inn.x, inn.y - 108, T('tagCombo'), '#ffd23a', 2); ringFx(inn.x, inn.y, 20, 80, HERO[inn.id].color, 0.4);
  } else { inn.x = clamp(out.x - out.face * 46, G.camX + 16, G.camX + VW - 100); inn.z = 160; inn.vz = -30; inn.vx = out.face * 80; setSt(inn, 'tagin'); }
  inn.inv = Math.max(inn.inv, 0.9); G.heroes.push(inn); G.player = inn; G.ally = out; out.bench = true;
  G.tagCd = forced ? 0.6 : TAG_CD; sfx('dash'); sfx('special');
}
function callAssist() {
  const p = G.player, a = G.ally;
  a.assist = true; a.bench = false; a.isPlayer = false; a.astPh = 'in'; a.face = p.face; a.hitDone = false; a._trail = [];
  a.y = clamp(p.y + (p.y < (LANE_T + LANE_B) / 2 ? 12 : -12), LANE_T, LANE_B); a.x = clamp(p.x - p.face * 36, G.camX + 14, G.camX + VW - 100); a.z = 130; a.vz = -60; a.vx = p.face * 60; setSt(a, 'tagin'); a.inv = 99;
  G.heroes.push(a); G.assistCd = ASSIST_CD; sfx('dash'); textFx(a.x, a.y - 112, T('assist') + '!', HERO[a.id].color, 1);
}
function updAssist(a, dt) {
  if (a.astPh === 'in') { updHero(a, dt, {}); if (a.st !== 'tagin') { const en = nearestEnemy(a, 420); if (en) a.face = en.x >= a.x ? 1 : -1; a.spCd = 0; startSpec(a); a.astPh = 'spec'; } }
  else if (a.astPh === 'spec') { updHero(a, dt, {}); if (a.st !== 'spec') { a.astPh = 'out'; a.inv = 0; jumpOut(a); } }
}
function updBench(b, dt) { b.spCd = Math.max(0, b.spCd - dt); b.shieldHP = 0; b.inv = 0; b.flash = 0; if (!b.dead) b.hp = Math.min(b.maxhp, b.hp + b.maxhp * 0.025 * dt); }
function updLeaving(dt) {
  for (const h of G.leaving) { h.leaveT += dt; h.x += h.vx * dt; if (!h.dead) { h.vz -= GRAV * dt * 0.7; h.z = Math.max(0, h.z + h.vz * dt); } h.fade = 1 - h.leaveT / 0.55; }
  G.leaving = G.leaving.filter(h => { if (h.leaveT < 0.55) return true; h.fade = null; h.z = 0; h.vz = 0; h.vx = 0; setSt(h, h.dead ? 'dead' : 'idle'); if (h.assist) { h.assist = false; h.bench = true; } return false; });
}
function tagStep(dt, pc) {
  G.tagCd = Math.max(0, G.tagCd - dt); G.assistCd = Math.max(0, G.assistCd - dt);
  const a = G.ally;
  if (a.assist && G.heroes.includes(a)) updAssist(a, dt); else if (a.bench && !a.assist) updBench(a, dt);
  updLeaving(dt);
  if (G.autoTag > 0) { G.autoTag -= dt; if (G.autoTag <= 0) { if (a.assist) G.autoTag = 0.1; else if (!a.dead) tagSwap(true); } return; }
  if (pc.tag && canTag()) tagSwap(false);
  else if (pc.assist && canAssist()) callAssist();
}

/* ---------- ally AI ---------- */
function allyCtl(a, dt) {
  const c = { mx: 0, my: 0, atk: false, atkHeld: false, jump: false, spec: false, dash: false, form: false, jumpHeld: false };
  const p = G.player; a.aiT -= dt; const en = nearestEnemy(a, 360); const s = hs(a); const ranged = a.id === 'malakor';
  let tx, ty;
  if (en) { const side = Math.sign(a.x - en.x) || 1; tx = ranged ? en.x + side * 130 : en.x + side * Math.max(16, s.reach * 0.7); ty = en.y; if (Math.abs(tx - p.x) > 260) tx = p.x + (tx > p.x ? 260 : -260); }
  else { tx = p.x - p.face * 46; ty = p.y + 16; }
  const dx = tx - a.x, dy = ty - a.y;
  if (Math.abs(dx) > 7) c.mx = Math.sign(dx); if (Math.abs(dy) > 5) c.my = Math.sign(dy);
  if (en) {
    const fx = en.x - a.x, need = ranged ? 260 : s.reach + (en.hr || 10);
    if (Math.abs(en.y - a.y) < (ranged ? 10 : 8) && Math.abs(fx) < need && a.aiT <= 0) { if ((fx > 0) === (a.face > 0) || !c.mx) { c.atk = true; c.mx = 0; } a.face = fx >= 0 ? 1 : -1; if (Math.random() < 0.02) a.aiT = rnd(0.2, 0.6); }
    let near = 0; for (const e of G.enemies) if (!e.dead && dist(e, a) < 115) near++;
    if (a.spCd <= 0) { if (a.id === 'malakor') { if (G.heroes.some(h => !h.dead && h.hp < h.maxhp * 0.6) || G.heroes.some(h => h.dead)) c.spec = true; } else if (near >= 2 || (G.boss && !G.boss.dead && dist(G.boss, a) < 160)) { if (!(a.id === 'lupus' && a.form === 'h') || Math.abs(en.y - a.y) < 12) c.spec = true; } }
    if (a.id === 'lupus' && a.form === 'h' && a.fury >= 120) c.form = true;
    for (const e of G.enemies) if (!e.dead && (e.ai === 'wind' || (e.pat && e.pat.ps === 1)) && dist(e, a) < 55 && a.dashCd <= 0 && Math.random() < 0.04) c.dash = true;
  }
  return c;
}

/* ---------- enemy logic ---------- */
function eHit(e, reach, dmg, o) {
  o = o || {}; const dm = dmg * e.dm;
  for (const h of G.heroes) {
    if (h.dead) continue; const dx = (h.x - e.x) * e.face;
    if (o.rad) { if (dist(e, h) > o.rad || h.z > 22) continue; } else { if (dx < -6 || dx > reach + 10) continue; if (Math.abs(h.y - e.y) > 13 || h.z > 30) continue; }
    hurt(e, h, dm, o);
  }
}
function moveTo(e, tx, ty, spd, dt) { const dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy); if (d < 2) return 0; const m = Math.min(d, spd * dt); e.x += dx / d * m; e.y += dy / d * m * 0.8; e.moving = true; return d; }
function getTok(e, max) { if (e.hasTok) return true; if (G.tok < max) { G.tok++; e.hasTok = true; return true; } return false; }
function relTok(e) { if (e.hasTok) { G.tok--; e.hasTok = false; } }

function updEnemy(e, dt) {
  e.ct += dt; e.flash = Math.max(0, e.flash - dt * 5); e.inv = Math.max(0, e.inv - dt); e.cd -= dt; e.moving = false;
  if (e.dead) { e.deadT += dt; e.x += e.vx * dt; friction(e, dt, 3); phys(e, dt); return; }
  if (e.bleedT > 0) { e.bleedT -= dt; e.hp -= e.bleedD * dt; if (Math.random() < dt * 8) blood(e.x, e.y, 30, 1); if (e.hp <= 0) { kill(e, 1, G.player); return; } }
  if (e.kind === 'boss') { updBoss(e, dt); bounds(e); return; }
  const def = e.def;
  if (e.arrive) { const inX = clamp(e.x, G.camX + 50, G.camX + VW - 140); e.face = inX >= e.x ? 1 : -1; e.x += e.face * Math.max(def.spd, 60) * dt; e.moving = true; if (Math.abs(inX - e.x) < 4 || (e.x > G.camX + 30 && e.x < G.camX + VW - 125)) e.arrive = false; phys(e, dt); return; }
  if (e.st === 'hurt') { e.t -= dt; e.x += e.vx * dt; friction(e, dt); if (e.t <= 0) setSt(e, 'idle'); bounds(e); return; }
  if (e.st === 'knock') { e.x += e.vx * dt; friction(e, dt, 1.2); phys(e, dt); bounds(e); return; }
  if (e.st === 'down') { e.t -= dt; e.x += e.vx * dt; friction(e, dt, 10); if (e.t <= 0) setSt(e, 'getup', 0.35); bounds(e); return; }
  if (e.st === 'getup') { e.t -= dt; if (e.t <= 0) { setSt(e, 'idle'); e.inv = 0.35; e.ai = 'move'; } return; }
  const tg = nearestHero(e); const dx = tg.x - e.x, dy = tg.y - e.y; const reach = def.reach || 32; e.blocking = false; phys(e, dt);
  const ai = def.ai;
  if (e.ai === 'move') {
    e.face = dx >= 0 ? 1 : -1;
    if (ai === 'melee' || ai === 'brute') {
      const maxTok = 2 + (G.stage >= 3 ? 1 : 0); if (def.shield) e.blocking = true;
      if (!e.hasTok) { const side = Math.sign(e.x - tg.x) || 1; moveTo(e, tg.x + side * (85 + (e.ct * 7 % 30)), tg.y + Math.sin(e.ct * 0.8 + e.x) * 15, def.spd * 0.8, dt); if (Math.hypot(dx, dy) < 170 && e.cd <= 0) getTok(e, maxTok); }
      else { moveTo(e, tg.x - e.face * reach * 0.75, tg.y, def.spd, dt); if (Math.abs(dx) < reach + 4 && Math.abs(dy) < 7 && e.cd <= 0) { e.ai = 'wind'; e.t = def.wind || 0.35; e.blocking = false; sfx('alarm'); } }
    } else if (ai === 'ranged') {
      const adx = Math.abs(dx); const want = adx < 115 ? -1 : adx > 200 ? 1 : 0; e.x += e.face * want * def.spd * dt; if (want) e.moving = true; moveTo(e, e.x, tg.y, def.spd * 0.8, dt);
      if (adx < 40 && e.cd <= 0) { e.ai = 'wind'; e.t = 0.3; e.melee = true; } else if (Math.abs(dy) < 11 && e.cd <= 0 && adx < 280) { e.ai = 'wind'; e.t = 0.5; e.melee = false; }
    } else if (ai === 'lunge') {
      const adx = Math.abs(dx);
      if (!e.hasTok) { const side = Math.sign(e.x - tg.x) || 1; moveTo(e, tg.x + side * 110, tg.y + Math.sin(e.ct * 1.5 + e.x) * 20, def.spd * 0.9, dt); if (e.cd <= 0) getTok(e, 3); }
      else { moveTo(e, tg.x - e.face * 75, tg.y, def.spd, dt); if (adx < 115 && adx > 45 && Math.abs(dy) < 9 && e.cd <= 0) { e.ai = 'wind'; e.t = 0.38; } }
    } else if (ai === 'beam') {
      const adx = Math.abs(dx); const want = adx < 130 ? -1 : adx > 210 ? 1 : 0; e.x += e.face * want * def.spd * dt; if (want) e.moving = true; moveTo(e, e.x, tg.y, def.spd * 0.9, dt);
      if (adx < 35 && e.cd <= 0) { e.ai = 'wind'; e.t = 0.25; e.melee = true; } else if (Math.abs(dy) < 8 && e.cd <= 0 && adx < 320) { e.ai = 'wind'; e.t = 0.75; e.melee = false; }
    }
  } else if (e.ai === 'wind') {
    e.t -= dt; if (ai === 'ranged' || ai === 'beam') e.face = dx >= 0 ? 1 : -1;
    if (e.t <= 0) { e.ai = 'hit'; e.t = 0.24; e.hitDone = false; e.ct = 0; }
  } else if (e.ai === 'hit') {
    e.t -= dt;
    if (!e.hitDone) {
      e.hitDone = true;
      if (ai === 'ranged') { if (e.melee) { eHit(e, 30, 16, { kx: 80 }); slashFx(e.x + e.face * 15, e.y, 30, e.face, '#ff2a40', 22, 0, 0.15); sfx('slash'); } else { shoot({ x: e.x + e.face * 28, y: e.y, z: 32, vx: e.face * 230, dmg: def.dmg * e.dm, team: 'e', r: 6, life: 2, type: 'bolt', col: '#ff3050' }); sfx('shot'); hitFlash(e.x + e.face * 30, e.y, 32, false, '#ff5060'); } }
      else if (ai === 'beam') { if (e.melee) { eHit(e, 35, 24, { kx: 110 }); slashFx(e.x + e.face * 15, e.y, 30, e.face, '#ff2a40', 26, 0, 0.15); sfx('slash'); } else { shoot({ x: e.x + e.face * 28, y: e.y, z: 30, vx: e.face * 400, dmg: def.dmg * e.dm, team: 'e', r: 20, life: 1.3, type: 'beam', col: '#ff2040', pierce: true }); sfx('shot'); } }
      else if (ai === 'lunge') { e.vx = e.face * 250; e.vz = 150; e.z = 1; e.lunged = true; e.t = 0.6; }
      else if (ai === 'brute') { eHit(e, 0, def.dmg, { rad: 64, launch: true, kx: 140, kz: 220 }); ringFx(e.x + e.face * 26, e.y, 0, 70, '#9aff6a', 0.4); dust(e.x + e.face * 26, e.y, 12); shake(7); sfx('boom'); }
      else { eHit(e, reach, def.dmg, { kx: 90, launch: (e.hitCount || 0) % 3 === 2 }); slashFx(e.x + e.face * reach * 0.5, e.y, 30, e.face, '#ff3040', reach * 0.8, -0.3, 0.18); sfx('slash'); e.hitCount = (e.hitCount || 0) + 1; }
    }
    if (ai === 'lunge' && e.lunged) {
      e.x += e.vx * dt; e.vx *= 0.985;
      for (const h of G.heroes) if (!h.dead && !e.lungeHit && Math.abs(h.x - e.x) < 17 && Math.abs(h.y - e.y) < 12 && h.z < 26) { e.lungeHit = true; hurt(e, h, def.dmg * e.dm, { kx: 90 }); }
      if (e.z <= 0 && e.t < 0.45) { e.lunged = false; e.lungeHit = false; e.ai = 'rec'; e.t = 0.7; e.vx = 0; relTok(e); dust(e.x, e.y, 3); }
    } else if (e.t <= 0) { e.ai = 'rec'; e.t = ai === 'brute' ? 0.9 : rnd(0.35, 0.8); }
  } else if (e.ai === 'rec') { e.t -= dt; if (def.shield) e.blocking = true; if (e.t <= 0) { e.ai = 'move'; e.cd = ai === 'ranged' || ai === 'beam' ? rnd(1.4, 2.6) : rnd(0.5, 1.4); relTok(e); } }
  bounds(e);
}

/* ---------- bosses ---------- */
function startPat(e, n) { e.pat = { n, t: 0, ps: 0, hits: 0 }; e.guard = false; e.guardHit = 0; e.ct = 0; }
function endPat(e, cd) { e.pat = null; e.cd = (cd != null ? cd : rnd(0.7, 1.4)) * (e.p2 ? 0.65 : 1); e.frame = 'idle'; e.guard = false; e.vx = 0; e.charging = false; e.windup = false; }
const bossFace = (e, tg) => { e.face = tg.x >= e.x ? 1 : -1; };
function updBoss(e, dt) {
  const def = e.def, tg = nearestHero(e);
  if (e.bossIn > 0) { e.bossIn -= dt; e.y = 232; if (e.x > G.camX + VW - 200) { e.x -= 160 * dt; e.moving = true; } return; }
  if (e.st === 'hurt') { e.t -= dt; e.x += e.vx * dt; friction(e, dt); if (e.t <= 0) setSt(e, 'idle'); return; }
  const spd = def.spd * (e.p2 ? 1.25 : 1);
  if (!e.p2 && e.hp < e.maxhp * 0.5) {
    e.p2 = true; e.pat = null; shake(10); ringFx(e.x, e.y, 30, 160, '#ff0033', 0.8); sfx('roar'); textFx(e.x, e.y - 120, T('p2'), '#ff3050', 2); e.cd = 0.8;
    if (e.type === 'voss') { spawnEnemy('ZS', -1); spawnEnemy('ZS', 1); }
    if (e.type === 'nacht') { e.key = def.big; e.hr = 26; e.def = Object.assign({}, def, { pats: ['slam', 'charge', 'shoot', 'summon', 'slam'], reach: 64 }); ringFx(e.x, e.y, 30, 120, '#a7ff1a', 0.8); }
    if (e.type === 'beast') for (let i = 0; i < 3; i++) spawnEnemy('H', i % 2 ? 1 : -1);
    if (e.type === 'warden') { spawnEnemy('Z', 1); spawnEnemy('ZS', -1); }
    if (e.type === 'prime') { spawnEnemy('M', 1); spawnEnemy('M', -1); }
  }
  if (!e.pat) {
    bossFace(e, tg); e.frame = 'idle'; const dx = tg.x - e.x, dy = tg.y - e.y; e.cd -= dt;
    if (Math.abs(dx) > 100 || Math.abs(dy) > 10) { moveTo(e, tg.x - e.face * 75, tg.y, spd * 0.7, dt); e.frame = 'walk'; }
    if (e.cd <= 0) { const pats = e.def.pats; startPat(e, pats[e.pi++ % pats.length]); }
    return;
  }
  const P = e.pat; P.t += dt; const dx = tg.x - e.x, dy = tg.y - e.y; const dm = e.dm * (e.p2 ? 1.15 : 1); const reach = e.def.reach || 56;
  switch (P.n) {
    case 'slash': {
      if (P.ps === 0) { bossFace(e, tg); e.frame = 'walk'; moveTo(e, tg.x - e.face * reach * 0.8, tg.y, spd * 1.2, dt); if ((Math.abs(dx) < reach + 12 && Math.abs(dy) < 7) || P.t > 3) { P.ps = 1; P.t = 0; e.ct = 0; } }
      else if (P.ps === 1) { e.frame = 'wind'; e.windup = true; if (P.t > (e.p2 ? 0.3 : 0.42)) { P.ps = 2; P.t = 0; e.ct = 0; } }
      else if (P.ps === 2) { e.windup = false; e.frame = 'atk'; P.hits++; eHit(e, reach, def.wide ? 62 : 40, { kx: 130, launch: P.hits >= 3, kz: 220 }); slashFx(e.x + e.face * reach * 0.5, e.y, 40, e.face, e.type === 'voss' ? '#ff2040' : '#ff5030', reach * 0.9, P.hits === 2 ? 0.5 : -0.4, 0.22); sfx('slash'); shake(4); e.x += e.face * 14; P.ps = 3; P.t = 0; }
      else if (P.ps === 3) { e.frame = 'atk'; if (P.t > 0.28) { if (P.hits < 3) { bossFace(e, tg); P.ps = 1; P.t = 0; e.ct = 0; } else endPat(e); } }
      break;
    }
    case 'charge': {
      if (P.ps === 0) { bossFace(e, tg); e.frame = 'wind'; e.windup = true; if (Math.abs(dy) > 4) e.y += Math.sign(dy) * 60 * dt; if (P.t > 0.85) { P.ps = 1; P.t = 0; e.windup = false; sfx('roar'); e.hitSet = new Set(); } }
      else if (P.ps === 1) {
        e.charging = true; e.frame = 'run'; e.x += e.face * 360 * dt; e.moving = true; if (Math.random() < 0.6) dust(e.x - e.face * 20, e.y, 1);
        for (const h of G.heroes) { if (h.dead || e.hitSet.has(h)) continue; if (Math.abs(h.x - e.x) < (def.wide ? 60 : 30) && Math.abs(h.y - e.y) < 15 && h.z < 30) { e.hitSet.add(h); hurt(e, h, 62 * dm, { launch: true, kx: 220, kz: 230 }); shake(8); } }
        const wall = e.x < G.camX + 50 + (def.wide ? 50 : 0) || e.x > G.camX + VW - 155 - (def.wide ? 50 : 0);
        if (P.t > 1.4 || wall) { e.charging = false; P.ps = 2; P.t = 0; shake(7); sparks(e.x + e.face * 20, e.y, 20, 14); dust(e.x, e.y, 10); sfx('boom'); }
      } else if (P.ps === 2) { e.frame = 'idle'; e.dazed = true; if (P.t > 1.1) { e.dazed = false; endPat(e, 0.6); } }
      break;
    }
    case 'guard': bossFace(e, tg); e.frame = 'block'; e.guard = true; if (P.t > 2.2 || e.guardHit >= 4) { e.guard = false; P.n = 'slash'; P.ps = 1; P.t = 0; P.hits = 1; } break;
    case 'wave': {
      bossFace(e, tg);
      if (P.ps === 0) { e.frame = 'wind'; e.windup = true; if (P.t > 0.55) { P.ps = 1; P.t = 0; e.ct = 0; } }
      else if (P.ps === 1) { e.windup = false; e.frame = 'spec'; shoot({ x: e.x + e.face * 30, y: e.y, z: 26, vx: e.face * 280, dmg: 52 * dm, team: 'e', r: 18, life: 1.5, type: 'wave', col: '#ff1a40', pierce: true, kx: 90 }); slashFx(e.x + e.face * 30, e.y, 40, e.face, '#ff1a40', 50, -0.2, 0.25); sfx('special'); P.hits++; P.ps = 2; P.t = 0; }
      else if (P.ps === 2 && P.t > 0.35) { if (P.hits < (e.p2 ? 3 : 2)) { P.ps = 0; P.t = 0; e.y += clamp(dy, -30, 30) * 0.6; } else endPat(e); }
      break;
    }
    case 'slam': {
      bossFace(e, tg);
      if (P.ps === 0) { e.frame = 'wind'; e.windup = true; if (P.t < 0.4) moveTo(e, tg.x - e.face * 60, tg.y, spd, dt); if (P.t > 0.85) { P.ps = 1; P.t = 0; e.ct = 0; } }
      else if (P.ps === 1) { e.windup = false; e.frame = 'atk'; shake(12); sfx('boom'); ringFx(e.x + e.face * 30, e.y, 0, 110, '#ffb060', 0.5); dust(e.x + e.face * 30, e.y, 16); eHit(e, 0, 58, { rad: 88, launch: true, kx: 150, kz: 260 }); for (const s of [-1, 1]) shoot({ x: e.x, y: e.y, z: 0, vx: s * 220, dmg: 40 * dm, team: 'e', r: 18, life: 0.9, type: 'shock', col: '#ffb060', pierce: true, low: true, kx: 90 }); P.ps = 2; P.t = 0; }
      else if (P.ps === 2) { e.frame = 'atk'; if (P.t > 0.9) endPat(e); }
      break;
    }
    case 'roar': {
      bossFace(e, tg); e.frame = 'spec'; if (P.ps === 0 && P.t > 0.2) { P.ps = 1; sfx('roar'); shake(12); ringFx(e.x, e.y, 30, 170, '#ff2030', 0.8); for (const h of G.heroes) if (!h.dead && dist(h, e) < 170) { setSt(h, 'hurt', 0.7); h.vx = Math.sign(h.x - e.x) * 90; h.inv = 0.3; } if (enemiesAlive() < 4) { spawnEnemy('H', -1); spawnEnemy('H', 1); if (e.p2) spawnEnemy('S', 1); } }
      if (P.t > 1.2) endPat(e); break;
    }
    case 'shoot': {
      bossFace(e, tg); const adx = Math.abs(dx);
      if (P.ps === 0) { e.frame = 'walk'; if (adx < 140) { e.x -= e.face * 80 * dt; e.moving = true; } else if (adx > 220) { e.x += e.face * 80 * dt; e.moving = true; } moveTo(e, e.x, tg.y, 50, dt); if (P.t > 0.7) { P.ps = 1; P.t = 0; e.ct = 0; } }
      else if (P.ps === 1) { e.frame = 'atk'; e.windup = true; if (P.t > 0.45) { for (let i = -1; i <= 1; i++) shoot({ x: e.x + e.face * 26, y: clamp(e.y + i * 16, LANE_T, LANE_B), z: 36, vx: e.face * 210, vy: i * 7, dmg: 30 * dm, team: 'e', r: 8, life: 2.2, type: 'orb', col: '#a7ff1a' }); sfx('shot'); P.hits++; P.ps = 2; P.t = 0; e.windup = false; } }
      else if (P.ps === 2 && P.t > 0.35) { if (P.hits < (e.p2 ? 4 : 3)) { P.ps = 1; P.t = 0; } else endPat(e); }
      break;
    }
    case 'summon': { bossFace(e, tg); e.frame = 'spec'; if (P.ps === 0 && P.t > 0.5) { P.ps = 1; sfx('special'); ringFx(e.x, e.y, 10, 70, '#a7ff1a', 0.6); if (enemiesAlive() < 5) { const ty = e.p2 ? ['S', 'M', 'H'] : ['H', 'S']; spawnEnemy(pick(ty), -1); spawnEnemy(pick(ty), 1); if (e.p2) spawnEnemy('M', 1); } } if (P.t > 1.3) endPat(e); break; }
    case 'blink': {
      if (P.ps === 0) { e.fade = Math.max(0, 1 - P.t / 0.3); e.frame = 'spec'; if (P.t > 0.3) { P.ps = 1; P.t = 0; const side = tg.x > G.camX + VW / 2 ? -1 : 1; e.x = clamp(tg.x + side * 95, G.camX + 40, G.camX + VW - 100); e.y = clamp(tg.y + rnd(-10, 10), LANE_T, LANE_B); ringFx(e.x, e.y, 10, 50, '#a7ff1a', 0.4); } }
      else if (P.ps === 1) { e.fade = Math.min(1, P.t / 0.25); bossFace(e, tg); e.frame = 'wind'; if (P.t > 0.5) { P.ps = 2; P.t = 0; e.ct = 0; e.frame = 'atk'; eHit(e, 70, 36, { kx: 120, launch: true }); slashFx(e.x + e.face * 34, e.y, 40, e.face, '#a7ff1a', 56, 0, 0.22); sfx('slash'); } }
      else if (P.ps === 2 && P.t > 0.4) endPat(e);
      break;
    }
    default: endPat(e);
  }
}
