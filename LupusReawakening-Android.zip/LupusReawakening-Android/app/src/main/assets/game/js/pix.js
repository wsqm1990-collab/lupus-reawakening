'use strict';
/* =====================================================================
   PIX — tiny pixel-art engine
   - Raster: hard-edged primitives (capsule / ellipse / polygon / line)
     with a per-pixel part-id buffer.
   - finalize(): automatic pixel-art shading (key light, shadow side,
     environment rim light, inner contour lines, 1px dark outline).
   - pixelize(): ordered-dither quantization for painted backgrounds.
   - Bitmap font 5x7 with Portuguese accents.
   ===================================================================== */
const PIX = {};

/* ---------- colour helpers ---------- */
function hex(h) { h = h.replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function pack(r, g, b, a) { return (((a == null ? 255 : a) << 24) | (b << 16) | (g << 8) | r) >>> 0; }
function packHex(h) { const c = hex(h); return pack(c[0], c[1], c[2]); }
function mixHex(a, b, t) { const A = hex(a), B = hex(b); return '#' + [0, 1, 2].map(i => Math.round(A[i] + (B[i] - A[i]) * t).toString(16).padStart(2, '0')).join(''); }
function shadeHex(h, f) { const c = hex(h); return '#' + c.map(v => Math.max(0, Math.min(255, Math.round(v * f))).toString(16).padStart(2, '0')).join(''); }
PIX.hex = hex; PIX.mix = mixHex; PIX.shade = shadeHex;

/* ---------- Raster ---------- */
class Raster {
  constructor(w, h, ox, oy) {
    this.w = w; this.h = h; this.ox = ox; this.oy = oy;
    this.col = new Uint32Array(w * h); this.id = new Uint8Array(w * h);
    this.parts = [null]; // id -> {edge, flat, glow}
  }
  part(opt) { this.parts.push(opt || {}); return this.parts.length - 1; }
  _put(x, y, c, id) { if (x < 0 || y < 0 || x >= this.w || y >= this.h) return; const i = y * this.w + x; this.col[i] = c; this.id[i] = id; }
  /* tapered capsule from A to B */
  capsule(ax, ay, bx, by, ra, rb, color, id) {
    const c = typeof color === 'string' ? packHex(color) : color;
    ax += this.ox; ay += this.oy; bx += this.ox; by += this.oy;
    const r = Math.max(ra, rb);
    const x0 = Math.floor(Math.min(ax, bx) - r - 1), x1 = Math.ceil(Math.max(ax, bx) + r + 1);
    const y0 = Math.floor(Math.min(ay, by) - r - 1), y1 = Math.ceil(Math.max(ay, by) + r + 1);
    const dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy || 1e-6;
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      const px = x + 0.5, py = y + 0.5;
      let t = ((px - ax) * dx + (py - ay) * dy) / L2; t = t < 0 ? 0 : t > 1 ? 1 : t;
      const qx = ax + dx * t - px, qy = ay + dy * t - py; const rr = ra + (rb - ra) * t;
      if (qx * qx + qy * qy <= rr * rr) this._put(x, y, c, id);
    }
  }
  ellipse(cx, cy, rx, ry, rot, color, id) {
    const c = typeof color === 'string' ? packHex(color) : color;
    cx += this.ox; cy += this.oy; const r = Math.max(rx, ry);
    const cs = Math.cos(-(rot || 0)), sn = Math.sin(-(rot || 0));
    for (let y = Math.floor(cy - r - 1); y <= Math.ceil(cy + r + 1); y++) for (let x = Math.floor(cx - r - 1); x <= Math.ceil(cx + r + 1); x++) {
      const px = x + 0.5 - cx, py = y + 0.5 - cy; const u = px * cs - py * sn, v = px * sn + py * cs;
      if ((u * u) / (rx * rx) + (v * v) / (ry * ry) <= 1) this._put(x, y, c, id);
    }
  }
  circle(cx, cy, r, color, id) { this.ellipse(cx, cy, r, r, 0, color, id); }
  poly(pts, color, id) {
    const c = typeof color === 'string' ? packHex(color) : color;
    let y0 = 1e9, y1 = -1e9; const P = pts.map(p => [p[0] + this.ox, p[1] + this.oy]);
    for (const p of P) { if (p[1] < y0) y0 = p[1]; if (p[1] > y1) y1 = p[1]; }
    const n = P.length;
    for (let y = Math.floor(y0); y <= Math.ceil(y1); y++) {
      const sy = y + 0.5; const xs = [];
      for (let i = 0; i < n; i++) { const a = P[i], b = P[(i + 1) % n]; if ((a[1] <= sy && b[1] > sy) || (b[1] <= sy && a[1] > sy)) xs.push(a[0] + (sy - a[1]) / (b[1] - a[1]) * (b[0] - a[0])); }
      xs.sort((p, q) => p - q);
      for (let k = 0; k + 1 < xs.length; k += 2) { for (let x = Math.ceil(xs[k] - 0.5); x <= Math.floor(xs[k + 1] - 0.5); x++) this._put(x, y, c, id); }
    }
  }
  /* 1px line (for chains, strands, details) */
  line(ax, ay, bx, by, color, id) {
    const c = typeof color === 'string' ? packHex(color) : color;
    ax = Math.round(ax + this.ox - 0.5); ay = Math.round(ay + this.oy - 0.5); bx = Math.round(bx + this.ox - 0.5); by = Math.round(by + this.oy - 0.5);
    const dx = Math.abs(bx - ax), dy = -Math.abs(by - ay), sx = ax < bx ? 1 : -1, sy = ay < by ? 1 : -1; let err = dx + dy;
    for (let g = 0; g < 400; g++) { this._put(ax, ay, c, id); if (ax === bx && ay === by) break; const e2 = 2 * err; if (e2 >= dy) { err += dy; ax += sx; } if (e2 <= dx) { err += dx; ay += sy; } }
  }
  dot(x, y, color, id) { const c = typeof color === 'string' ? packHex(color) : color; this._put(Math.floor(x + this.ox), Math.floor(y + this.oy), c, id); }
  rect(x, y, w, h, color, id) { const c = typeof color === 'string' ? packHex(color) : color; for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this._put(Math.floor(x + this.ox) + i, Math.floor(y + this.oy) + j, c, id); }

  /* light: {rim:'#hex', rimK, amb:'#hex', ambK, outline:'#hex', key:1.22, dark:0.66} */
  finalize(light) {
    light = light || {};
    const w = this.w, h = this.h, col = this.col, id = this.id, parts = this.parts;
    const out = new Uint32Array(w * h);
    const rim = hex(light.rim || '#8fb4ff'), rimK = light.rimK != null ? light.rimK : 0.42;
    const amb = hex(light.amb || '#ffffff'), ambK = light.ambK != null ? light.ambK : 0.0;
    const key = light.key || 1.22, dark = light.dark || 0.64;
    const ol = hex(light.outline || '#0c0710');
    const OL = pack(ol[0], ol[1], ol[2]);
    const at = (x, y) => (x < 0 || y < 0 || x >= w || y >= h) ? 0 : id[y * w + x];
    let minx = w, miny = h, maxx = -1, maxy = -1;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const i = y * w + x, p = id[i];
      if (!p) continue;
      if (x < minx) minx = x; if (x > maxx) maxx = x; if (y < miny) miny = y; if (y > maxy) maxy = y;
      const c = col[i]; let r = c & 255, g = (c >> 8) & 255, b = (c >> 16) & 255;
      const P = parts[p] || {};
      if (!P.glow) {
        let f = 1;
        const ul = at(x - 1, y - 1), u = at(x, y - 1), l = at(x - 1, y);
        const dr = at(x + 1, y + 1), d2 = at(x + 2, y + 2), rr = at(x + 1, y), dd = at(x, y + 1);
        if (!P.flat) {
          if (ul !== p || u !== p) f = key;
          else if (dr !== p || d2 !== p || dd !== p) f = dark;
        }
        /* inner contour: neighbour belongs to a part drawn behind me */
        if (P.edge !== false) {
          const n4 = [u, dd, l, rr];
          for (const q of n4) if (q && q < p && !(parts[q] && parts[q].noLine)) { f = Math.min(f, 0.5); break; }
        }
        r *= f; g *= f; b *= f;
        if (ambK) { r = r * (1 - ambK) + r * amb[0] / 255 * ambK; g = g * (1 - ambK) + g * amb[1] / 255 * ambK; b = b * (1 - ambK) + b * amb[2] / 255 * ambK; }
        /* environment rim light on the back edge */
        if (rimK && (rr === 0 || at(x + 1, y - 1) === 0) && !P.noRim) { r = r + (rim[0] - r) * rimK; g = g + (rim[1] - g) * rimK; b = b + (rim[2] - b) * rimK; }
      }
      out[i] = pack(Math.min(255, r | 0), Math.min(255, g | 0), Math.min(255, b | 0));
    }
    /* outline */
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const i = y * w + x; if (id[i]) continue;
      if (at(x - 1, y) || at(x + 1, y) || at(x, y - 1) || at(x, y + 1)) out[i] = OL;
    }
    if (maxx < 0) { minx = miny = 0; maxx = maxy = 0; }
    minx = Math.max(0, minx - 1); miny = Math.max(0, miny - 1); maxx = Math.min(w - 1, maxx + 1); maxy = Math.min(h - 1, maxy + 1);
    const cw = maxx - minx + 1, ch = maxy - miny + 1;
    const cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
    const g2 = cv.getContext('2d'); const im = g2.createImageData(cw, ch); const d = new Uint32Array(im.data.buffer);
    for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) d[y * cw + x] = out[(y + miny) * w + x + minx];
    g2.putImageData(im, 0, 0);
    /* anchor (ox,oy) relative to the cropped canvas */
    return { cv, ax: this.ox - minx, ay: this.oy - miny, w: cw, h: ch };
  }
}
PIX.Raster = Raster;

/* ---------- pixelize: alpha threshold + Bayer-dithered quantization ---------- */
const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
PIX.pixelize = function (cv, levels, keepAlpha) {
  const g = cv.getContext('2d'); const im = g.getImageData(0, 0, cv.width, cv.height); const d = im.data; const w = cv.width;
  const step = 255 / (levels || 20);
  for (let i = 0, p = 0; i < d.length; i += 4, p++) {
    const x = p % w, y = (p / w) | 0; const th = (BAYER[(y & 3) * 4 + (x & 3)] / 16 - 0.5) * step;
    for (let k = 0; k < 3; k++) { const v = d[i + k] + th; d[i + k] = Math.max(0, Math.min(255, Math.round(v / step) * step)); }
    if (!keepAlpha) d[i + 3] = d[i + 3] < 110 ? 0 : 255;
  }
  g.putImageData(im, 0, 0); return cv;
};
PIX.canvas = function (w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.imageSmoothingEnabled = false; return [c, g]; };

/* ---------- bitmap font 5x7 (+accents) ---------- */
const GLYPH = {
  'A': ['01110', '10001', '10001', '11111', '10001', '10001', '10001'], 'B': ['11110', '10001', '10001', '11110', '10001', '10001', '11110'],
  'C': ['01111', '10000', '10000', '10000', '10000', '10000', '01111'], 'D': ['11110', '10001', '10001', '10001', '10001', '10001', '11110'],
  'E': ['11111', '10000', '10000', '11110', '10000', '10000', '11111'], 'F': ['11111', '10000', '10000', '11110', '10000', '10000', '10000'],
  'G': ['01111', '10000', '10000', '10011', '10001', '10001', '01111'], 'H': ['10001', '10001', '10001', '11111', '10001', '10001', '10001'],
  'I': ['11111', '00100', '00100', '00100', '00100', '00100', '11111'], 'J': ['00111', '00001', '00001', '00001', '10001', '10001', '01110'],
  'K': ['10001', '10010', '10100', '11000', '10100', '10010', '10001'], 'L': ['10000', '10000', '10000', '10000', '10000', '10000', '11111'],
  'M': ['10001', '11011', '10101', '10101', '10001', '10001', '10001'], 'N': ['10001', '11001', '10101', '10011', '10001', '10001', '10001'],
  'O': ['01110', '10001', '10001', '10001', '10001', '10001', '01110'], 'P': ['11110', '10001', '10001', '11110', '10000', '10000', '10000'],
  'Q': ['01110', '10001', '10001', '10001', '10101', '10010', '01101'], 'R': ['11110', '10001', '10001', '11110', '10100', '10010', '10001'],
  'S': ['01111', '10000', '10000', '01110', '00001', '00001', '11110'], 'T': ['11111', '00100', '00100', '00100', '00100', '00100', '00100'],
  'U': ['10001', '10001', '10001', '10001', '10001', '10001', '01110'], 'V': ['10001', '10001', '10001', '10001', '10001', '01010', '00100'],
  'W': ['10001', '10001', '10001', '10101', '10101', '10101', '01010'], 'X': ['10001', '10001', '01010', '00100', '01010', '10001', '10001'],
  'Y': ['10001', '10001', '01010', '00100', '00100', '00100', '00100'], 'Z': ['11111', '00001', '00010', '00100', '01000', '10000', '11111'],
  '0': ['01110', '10011', '10101', '10101', '11001', '10001', '01110'], '1': ['00100', '01100', '00100', '00100', '00100', '00100', '01110'],
  '2': ['01110', '10001', '00001', '00110', '01000', '10000', '11111'], '3': ['11110', '00001', '00001', '01110', '00001', '00001', '11110'],
  '4': ['00010', '00110', '01010', '10010', '11111', '00010', '00010'], '5': ['11111', '10000', '11110', '00001', '00001', '10001', '01110'],
  '6': ['00110', '01000', '10000', '11110', '10001', '10001', '01110'], '7': ['11111', '00001', '00010', '00100', '01000', '01000', '01000'],
  '8': ['01110', '10001', '10001', '01110', '10001', '10001', '01110'], '9': ['01110', '10001', '10001', '01111', '00001', '00010', '01100'],
  '.': ['00000', '00000', '00000', '00000', '00000', '01100', '01100'], ',': ['00000', '00000', '00000', '00000', '01100', '00100', '01000'],
  ':': ['00000', '01100', '01100', '00000', '01100', '01100', '00000'], '!': ['00100', '00100', '00100', '00100', '00100', '00000', '00100'],
  '?': ['01110', '10001', '00001', '00110', '00100', '00000', '00100'], '-': ['00000', '00000', '00000', '01110', '00000', '00000', '00000'],
  '+': ['00000', '00100', '00100', '11111', '00100', '00100', '00000'], '/': ['00001', '00010', '00010', '00100', '01000', '01000', '10000'],
  "'": ['00100', '00100', '01000', '00000', '00000', '00000', '00000'], '"': ['01010', '01010', '00000', '00000', '00000', '00000', '00000'],
  '(': ['00010', '00100', '01000', '01000', '01000', '00100', '00010'], ')': ['01000', '00100', '00010', '00010', '00010', '00100', '01000'],
  '%': ['11001', '11010', '00010', '00100', '01000', '01011', '10011'], '#': ['01010', '11111', '01010', '01010', '01010', '11111', '01010'],
  '>': ['10000', '11000', '11100', '11110', '11100', '11000', '10000'], '<': ['00001', '00011', '00111', '01111', '00111', '00011', '00001'],
  '^': ['00100', '01110', '11111', '00000', '00000', '00000', '00000'], '*': ['00000', '10101', '01110', '11111', '01110', '10101', '00000'],
  '=': ['00000', '00000', '11111', '00000', '11111', '00000', '00000'], '|': ['00100', '00100', '00100', '00100', '00100', '00100', '00100'],
  '_': ['00000', '00000', '00000', '00000', '00000', '00000', '11111'], ' ': ['00000', '00000', '00000', '00000', '00000', '00000', '00000'],
  '¿': ['00100', '00000', '00100', '01100', '10000', '10001', '01110'], '¡': ['00100', '00000', '00100', '00100', '00100', '00100', '00100'],
  '@': ['01110', '10001', '10111', '10101', '10111', '10000', '01110'], '&': ['01100', '10010', '10100', '01000', '10101', '10010', '01101']
};
const ACC = { 'Ñ': ['N', 'tilde'], 'È': ['E', 'grave'], 'Ì': ['I', 'grave'], 'Ò': ['O', 'grave'], 'Ù': ['U', 'grave'], 'Ä': ['A', 'uml'], 'Ë': ['E', 'uml'], 'Ï': ['I', 'uml'], 'Ö': ['O', 'uml'], 'Î': ['I', 'circ'], 'Û': ['U', 'circ'], 'Ÿ': ['Y', 'uml'], 'Á': ['A', 'acute'], 'À': ['A', 'grave'], 'Â': ['A', 'circ'], 'Ã': ['A', 'tilde'], 'É': ['E', 'acute'], 'Ê': ['E', 'circ'], 'Í': ['I', 'acute'], 'Ó': ['O', 'acute'], 'Ô': ['O', 'circ'], 'Õ': ['O', 'tilde'], 'Ú': ['U', 'acute'], 'Ü': ['U', 'uml'], 'Ç': ['C', 'ced'] };
const ACCPIX = { acute: [[2, -2], [3, -2]], grave: [[1, -2], [2, -2]], circ: [[1, -1], [2, -2], [3, -1]], tilde: [[0, -1], [1, -2], [2, -1], [3, -2]], uml: [[1, -2], [3, -2]] };
const fontCache = new Map();
/* draw text with the pixel font. opts: {s:scale, col, out:outline col|null, shadow, align:'l'|'c'|'r', grad:[top,bottom]} */
const SYSFONT = '"Noto Sans","Noto Sans CJK SC","Noto Sans CJK JP","Noto Sans CJK KR","Noto Sans Devanagari","Noto Sans Arabic","Noto Naskh Arabic",Roboto,system-ui,sans-serif';
PIX.norm = str => String(str).toUpperCase().replace(/[’‘]/g, "'").replace(/[“”]/g, '"').replace(/…/g, '...');
PIX.isPixel = function (str) { for (const ch of str) { if (!GLYPH[ch] && !ACC[ch]) return false; } return true; };
const _mctx = document.createElement('canvas').getContext('2d');
PIX.sysFont = s => 'bold ' + (8.6 * s) + 'px ' + SYSFONT;
PIX.textW = function (str, s) { s = s || 1; str = PIX.norm(str); if (PIX.isPixel(str)) return Math.max(0, str.length * 6 * s - s); _mctx.font = PIX.sysFont(s); return Math.ceil(_mctx.measureText(str).width); };
PIX.textSys = function (g, str, x, y, opt) {
  const s = opt.s || 1; g.save(); g.font = PIX.sysFont(s); g.textBaseline = 'middle'; g.textAlign = 'left';
  const rtl = /[\u0590-\u08FF]/.test(str); g.direction = rtl ? 'rtl' : 'ltr'; if (rtl) g.textAlign = 'right';
  const w = Math.ceil(g.measureText(str).width); let x0 = x; if (opt.align === 'c') x0 = x - w / 2; else if (opt.align === 'r') x0 = x - w;
  const xd = rtl ? x0 + w : x0, yy = y + 3.6 * s;
  const out = opt.out === undefined ? '#0c0710' : opt.out;
  if (opt.shadow) { g.fillStyle = opt.shadow; g.fillText(str, xd + s, yy + s); }
  if (out) { g.lineJoin = 'round'; g.strokeStyle = out; g.lineWidth = Math.max(1.4, s * 1.5); g.strokeText(str, xd, yy); }
  if (opt.grad) { const gr = g.createLinearGradient(0, y, 0, y + 7 * s); opt.grad.forEach((c, i) => gr.addColorStop(i / (opt.grad.length - 1), c)); g.fillStyle = gr; } else g.fillStyle = opt.col || '#fff';
  g.fillText(str, xd, yy); g.restore(); return w;
};
PIX.text = function (g, str, x, y, opt) {
  opt = opt || {}; const s = opt.s || 1; str = PIX.norm(str);
  if (!PIX.isPixel(str)) return PIX.textSys(g, str, x, y, opt);
  const key = str + '|' + s + '|' + (opt.col || '#fff') + '|' + (opt.out === undefined ? 'd' : opt.out) + '|' + (opt.grad ? opt.grad.join() : '') + '|' + (opt.shadow || '');
  let cv = fontCache.get(key);
  if (!cv) {
    const pad = 2 * s; const W = PIX.textW(str, s) + pad * 2 + s, H = 9 * s + pad * 2 + s;
    const [c, g2] = PIX.canvas(W, H);
    const drawGlyphs = (col, dx, dy) => {
      g2.fillStyle = col;
      for (let i = 0; i < str.length; i++) {
        let ch = str[i], acc = null; if (ACC[ch]) { acc = ACC[ch][1]; ch = ACC[ch][0]; }
        const G = GLYPH[ch] || GLYPH['?']; const bx = pad + i * 6 * s + dx, by = pad + 2 * s + dy;
        for (let r = 0; r < 7; r++) for (let k = 0; k < 5; k++) if (G[r][k] === '1') g2.fillRect(bx + k * s, by + r * s, s, s);
        if (acc === 'ced') { g2.fillRect(bx + 2 * s, by + 7 * s, s, s); g2.fillRect(bx + 1 * s, by + 8 * s, s, s); }
        else if (acc) for (const [ax, ay] of ACCPIX[acc]) g2.fillRect(bx + ax * s, by + ay * s, s, s);
      }
    };
    const out = opt.out === undefined ? '#0c0710' : opt.out;
    if (opt.shadow) drawGlyphs(opt.shadow, s, s);
    if (out) { for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [1, 1], [1, -1], [-1, 1]]) drawGlyphs(out, dx * Math.max(1, s >> 1), dy * Math.max(1, s >> 1)); }
    drawGlyphs(opt.col || '#fff', 0, 0);
    if (opt.grad) {
      const [c2, g3] = PIX.canvas(W, H); g3.drawImage(c, 0, 0);
      const gr = g3.createLinearGradient(0, pad + 2 * s, 0, pad + 9 * s); opt.grad.forEach((cc, i) => gr.addColorStop(i / (opt.grad.length - 1), cc));
      // recolour only the glyph body (not outline): redraw glyph mask filled by gradient
      const [m, gm] = PIX.canvas(W, H); const save = g2; drawGlyphsTo(gm, str, s, pad);
      gm.globalCompositeOperation = 'source-in'; gm.fillStyle = gr; gm.fillRect(0, 0, W, H);
      g3.drawImage(m, 0, 0); cv = c2;
    } else cv = c;
    if (fontCache.size > 600) fontCache.clear();
    fontCache.set(key, cv);
  }
  const w = cv.width; const pad = 2 * s;
  let dx = x - pad; if (opt.align === 'c') dx = Math.round(x - w / 2); else if (opt.align === 'r') dx = x - w + pad;
  g.drawImage(cv, Math.round(dx), Math.round(y - pad - 2 * s));
  return w - pad * 2;
};
function drawGlyphsTo(g2, str, s, pad) {
  g2.fillStyle = '#fff';
  for (let i = 0; i < str.length; i++) {
    let ch = str[i], acc = null; if (ACC[ch]) { acc = ACC[ch][1]; ch = ACC[ch][0]; }
    const G = GLYPH[ch] || GLYPH['?']; const bx = pad + i * 6 * s, by = pad + 2 * s;
    for (let r = 0; r < 7; r++) for (let k = 0; k < 5; k++) if (G[r][k] === '1') g2.fillRect(bx + k * s, by + r * s, s, s);
    if (acc === 'ced') { g2.fillRect(bx + 2 * s, by + 7 * s, s, s); g2.fillRect(bx + s, by + 8 * s, s, s); }
    else if (acc) for (const [ax, ay] of ACCPIX[acc]) g2.fillRect(bx + ax * s, by + ay * s, s, s);
  }
}
/* wrap text into lines that fit width (in px at scale s) */
PIX.wrap = function (str, maxW, s) {
  str = String(str); const cjk = /[\u3040-\u30ff\u3400-\u9fff]/.test(str);
  const words = cjk ? Array.from(str) : str.split(' '); const sep = cjk ? '' : ' '; const lines = []; let cur = '';
  const noStart = '。、，．！？）」』…ー・：；';
  for (const w of words) { const t = cur ? cur + sep + w : w; if (PIX.textW(t, s) > maxW && cur && !(cjk && noStart.includes(w))) { lines.push(cur); cur = w; } else cur = t; }
  if (cur) lines.push(cur); return lines;
};

/* ---------- pixel UI frame (angled corners, Cosmic-Invasion-ish) ---------- */
PIX.panel = function (g, x, y, w, h, opt) {
  opt = opt || {}; x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
  const cut = opt.cut != null ? opt.cut : 4; const bg = opt.bg || 'rgba(10,8,18,0.86)', edge = opt.edge || '#ff0033', edge2 = opt.edge2 || shadeHex(opt.edge && opt.edge[0] === '#' ? opt.edge : '#ff0033', 0.45);
  const path = () => { g.beginPath(); g.moveTo(x + cut, y); g.lineTo(x + w, y); g.lineTo(x + w, y + h - cut); g.lineTo(x + w - cut, y + h); g.lineTo(x, y + h); g.lineTo(x, y + cut); g.closePath(); };
  g.fillStyle = bg; path(); g.fill();
  // crisp 1px border with rects
  g.fillStyle = edge2;
  g.fillRect(x + cut, y, w - cut, 1); g.fillRect(x, y + h - 1, w - cut, 1); g.fillRect(x, y + cut, 1, h - cut); g.fillRect(x + w - 1, y, 1, h - cut);
  for (let i = 0; i < cut; i++) { g.fillRect(x + cut - i - 1, y + i, 1, 1); g.fillRect(x + w - 1 - i, y + h - cut + i, 1, 1); }
  g.fillStyle = edge; g.fillRect(x + cut, y, Math.min(18, w - cut), 1); g.fillRect(x, y + cut, 1, Math.min(10, h - cut)); g.fillRect(x + w - 18, y + h - 1, 18 - cut, 1);
};
PIX.bar = function (g, x, y, w, h, f, col, back, segs) {
  x = Math.round(x); y = Math.round(y); g.fillStyle = back || '#1a0d16'; g.fillRect(x, y, w, h);
  const fw = Math.round((w - 2) * Math.max(0, Math.min(1, f)));
  g.fillStyle = col; g.fillRect(x + 1, y + 1, fw, h - 2);
  g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillRect(x + 1, y + 1, fw, 1);
  g.fillStyle = 'rgba(0,0,0,0.3)'; g.fillRect(x + 1, y + h - 2, fw, 1);
  if (segs) { g.fillStyle = '#0c0710'; for (let i = 1; i < segs; i++) g.fillRect(x + Math.round(w * i / segs), y, 1, h); }
};
