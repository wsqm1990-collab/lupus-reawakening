'use strict';
/* ===== CORE: screen scaling, input, save, scenes, audio ===== */
const VH = 270;
let VW = 480;
const cv = document.getElementById('c');
const ctx = cv.getContext('2d');
const [BUF, bg] = PIX.canvas(1248, VH * 2);   // 2x frame buffer (540 px tall)
let SCALE = 1, OX = 0, OY = 0, PORTRAIT = false;
function resize() {
  const dpr = Math.min(window.devicePixelRatio || 1, window.DPR_CAP || 3);
  const iw = window.innerWidth, ih = window.innerHeight;
  PORTRAIT = ih > iw * 1.05;
  VW = Math.round(Math.min(624, Math.max(480, VH * iw / ih)));
  cv.width = Math.round(iw * dpr); cv.height = Math.round(ih * dpr);
  cv.style.width = iw + 'px'; cv.style.height = ih + 'px';
  SCALE = Math.min(cv.width / VW, cv.height / VH);
  OX = Math.round((cv.width - VW * SCALE) / 2); OY = Math.round((cv.height - VH * SCALE) / 2);
  cv._dpr = dpr;
}
window.addEventListener('resize', resize);
window.addEventListener('orientationchange', () => setTimeout(resize, 200));
resize();

const rnd = (a, b) => a + Math.random() * (b - a);
const rndi = (a, b) => Math.floor(rnd(a, b + 1));
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const pick = a => a[Math.floor(Math.random() * a.length)];
const dist = (a, b) => Math.hypot(a.x - b.x, (a.y - b.y) * 1.7);

/* ---------- save ---------- */
const SAVE_KEY = 'lupus_reawakening_v2';
let SAVE = { unlocked: 1, hero: 'lupus', ally: 'vespera', up: { dmg: 0, hp: 0, fury: 0, cd: 0 }, seenIntro: false, diff: 'normal', shards: 0, stars: {}, xp: {}, owned: {}, pal: {}, lang: 'en', music: true, sfx: true, best: {} };
function loadSave() { try { const s = JSON.parse(localStorage.getItem(SAVE_KEY)); if (s) SAVE = Object.assign(SAVE, s, { up: Object.assign(SAVE.up, s.up || {}) }); } catch (e) { } }
function saveGame() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(SAVE)); } catch (e) { } }
loadSave();

/* ---------- scenes ---------- */
const Scenes = {};
const Scene = { cur: null, name: '', fade: 0, go(name, arg) { Scene.name = name; Scene.cur = Scenes[name]; Scene.fade = 1; Inp.reset(); Scene.cur.enter && Scene.cur.enter(arg); } };

/* ---------- input ---------- */
const Inp = {
  keys: {}, edge: {}, held: {}, joy: { id: null, ox: 0, oy: 0, x: 0, y: 0, ax: 0, ay: 0 }, btnIds: {},
  reset() { this.edge = {}; this.held = {}; this.keys = {}; this.joy.id = null; this.joy.ax = this.joy.ay = 0; this.btnIds = {}; }
};
const keyMap = { ArrowLeft: 'l', ArrowRight: 'r', ArrowUp: 'u', ArrowDown: 'd', a: 'l', d: 'r', w: 'u', s: 'd', A: 'l', D: 'r', W: 'u', S: 'd',
  j: 'atk', J: 'atk', z: 'atk', Z: 'atk', k: 'jump', K: 'jump', x: 'jump', X: 'jump', l: 'spec', L: 'spec', c: 'spec', C: 'spec', ' ': 'dash', Shift: 'dash', e: 'form', E: 'form', Tab: 'form', v: 'form', V: 'form', q: 'tag', Q: 'tag', f: 'assist', F: 'assist', r: 'super', R: 'super', g: 'block', G: 'block', b: 'block', B: 'block', h: 'sense', H: 'sense', n: 'sense', N: 'sense' };
window.addEventListener('keydown', e => {
  audioInit();
  if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') { Scene.cur && Scene.cur.onKey && Scene.cur.onKey('pause'); }
  if (e.key === 'Enter') { Scene.cur && Scene.cur.onKey && Scene.cur.onKey('ok'); }
  const m = keyMap[e.key]; if (!m) return; e.preventDefault();
  if (!Inp.keys[m]) Inp.edge[m] = true; Inp.keys[m] = true; Inp.held[m] = true;
});
window.addEventListener('keyup', e => { const m = keyMap[e.key]; if (m) { Inp.keys[m] = false; Inp.held[m] = false; } });
function toLogical(e) { return { x: (e.clientX * cv._dpr - OX) / SCALE, y: (e.clientY * cv._dpr - OY) / SCALE }; }
cv.addEventListener('pointerdown', e => { e.preventDefault(); audioInit(); try { cv.setPointerCapture(e.pointerId); } catch (_) { } const p = toLogical(e); Scene.cur && Scene.cur.onDown && Scene.cur.onDown(e.pointerId, p.x, p.y); });
cv.addEventListener('pointermove', e => { e.preventDefault(); const p = toLogical(e); Scene.cur && Scene.cur.onMove && Scene.cur.onMove(e.pointerId, p.x, p.y); });
cv.addEventListener('pointerup', e => { e.preventDefault(); const p = toLogical(e); Scene.cur && Scene.cur.onUp && Scene.cur.onUp(e.pointerId, p.x, p.y); });
cv.addEventListener('pointercancel', e => { Scene.cur && Scene.cur.onUp && Scene.cur.onUp(e.pointerId, -1, -1); });
cv.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('visibilitychange', () => { if (document.hidden && Scene.cur && Scene.cur.onKey) Scene.cur.onKey('hide'); if (AU.c) { if (document.hidden) AU.c.suspend(); else AU.c.resume(); } });

/* ---------- audio (procedural) ---------- */
const AU = { c: null, master: null, mus: null, sfx: null, step: 0, next: 0, timer: null, stage: 0, playing: false };
function audioInit() {
  if (AU.c) { if (AU.c.state === 'suspended') AU.c.resume(); return; }
  try {
    AU.c = new (window.AudioContext || window.webkitAudioContext)();
    AU.master = AU.c.createGain(); AU.master.gain.value = 0.7; AU.master.connect(AU.c.destination);
    AU.mus = AU.c.createGain(); AU.mus.gain.value = SAVE.music ? 0.32 : 0; AU.mus.connect(AU.master);
    AU.sfx = AU.c.createGain(); AU.sfx.gain.value = SAVE.sfx ? 0.8 : 0; AU.sfx.connect(AU.master);
    const len = AU.c.sampleRate; AU.nbuf = AU.c.createBuffer(1, len, AU.c.sampleRate);
    const d = AU.nbuf.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    if (AU.wantMusic != null) musicStart(AU.wantMusic);
  } catch (e) { AU.c = null; }
}
function setAudioOpts() { if (!AU.c) return; AU.mus.gain.value = SAVE.music ? 0.32 : 0; AU.sfx.gain.value = SAVE.sfx ? 0.8 : 0; }
function tone(f, d, type, v, slide, dest, when) {
  if (!AU.c) return; const t = when || AU.c.currentTime;
  const o = AU.c.createOscillator(), g = AU.c.createGain();
  o.type = type || 'square'; o.frequency.setValueAtTime(f, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f + slide), t + d);
  g.gain.setValueAtTime(v || 0.2, t); g.gain.exponentialRampToValueAtTime(0.0008, t + d);
  o.connect(g); g.connect(dest || AU.sfx); o.start(t); o.stop(t + d + 0.02);
}
function noise(d, v, fq, dest, when, type) {
  if (!AU.c) return; const t = when || AU.c.currentTime;
  const s = AU.c.createBufferSource(); s.buffer = AU.nbuf; const f = AU.c.createBiquadFilter(); f.type = type || 'lowpass'; f.frequency.value = fq || 2000;
  const g = AU.c.createGain(); g.gain.setValueAtTime(v || 0.3, t); g.gain.exponentialRampToValueAtTime(0.0008, t + d);
  s.connect(f); f.connect(g); g.connect(dest || AU.sfx); s.start(t, Math.random() * 0.5); s.stop(t + d + 0.02);
}
const SFX = {
  hit() { noise(0.09, 0.5, 2400); tone(150, 0.09, 'square', 0.22, -90); },
  hit2() { noise(0.14, 0.7, 1600); tone(90, 0.16, 'sawtooth', 0.3, -50); },
  slash() { noise(0.12, 0.25, 6000, null, null, 'highpass'); tone(600, 0.1, 'sawtooth', 0.08, -400); },
  jump() { tone(260, 0.12, 'triangle', 0.14, 260); },
  land() { noise(0.06, 0.2, 500); },
  dash() { noise(0.18, 0.25, 3000, null, null, 'bandpass'); },
  hurt() { tone(220, 0.18, 'sawtooth', 0.25, -150); noise(0.1, 0.3, 1200); },
  shot() { tone(900, 0.12, 'square', 0.1, -700); noise(0.05, 0.2, 4000, null, null, 'highpass'); },
  special() { tone(110, 0.5, 'sawtooth', 0.3, 330); noise(0.4, 0.3, 1200); },
  howl() { tone(240, 0.9, 'sawtooth', 0.28, 160); tone(235, 0.9, 'triangle', 0.22, 150); noise(0.5, 0.3, 800); },
  transform() { tone(70, 0.8, 'sawtooth', 0.35, 200); noise(0.7, 0.4, 500); tone(400, 0.5, 'square', 0.1, -300); },
  pick() { tone(660, 0.1, 'triangle', 0.2); tone(990, 0.16, 'triangle', 0.2, 0, null, AU.c ? AU.c.currentTime + 0.08 : 0); },
  boom() { noise(0.6, 0.8, 400); tone(60, 0.6, 'sawtooth', 0.4, -30); },
  die() { tone(180, 0.35, 'sawtooth', 0.25, -150); noise(0.25, 0.4, 900); },
  ui() { tone(520, 0.07, 'square', 0.12); },
  ok() { tone(440, 0.07, 'square', 0.13); tone(880, 0.1, 'square', 0.13, 0, null, AU.c ? AU.c.currentTime + 0.07 : 0); },
  roar() { tone(80, 1.2, 'sawtooth', 0.4, 60); noise(1.0, 0.5, 600); },
  heal() { tone(520, 0.2, 'sine', 0.2, 300); tone(780, 0.3, 'sine', 0.2, 300); },
  sting() { tone(55, 0.7, 'sawtooth', 0.35, -20); noise(0.5, 0.5, 700); tone(220, 0.5, 'square', 0.08, 440); },
  stingBoss() { tone(41, 1.4, 'sawtooth', 0.45, -10); tone(82, 1.2, 'square', 0.12, -30); noise(1.0, 0.6, 500); tone(660, 0.8, 'triangle', 0.06, -500); },
  heart() { tone(60, 0.12, 'sine', 0.5, -20); tone(55, 0.14, 'sine', 0.4, -20, null, AU.c ? AU.c.currentTime + 0.18 : 0); },
  impact() { noise(0.35, 0.6, 900); tone(70, 0.4, 'sawtooth', 0.35, -40); },
  alarm() { tone(440, 0.2, 'square', 0.12); tone(330, 0.3, 'square', 0.12, 0, null, AU.c ? AU.c.currentTime + 0.2 : 0); }
};
/* haptics: native bridge in the APK, Vibration API on the web; respects the option */
function vibe(ms, amp) { if (SAVE.vib === false) return; try { if (window.LupusNative && LupusNative.vibrate) LupusNative.vibrate(ms | 0, amp || 120); else if (navigator.vibrate) navigator.vibrate(ms | 0); } catch (e) { } }
function sfx(n) { if (AU.c && SAVE.sfx && SFX[n]) SFX[n](); }

/* music: procedural composer — 4-bar loops with chords, bass, arps, a lead melody and drums;
   a heavier layer kicks in during boss fights */
const MODES = { aeo: [0, 2, 3, 5, 7, 8, 10], phr: [0, 1, 3, 5, 7, 8, 10], hmin: [0, 2, 3, 5, 7, 8, 11], dor: [0, 2, 3, 5, 7, 9, 10] };
const SONGS = [
  { root: 45, mode: 'aeo', bpm: 112, prog: [0, 5, 3, 4], kick: 'x...x...x...x.x.', hat: 16, arp: 1, bassP: 'x.x.x..xx.x.x..x', seed: 7 },   // neon slums
  { root: 43, mode: 'hmin', bpm: 104, prog: [0, 3, 5, 4], kick: 'x.....x...x.....', hat: 8, arp: 1, bassP: 'x...x.x.x...x.x.', seed: 13 }, // cathedral
  { root: 40, mode: 'dor', bpm: 96, prog: [0, 6, 3, 4], kick: 'x.......x..x....', hat: 8, arp: 0, bassP: 'x..x..x.x..x..x.', seed: 21 },   // undercity
  { root: 38, mode: 'phr', bpm: 118, prog: [0, 1, 0, 6], kick: 'x...x...x...x...', hat: 16, arp: 1, bassP: 'xx.xx.x.xx.xx.x.', seed: 33 }, // metro
  { root: 36, mode: 'phr', bpm: 126, prog: [0, 1, 5, 4], kick: 'x.x.x...x.x.x..x', hat: 16, arp: 1, bassP: 'x.xxx.x.x.xxx.xx', seed: 47 }, // bio-lab
  { root: 41, mode: 'hmin', bpm: 88, prog: [0, 5, 6, 4], kick: 'x.......x.......', hat: 8, arp: 0, bassP: 'x.......x...x...', seed: 5 }      // menus / title
];
const mf = n => 440 * Math.pow(2, (n - 69) / 12);
function rng(seed) { let x = seed * 9301 + 49297; return () => { x = (x * 9301 + 49297) % 233280; return x / 233280; }; }
function makeLead(S) { const r = rng(S.seed), out = []; let deg = 4; for (let st = 0; st < 64; st++) { const pos = st & 15; let on = pos % 4 === 0 ? r() < 0.8 : pos % 2 === 0 ? r() < 0.45 : r() < 0.12; if (on) { const cr = S.prog[st >> 4]; deg = pos % 4 === 0 ? cr + [0, 2, 4, 7][Math.floor(r() * 4)] : deg + (r() < 0.5 ? -1 : 1) * (r() < 0.75 ? 1 : 2); deg = Math.max(cr - 2, Math.min(cr + 9, deg)); out.push({ deg, len: pos % 4 === 0 ? 2 + Math.floor(r() * 3) : 1 }); } else out.push(null); } return out; }
SONGS.forEach(S => { S.scale = MODES[S.mode]; S.lead = makeLead(S); });
const noteOf = (S, deg, oct) => { const n = S.scale.length, o = Math.floor(deg / n), d = ((deg % n) + n) % n; return S.root + 12 * (oct + o) + S.scale[d]; };
function musicStart(i) {
  AU.wantMusic = i; if (!AU.c) return; if (AU.playing && AU.stage === i) return; AU.stage = i; AU.playing = true; AU.step = 0; AU.loop = 0; AU.next = AU.c.currentTime + 0.1;
  if (!AU.timer) AU.timer = setInterval(musicTick, 60);
}
function musicStop() { AU.playing = false; AU.wantMusic = null; }
function musicTick() {
  if (!AU.c || !AU.playing) return;
  const S = SONGS[AU.stage % SONGS.length], boss = typeof G !== 'undefined' && G && G.boss && !G.boss.dead && Scene.name === 'play';
  const dur = 60 / (S.bpm * (boss ? 1.08 : 1)) / 4;
  while (AU.next < AU.c.currentTime + 0.25) {
    const st = AU.step % 64, pos = st & 15, bar = st >> 4, t = AU.next, cr = S.prog[bar], M = AU.mus;
    /* drums */
    if (S.kick[pos] === 'x' || (boss && pos % 4 === 0)) { tone(110, 0.16, 'sine', 0.55, -75, M, t); noise(0.03, 0.15, 900, M, t); }
    if (pos === 4 || pos === 12) { noise(0.16, 0.32, 2400, M, t, 'bandpass'); tone(200, 0.08, 'triangle', 0.12, -60, M, t); }
    if (boss && (pos === 14 || pos === 15) && bar === 3) noise(0.1, 0.25, 1800, M, t, 'bandpass');
    if (S.hat === 16 || pos % 2 === 0) noise(0.025, pos % 4 === 2 ? 0.11 : 0.06, 9000, M, t, 'highpass');
    /* bass */
    if (S.bassP[pos] === 'x') { const n = noteOf(S, cr + (pos === 10 && bar % 2 ? 4 : 0), -1); tone(mf(n), dur * 1.8, 'sawtooth', 0.2, 0, M, t); tone(mf(n - 12), dur * 1.2, 'square', 0.06, 0, M, t); }
    /* pad: chord at each bar */
    if (pos === 0) for (const k of [0, 2, 4]) tone(mf(noteOf(S, cr + k, 1)), dur * 15, 'triangle', 0.035, 0, M, t);
    /* arpeggio */
    if (S.arp && (AU.loop % 2 === 1 || boss) && pos % 2 === 0) { const k = [0, 2, 4, 7][(pos >> 1) % 4]; tone(mf(noteOf(S, cr + k, 2)), dur * 1.1, 'square', 0.022, 0, M, t); }
    /* lead melody: second half of each section, always during bosses */
    const L = S.lead[st]; if (L && (AU.loop % 4 >= 2 || boss || AU.stage === 5)) { const n = noteOf(S, L.deg, 1 + (boss ? 1 : 0)); tone(mf(n), dur * L.len * 1.3, boss ? 'sawtooth' : 'square', boss ? 0.045 : 0.04, 0, M, t); tone(mf(n) * 1.005, dur * L.len * 1.3, 'triangle', 0.03, 0, M, t); }
    AU.step++; if (AU.step % 64 === 0) AU.loop++; AU.next += dur;
  }
}

