'use strict';
/* =====================================================================
   v9.4 — combat feel and clarity, closer to modern premium brawlers.
   Loaded after every other module and before main.js.
   ===================================================================== */
(function () {
  /* ---------- 1. Text for the Swap / Form taps on the HUD pictures ---------- */
  /* Column order of TR9 rows: en, es, fr, de, it, ru, zh, ja, ko, hi, ar */
  if (window.TR9 && TR9.add) TR9.add([
    ['FURY READY! Tap the WOLF at the top to turn into the WEREWOLF!', '¡FURIA LISTA! ¡Toca el LOBO de arriba para convertirte en HOMBRE LOBO!', 'FUREUR PRÊTE ! Touche le LOUP en haut pour devenir LOUP-GAROU !', 'WUT BEREIT! Tippe oben auf den WOLF, um zum WERWOLF zu werden!', 'FURIA PRONTA! Tocca il LUPO in alto per diventare LUPO MANNARO!', 'ЯРОСТЬ ГОТОВА! Нажмите на ВОЛКА вверху, чтобы стать ОБОРОТНЕМ!', '怒气已满！点击上方的【狼】化身狼人！', '怒り満タン！上の「狼」をタップして人狼に変身！', '분노 충전! 위쪽의 늑대를 탭해 늑대인간으로 변신하세요!', 'क्रोध तैयार! भेड़िया-मानव बनने के लिए ऊपर भेड़िये पर टैप करें!', 'الغضب جاهز! انقر على الذئب في الأعلى لتتحول إلى مستذئب!'],
    ['PARTNER: VESPERA — Tap her picture (top left) to SWAP · ASSIST calls in her strike', 'COMPAÑERA: VESPERA — Toca su retrato (arriba a la izquierda) para CAMBIAR · AYUDA la llama para un golpe', 'PARTENAIRE : VESPERA — Touche son portrait (en haut à gauche) pour le RELAIS · AIDE l’appelle pour une frappe', 'PARTNERIN: VESPERA — Tippe auf ihr Bild (oben links) zum WECHSELN · HILFE ruft ihren Angriff', 'COMPAGNA: VESPERA — Tocca il suo ritratto (in alto a sinistra) per il CAMBIO · AIUTO la chiama per un colpo', 'НАПАРНИЦА: ВЕСПЕРА — Нажмите на её портрет (слева вверху) для СМЕНЫ · ПОМОЩЬ вызывает её удар', '搭档：维斯佩拉 — 点击她的头像（左上角）即可【换人】·【援助】呼叫她出手', '相棒：ヴェスペラ — 左上の顔をタップで「交代」・「援護」で攻撃を呼ぶ', '파트너: 베스페라 — 왼쪽 위 초상화를 탭해 교대 · 지원으로 그녀의 공격 호출', 'साथी: वेस्पेरा — बदलने के लिए उसकी तस्वीर (ऊपर बाएँ) पर टैप करें · मदद से उसका वार बुलाएँ', 'الشريكة: فيسبيرا — انقر على صورتها (أعلى اليسار) للتبديل · مساعدة تستدعي ضربتها'],
    ['Tap the pictures at the top (cleaner screen)', 'Tocar los retratos de arriba (pantalla más limpia)', 'Toucher les portraits en haut (écran plus dégagé)', 'Oben auf die Bilder tippen (aufgeräumter Bildschirm)', 'Tocca i ritratti in alto (schermo più pulito)', 'Нажимать на портреты вверху (чище экран)', '点击上方头像（画面更简洁）', '上の顔アイコンをタップ（画面すっきり）', '위쪽 초상화 탭 (더 깔끔한 화면)', 'ऊपर की तस्वीरों पर टैप करें (साफ़ स्क्रीन)', 'النقر على الصور في الأعلى (شاشة أنظف)'],
    ['Also show the SWAP and FORM buttons', 'Mostrar también los botones CAMBIO y FORMA', 'Afficher aussi les boutons RELAIS et FORME', 'Auch die Tasten WECHSEL und FORM zeigen', 'Mostra anche i pulsanti CAMBIO e FORMA', 'Показывать также кнопки СМЕНА и ФОРМА', '同时显示【换人】和【变身】按钮', '「交代」と「変身」ボタンも表示', '교대·변신 버튼도 표시', 'बदलें और रूप बटन भी दिखाएँ', 'إظهار زرّي تبديل وتحول أيضًا'],
    ['Swap and Form', 'Cambio y forma', 'Relais et forme', 'Wechsel und Form', 'Cambio e forma', 'Смена и форма', '换人与变身', '交代と変身', '교대와 변신', 'बदलें और रूप', 'التبديل والتحول']
  ]);
  const TUT94 = {
    en: ["SWAP: TAP YOUR PARTNER'S PICTURE (TOP LEFT)", 'THORNE: TAP THE WOLF AT THE TOP TO TRANSFORM'],
    pt: ['TROCA: TOQUE NA FOTO DO PARCEIRO (NO ALTO, À ESQUERDA)', 'THORNE: TOQUE NO LOBO LÁ EM CIMA PARA SE TRANSFORMAR'],
    es: ['CAMBIO: TOCA EL RETRATO DE TU COMPAÑERO (ARRIBA A LA IZQUIERDA)', 'THORNE: TOCA EL LOBO DE ARRIBA PARA TRANSFORMARTE'],
    fr: ['RELAIS : TOUCHE LE PORTRAIT DE TON PARTENAIRE (EN HAUT À GAUCHE)', 'THORNE : TOUCHE LE LOUP EN HAUT POUR TE TRANSFORMER'],
    de: ['WECHSEL: TIPPE AUF DAS BILD DEINES PARTNERS (OBEN LINKS)', 'THORNE: TIPPE OBEN AUF DEN WOLF ZUM VERWANDELN'],
    it: ['CAMBIO: TOCCA IL RITRATTO DEL TUO COMPAGNO (IN ALTO A SINISTRA)', 'THORNE: TOCCA IL LUPO IN ALTO PER TRASFORMARTI'],
    ru: ['СМЕНА: НАЖМИТЕ НА ПОРТРЕТ НАПАРНИКА (СЛЕВА ВВЕРХУ)', 'ТОРН: НАЖМИТЕ НА ВОЛКА ВВЕРХУ, ЧТОБЫ ПРЕВРАТИТЬСЯ'],
    zh: ['换人：点击搭档头像（左上角）', '索恩：点击上方的狼来变身'],
    ja: ['交代：左上の相棒の顔をタップ', 'ソーン：上の狼をタップして変身'],
    ko: ['교대: 왼쪽 위 파트너 초상화를 탭', '존 손: 위쪽 늑대를 탭해 변신'],
    hi: ['बदलें: साथी की तस्वीर पर टैप करें (ऊपर बाएँ)', 'थॉर्न: रूप बदलने के लिए ऊपर भेड़िये पर टैप करें'],
    ar: ['تبديل: انقر على صورة شريكك (أعلى اليسار)', 'ثورن: انقر على الذئب في الأعلى لتتحول']
  };
  if (typeof I18N !== 'undefined') for (const c in TUT94) if (I18N[c] && I18N[c].ui) { I18N[c].ui.tut_tag94 = TUT94[c][0]; I18N[c].ui.tut_form94 = TUT94[c][1]; }
  /* the active table was built before these keys existed; later language changes rebuild it from I18N */
  if (typeof STR !== 'undefined' && STR[SAVE.lang]) { const L = TUT94[SAVE.lang] || TUT94.en; STR[SAVE.lang].tut_tag94 = L[0]; STR[SAVE.lang].tut_form94 = L[1]; }
  /* training steps 'tag' and 'form' point at the HUD pictures on touch screens */
  window.tutKey94 = step => 'tut_' + step + ((step === 'tag' || step === 'form') && window.ControlsUI && ControlsUI.portraits && ControlsUI.portraits() ? '94' : '');

  /* ---------- 2. Fighters stand out from the night ----------
     Each stage multiplies the sprites by its ambient colour so they sit in the
     scene; it also sank dark characters into dark backdrops. Keep the stage's
     hue but lift the light on fighters, and strengthen the existing rim light. */
  const mix = (hex, k) => { const n = parseInt(String(hex || '#ffffff').slice(1), 16); const c = [n >> 16 & 255, n >> 8 & 255, n & 255].map(v => Math.round(v + (255 - v) * k)); return '#' + c.map(v => v.toString(16).padStart(2, '0')).join(''); };
  const lifted = new WeakMap();
  if (window.ART && ART.useLook) {
    const useLook = ART.useLook;
    ART.useLook = function (look) {
      if (look && typeof look === 'object' && !look._lit94) {
        let l = lifted.get(look);
        if (!l) { l = Object.assign({}, look, { amb: mix(look.amb, 0.5), tintA: (look.tintA || 0) * 0.5, rimA: Math.min(0.85, (look.rimA || 0.5) * 1.3), _lit94: true }); lifted.set(look, l); }
        look = l;
      }
      return useLook.call(this, look);
    };
    if (ART.look) ART.useLook(ART.look);
  }

  /* ---------- 3. Damage numbers: one small number per target that counts up ---------- */
  const DMG = { '#ffffff': 'e', '#ffd23a': 'e', '#ff4060': 'p', '#9ab4ff': 'g' };
  const textFx0 = window.textFx;
  window.textFx = function (x, y, s, col, size) {
    const kind = typeof s === 'string' && /^\d+$/.test(s) && DMG[col || '#fff'];
    if (kind && typeof G !== 'undefined' && G && G.texts) {
      const n = +s;
      for (const q of G.texts) if (q.dmg === kind && q.t < 0.45 && Math.abs(q.ox - x) < 22 && Math.abs(q.oy - y) < 30) {
        q.sum += n; q.s = '' + q.sum; q.t = Math.min(q.t, 0.1); q.vy = Math.min(q.vy, -12); if (col === '#ffd23a') q.col = col;
        return;
      }
      textFx0(x, y, s, col, 1);
      const q = G.texts[G.texts.length - 1]; if (q) { q.dmg = kind; q.sum = n; q.ox = x; q.oy = y; }
      return;
    }
    return textFx0.apply(this, arguments);
  };

  /* ---------- 4. Weight of a hit ---------- */
  const hurt0 = window.hurt;
  window.hurt = function (att, tg, dmg, o) {
    const wasKnock = tg && tg.st === 'knock';
    const landed = hurt0.apply(this, arguments);
    if (landed && tg && (tg.kind === 'enemy' || tg.kind === 'boss' || tg.kind === 'hero')) {
      tg._hitT = G.time;
      /* 9.5: no code-made tumble on a launch — the fall is shown by the drawn knockdown frames */
      /* finishers and launches hold the frame a touch longer and kick the camera */
      if (att && att.team === 'p' && o && o.launch && tg.team === 'e') { freeze(0.1); shake(5); }
      if (att && att.isPlayer && tg.team === 'e') att._conn94 = G.time;
      if (FX.ready && tg.team === 'e') {
        const dir = att ? (tg.x >= att.x ? 1 : -1) : (tg.face || 1) * -1;
        /* the blow that ends an enemy: a knockout burst */
        if (tg.dead && !tg._ko94) { tg._ko94 = true; FX.spawn('ko', tg.x, tg.y, (tg.z || 0) + entHeight(tg) * 0.45, { sc: tg.kind === 'boss' ? 1.4 : 1, dur: 0.5 }); }
        /* a heavy push along the floor kicks up a skid of dust behind the feet */
        else if (o && !o.launch && (o.kx || 0) >= 100 && !(tg.z > 2)) FX.spawn('skid', tg.x - dir * 6, tg.y, 0, { face: dir, sc: 0.9, dur: 0.4 });
      }
    }
    return landed;
  };

  /* ---------- 4b. Jump cancel ----------
     Once a swing has landed, JUMP cuts its recovery short, so a launcher can be
     chased into the air and juggled (air hits re-launch an airborne enemy). */
  const updHero0 = window.updHero;
  if (typeof updHero0 === 'function') window.updHero = function (h, dt, c) {
    if (c && c.jump && h && h.isPlayer && h.st === 'atk' && h.hitDone && h._conn94 != null && G.time - h._conn94 < 0.6 && !(G.hitstop > 0) && heroGrounded(h)) {
      h.queued = false; h.chainT = 0; setSt(h, 'idle');
    }
    return updHero0.call(this, h, dt, c);
  };

  /* ---------- 5. Image effects (replace the code-drawn sparks, rings and slashes) ----------
     The sprite sheets live in assets/fx/fx94.webp with their frames in
     js/fx94-atlas.js (window.FX94_ATLAS). Until that art is in the build the
     game keeps its previous effects. */
  const A = window.FX94_ATLAS || null;
  const FX = window.FX94 = { ready: false, list: [], img: null, tinted: new Map() };
  if (A && A.src) {
    const im = new Image();
    im.onload = () => { FX.img = im; FX.ready = true; };
    im.src = A.src;
  }
  const SIZE = { hitL: 30, hitH: 56, block: 40, ko: 92, claw: 62, crescent: 58, ring: 118, parry: 50, dust: 50, skid: 58, blood: 40, warn: 26 };
  const ADD = { hitL: 1, hitH: 1, block: 1, ko: 1, claw: 1, crescent: 1, ring: 1, parry: 1 };
  FX.spawn = function (name, x, y, z, o) {
    if (!FX.ready || !A.frames[name] || FX.list.length > 90) return false;
    o = o || {};
    FX.list.push({ name, x, y, z: z || 0, t: 0, dur: o.dur || A.dur && A.dur[name] || 0.3, face: o.face || 1, sc: o.sc || 1, rot: o.rot || 0, tint: o.tint || null, alpha: o.alpha == null ? 1 : o.alpha });
    return true;
  };
  FX.step = function (dt) { if (!FX.list.length) return; for (const q of FX.list) q.t += dt; FX.list = FX.list.filter(q => q.t < q.dur); };
  function tinted(name, i, col) {
    const key = name + i + col; let c = FX.tinted.get(key); if (c) return c;
    const f = A.frames[name][i]; c = document.createElement('canvas'); c.width = f[2]; c.height = f[3];
    const g = c.getContext('2d'); g.drawImage(FX.img, f[0], f[1], f[2], f[3], 0, 0, f[2], f[3]);
    g.globalCompositeOperation = 'source-atop'; g.globalAlpha = 0.5; g.fillStyle = col; g.fillRect(0, 0, c.width, c.height);
    if (FX.tinted.size > 160) FX.tinted.delete(FX.tinted.keys().next().value);
    FX.tinted.set(key, c); return c;
  }
  function blit(g, name, i, x, y, sc, face, rot, alpha, tint) {
    const f = A.frames[name][i]; if (!f) return;
    /* one scale per effect (its largest frame = SIZE), so a spark still grows and fades */
    const k = SIZE[name] / ((A.ref && A.ref[name]) || Math.max(f[2], f[3])) * sc;
    g.save(); g.translate(x, y); if (rot) g.rotate(rot * face); if (face < 0) g.scale(-1, 1); g.scale(k, k);
    if (ADD[name]) g.globalCompositeOperation = 'lighter'; g.globalAlpha = alpha; g.imageSmoothingEnabled = true;
    if (tint) g.drawImage(tinted(name, i, tint), -f[4], -f[5]); else g.drawImage(FX.img, f[0], f[1], f[2], f[3], -f[4], -f[5], f[2], f[3]);
    g.restore();
  }
  FX.draw = function (g, cam) {
    if (!FX.ready) return;
    for (const q of FX.list) {
      const n = A.frames[q.name].length, i = Math.min(n - 1, Math.floor(q.t / q.dur * n));
      blit(g, q.name, i, q.x - cam, q.y - q.z, q.sc, q.face, q.rot, q.alpha, q.tint);
    }
    /* warning icon over every enemy that is winding up an attack */
    if (A.frames.warn && G.enemies) for (const e of G.enemies) {
      const wind = !e.dead && ((e.kind === 'enemy' && e.ai === 'wind') || (e.kind === 'boss' && e.windup));
      if (!wind) continue;
      const el = e._tag === 'aiwind' ? G.time - e._t0 : 0.3, n = A.frames.warn.length;
      const i = el < 0.18 ? Math.min(2, Math.floor(el / 0.06)) : 3 + Math.floor(G.time * 8) % Math.max(1, n - 3);
      const h = entHeight(e) * depthScale(e.y) * (e.elite ? 1.14 : 1) * (e.big || 1);
      blit(g, 'warn', Math.min(n - 1, i), e.x - cam, e.y - e.z - h - 8, 1, 1, 0, 1, null);
    }
  };
  /* route the old effect calls to the art when it is available */
  const BLUE = new Set(['#9cf', '#9ab4ff', '#c8d8ff', '#9cf4ff']);
  const route = (name, take) => { const f0 = window[name]; if (typeof f0 !== 'function') return; window[name] = function () { if (FX.ready && typeof G !== 'undefined' && G && take.apply(this, arguments)) return; return f0.apply(this, arguments); }; };
  route('hitFlash', (x, y, z, big, col) => FX.spawn(big ? 'hitH' : 'hitL', x, y, z, { sc: big ? 1 : 0.85, tint: col && col !== '#ffffff' ? col : null, dur: big ? 0.3 : 0.22 }));
  route('sparks', (x, y, z, n, col) => {
    if (n < 4) return false;
    if (BLUE.has(col)) return FX.spawn('block', x, y, z, { sc: 0.6 + Math.min(0.5, n * 0.03), dur: 0.26 });
    if ((!col || col === '#ffffff' || col === '#fff') && n >= 12) return FX.spawn('parry', x, y, z, { sc: 0.9, dur: 0.3 });
    return FX.spawn('hitL', x, y, z, { sc: 0.45 + Math.min(0.6, n * 0.04), tint: col && col !== '#fff' && col !== '#ffffff' ? col : null, dur: 0.2 });
  });
  route('slashFx', (x, y, z, face, col, size, ang, dur) => {
    if (col === '#ff3a4a') return true;   /* human Lupus punches: the new frames and the hit spark show the blow, no blade arc */
    const claw = col === '#ff6a30' || col === '#ff1030';
    return FX.spawn(claw ? 'claw' : 'crescent', x, y, z, { face, sc: (size || 30) / 34, rot: (ang || 0) * 0.7, tint: claw ? null : col, dur: Math.max(0.2, dur || 0.18) });
  });
  route('ringFx', (x, y, z, rmax, col, dur) => FX.spawn('ring', x, y, 0, { sc: Math.max(0.3, (rmax || 60) / 70), tint: col, dur: Math.max(0.28, dur || 0.4) }));
  route('dust', (x, y, n) => n >= 4 && FX.spawn('dust', x, y, 0, { sc: 0.45 + Math.min(0.7, n * 0.035), face: Math.random() < 0.5 ? -1 : 1, dur: 0.42 }));
  route('blood', (x, y, z, n) => n >= 5 && FX.spawn('blood', x, y, z, { sc: 0.5 + Math.min(0.8, n * 0.03), face: Math.random() < 0.5 ? -1 : 1, dur: 0.38 }));
})();
