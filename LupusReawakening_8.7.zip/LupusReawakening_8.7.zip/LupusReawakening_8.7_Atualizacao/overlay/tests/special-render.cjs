'use strict';
const assert = require('node:assert/strict');
const { createRuntime } = require('./runtime.cjs');

/* Compare actual rendered pixels. Unlike the old accessory test, painting any
 * nonempty shape is not a pass: normal poses must contain only native sprites
 * plus the existing player marker, and exiting the special must be visually
 * identical to a fresh destination pose without its old chain frame.
 */
async function main() {
  const r=createRuntime();await r.settle();
  r.run(`window.renderAuditEntity=function(state,history){
    G.time=3.25;G.superFx=null;G.slow=1;
    const h=G.player;
    Object.assign(h,{form:'h',dead:false,x:160,y:232,z:0,vz:0,vx:0,inv:0,flash:0,
      ct:.11,t:.4,specDur:.55,atkDur:.3,atkT:.14,idx:1,air:false,wph:7,
      landT:0,face:1,shieldHP:0,taunt:false,_lastFr:null,_lastAn:null,_xf:null,
      _trail:[],_trailT:null},state);
    if(history){const f=ART.frame(heroKey(h),'spec',5,false);h._lastFr=f;h._lastAn='spec';h._xf={fr:f,t:.07};}
    const [cv,g]=PIX.canvas(840,620),[reference,rg]=PIX.canvas(840,620);
    for(const ctx of [g,rg]){ctx.setTransform(2,0,0,2,0,0);ctx.imageSmoothingEnabled=false;ctx.fillStyle='#171b28';ctx.fillRect(0,0,420,310);}
    const calls=[],nativeDraw=ART.draw;
    ART.draw=function(ctx,fr,x,y,options){if(ctx===g)calls.push({fr,x,y,options,alpha:ctx.globalAlpha,composite:ctx.globalCompositeOperation,smooth:ctx.imageSmoothingEnabled});return nativeDraw.apply(this,arguments);};
    try{drawEnt(g,h,0);}finally{ART.draw=nativeDraw;}
    drawPlayerMark(rg,h,0);
    for(const c of calls){rg.globalAlpha=c.alpha;rg.globalCompositeOperation=c.composite;rg.imageSmoothingEnabled=c.smooth;nativeDraw(rg,c.fr,c.x,c.y,c.options);}
    const actual=g.getImageData(0,0,840,620).data,expected=rg.getImageData(0,0,840,620).data;
    let extraPixels=0;for(let p=0;p<actual.length;p+=4)if(actual[p]!==expected[p]||actual[p+1]!==expected[p+1]||actual[p+2]!==expected[p+2]||actual[p+3]!==expected[p+3])extraPixels++;
    const pixels=new Uint8Array(actual),ids=calls.map(c=>({key:c.fr.key,id:c.fr.id}));
    cv.width=cv.height=reference.width=reference.height=0;
    return {pixels,extraPixels,ids};
  };`);
  const result=state=>r.run(`renderAuditEntity(${JSON.stringify(state)},false)`);
  let checks=0;
  console.log('TAP version 13');
  for(const stage of [0,1]) {
    await r.play(stage);
    let cases=0;
    for(const face of [1,-1])for(const y of [196,232,262])for(const landT of [0,.03]) {
      for(const pose of [{st:'idle'},{st:'walk'},{st:'dash'},{st:'air',z:30,vz:160},{st:'atk',idx:1},{st:'atk',idx:3},{st:'hurt'},{st:'spec'}]) {
        const state={...pose,face,y,landT},painted=result(state);
        assert.ok(painted.ids.length>0,'native sprite was not drawn');
        assert.equal(painted.extraPixels,0,`stage${stage+1}/${pose.st}/face${face}/y${y}/land${landT} contains pixels outside native sprite rendering`);
        cases++;
      }
    }
    console.log(`ok ${++checks} - ${stage===0?'1944':'modern'} rendering matches only original sprites and player marker in ${cases} pose/transform cases`);
    for(const st of ['idle','hurt','dash']) {
      for(const face of [1,-1])for(const y of [196,232,262]) {
        const state={st,face,y,landT:.03};
        const afterSpecial=r.run(`renderAuditEntity(${JSON.stringify(state)},true)`),fresh=result(state);
        assert.ok(Buffer.from(afterSpecial.pixels).equals(Buffer.from(fresh.pixels)),`stage${stage+1}/spec→${st}/face${face}/y${y} retains visible previous-special pixels`);
      }
      console.log(`ok ${++checks} - ${stage===0?'1944':'modern'} spec → ${st} has no visible chain/aura afterimage in either facing or depth`);
    }
  }
  // Preserve ordinary smoothing: unrelated transitions should still show the
  // old pose. This prevents solving the bug by disabling all crossfades.
  await r.play(1);
  r.run("Object.assign(G.player,{st:'idle',form:'h',inv:0,landT:0,_lastFr:ART.frame('lupus_h','hurt',0,false),_lastAn:'hurt',_xf:null})");
  const ordinary=r.run(`(()=>{const [cv,g]=PIX.canvas(840,620),calls=[],original=ART.draw;ART.draw=function(g,fr){calls.push(fr.id);return original.apply(this,arguments)};try{drawEnt(g,G.player,0)}finally{ART.draw=original;cv.width=cv.height=0;}return calls;})()`);
  assert.ok(ordinary.length>=2,'the fix removed unrelated native animation crossfades');
  assert.deepEqual(r.json('window.__err||[]'),[]);assert.deepEqual([...r.missing],[]);
  console.log(`ok ${++checks} - unrelated native animation crossfades remain visible`);
  console.log(`1..${checks}\n# ${checks} passed, 0 failed`);
}
main().catch(e=>{console.error(e.stack);process.exitCode=1;});
