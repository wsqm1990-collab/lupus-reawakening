'use strict';
/* Campaign duels use the existing controls: a shared combat plane, readable
   pressure/recovery, short input buffers and counter attacks. Story exits,
   minibosses, the twin Pack and the giant keep their authored rules. */
(function () {
  const txt = (pt, en) => /^pt/.test(SAVE.lang || '') ? pt : (window.TR9 ? TR9(en) : en);
  const family = e => /nacht|morrigan|construct/.test(e.type) ? 'caster' : /prime|beast|kane/.test(e.type) ? 'heavy' : 'blade';
  const allowed = e => !!(G && e && e === G.boss && e.kind === 'boss' && !G.mode && !e.mini && !e.giant && e.def && !e.def.yieldAt && !e.def.pair && !e.def.phases);
  const storyExit = e => !!(e && (e.fleeing || e.yielding || e.duelBeat));
  const speech = () => !!(G && ((G.talkQ && G.talkQ.length) || (window.Dialogue9 && Dialogue9.busy())));
  const blocked = () => !G || Scene.name !== 'play' || Scenes.play.menu || PORTRAIT || document.hidden || G.panel || G.choice || G.over > 0 || G.clearT > 0 || G.cine || G.superFx || G.nachtBeat90 || (G.cineBar || 0) > 0.5;
  const grounded = h => window.Traversal90 ? Traversal90.grounded(h) : h.z <= 0 && h.vz === 0;
  function state() { return G && G.duel90; }
  function active() { const s = state(); return !!(s && s.active && allowed(s.boss) && !s.boss.dead && !storyExit(s.boss)); }
  function ensure() {
    if (!G || !allowed(G.boss) || G.boss.dead) { if (G && G.duel90) G.duel90.active = false; return null; }
    let s = state();
    if (!s || s.boss !== G.boss) s = G.duel90 = { boss: G.boss, active: false, intro: 0.72, lane: clamp(232, LANE_T + 4, LANE_B - 4), camX: G.camX, turn: 0, counterUntil: 0, buffer: null, cue: '', cueT: 0, lastHero: null };
    // A duel ends at the authored escape threshold. A protected story beat can
    // suspend the same duel, then resume it without replaying its introduction.
    if (storyExit(s.boss)) { s.active = false; s.buffer = null; s.boss._duelMove90 = null; s.boss._duelOpen90 = 0; return null; }
    if (!s.active && !blocked() && !speech() && G.title <= 0.3 && s.boss.bossIn <= 0) {
      s.active = true; s.camX = G.camX;
      s.boss.y = s.lane; s.boss.vy = 0;
      G.player.y = s.lane; G.player.vy = 0;
      // Crates stay visible and destructible, but cannot form a wall between fighters.
      for (const p of G.props) p.duelPass90 = true;
    }
    return s;
  }
  function plane(s) {
    if (!s || !s.active || blocked()) return;
    s.camX = clamp(s.camX, 0, Math.max(0, WORLD_W - VW)); G.camX = s.camX; G.look = 0;
    for (const h of G.heroes) if (!h.dead) { h.y = s.lane; h.vy = 0; }
    for (const e of G.enemies) if (!e.dead && !e.giant && !e.fleeing) { e.y = s.lane; e.vy = 0; }
  }
  function update(dt) {
    const s = ensure(); if (!s || !s.active || blocked()) return;
    plane(s);
    if (s.intro > 0 && !speech()) {
      s.intro = Math.max(0, s.intro - dt);
      G.player.inv = Math.max(G.player.inv, 0.12); s.boss.inv = Math.max(s.boss.inv, 0.12);
    }
    if (s.cueT > 0) s.cueT = Math.max(0, s.cueT - dt);
    if (s.buffer && G.time > s.buffer.until) s.buffer = null;
    if (s.lastHero !== G.player) { s.lastHero = G.player; s.buffer = null; }
  }
  function filterInput(c) {
    const s = ensure(); if (!s || !s.active) return c;
    if (blocked() || s.intro > 0) {
      for (const k of ['atk', 'atkHeld', 'jump', 'jumpHeld', 'spec', 'dash', 'block', 'form', 'formHeld', 'tag', 'assist', 'super']) c[k] = false;
      c.mx = c.my = 0; return c;
    }
    const h = G.player, vertical = c.my || 0;
    // The optional Arcade layout adds directional finishers; the standard
    // layout retains exactly the same action meanings and three-hit chain.
    if (SAVE.controls && SAVE.controls.preset === 'arcade' && c.atk && grounded(h)) {
      h._duelWanted90 = vertical < -0.45 ? 'launcher' : vertical > 0.45 ? 'sweep' : null;
    }
    c.my = 0;
    if (h.st === 'atk') {
      const progress = 1 - h.atkT / Math.max(0.01, h.atkDur);
      if (c.dash && h.dashCd <= 0 && progress >= 0.28) { startDash(h, c.mx, 0); c.dash = false; s.buffer = null; }
      else if ((c.jump || c.block) && progress >= 0.72) { setSt(h, 'idle'); h.queued = false; c.atk = c.atkHeld = false; }
      else if (c.jump || c.dash) s.buffer = { key: c.dash ? 'dash' : 'jump', until: G.time + 0.12 };
    } else if (h.st === 'dash' && c.atk && grounded(h)) {
      h._duelWanted90 = 'drive'; setSt(h, 'idle');
    } else if (h.st === 'spec' && h.specDur - h.t < 0.12 && (c.jump || c.dash || c.atk)) s.buffer = { key: c.dash ? 'dash' : c.jump ? 'jump' : 'atk', until: G.time + 0.12 };
    if (s.buffer && ['idle', 'walk', 'air'].includes(h.st) && G.time <= s.buffer.until) { c[s.buffer.key] = true; s.buffer = null; }
    return c;
  }
  const ctl0 = playerCtl;
  playerCtl = function () { return filterInput(ctl0()); };
  const attack0 = startAtk;
  startAtk = function (h) {
    const s = state(), counter = active() && h === G.player && s.counterUntil >= G.time;
    const kind = counter ? 'counter' : h._duelWanted90 || null; h._duelWanted90 = null;
    attack0(h);
    if (active() && h === G.player && kind) {
      h._duelStrike90 = { kind, until: G.time + 0.6, hit: false };
      Object.defineProperties(h._duelStrike90, { run: { value: G }, boss: { value: s.boss } });
      if (kind === 'launcher' || kind === 'sweep') { h.idx = 3; h.atkDur = kind === 'launcher' ? 0.32 : 0.36; h.atkT = h.atkDur; }
      if (counter) { s.counterUntil = 0; s.cue = txt('CONTRA-ATAQUE', 'COUNTER'); s.cueT = 0.65; }
    } else h._duelStrike90 = null;
  };
  function recover(e, duration, counter) {
    e._duelMove90 = null; e.pat = null; e.guard = e.windup = e.charging = false; e.vx = e.vy = 0; e.frame = 'idle'; e.cd = duration;
    e._duelOpen90 = G.time + duration;
    if (counter) { setSt(e, 'hurt', 0.28); state().counterUntil = G.time + 0.8; state().cue = txt('ABERTO! CONTRA-ATAQUE', 'OPEN! COUNTER'); state().cueT = 0.7; }
  }
  // Ranged normal attacks reach hurt() through a small owner proxy. Bind the
  // exact shot at creation instead of matching an arbitrary later hit by ID.
  // Its finisher/counter remains valid for that shot's flight, including a tag.
  const hit0 = heroHit;
  heroHit = function (h) {
    const strike = active() && h === G.player && h._duelStrike90;
    const binding = strike && !strike.hit && G.time <= strike.until ? { run: G, boss: state().boss, source: h, strike } : null;
    const before = G ? G.proj.length : 0, result = hit0.apply(this, arguments);
    if (binding && G === binding.run) for (let i = before; i < G.proj.length; i++) {
      const p = G.proj[i];
      if (p.team === 'p' && p.owner === h.id) Object.defineProperty(p, '_duelHit90', { value: Object.assign({ until: G.time + p.life + 0.05 }, binding), configurable: true });
    }
    return result;
  };
  let projectile90 = null;
  const proj0 = updProj;
  updProj = function (p) {
    const previous = projectile90; projectile90 = p;
    try { return proj0.apply(this, arguments); } finally { projectile90 = previous; }
  };
  const hurt0 = hurt;
  hurt = function (att, target, damage, options) {
    const s = state(), own = active() && !blocked(), o = Object.assign({}, options || {});
    const parry = own && att === s.boss && target === G.player && target.st === 'guard' && !o.unblock && (att.x - target.x) * target.face >= -4 && G.time - (target.guardT0 == null ? -9 : target.guardT0) < 0.18 + (skl(target.id).def >= 3 ? 0.06 : 0);
    const bound = projectile90 && projectile90._duelHit90;
    const shot = bound && s && bound.run === G && bound.boss === s.boss && att.team === 'p' && att.id === bound.source.id && G.time <= bound.until ? bound.strike : null;
    const candidate = shot || (att === G.player && att._duelStrike90);
    const strike = own && target === s.boss && candidate && candidate.run === G && candidate.boss === s.boss && !candidate.hit && (shot || G.time <= candidate.until) ? candidate : null;
    if (strike) {
      damage *= strike.kind === 'counter' ? 1.65 : strike.kind === 'drive' ? 1.25 : 1.15;
      o.brk = true;
      if (strike.kind === 'launcher') { o.launch = false; o.kx = 130; o.stun = 0.25; }
      if (strike.kind === 'sweep') { o.kx = 60; o.stun = 0.32; }
    }
    if (own && att.team === 'p' && target === s.boss && (target._duelOpen90 || 0) > G.time) damage *= 1.2;
    const result = hurt0(att, target, damage, o);
    if (parry && result === false && !target.dead && !att.dead) recover(att, 0.85, true);
    if (strike && result) { strike.hit = true; if (!target.dead && !bossExitProtected(target)) { target.poise = Math.max(target.poise, target.poiseMax * 0.35); } }
    return result;
  };
  const patterns = {
    blade: ['cross', 'low', 'breaker'], heavy: ['breaker', 'low', 'cross'], caster: ['low', 'cross', 'breaker']
  };
  const labels = {
    cross: ['COMBO • BLOQUEIE', 'COMBO • BLOCK'], low: ['GOLPE BAIXO • PULE', 'LOW STRIKE • JUMP'], breaker: ['QUEBRA-GUARDA • DASH', 'GUARD BREAK • DASH']
  };
  function beginMove(e, s) {
    const kind = patterns[family(e)][Math.floor((s.turn - 1) / 2) % 3];
    e._duelMove90 = { kind, phase: 'wind', t: 0, hit: false, strikes: 0, face: G.player.x >= e.x ? 1 : -1 };
    e.pat = { n: kind === 'low' ? 'sweep' : kind === 'breaker' ? 'grab' : 'combo', ps: 0, t: 0, hits: 0 };
    e.face = e._duelMove90.face; e.guard = false; e.windup = true; e.frame = 'wind';
  }
  function customMove(e, dt) {
    const m = e._duelMove90, s = state(), p = G.player;
    if (!e.pat) { recover(e, 0.55, false); return; }
    m.t += dt; e.pat.t = m.t;
    const reach = Math.max(48, Math.min(100, e.def.reach || 58));
    const wind = m.kind === 'cross' ? (m.strikes ? 0.22 : 0.48) : m.kind === 'low' ? 0.62 : 0.78;
    if (m.phase === 'wind') {
      e.frame = 'wind'; e.windup = true;
      if (m.t < wind * 0.55) { e.face = p.x >= e.x ? 1 : -1; m.face = e.face; const gap = Math.abs(p.x - e.x); if (gap > reach * 1.05) e.x += e.face * Math.min(gap - reach, e.def.spd * dt); }
      if (m.t >= wind * DF().wind) { m.phase = 'strike'; m.t = 0; m.hit = false; e.windup = false; e.frame = 'atk'; e.face = m.face; e.pat.ps = 1; }
    } else if (m.phase === 'strike') {
      e.frame = 'atk';
      if (m.kind === 'breaker') { e.charging = true; e.x += e.face * 210 * dt; }
      else if (m.kind === 'cross') e.x += e.face * 100 * dt;
      if (!m.hit && m.t >= 0.09) {
        m.hit = true; m.strikes++; e.pat.hits = m.strikes;
        if (m.kind === 'low') {
          for (const h of G.heroes) if (!h.dead && h.z < 18 && (h.x - e.x) * e.face >= -8 && Math.abs(h.x - e.x) < reach + 24) hurt(e, h, 42 * e.dm, { kx: 85, stun: 0.25 });
        } else eHit(e, reach + (m.kind === 'breaker' ? 16 : 0), m.kind === 'breaker' ? 62 : 30, { kx: m.kind === 'breaker' ? 160 : 65, launch: m.kind === 'breaker' || m.strikes >= 3, kz: 200, unblock: m.kind === 'breaker' });
        sfx(m.kind === 'breaker' ? 'hit2' : 'slash');
      }
      if (m.t >= (m.kind === 'breaker' ? 0.24 : 0.16)) {
        e.charging = false;
        if (m.kind === 'cross' && m.strikes < 3) { m.phase = 'wind'; m.t = 0; e.pat.ps = 0; }
        else { m.phase = 'recover'; m.t = 0; e.windup = false; e._duelOpen90 = G.time + (m.kind === 'breaker' ? 1.05 : 0.72); e.pat.ps = 2; }
      }
    } else {
      e.frame = 'idle'; e.windup = e.charging = false;
      if (m.t >= (m.kind === 'breaker' ? 1.05 : 0.72)) recover(e, 0.5, false);
    }
    bounds(e); e.y = s.lane;
  }
  const boss0 = updBoss;
  updBoss = function (e, dt) {
    const s = state();
    if (allowed(e) && e.def.flee && e.bossIn <= 0 && e.hp <= e.maxhp * e.def.flee) holdBossExit(e);
    if (!active() || e !== s.boss) return boss0(e, dt);
    // Residual cinematic bars can outlast G.cine for a few rendered frames.
    // The boss must honor the same gate as player input in that interval.
    if (blocked()) return;
    if (s.intro > 0) { e.frame = 'idle'; e.windup = false; return; }
    // Authored transformations still run at their original threshold.
    if (e.morph > 0 || e.st === 'hurt' || (!e.p2 && e.hp < e.maxhp * 0.5)) { if (e._duelMove90) recover(e, 0.4, false); return boss0(e, dt); }
    if (e._duelMove90) return customMove(e, dt);
    if (!e.pat && e.cd <= 0) { s.turn++; if (s.turn % 2 === 1) { beginMove(e, s); return; } }
    boss0(e, dt);
  };
  // Props can be broken during a duel, while their collision cannot divide it.
  const separate0 = separate;
  separate = function (dt) {
    if (!active()) return separate0(dt);
    const props = G.props; G.props = []; try { return separate0(dt); } finally { G.props = props; }
  };
  const play = Scenes.play, update0 = play.update;
  play.update = function (dt) {
    if (!this.menu && Scene.cur === this) update(dt);
    const result = update0.call(this, dt);
    if (Scene.cur === this && active() && !blocked() && !G.superFx) plane(state());
    return result;
  };
  function hudModel(b) {
    const x = 122, w = Math.max(170, VW - 148);
    return { x, y: 46, w, h: 23, name: b.def.name || txt('CHEFE', 'BOSS'), hp: clamp(b.hp / Math.max(1, b.maxhp), 0, 1), intro: active() && state().intro > 0, cue: active() && state().cueT > 0 ? state().cue : '' };
  }
  function drawHUD(g, b) {
    if (!b || b.dead || b.bossIn > 0 || !allowed(b)) return false;
    if (blocked() || storyExit(b)) return true;
    const q = hudModel(b), s = state();
    const name = q.intro ? HERO[G.player.id].name + '  VS  ' + q.name : q.name;
    PIX.text(g, name, q.x + q.w / 2, q.y, { align: 'c', col: '#f1e6e9', out: '#08060e' });
    PIX.bar(g, q.x, q.y + 11, q.w, 6, q.hp, '#d52a48', '#271322');
    let cue = '';
    if (s && s.cueT > 0) cue = s.cue;
    else if (b._duelMove90 && b._duelMove90.phase === 'wind') cue = txt(...labels[b._duelMove90.kind]);
    else if ((b._duelOpen90 || 0) > G.time) cue = txt('ABERTURA', 'OPENING');
    if (cue && !speech()) PIX.text(g, cue, q.x + q.w / 2, q.y + 20, { align: 'c', col: b._duelMove90 && b._duelMove90.kind === 'breaker' ? '#ff8a78' : '#e8d790', out: '#09060e' });
    return true;
  }
  function drawHD() { /* Boss UI belongs to the single integrated pixel HUD. */ }
  window.Duel90 = {
    active, allowed, update, filterInput, drawHUD, drawHD,
    instructions() { return txt('ATACAR encadeia 3 golpes. DASH cancela após o início do golpe; PULO ou BLOQ cancelam o fim. Bloqueie no impacto e ataque para um contra-ataque forte. Salte golpes baixos, esquive quebra-guardas e puna a recuperação. Arcade opcional: cima + ATACAR dá um finalizador forte; baixo + ATACAR varre. Chefes permanecem no chão.', 'ATTACK chains 3 hits. DASH cancels after startup; JUMP or BLOCK cancel the ending. Block on impact, then attack for a strong counter. Jump low strikes, dash guard breaks and punish recovery. Optional Arcade: up + ATTACK is a heavy finisher; down + ATTACK sweeps. Bosses stay grounded.'); },
    snapshot() { const s = state(); return s ? { active: active(), boss: s.boss.type, lane: s.lane, camX: s.camX, intro: s.intro, turn: s.turn, counterUntil: s.counterUntil, move: s.boss._duelMove90 ? Object.assign({}, s.boss._duelMove90) : null, hud: hudModel(s.boss) } : null; }
  };
}());
