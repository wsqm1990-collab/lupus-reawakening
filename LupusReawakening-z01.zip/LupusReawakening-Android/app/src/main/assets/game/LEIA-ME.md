# LUPUS: REAWAKENING 9.0

Jogo de ação offline em HTML5 Canvas, incluído no aplicativo Android LUPUS 9.0.
Inglês é o idioma principal; português brasileiro pode ser escolhido nas opções.

Esta pasta contém o jogo e todos os recursos utilizados. Para compilar o Android,
consulte o README da raiz do pacote de código completo e abra
`src/LupusReawakening-Android` no Android Studio. A compilação release exige o
perfil privado de assinatura correspondente à instalação que será atualizada.
Não substitua a chave por uma chave de debug: isso impediria a atualização.

O APK distribuído usa `com.thorneindustries.lupus.preview`, versão 9.0/código26,
com a assinatura histórica da nossa 8.8 paralela. A instalação 8.9 do Gemini
permanece separada, com seu próprio progresso.

## Jogar

- Movimento: analógico virtual, setas/WASD ou controle compatível.
- Ataque: segure para encadear golpes; use salto, esquiva, defesa e especial.
- Duelos: bloqueie no impacto para abrir um contra-ataque, salte golpes baixos
  e esquive ataques que quebram a guarda. As instruções completas ficam na pausa.
- O preset Arcade é opcional e pode ser escolhido nas opções de controles.
- Investigações: aproxime-se das entradas iluminadas e siga a indicação de
  interação. No refúgio, aproxime-se do mapa, arquivos, rádio ou bancada médica.
- Refúgio e mapa ficam disponíveis depois do prólogo, em momentos seguros.
- No refúgio, a pausa oferece exportação/importação manual de backup JSON.

As HQs, vozes e efeitos estão incluídos no APK e funcionam sem conexão.
