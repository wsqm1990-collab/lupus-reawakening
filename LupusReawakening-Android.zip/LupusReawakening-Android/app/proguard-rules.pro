# sem regras
