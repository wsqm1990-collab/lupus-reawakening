'use strict';
/* =====================================================================
   AUDIO v7 — real soundtrack (assets/music/*.ogg) and character voices
   (assets/voice/*.ogg). If a track cannot play, the procedural composer
   in core.js takes over, so the game is never silent.
   ===================================================================== */
const MUSIC_BY_IDX = ['stage1', 'stage2', 'stage3', 'stage4', 'stage5', 'title'];
const MUS = { cur: null, base: null, el: {}, failed: {}, pend: null, fading: [] };
const _procStart = window.musicStart, _procStop = window.musicStop;
const musVol = () => SAVE.music ? 0.6 : 0;
const musName = i => typeof i === 'number' ? (MUSIC_BY_IDX[i] || 'title') : (i || 'title');
const procIdx = n => { const m = /^stage(\d+)$/.exec(n); return m ? (+m[1] - 1) % 5 : n === 'title' ? 5 : 4; };
function musEl(n) {
  let a = MUS.el[n]; if (a) return a;
  a = new Audio('assets/music/' + n + '.ogg'); a.preload = 'auto'; a.loop = !/^(victory|gameover)$/.test(n);
  a.addEventListener('error', () => { MUS.failed[n] = true; if (MUS.cur === n) { MUS.cur = null; _procStart(procIdx(n)); } });
  MUS.el[n] = a; return a;
}
function musPlay(n) {
  const a = musEl(n);
  for (const k in MUS.el) if (k !== n && !MUS.el[k].paused) fadeOut(MUS.el[k]);
  MUS.fading = MUS.fading.filter(x => x !== a);
  try { a.currentTime = 0; } catch (e) { }
  a.volume = 0; const p = a.play(); MUS.cur = n;
  if (p && p.catch) p.catch(() => { MUS.pend = n; });
  fadeIn(a);
}
function fadeIn(a) { const tgt = musVol(); let v = 0; const id = setInterval(() => { v = Math.min(tgt, v + 0.06); try { a.volume = v; } catch (e) { } if (v >= tgt || MUS.fading.includes(a)) clearInterval(id); }, 50); }
function fadeOut(a) { MUS.fading.push(a); const id = setInterval(() => { const v = Math.max(0, a.volume - 0.08); try { a.volume = v; } catch (e) { } if (v <= 0) { clearInterval(id); a.pause(); MUS.fading = MUS.fading.filter(x => x !== a); } }, 50); }
window.musicStart = function (i) {
  const n = musName(i); AU.wantMusic = i; MUS.base = n;
  if (MUS.failed[n]) { MUS.cur = null; for (const k in MUS.el) MUS.el[k].pause(); _procStart(procIdx(n)); return; }
  _procStop(); AU.wantMusic = i;
  if (MUS.cur === n && !musEl(n).paused) return;
  musPlay(n);
};
window.musicStop = function () { _procStop(); MUS.base = null; MUS.cur = null; for (const k in MUS.el) if (!MUS.el[k].paused) fadeOut(MUS.el[k]); };
const _setOpts = window.setAudioOpts;
window.setAudioOpts = function () { _setOpts(); for (const k in MUS.el) { const a = MUS.el[k]; if (!a.paused && !MUS.fading.includes(a)) a.volume = musVol(); } };
/* autoplay may be blocked until the first touch (browsers); the APK allows it */
const resumeMus = () => { if (MUS.pend) { const n = MUS.pend; MUS.pend = null; if (MUS.base === n || MUS.cur === n) musPlay(n); } };
['pointerdown', 'keydown'].forEach(ev => document.addEventListener(ev, resumeMus, true));
document.addEventListener('visibilitychange', () => { const a = MUS.cur && MUS.el[MUS.cur]; if (!a) return; if (document.hidden) a.pause(); else if (MUS.base) { const p = a.play(); if (p && p.catch) p.catch(() => { MUS.pend = MUS.cur; }); } });
/* in-game: boss / endless / rush tracks take over automatically */
setInterval(() => {
  if (!MUS.base || Scene.name !== 'play' || typeof G === 'undefined' || !G) return;
  let want = MUS.base;
  if (G.mode === 'endless') want = G.boss && !G.boss.dead ? 'boss' : 'endless';
  else if (G.mode === 'rush') want = 'boss';
  else if (G.boss && !G.boss.dead && G.boss.bossIn < 1.5) want = (G.stage === 4 || G.stage === 9) ? 'finalboss' : 'boss';
  if (want !== MUS.cur && !MUS.failed[want] && G.over <= 0 && !G.clearT) musPlay(want);
}, 300);

/* ---------- voices ---------- */
const VOX = { pool: {}, last: {}, ok: {} };
function voice(n, gap) {
  if (!SAVE.sfx || VOX.ok[n] === false) return;
  const now = performance.now(), who = n.split('_')[0];
  if (now - (VOX.last[who] || 0) < (gap || 900)) return; VOX.last[who] = now;
  let a = VOX.pool[n];
  if (!a) { a = new Audio('assets/voice/' + n + '.ogg'); a.addEventListener('error', () => { VOX.ok[n] = false; }); VOX.pool[n] = a; }
  try { a.currentTime = 0; a.volume = 0.9; const p = a.play(); if (p && p.catch) p.catch(() => { }); } catch (e) { }
}
const VOX_HEROES = ['lupus', 'vespera', 'triton', 'malakor', 'echo', 'brann'];
const wrap = (name, after) => { const f = window[name]; if (typeof f !== 'function') return; window[name] = function () { const r = f.apply(this, arguments); try { after.apply(this, [r].concat([].slice.call(arguments))); } catch (e) { } return r; }; };
wrap('startAtk', (r, h) => { if (h && h.kind === 'hero' && h.idx === 3 && Math.random() < 0.55) voice(h.id + '_atk' + (Math.random() < 0.5 ? 1 : 2), 1400); else if (h && h.kind === 'hero' && h.idx === 1 && Math.random() < 0.12) voice(h.id + '_atk1', 2200); });
wrap('startSpec', (r, h) => { if (h && h.kind === 'hero' && !h.assist) voice(h.id + '_special', 300); });
wrap('startXform', (r, h, to) => { if (h && to !== 'h') voice('lupus_transform', 300); });
wrap('tagSwap', () => { const p = G && G.player; if (p) voice(p.id + '_tagin', 300); });
wrap('callAssist', () => { const a = G && G.heroes.find(h => h.assist); if (a) voice(a.id + '_assist', 300); });
wrap('startSuper', () => { if (G && G.team && G.team.some(h => h.id === 'lupus')) voice('lupus_super', 200); });
wrap('hurt', (r, att, tg, dmg) => { if (r && tg && tg.kind === 'hero' && !tg.dead && dmg > 30) voice(tg.id + '_hurt', 2500); });
wrap('kill', (r, f) => { if (!f) return; if (f.kind === 'hero') voice(f.id + '_ko', 200); else if (f.kind === 'boss' && G.mode !== 'endless') { VOX.last[f.type] = 0; voice(f.type + '_defeat', 0); } });
