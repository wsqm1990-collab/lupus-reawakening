'use strict';
/* ===== MAIN LOOP: update scene -> draw on pixel buffer -> nearest-neighbour upscale ===== */
let lastT = 0;
function frame(t) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (t - lastT) / 1000 || 0.016); lastT = t;
  bg.setTransform(2, 0, 0, 2, 0, 0); bg.imageSmoothingEnabled = false; bg.globalAlpha = 1; bg.globalCompositeOperation = 'source-over';
  bg.save(); bg.beginPath(); bg.rect(0, 0, VW, VH); bg.clip();
  const s = Scene.cur;
  if (s) { try { s.update && s.update(dt); s.draw && s.draw(bg); } catch (e) { console.error(e); window.__err = (window.__err || []).concat(String(e && e.stack || e)); } }
  if (Scene.fade > 0) { bg.fillStyle = 'rgba(0,0,0,' + Scene.fade + ')'; bg.fillRect(0, 0, VW, VH); Scene.fade = Math.max(0, Scene.fade - dt * 4); }
  bg.restore();
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.imageSmoothingEnabled = false; ctx.fillStyle = '#000'; ctx.fillRect(0, 0, cv.width, cv.height);
  ctx.imageSmoothingEnabled = Math.abs(SCALE / 2 - Math.round(SCALE / 2)) > 0.05; ctx.drawImage(BUF, 0, 0, VW * 2, VH * 2, OX, OY, Math.round(VW * SCALE), Math.round(VH * SCALE));
}
window.androidBack = function () {
  const n = Scene.name;
  if (n === 'play') { if (G && (G.over > 0 || G.clearT > 0)) return 'ok'; Scenes.play.onKey('pause'); return 'ok'; }
  if (n === 'title') { if (Scenes.title.opts) { Scenes.title.opts = false; return 'ok'; } return 'exit'; }
  if (n === 'stages') { Scene.go('select'); return 'ok'; }
  if (n === 'clear' || n === 'load') return 'ok';
  Scene.go('title'); return 'ok';
};
window.addEventListener('error', e => { window.__err = (window.__err || []).concat(e.message); });
/* English is the main language: every player starts in English once; the options menu changes it */
if (!SAVE.langV5) { SAVE.lang = 'en'; SAVE.langV5 = true; saveGame(); } if (!I18N[SAVE.lang]) SAVE.lang = 'en'; applyLang();
const startGame = () => { Scene.go('load'); requestAnimationFrame(frame); ART.load(() => { Scenes.load.ready = true; COMIC.load(); }); };
if (document.fonts && document.fonts.ready) document.fonts.ready.then(startGame); else startGame();
