# CYBERCLAWS — projeto Android

Versão 9.7. O jogo fica em `app/src/main/assets/game/` (HTML5 + Canvas) e roda dentro de um WebView.

## Novidades da 9.7 (todos os heróis desenhados quadro a quadro)
- Os cinco parceiros foram redesenhados quadro a quadro no visual cyberpunk aprovado (cerca de 70
  quadros cada), com golpes próprios:
  - Vespera: garra de sangue, chute alto, corte giratório com as asas e a espiral de sangue — a bola
    sai da mão desenhada.
  - Triton: estocada com o tridente, varrida, golpe por cima e o especial da maré — a onda é
    desenhada à parte e nasce onde o tridente bate no chão.
  - Malakor: magia com uma mão, com as duas mãos, a caveira em chamas e a barreira — os raios e a
    caveira saem da mão desenhada.
  - Echo: tiro rápido, golpe com o braço-canhão, rajada para cima e o canhão de trilho — o raio sai
    da ponta do canhão desenhado e acompanha o coice.
  - Brann: soco acorrentado, martelo duplo, uppercut e o tremor de pedra — as ondas de choque são
    pontas de pedra desenhadas.
- John Thorne em 1944 (fase 1), desenhado quadro a quadro nas duas formas:
  - Humano, com os braços de Lunarium: jab, direto, uppercut e o Rugido Lunar com o círculo de
    energia vermelho.
  - Lobisomem, com garras de prata: três golpes de garra, o uivo com os símbolos da lua, e corre de
    quatro como um lobo (também na esquiva).
- Fenrir Desperto (fase 16), desenhado quadro a quadro: estocada de garra, rasgo para cima, duplo
  corte, mergulho em X e o Uivo do Ragnarok, com a juba virando uma coluna de fogo. A
  transformação agora brilha dourada.
- Alfa e Fenrir: o brilho fica atrás do corpo e os golpes não deixam mais cópias fantasma da pose
  anterior.
- Código da 9.7: `js/hero96.js` (regras de cada herói). Quadros: `js/atlas97v.js`,
  `js/atlas97t.js`, `js/atlas97m.js`, `js/atlas97e.js`, `js/atlas97b.js`, `js/atlas97j.js`,
  `js/atlas97w.js` e `js/atlas97x.js`. Ferramentas: `tools/anim96/`.

## Novidades da 9.6 (Thorne desenhado quadro a quadro)
- As três formas do Thorne foram redesenhadas no visual cyberpunk aprovado, quadro a quadro, como
  num desenho animado: humano (71 quadros), lobisomem (70) e Alfa (70). Cada forma tem golpes
  próprios:
  - Humano: jab, direto, gancho com pistão, especial da corrente, ataque aéreo de martelo duplo.
  - Lobisomem: anda curvado, corre de quatro como um lobo (também na esquiva), três golpes de garra
    com o rastro desenhado, mergulho com as garras e o especial do uivo.
  - Alfa: estocada de garra, garra subindo, martelo duplo que racha o chão, mergulho em X e o
    especial da explosão de espinhos.
  - Todas: andar, correr, pulo, defesa, dano, voar longe, cair, levantar e pose de vitória.
- O Leviatã foi redesenhado no visual novo (16 quadros) e ganhou retrato novo.
- Cinco páginas de quadrinho corrigidas: a Torre Thorne no tamanho certo (cs30), a Echo arrancando
  o olho-transmissor (cs57), as docas com as duas asas do Brann (cs79), o Thule ligado às máquinas
  (cs81) e a fuga de 1944 com as correntes (cs89).
- Código da 9.6: `js/hero96.js` e `js/lev96.js`. Quadros: `js/atlas96h.js`, `js/atlas96f.js`,
  `js/atlas96a.js` e `js/atlas96.js`. Ferramentas: `tools/anim96/` (guias de pose, textos e
  montagem), `tools/lev96/` e `tools/comic96/`.

## Novidades da 9.5 (o jogo agora se chama CyberClaws)
- Nome novo: o jogo se chama **CyberClaws** e o herói é **Thorne** (John Thorne) em todos os 12
  idiomas, nos menus, legendas e quadrinhos. Logo novo desenhado na tela de título e na tela de
  carregamento (`assets/ui/logo95.webp`).
- Falas regravadas com o nome novo, em inglês e português: o "Sargento Thorne" de 1944 (i05a), o
  final "Thorne vai voltar" (f01m) e a chegada do caçador Kane (`kane_intro`).
- Fase 4 (defesa): a última fala no nocaute do chefe termina antes de o quadrinho começar; falas
  novas de combate ficam em silêncio nesse momento.
- Fase 5 (metrô alagado): a transformação do chefe ganhou uma pausa dramática antes do quadrinho, e
  os toques que eram para a luta não pulam mais o quadrinho.
- Sem cambalhota artificial: o inimigo lançado não gira mais feito por código.
- Difícil e Pesadelo bem mais duros: chefes com mais vida e mais resistência, menos cura e menos
  itens, golpes mais rápidos e inimigos que atacam pelas costas quando o herói está ocupado
  batendo em outro.
- Fase 6 (sabotagem): o gás tóxico sai de saídas desenhadas no chão — luzes e uma caveira avisam,
  depois a nuvem verde sobe e se espalha (`assets/fx/fx95.webp`, lista em `js/fx95-atlas.js`).
  Na primeira vez, o Malakor avisa pelo rádio (fala nova, inglês e português).
- Fase 7 (Necrópole de Neon): inimigo novo, o **Corvo de Luto**, desenhado quadro a quadro
  (`assets/chars/mourner.webp`, `js/atlas95.js`). Ele aparece e some numa nuvem de penas, reaparece
  atrás do herói e solta um grito de corvo quando acerta. O Malakor avisa na primeira vez.
- A névoa da fase 7 fica atrás dos lutadores: ninguém mais aparece apagado.
- Código da 9.5: `js/v95.js`. Artes geradas: `tools/art95/build95.py`. Vozes: `tools/voice95.py`
  (registro em `tools/voice95-production.json`).

## Vozes
- Falas da história: `assets/voice/dialogue/` (português) e `assets/voice/dialogue/en/` (inglês).
- Gritos de combate gravados com a voz de cada personagem: `assets/voice/pt/` e `assets/voice/en/`
  (lista em `js/voice-manifest93.js`). Jogo em português usa `pt/`; os outros idiomas usam `en/`.
- Vozes de monstros e soldados ficam em `assets/voice/`.

## Como o APK é gerado
O GitHub gera o APK sozinho. No repositório ficam as partes `LupusReawakening-zNN.zip`; o
GitHub Actions junta todas, compila e publica em **Releases** como "CyberClaws 9.x - APK N".

## Instalação
- ID do app: `com.thorneindustries.lupus.preview` (o mesmo desde a 9.0), assinado com `app/lupus.keystore`.
  Por isso a 9.7 instala por cima da 9.0 a 9.6 e mantém o progresso.
- Nome no celular: "CyberClaws".
- Antes de publicar na Play Store, crie uma chave nova e particular: esta chave está visível no repositório.
