#!/usr/bin/env python3
"""Package a cumulative source update, or an explicit delta over an older update."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

BASE_REPOSITORY = 'https://github.com/wsqm1990-collab/lupus-reawakening'
LEGACY_COMMIT = '5e53d272f87e3286adee8b273a3f388a39166274'
PROJECT = 'src/LupusReawakening-Android'

APPLY = r'''#!/usr/bin/env python3
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

parser = argparse.ArgumentParser(description='Aplicar uma atualização de fontes ao repositório LUPUS.')
parser.add_argument('--repo', type=Path, default=Path.cwd(), help='Pasta do repositório original')
args = parser.parse_args()
repo = args.repo.resolve()
bundle = Path(__file__).resolve().parent
manifest = json.loads((bundle / 'manifest.json').read_text())
version = str(manifest['version'])
if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*', version):
    raise SystemExit('Versão de atualização inválida.')
overlay = bundle / 'overlay'
archives = sorted(repo.glob('LupusReawakening-z*.zip'))
project = repo / 'src/LupusReawakening-Android'
if not archives and not (project / 'settings.gradle').is_file():
    raise SystemExit('Informe --repo com a pasta do repositório original, contendo os ZIPs ou o projeto Android.')
# Validate every incoming file and every required base file before writing.
for item in manifest['files']:
    source = (overlay / item['path']).resolve()
    target = (repo / item['path']).resolve()
    if not target.is_relative_to(repo) or not source.is_relative_to(overlay.resolve()) or not source.is_file():
        raise SystemExit('Caminho de atualização inválido.')
    if hashlib.sha256(source.read_bytes()).hexdigest() != item['sha256']:
        raise SystemExit('Arquivo de atualização incompleto: ' + item['path'])
for item in manifest.get('required_base_files', []):
    source = (repo / item['path']).resolve()
    if not source.is_relative_to(repo) or not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest() != item['sha256']:
        raise SystemExit('Este delta exige a atualização ' + str(manifest.get('base_version', 'anterior'))
                         + ' completa. Arquivo da base ausente ou alterado: ' + item['path']
                         + '. Use o pacote cumulativo se não tiver essa base.')
# Fill missing legacy files only; never erase local edits by unzipping over them.
for archive in archives:
    with zipfile.ZipFile(archive) as source:
        for item in source.infolist():
            target = (repo / 'src' / item.filename).resolve()
            if not target.is_relative_to((repo / 'src').resolve()):
                raise SystemExit('Caminho inválido no arquivo original.')
            if item.is_dir() or target.exists():
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read(item))
backup = repo / ('backup-lupus-' + version + '-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
for item in manifest['files']:
    source, target = overlay / item['path'], repo / item['path']
    if target.exists() and target.read_bytes() != source.read_bytes():
        saved = backup / item['path']
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, saved)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
wrapper = project / 'gradlew'
if wrapper.is_file():
    wrapper.chmod(wrapper.stat().st_mode | 0o111)
print('Atualização ' + version + ' aplicada. Projeto: ' + str(project))
if backup.exists():
    print('Cópia dos arquivos anteriores: ' + str(backup))
print('Consulte README.md para executar os testes e gerar o APK.')
'''


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def previous_manifest(path: Path) -> dict:
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as bundle:
            manifest = json.loads(bundle.read('manifest.json'))
    else:
        manifest = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(manifest.get('files'), list) or not manifest.get('version'):
        raise ValueError('The previous update must contain a version and a files manifest.')
    for item in manifest.get('required_base_files', []) + manifest['files']:
        rel = Path(item['path'])
        if rel.is_absolute() or '..' in rel.parts or not re.fullmatch(r'[0-9a-f]{64}', item['sha256']):
            raise ValueError('The previous update contains an invalid path or SHA-256.')
    return manifest


def package_update(repo: Path, output: Path, version: str | None = None,
                   previous: Path | None = None, base_commit: str | None = None) -> dict:
    repo = repo.resolve()
    if version is None:
        gradle = (repo / PROJECT / 'app/build.gradle').read_text(encoding='utf-8')
        match = re.search(r'\bversionName\s+[\'"]([^\'"]+)[\'"]', gradle)
        if not match:
            raise ValueError('No Android versionName found; provide --version.')
        version = match.group(1)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*', version):
        raise ValueError('Version must be a plain version identifier.')
    baseline = {}
    for archive in sorted(repo.glob('LupusReawakening-z*.zip')):
        with zipfile.ZipFile(archive) as bundle:
            for item in bundle.infolist():
                if not item.is_dir():
                    baseline['src/' + item.filename] = hashlib.sha256(bundle.read(item)).hexdigest()
    old = previous_manifest(previous) if previous else None
    old_files = ({item['path']: item for item in old.get('required_base_files', []) + old['files']}
                 if old else {})
    if old_files:
        baseline.update({rel: item['sha256'] for rel, item in old_files.items()})
    selected = []
    for path in repo.rglob('*'):
        if path.is_symlink() or not path.is_file():
            continue
        rel = path.relative_to(repo)
        if any(part in ['.git', '.gradle', 'build', 'node_modules', 'output', '__pycache__']
               or part.startswith('backup-lupus-') for part in rel.parts):
            continue
        if path.suffix.lower() in ['.zip', '.apk', '.keystore', '.jks', '.p12', '.pfx'] or path.name in ['local.properties', 'signing.properties'] or path.name.endswith('.part.ogg'):
            continue
        file_hash = digest(path)
        if file_hash == baseline.get(rel.as_posix()):
            continue
        selected.append((rel.as_posix(), path, file_hash))
    selected.sort()
    selected_paths = {rel for rel, _, _ in selected}
    required = [item for rel, item in sorted(old_files.items()) if rel not in selected_paths]
    # A delta must not silently inherit a removed file that cannot exist in the target sources.
    for item in required:
        path = repo / item['path']
        if not path.is_file() or digest(path) != item['sha256']:
            raise ValueError('A required base file changed or was removed; use a cumulative package: ' + item['path'])
    manifest = {
        'version': version,
        'package_type': 'delta' if old else 'cumulative',
        'base_version': old['version'] if old else '8.1',
        'base_repository': BASE_REPOSITORY,
        'base_commit': base_commit or (old.get('target_commit') if old else LEGACY_COMMIT),
        'files': [{'path': rel, 'sha256': file_hash} for rel, _, file_hash in selected],
    }
    if required:
        manifest['required_base_files'] = required
    output.parent.mkdir(parents=True, exist_ok=True)
    requirement = ('Este delta exige a atualização ' + str(old['version']) + ' já aplicada.\n'
                   if old else 'Este pacote cumulativo inclui as mudanças anteriores; não é preciso aplicar outra atualização antes.\n')
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        bundle.writestr('APLICAR_ATUALIZACAO.py', APPLY)
        bundle.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        bundle.writestr('LEIA_PRIMEIRO.txt', 'LUPUS: REAWAKENING ' + version + ' — código atualizado\n\n'
                        + requirement + 'As mídias originais continuam no repositório.\n'
                        'Descompacte o pacote e execute com Python 3.9 ou posterior:\n'
                        'python3 APLICAR_ATUALIZACAO.py --repo CAMINHO_DO_REPOSITORIO\n\n'
                        'O aplicador confere os arquivos e guarda uma cópia dos arquivos anteriores que substituir.\n'
                        'Ele preserva o Git e nunca baixa arquivos da internet.\n'
                        'Depois siga README.md para testar e compilar o projeto Android.\n'
                        'Para jogar no celular, instale o APK ' + version + ' entregue separadamente.\n')
        for rel, path, _ in selected:
            bundle.write(path, 'overlay/' + rel)
    return {'output': str(output.resolve()), 'version': version, 'package_type': manifest['package_type'],
            'base_version': manifest['base_version'], 'files': len(selected), 'bytes': output.stat().st_size}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--version', help='Defaults to Android versionName.')
    parser.add_argument('--base-manifest', type=Path, help='Optional prior update ZIP or manifest.json for an incremental delta.')
    parser.add_argument('--base-commit', help='Optional exact source commit required by this update.')
    args = parser.parse_args()
    result = package_update(Path(__file__).resolve().parents[1], args.output, args.version,
                            args.base_manifest, args.base_commit)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
