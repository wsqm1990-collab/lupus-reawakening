'use strict';
/* =====================================================================
   9.8 — stage 1's enemies and boss drawn frame by frame: the Thule
   soldier (js/atlas98t.js), the Failed Experiment (js/atlas98m.js), the
   Plague Hound (js/atlas98h.js) and Lieutenant Kreutz in 1944
   (js/atlas98k.js). Every enemy atlas marked v96 is played with these
   rules:
   - an attack plays its drawn wind-up over the whole wind-up, the strike
     on the blow and the recovery after it (the atlas 'prof');
   - the hound's lunge shows the crouch, then the leap and the bite in the
     air, the landing and the recovery;
   - a hit plays its three frames, a throw shows rising / falling /
     hitting the floor, getting up plays all its frames;
   - the walk cycle runs backwards when the enemy backs away while facing
     the hero (no moonwalk);
   - blows whose motion is drawn in the frames get no generic slash on top.
   Kreutz: the sabre combo and slash raise, cut and follow through on the
   blows and recover after the last one; before a charge he raises the
   sabre, after crashing into a wall he reels; his pistol is drawn, aimed
   down at the hero and fired, and holstered again. His bullets (same
   start, speed, damage and hits as before) leave the drawn muzzle and
   are drawn as tracers flying at the hero's chest.
   ===================================================================== */
(function () {
  const drawn = e => { if (!e || e.kind === 'hero' || e.kind === 'prop' || e.kind === 'obj') return null; const A = window.ATLAS[e.key]; return A && A.v96 ? A : null; };
  const WALK = { tsold: 10, mutant: 8.5, hound: 14, kreutz44: 9 };       /* walk frames per second */
  const prog = (e, n) => Math.min(n - 1, Math.floor(e.ct / Math.max(0.05, e.ct + Math.max(0, e.t)) * n));
  function knockFrame(e) { if (e.ct < 0.12 || (e.vz > 60 && e.z > 10)) return 0; return e.z > 14 ? 1 : 2; }
  /* the walk cycle; backwards while backing away from the hero it faces */
  function walk(e, key, rate) {
    const n = ART.frameCount(key, 'walk');
    if (e._seed98 == null) e._seed98 = Math.random() * n;
    const dx = e._px98 == null ? 0 : e.x - e._px98; e._px98 = e.x;
    if (Math.abs(dx) > 0.05) e._back98 = dx * e.face < 0;
    const i = Math.floor(G.time * (rate || WALK[key] || 10) + e._seed98) % n;
    return ['walk', e._back98 ? n - 1 - i : i];
  }

  /* ---------- the regular enemies ---------- */
  function enemyFrame(e, A) {
    const key = e.key, n = an => ART.frameCount(key, an), P = A.prof;
    if (e.dead) return e.z > 1 ? ['knock', knockFrame(e), false] : ['down', 0];
    switch (e.st) {
      case 'hurt': return ['hurt', prog(e, n('hurt')), false];
      case 'knock': return ['knock', knockFrame(e), false];
      case 'down': return ['down', 0];
      case 'getup': return ['getup', prog(e, n('getup')), false];
    }
    if (e.arrive) return walk(e, key);
    const ai = e.def && e.def.ai;
    if (P && (ai === 'melee' || ai === 'lunge')) {
      const el = track(e, 'ai' + e.ai);
      if (e.ai === 'wind') { const p = el / Math.max(0.05, el + Math.max(0, e.t)); return ['atk', P.wind[Math.min(P.wind.length - 1, Math.floor(p * P.wind.length))], false]; }
      if (e.ai === 'hit') {
        if (ai === 'lunge' && e.lunged) return ['atk', e.vz > 20 ? P.hit[0] : P.hit[P.hit.length - 1], false];   /* the leap, then the bite */
        return ['atk', P.hit[Math.min(P.hit.length - 1, Math.floor(el / 0.1))], false];
      }
      if (e.ai === 'rec' && el < 0.24) return ['atk', P.rec[Math.min(P.rec.length - 1, Math.floor(el / 0.12))], false];
    }
    if (e.moving) return walk(e, key);
    if (e._seed98 == null) e._seed98 = Math.random() * 6;
    return ['idle', Math.floor(G.time * 7 + e._seed98)];
  }

  /* ---------- Kreutz, 1944 ---------- */
  function kreutzFrame(e, A) {
    if (e.dead || e.st === 'hurt') { e._hold98 = null; return null; }
    if (e.bossIn > 0 || e.fleeing) return e.fleeing ? null : walk(e, e.key, 9);
    const P = e.pat, f = e.frame, T = G.time;
    if (e.morph > 0) { const el = track(e, 'spec'); return ['atk1', el < 0.15 ? 0 : 1, false]; }    /* raises the sabre high */
    const el = track(e, f + (P ? P.n + P.ps + P.hits : ''));
    if (!P) {
      /* just after the last cut: the recovery; just after the last shot: the pistol goes back into its holster */
      const L = e._l98, was = e._lp98; e._lp98 = false;
      if (was && f === 'idle' && L && L[1] >= 3) {
        if (L[0] === 'atk1') e._hold98 = { an: 'atk1', seq: [5], t0: T, dur: 0.15 };
        else if (L[0] === 'atk2') e._hold98 = { an: 'atk2', seq: [2, 1, 0], t0: T, dur: 0.27 };
      }
      const H = e._hold98;
      if (H) { const k = (T - H.t0) / H.dur; if (k < 1 && (f === 'idle' || f === 'walk')) return [H.an, H.seq[Math.min(H.seq.length - 1, Math.floor(k * H.seq.length))], false]; e._hold98 = null; }
      return f === 'walk' ? walk(e, e.key, 9) : null;
    }
    e._lp98 = true; e._hold98 = null;
    if (f === 'walk') return walk(e, e.key, 9);
    switch (P.n) {
      case 'combo':                                   /* three lunging cuts */
        if (f === 'wind') return ['atk1', Math.min(2, Math.floor(el / Math.max(0.1, 0.35 * DF().wind) * 3)), false];
        if (P.ps === 1) return ['atk1', P.hits === 0 ? (el < 0.09 ? 2 : 3) : (el < 0.05 ? 1 : el < 0.1 ? 2 : 3), false];
        return ['atk1', el < 0.07 ? 3 : 4, false];
      case 'slash':                                   /* three heavy cuts, each with its wind-up */
        if (f === 'wind') return ['atk1', Math.min(2, Math.floor(el / Math.max(0.1, (e.p2 ? 0.3 : 0.42) * DF().wind) * 3)), false];
        if (f === 'atk') return ['atk1', el < 0.09 ? 3 : el < 0.19 ? 4 : 5, false];
        break;
      case 'charge':                                  /* sabre raised, the dash, then reeling from the crash */
        if (f === 'wind') return ['atk1', el < 0.5 ? 0 : 1, false];
        if (f === 'run') return ['run', Math.floor(T * 15)];
        if (e.dazed) return ['hurt', 1, false];
        break;
      case 'shoot':                                   /* draws, aims down, fires; holds the aim between shots */
        if (P.ps === 1) return ['atk2', P.hits === 0 ? (el < 0.09 ? 0 : el < 0.18 ? 1 : el < 0.28 ? 2 : 3) : 4, false];
        if (P.ps === 2) return ['atk2', el < 0.08 ? 5 : 4, false];
        break;
    }
    return null;
  }

  const ef0 = window.entFrame;
  window.entFrame = function (e) {
    const A = drawn(e);
    if (!A) return ef0(e);
    const r = (e.kind === 'boss' ? (e.key === 'kreutz44' ? kreutzFrame(e, A) : null) : enemyFrame(e, A)) || ef0(e);
    e._l98 = r;
    return r;
  };

  /* ---------- no generic slash over blows whose motion is drawn ---------- */
  let cur = null;
  const slash0 = window.slashFx;
  window.slashFx = function () { if (cur) return; return slash0.apply(this, arguments); };
  const ue0 = window.updEnemy;
  window.updEnemy = function (e) {
    if (!(e && e.kind === 'enemy' && drawn(e) && e.key !== 'hound')) return ue0.apply(this, arguments);
    const c0 = cur; cur = e;
    try { return ue0.apply(this, arguments); } finally { cur = c0; }
  };

  /* ---------- Kreutz's pistol ---------- */
  const K = window.ATLAS.kreutz44;
  if (K && K.v96 && K.muzzle && typeof BOSS !== 'undefined' && BOSS.kreutz44) {
    /* the bullets start level with the drawn muzzle (their flight height and hits are unchanged) */
    BOSS.kreutz44.muzzle = [Math.round(K.muzzle[0]), (BOSS.kreutz44.muzzle || [44, 44])[1]];
  }
  const ub0 = window.updBoss;
  window.updBoss = function (e) {
    const A = e && e.key === 'kreutz44' ? drawn(e) : null;
    if (!A) return ub0.apply(this, arguments);
    const n0 = G.proj.length, c0 = cur; cur = e;
    try { return ub0.apply(this, arguments); }
    finally {
      cur = c0;
      if (A.muzzle) for (let i = n0; i < G.proj.length; i++) { const p = G.proj[i]; if (p.team === 'e' && p.type === 'orb' && !p.k98) aim(e, p, A); }
    }
  };
  /* a bullet is drawn from the muzzle in the frames to the hero's chest, then on along its flight line */
  function aim(e, p, A) {
    const ds = depthScale(e.y), tg = nearestHero(e);
    const x0 = p.x, z0 = A.muzzle[1] * ds;
    const zT = tg ? tg.z + entHeight(tg) * depthScale(tg.y) * 0.6 : p.z + 14;
    const S = Math.max(50, Math.abs((tg ? tg.x : x0 + e.face * 150) - x0));
    p.k98 = { x0, z0, zT, S };
  }
  const zOf = p => { const k = p.k98, s = Math.abs(p.x - k.x0); return Math.max(p.z, k.z0 + (k.zT - k.z0) * s / k.S); };
  const up0 = window.updProj;
  window.updProj = function (p) {
    if (!p.k98) return up0.apply(this, arguments);
    const np = G.parts.length, r = up0.apply(this, arguments);
    const dz = zOf(p) - p.z; for (let i = np; i < G.parts.length; i++) G.parts[i].z += dz;    /* the sparks burst where it is drawn */
    return r;
  };
  const dp0 = window.drawProj;
  window.drawProj = function (g, p, cam) {
    if (!p.k98) return dp0.apply(this, arguments);
    const k = p.k98, s = Math.sign(p.vx) || 1, z = zOf(p), x = p.x - cam, y = p.y - z;
    const slope = Math.abs(p.x - k.x0) < k.S && z > p.z ? (k.zT - k.z0) / k.S : 0;
    const vx = p.vx || s, vy = (p.vy || 0) - slope * Math.abs(vx), L = Math.hypot(vx, vy) || 1, ux = vx / L, uy = vy / L;
    RD.glow(g, x, y, 11, p.col, 0.5);
    g.save(); g.globalCompositeOperation = 'lighter'; g.lineCap = 'round';
    const tx = x - ux * 20, ty = y - uy * 20, gr = g.createLinearGradient(tx, ty, x, y);
    gr.addColorStop(0, 'rgba(255,200,80,0)'); gr.addColorStop(1, p.col);
    g.strokeStyle = gr; g.lineWidth = 2.4; g.beginPath(); g.moveTo(tx, ty); g.lineTo(x, y); g.stroke();
    g.fillStyle = '#ffffff'; g.beginPath(); g.arc(x, y, 1.5, 0, 7); g.fill();
    g.restore();
  };
})();
