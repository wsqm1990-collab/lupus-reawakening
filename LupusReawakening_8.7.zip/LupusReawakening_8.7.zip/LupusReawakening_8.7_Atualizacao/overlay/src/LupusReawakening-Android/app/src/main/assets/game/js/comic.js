'use strict';
/* =====================================================================
   COMIC — cutscenes as comic-book pages.
   Panels assemble one by one; the camera zooms into the active panel;
   balloons / captions / SFX pop in with text from the current language.
   Panels whose image is missing are skipped automatically.
   beat: t = cap | say | think | sfx ; k = text key ; x,y = box anchor
   (fraction of panel, top-left) ; tx,ty = tail target ; f = image focus
   ===================================================================== */
const P = (img, beats, f) => ({ img, beats, f: f || [0.5, 0.5] });
const CUTS = {
  intro: [
    [P('cs01', [{ t: 'cap', k: 'c01a', x: .03, y: .05 }, { t: 'cap', k: 'n01', x: .03, y: .17 }, { t: 'cap', k: 'c01b', x: .40, y: .80 }], [.4, .5])],
    [P('cs02', [{ t: 'cap', k: 'c02a', x: .03, y: .05 }, { t: 'say', k: 'c02b', x: .42, y: .05, tx: .36, ty: .22 }, { t: 'cap', k: 'n02', x: .03, y: .84 }], [.45, .5]), P('cs03', [{ t: 'sfx', txt: 'SNIKT!', x: .72, y: .66, col: '#e8f0ff', rot: -.25 }, { t: 'say', k: 'c03a', x: .04, y: .05, tx: .42, ty: .22, shout: true }, { t: 'cap', k: 'n03', x: .03, y: .86 }], [.5, .4])],
    [P('cs04', [{ t: 'cap', k: 'n04', x: .03, y: .04 }, { t: 'sfx', txt: 'KRA-KOOM!', x: .68, y: .42, col: '#ffcf3a', rot: -.12 }, { t: 'cap', k: 'c04a', x: .03, y: .84 }])],
    [P('cs05', [{ t: 'cap', k: 'c05a', x: .06, y: .04 }, { t: 'cap', k: 'n05', x: .06, y: .14 }, { t: 'cap', k: 'c05b', x: .06, y: .86 }], [.5, .3]), P('cs06', [{ t: 'cap', k: 'n06', x: .03, y: .84 }, { t: 'say', k: 'c06a', x: .03, y: .05, tx: .32, ty: .30 }, { t: 'say', k: 'c06b', x: .50, y: .05, tx: .40, ty: .30 }, { t: 'cap', k: 'n07', x: .03, y: .84 }], [.45, .5])],
    [P('cs07', [{ t: 'think', k: 'c07a', x: .04, y: .05, tx: .40, ty: .30 }, { t: 'cap', k: 'n10', x: .04, y: .84 }], [.6, .4]),
     P('cs08', [{ t: 'cap', k: 'n08', x: .02, y: .03 }, { t: 'tag', hero: 'lupus', x: .03, y: .80 }, { t: 'tag', hero: 'vespera', x: .27, y: .80 }, { t: 'tag', hero: 'triton', x: .50, y: .80 }, { t: 'tag', hero: 'malakor', x: .74, y: .80 },
       { t: 'say', k: 'c08a', x: .16, y: .04, tx: .40, ty: .28 }, { t: 'say', k: 'c08b', x: .40, y: .14, tx: .60, ty: .24 }, { t: 'say', k: 'c08c', x: .60, y: .04, tx: .82, ty: .30 }])],
    [P('cs09', [{ t: 'say', k: 'c09a', x: .22, y: .05, tx: .52, ty: .22 }, { t: 'cap', k: 'c09b', x: .03, y: .84, big: true }, { t: 'cap', k: 'n09', x: .03, y: .04 }])]
  ],
  s1pre: [[Object.assign(P('cs10', [{ t: 'cap', k: 'c10a', x: .03, y: .05 }, { t: 'say', k: 'c10b', x: .62, y: .05, tx: .62, ty: .30 }, { t: 'say', k: 'c10c', x: .05, y: .20, tx: .36, ty: .25 }]), { team: ['vespera'] })]],
  s1post: [[P('cs11', [{ t: 'say', k: 'c11a', x: .05, y: .05, tx: .45, ty: .30, weak: true }, { t: 'cap', k: 'c11b', x: .04, y: .84 }], [.5, .6])]],
  s2pre: [[Object.assign(P('cs12', [{ t: 'cap', k: 'c12a', x: .06, y: .04 }, { t: 'say', k: 'c12b', x: .30, y: .14, tx: .25, ty: .17 }], [.5, .35]), { team: ['vespera'] }), P('cs13', [{ t: 'say', k: 'c13a', x: .04, y: .05, tx: .44, ty: .35 }, { t: 'say', k: 'c13b', x: .60, y: .12, tx: .50, ty: .35, shout: true }])]],
  s2post: [[P('cs14', [{ t: 'say', k: 'c14a', x: .45, y: .04, tx: .38, ty: .28, weak: true }, { t: 'say', k: 'c14b', x: .04, y: .40, tx: .30, ty: .36, weak: true }])]],
  s3pre: [[P('cs15', [{ t: 'cap', k: 'c15a', x: .03, y: .05 }, { t: 'sfx', txt: 'BLAM!', x: .28, y: .30, col: '#ff6a2a', rot: -.2 }, { t: 'say', k: 'c15b', x: .60, y: .05, tx: .99, ty: .30, shout: true }])]],
  s3post: [[P('cs16', [{ t: 'say', k: 'c16a', x: .03, y: .04, tx: .30, ty: .35 }, { t: 'say', k: 'c16b', x: .50, y: .30, tx: .72, ty: .15 }])]],
  s4pre: [[Object.assign(P('cs17', [{ t: 'cap', k: 'c17a', x: .03, y: .05 }, { t: 'say', k: 'c17b', x: .42, y: .04, tx: .80, ty: .18 }, { t: 'say', k: 'c17c', x: .34, y: .55, tx: .20, ty: .75 }]), { team: ['triton'] })]],
  s4post: [[P('cs18', [{ t: 'sfx', txt: 'SHHLK!', x: .65, y: .70, col: '#a7ff1a', rot: .15 }, { t: 'say', k: 'c18a', x: .46, y: .04, tx: .44, ty: .27, shout: true }]), P('cs19', [{ t: 'say', k: 'c19a', x: .05, y: .05, tx: .40, ty: .35, weak: true }])]],
  s5pre: [[P('cs20', [{ t: 'cap', k: 'c20a', x: .06, y: .04 }, { t: 'sfx', txt: 'KRASSH!', x: .50, y: .64, col: '#ff2a40', rot: -.15 }]), P('cs21', [{ t: 'say', k: 'c21a', x: .04, y: .05, tx: .30, ty: .30 }, { t: 'say', k: 'c21b', x: .45, y: .72, tx: .30, ty: .50, shout: true }])]],
  act2: [[P('cs25', [{ t: 'cap', k: 'c25a', x: .03, y: .05 }, { t: 'sfx', txt: 'CLINK', x: .70, y: .78, col: '#ff2a40', rot: -.15 }, { t: 'cap', k: 'c25b', x: .03, y: .84 }], [.6, .6])],
    [P('cs26', [{ t: 'tag', hero: 'echo', x: .74, y: .80 }, { t: 'say', k: 'c26a', x: .55, y: .04, tx: .86, ty: .20 }, { t: 'say', k: 'c26b', x: .03, y: .06, tx: .10, ty: .20 }, { t: 'say', k: 'c26c', x: .52, y: .20, tx: .86, ty: .22 }], [.6, .4])],
    [P('cs27', [{ t: 'cap', k: 'c27a', x: .04, y: .04 }, { t: 'tag', hero: 'brann', x: .05, y: .82 }, { t: 'say', k: 'c27b', x: .46, y: .16, tx: .60, ty: .26, shout: true }], [.5, .35])]],
  s6pre: [[P('cs28', [{ t: 'cap', k: 'c28a', x: .03, y: .04 }, { t: 'say', k: 'c28b', x: .08, y: .16, tx: .18, ty: .30 }, { t: 'say', k: 'c28c', x: .62, y: .10, tx: .90, ty: .26 }], [.5, .4])]],
  s6post: [[P('cs29', [{ t: 'say', k: 'c29a', x: .05, y: .05, tx: .32, ty: .30, weak: true }, { t: 'cap', k: 'c29b', x: .05, y: .84 }], [.5, .5])]],
  s7pre: [[P('cs30', [{ t: 'cap', k: 'c30a', x: .05, y: .04 }, { t: 'sfx', txt: 'KRA-THOOM!', x: .50, y: .20, col: '#cfe0ff', rot: -.2 }, { t: 'cap', k: 'c30b', x: .05, y: .86 }], [.5, .3])]],
  s7post: [[P('cs31', [{ t: 'say', k: 'c31a', x: .03, y: .05, tx: .22, ty: .25, weak: true }, { t: 'cap', k: 'c31b', x: .40, y: .84 }], [.5, .5])]],
  s8pre: [[P('cs32', [{ t: 'say', k: 'c32a', x: .50, y: .04, tx: .86, ty: .22 }, { t: 'say', k: 'c32b', x: .04, y: .06, tx: .12, ty: .22 }], [.5, .4])],
    [P('cs33', [{ t: 'sfx', txt: 'SKRAAAA!', x: .55, y: .14, col: '#3af0ff', rot: -.1 }, { t: 'cap', k: 'c33a', x: .04, y: .86 }], [.5, .3])]],
  s9pre: [[Object.assign(P('cs34', [{ t: 'cap', k: 'c34a', x: .03, y: .04 }, { t: 'say', k: 'c34b', x: .08, y: .20, tx: .22, ty: .30, shout: true }], [.5, .5]), { team: ['lupus', 'vespera'] })],
    [P('cs35', [{ t: 'say', k: 'c35a', x: .55, y: .04, tx: .72, ty: .24 }, { t: 'say', k: 'c35b', x: .03, y: .06, tx: .30, ty: .26, shout: true }], [.5, .45])]],
  s10pre: [[P('cs36', [{ t: 'cap', k: 'c36a', x: .03, y: .04 }, { t: 'say', k: 'c36b', x: .03, y: .18, tx: .08, ty: .40 }], [.5, .35])],
    [P('cs37', [{ t: 'sfx', txt: 'FWOOOM!', x: .50, y: .60, col: '#ffb020', rot: -.15 }, { t: 'say', k: 'c37a', x: .05, y: .04, tx: .50, ty: .22, shout: true }], [.5, .3])]],
  finale: [[P('cs38', [{ t: 'cap', k: 'c38a', x: .30, y: .04 }, { t: 'say', k: 'c38b', x: .30, y: .22, tx: .40, ty: .45 }, { t: 'cap', k: 'c38c', x: .60, y: .86, big: true }], [.5, .45])]],
  ending: [[P('cs22', [{ t: 'say', k: 'c22a', x: .04, y: .04, tx: .19, ty: .24 }, { t: 'say', k: 'c22b', x: .45, y: .06, tx: .38, ty: .34 }])], [P('cs23', [{ t: 'cap', k: 'c23a', x: .03, y: .05 }, { t: 'say', k: 'c23b', x: .50, y: .10, tx: .41, ty: .36 }]), P('cs24', [{ t: 'cap', k: 'c24a', x: .05, y: .82, big: true }], [.5, .55])]]
};

/* who says each line (portrait + name in the dialogue band) */
const SPK = { c02b: 'thule', c03a: 'lupus_h', c06a: 'lupus_h', c06b: 'lupus_h', c07a: 'lupus_h', c08a: 'vespera', c08b: 'malakor', c08c: 'triton', c09a: 'lupus_h',
  c10b: 'vespera', c10c: 'lupus_h', c11a: 'warden', c12b: 'vespera', c13a: 'voss', c13b: 'voss', c14a: 'voss', c14b: 'voss', c15b: 'triton', c16a: 'malakor', c16b: 'triton',
  c17b: 'nacht', c17c: 'triton', c18a: 'nacht', c19a: 'nacht', c21a: 'lupus_h', c21b: 'lupus_f', c26a: 'echo', c26b: 'lupus_h', c26c: 'echo', c27b: 'brann', c28b: 'vespera', c28c: 'brann',
  c29a: 'morrigan', c31a: 'kane', c32a: 'triton', c32b: 'lupus_h', c34b: 'vespera', c35a: 'kreutz', c35b: 'lupus_h', c36b: 'lupus_h', c37a: 'firstwolf', c38b: 'lupus_h', c22a: 'vespera', c22b: 'lupus_h', c23b: 'lupus_h' };
const SPK_NAME = { lupus_h: 'LUPUS', lupus_f: 'LUPUS', lupus_a: 'LUPUS', thule: 'THULE', firstwolf: 'THULE' };
function spkName(k) { if (SPK_NAME[k]) return SPK_NAME[k]; if (HERO[k]) return HERO[k].name; const b = BOSS[k]; return b ? b.name.split(',')[0] : k.toUpperCase(); }
function spkCol(k) { const h = HERO[k] || (k && k.startsWith('lupus') ? HERO.lupus : null); return h ? h.color : '#ff5060'; }
const BAND = 74;

/* soundtrack per page (see musicMood in audio.js) */
const CUT_MOOD = { intro: ['cue_1944', 'cue_1944', 'cue_1944', 'cue_mystery', 'cue_heroic', 'cue_heroic'], s1pre: ['cue_heroic'], s1post: ['cue_tension'], s2pre: ['cue_mystery'], s2post: ['cue_tension'],
  s3pre: ['cue_tension'], s3post: ['cue_sorrow'], s4pre: ['cue_villain'], s4post: ['cue_villain'], s5pre: ['cue_villain'], ending: ['cue_sorrow', 'cue_dawn'],
  act2: ['cue_tension', 'cue_heroic', 'cue_mystery'], s6pre: ['cue_mystery'], s6post: ['cue_sorrow'], s7pre: ['cue_tension'], s7post: ['cue_betrayal'], s8pre: ['cue_sorrow', 'cue_villain'],
  s9pre: ['cue_heroic', 'cue_villain'], s10pre: ['cue_heroic', 'cue_villain'], finale: ['cue_dawn'] };

/* ---------- loading ---------- */
const COMIC = { img: {}, pending: 0, started: false };
/* Installed after the versioned story table has defined COMIC_LIST. One image
   has one pair of load handlers, even when several panels request it. */
COMIC.installCache = function () {
  COMIC.need = function (list, done) {
    const keys = [...new Set(list || [])].filter(k => COMIC.has(k));
    const missing = keys.filter(k => !(COMIC.img[k] && (COMIC.img[k].ok || COMIC.img[k].bad)));
    let left = missing.length, active = true;
    const finish = () => { if (active && --left <= 0) { active = false; if (done) done(); } };
    if (!left) { active = false; if (done) done(); return () => {}; }
    for (const k of missing) {
      let im = COMIC.img[k];
      if (!im) {
        im = new Image(); im._comicWait = []; COMIC.img[k] = im; COMIC.pending++;
        const settle = ok => {
          if (im._comicSettled) return; im._comicSettled = true; COMIC.pending = Math.max(0, COMIC.pending - 1);
          im.ok = ok; im.bad = !ok; im.onload = im.onerror = null;
          const callbacks = im._comicWait; im._comicWait = []; callbacks.forEach(cb => cb());
        };
        im.onload = () => settle(true); im.onerror = () => settle(false);
        if (done) im._comicWait.push(finish); im.src = 'assets/comic/' + k + '.webp';
      } else {
        /* The old loader can have an image in flight when this is installed. */
        if (done) { if (!im._comicWait) { im.addEventListener('load', finish, { once: true }); im.addEventListener('error', finish, { once: true }); }
          else im._comicWait.push(finish); }
      }
    }
    return () => { active = false; for (const k of missing) { const im = COMIC.img[k]; if (im && im._comicWait) im._comicWait = im._comicWait.filter(cb => cb !== finish); } };
  };
  COMIC.free = function (keep) {
    const K = new Set(keep || []);
    for (const k in COMIC.img) {
      if (K.has(k) || k === '@duo') continue; const im = COMIC.img[k]; delete COMIC.img[k];
      if (!im._comicSettled && im._comicWait) { COMIC.pending = Math.max(0, COMIC.pending - 1); im._comicSettled = true; }
      im._comicWait = []; im.onload = im.onerror = null; im.src = '';
    }
  };
};
COMIC.load = function () {
  if (COMIC.started) return; COMIC.started = true;
  for (let i = 1; i <= 38; i++) { const k = 'cs' + String(i).padStart(2, '0'); const im = new Image(); COMIC.pending++; im.onload = () => { COMIC.pending--; im.ok = true; }; im.onerror = () => { COMIC.pending--; im.ok = false; }; im.src = 'assets/comic/' + k + '.webp'; COMIC.img[k] = im; }
};
COMIC.has = k => { const im = COMIC.img[k]; return !!(im && im.ok); };
/* personalised cutscenes: panels drawn with a specific ally are swapped for a "duo panel" of the
   team the player picked; every stage intro ends on that duo panel */
COMIC.pages = function (id) {
  const m = /^s(\d+)pre$/.exec(id), si = m ? +m[1] - 1 : -1, team = [SAVE.hero, SAVE.ally]; let used = false;
  const pages = (CUTS[id] || []).map(pg => pg.map(p => { if (p.team && !p.team.every(h => team.includes(h))) { if (used) return null; used = true; return duoPanel(si); } return p; }).filter(p => p && COMIC.has(p.img))).filter(pg => pg.length);
  if (si >= 0 && !used && typeof ART !== 'undefined' && ART.img['c_lupus_h']) pages.push([duoPanel(si)]);
  return pages;
};
const DUO_COL = ['#ff2a40', '#ff3050', '#a7ff1a', '#3af0ff', '#ff1030', '#7affd0', '#4a8cff', '#30ffd0', '#ff2050', '#ffb020'];
function duoPanel(si) {
  const q = Math.max(0, si), h = SAVE.hero, a = SAVE.ally; buildDuo(q);
  return P('@duo', [
    { t: 'cap', txt: T('stage') + ' ' + (q + 1) + ': ' + STAGES[q].name[SAVE.lang], x: .36, y: .90 },
    { t: 'tag', hero: h, x: .04, y: .80 }, { t: 'tag', hero: a, x: .78, y: .80 },
    { t: 'say', k: 'q_' + h + (q % 3), spk: ROSTER_KEY[h], x: .04, y: .05, tx: .28, ty: .24 },
    { t: 'say', k: 'q_' + a + ((q + 1) % 3), spk: ROSTER_KEY[a], x: .54, y: .05, tx: .72, ty: .24 }
  ], [.5, .4]);
}
function buildDuo(si) {
  const key = si + '|' + SAVE.hero + '|' + SAVE.ally; if (COMIC.duoKey === key && COMIC.img['@duo']) return;
  const W = 1280, H = 720, [c, g] = PIX.canvas(W, H), st = STAGES[si], col = DUO_COL[si] || '#ff2a40';
  /* backdrop: the stage's own art, darkened and tinted */
  const bgi = ART.img['s' + st.id + '_l3'] || ART.img['s' + st.id + '_l2'];
  if (bgi && bgi.width) { const sh = bgi.height * 0.8, sw = sh * W / H; g.imageSmoothingEnabled = false; g.drawImage(bgi, (bgi.width - sw) * 0.35, bgi.height * 0.08, sw, sh, 0, 0, W, H); }
  else { g.fillStyle = '#120818'; g.fillRect(0, 0, W, H); }
  g.fillStyle = 'rgba(8,3,14,0.62)'; g.fillRect(0, 0, W, H);
  /* comic speed lines + halftone */
  g.save(); g.translate(W / 2, H * 0.42); for (let i = 0; i < 64; i++) { const an = i / 64 * 6.283; g.globalAlpha = i % 2 ? 0.07 : 0.16; g.fillStyle = i % 2 ? '#ffffff' : col; g.beginPath(); g.moveTo(Math.cos(an) * 150, Math.sin(an) * 150); g.lineTo(Math.cos(an - 0.025) * 1500, Math.sin(an - 0.025) * 1500); g.lineTo(Math.cos(an + 0.025) * 1500, Math.sin(an + 0.025) * 1500); g.fill(); } g.restore();
  g.fillStyle = col; for (let y = H * 0.55; y < H; y += 12) for (let x = ((y / 12) % 2) * 6; x < W; x += 12) { g.globalAlpha = 0.18 * (y - H * 0.55) / (H * 0.45); g.beginPath(); g.arc(x, y, 1 + 3 * (y - H * 0.55) / (H * 0.45), 0, 7); g.fill(); } g.globalAlpha = 1;
  const glow = g.createRadialGradient(W / 2, H * 0.55, 20, W / 2, H * 0.55, W * 0.5); glow.addColorStop(0, 'rgba(255,255,255,0.10)'); glow.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = glow; g.fillRect(0, 0, W, H);
  /* the two heroes, big, facing each other, rim-lit in their colours */
  const feet = H * 0.95, SC = 2.7;
  const fig = (id, x, face) => {
    const k = ROSTER_KEY[id], fr = ART.frame(k, 'idle', 0), img = ART.img['c_' + k]; if (!fr || !img) return;
    g.save(); g.fillStyle = 'rgba(0,0,0,0.55)'; g.beginPath(); g.ellipse(x, feet, 120, 22, 0, 0, 7); g.fill(); g.restore();
    g.save(); g.translate(x, feet); if (face < 0) g.scale(-1, 1); g.scale(SC, SC); g.imageSmoothingEnabled = false;
    g.globalAlpha = 0.9; g.drawImage(ART.silhouette(fr, HERO[id].color), -fr.ax - 2, -fr.ay - 1.5); g.drawImage(ART.silhouette(fr, '#000000'), -fr.ax + 1.5, -fr.ay + 1);
    g.globalAlpha = 1; g.drawImage(img, fr.sx, fr.sy, fr.w, fr.h, -fr.ax, -fr.ay, fr.w, fr.h); g.restore();
  };
  fig(SAVE.hero, W * 0.29, 1); fig(SAVE.ally, W * 0.71, -1);
  c.ok = true; COMIC.img['@duo'] = c; COMIC.duoKey = key;
}
COMIC.exists = function (id) { return COMIC.pages(id).length > 0; };

/* ---------- layout ---------- */
function layoutPage(pg) {
  const gap = 10, availW = VW - 28, availH = VH - 34 - BAND;
  const asp = pg.map(p => { const im = COMIC.img[p.img]; return im.width / im.height; });
  const sum = asp.reduce((a, b) => a + b, 0);
  const h = Math.min(availH, (availW - gap * (pg.length - 1)) / sum);
  const tw = asp.reduce((a, b) => a + b * h, 0) + gap * (pg.length - 1);
  let x = (VW - tw) / 2; const y = (VH - BAND - h) / 2 + 6;
  return pg.map((p, i) => { const r = { x, y, w: asp[i] * h, h }; x += r.w + gap; return r; });
}

/* ---------- balloons ---------- */
function balloonText(b) { if (b.t === 'tag') return HERO[b.hero].name + ' ' + HERO[b.hero].role; return b.txt || CT(b.k); }
/* character name tag: name in the hero colour + role underneath */
function tagBox(b, pr) { const H = HERO[b.hero]; const role = PIX.wrap(H.role, 92, 1).slice(0, 2); const tw = Math.max(PIX.textW(H.name, 1), ...role.map(l => PIX.textW(l, 1))) + 10, th = 13 + role.length * 9;
  let bx = pr.x + pr.w * b.x, by = pr.y + pr.h * b.y; bx = Math.max(pr.x + 3, Math.min(bx, pr.x + pr.w - tw - 3)); by = Math.max(pr.y + 3, Math.min(by, pr.y + pr.h - th - 3)); return { x: bx, y: by, w: tw, h: th, role, H }; }
function drawBalloon(g, b, pr, k, scale) {
  const s = 1, txt = balloonText(b); if (!txt) return null;
  const maxW = b.t === 'cap' ? Math.min(220, pr.w * 0.6) : Math.min(170, pr.w * 0.46);
  if (b.t === 'tag') {
    const r = tagBox(b, pr), pop = Math.min(1, k); g.save(); g.globalAlpha = pop; g.translate(0, (1 - pop) * 8);
    g.fillStyle = '#000'; g.fillRect(r.x - 1.5, r.y - 1.5, r.w + 3, r.h + 3); g.fillStyle = 'rgba(12,6,20,0.94)'; g.fillRect(r.x, r.y, r.w, r.h); g.fillStyle = r.H.color; g.fillRect(r.x, r.y, r.w, 2); g.fillRect(r.x, r.y, 2, r.h);
    PIX.text(g, r.H.name, r.x + 5, r.y + 4, { col: r.H.color, out: '#000' }); r.role.forEach((l, i) => PIX.text(g, l, r.x + 5, r.y + 14 + i * 9, { col: '#d8d0e8', out: null }));
    g.restore(); return r;
  }
  if (b.t === 'sfx') {
    const sz = 3 + (pr.w > 260 ? 1 : 0); const pop = k < 1 ? 1.6 - 0.6 * k + Math.sin(k * 9) * 0.1 * (1 - k) : 1;
    g.save(); g.translate(pr.x + pr.w * b.x, pr.y + pr.h * b.y); g.rotate(b.rot || 0); g.scale(pop, pop);
    PIX.text(g, txt, 0, -3.5 * sz, { s: sz, align: 'c', col: b.col || '#fff', out: '#000', shadow: '#000' }); g.restore(); return null;
  }
  const lines = PIX.wrap(txt, maxW - 12, s); const lh = 10;
  const tw = Math.max(...lines.map(l => PIX.textW(l, s))) + 14, th = lines.length * lh + 9;
  let bx = pr.x + pr.w * b.x, by = pr.y + pr.h * b.y;
  bx = Math.min(bx, pr.x + pr.w - tw - 4); by = Math.min(by, pr.y + pr.h - th - 4); bx = Math.max(pr.x + 4, bx); by = Math.max(pr.y + 4, by);
  const rect = { x: bx, y: by, w: tw, h: th };
  const pop = Math.min(1, k); const sc = pop < 1 ? 0.6 + 0.4 * pop + Math.sin(pop * Math.PI) * 0.12 : 1;
  g.save(); g.globalAlpha = Math.min(1, pop * 2) * (b.alpha == null ? 1 : b.alpha);
  g.translate(bx + tw / 2, by + th / 2); g.scale(sc, sc); g.translate(-(bx + tw / 2), -(by + th / 2));
  if (b.t === 'cap') {
    g.fillStyle = '#000'; g.fillRect(bx - 1.5, by - 1.5, tw + 3, th + 3); g.fillStyle = b.big ? '#ff2a40' : '#ffd84a'; g.fillRect(bx, by, tw, th);
    g.fillStyle = 'rgba(0,0,0,0.12)'; g.fillRect(bx, by + th - 2, tw, 2);
    lines.forEach((l, i) => PIX.text(g, l, bx + 7, by + 5 + i * lh, { col: b.big ? '#ffffff' : '#141014', out: b.big ? '#000' : null }));
  } else {
    const tx = pr.x + pr.w * (b.tx != null ? b.tx : b.x), ty = pr.y + pr.h * (b.ty != null ? b.ty : b.y + 0.3);
    const cx = bx + tw / 2, cy = by + th / 2;
    g.lineJoin = 'round'; g.lineWidth = 2;
    const shape = () => {
      g.beginPath();
      if (b.shout) { const n = 18; for (let i = 0; i <= n; i++) { const a = i / n * 6.283, r = i % 2 ? 1 : 1.16; const px = cx + Math.cos(a) * (tw / 2 + 6) * r, py = cy + Math.sin(a) * (th / 2 + 5) * r; i ? g.lineTo(px, py) : g.moveTo(px, py); } }
      else if (b.t === 'think') { for (let i = 0; i < 10; i++) { const a = i / 10 * 6.283; g.moveTo(cx + Math.cos(a) * (tw / 2) + 7, cy + Math.sin(a) * (th / 2)); g.arc(cx + Math.cos(a) * (tw / 2), cy + Math.sin(a) * (th / 2), 7, 0, 6.283); } g.rect(bx + 2, by + 2, tw - 4, th - 4); }
      else { const r = Math.min(th / 2, 10); g.moveTo(bx + r, by - 2); g.lineTo(bx + tw - r, by - 2); g.quadraticCurveTo(bx + tw + 4, by - 2, bx + tw + 4, by + th / 2); g.quadraticCurveTo(bx + tw + 4, by + th + 2, bx + tw - r, by + th + 2); g.lineTo(bx + r, by + th + 2); g.quadraticCurveTo(bx - 4, by + th + 2, bx - 4, by + th / 2); g.quadraticCurveTo(bx - 4, by - 2, bx + r, by - 2); }
    };
    const tail = () => {
      if (b.t === 'think') { for (let i = 1; i <= 3; i++) { const q = i / 4; g.moveTo(lerp(cx, tx, q) + 4 - i, lerp(by + th, ty, q)); g.arc(lerp(cx, tx, q), lerp(by + th, ty, q), 4 - i * 0.8, 0, 6.283); } return; }
      const dx = tx - cx, dy = ty - cy, d = Math.hypot(dx, dy) || 1, nx = -dy / d, ny = dx / d, w = 5;
      const sx = cx + dx / d * Math.min(tw, th) * 0.3, sy = cy + dy / d * Math.min(tw, th) * 0.3;
      /* tail reaches out of the balloon toward the speaker, but never further than ~46px past the edge */
      const edge = Math.min(Math.abs(dx) > 0.01 ? (tw / 2 + 4) / Math.abs(dx / d) : 1e9, Math.abs(dy) > 0.01 ? (th / 2 + 4) / Math.abs(dy / d) : 1e9);
      const len = Math.max(edge + 8, Math.min(d * 0.85, edge + 46));
      const ex = cx + dx / d * len, ey = cy + dy / d * len;
      g.moveTo(sx + nx * w, sy + ny * w); g.quadraticCurveTo(lerp(sx, ex, 0.6) + nx * 2, lerp(sy, ey, 0.6) + ny * 2, ex, ey); g.lineTo(sx - nx * w, sy - ny * w);
    };
    /* outline (body + tail), then fill each part separately so the tail never punches through the text */
    g.fillStyle = '#000'; g.strokeStyle = '#000'; g.lineWidth = 4;
    g.beginPath(); tail(); g.closePath(); g.stroke(); g.beginPath(); shape(); g.closePath(); g.stroke();
    g.fillStyle = b.weak ? '#e8e4ee' : '#ffffff';
    g.beginPath(); tail(); g.closePath(); g.fill(); g.beginPath(); shape(); g.closePath(); g.fill();
    lines.forEach((l, i) => PIX.text(g, l, cx, by + 5 + i * lh, { align: 'c', col: '#141014', out: null }));
  }
  g.restore(); return rect;
}
const overlap = (a, b) => a && b && a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;

/* ---------- scene ---------- */
Scenes.comic = {
  enter(arg) {
    this.id = arg.id; this.then = arg.then; this.pages = null; this.wait = 0; this.t = 0; this.ready = false;
    this.skipBtn = null; if (arg.music != null) musicStart(arg.music);
    this.pg0 = COMIC.pages(this.id); const imgs = [].concat(...this.pg0.map(pg => pg.map(p => p.img)));
    COMIC.free(imgs); COMIC.need(imgs, () => { this.ready = true; });
  },
  init() {
    this.pages = this.pg0.map(pg => pg.filter(p => COMIC.img[p.img] && COMIC.img[p.img].ok)).filter(pg => pg.length); if (!this.pages.length) { this.done(); return; }
    this.pi = 0; this.startPage();
  },
  startPage() { this.pg = this.pages[this.pi]; { const ms = CUT_MOOD[this.id], pm = this.pg.find(p => p.mood); if (typeof musicMood === 'function' && (ms || pm)) musicMood(pm ? pm.mood : ms[Math.min(this.pi, ms.length - 1)] || ms[ms.length - 1]); if (this.pg.some(p => p.reveal) && typeof playSting === 'function') playSting('sting_reveal'); } this.rects = layoutPage(this.pg); this.ci = 0; this.bi = -1; this.mode = 'panel'; this.mt = 0; this.shown = this.pg.map(() => 0); this.cam = this.cam || { x: 0, y: 0, w: VW, h: VH }; this.nextBeat(); },
  nextBeat() {
    const p = this.pg[this.ci];
    if (this.shown[this.ci] === 0) { this.shown[this.ci] = 0.0001; sfx('ui'); }
    this.bi++; this.bt = 0;
    if (this.bi >= p.beats.length) {
      if (this.ci < this.pg.length - 1) { this.ci++; this.bi = -1; this.nextBeat(); return; }
      this.mode = 'overview'; this.mt = 0; return;
    }
    const b = p.beats[this.bi]; if (b.vo && typeof voice === 'function') voice(b.vo, 0); if (b.t === 'sfx') { if (typeof playSting === 'function') playSting('sting_impact'); else sfx('impact'); if (typeof musDuck === 'function') musDuck(0.35, 0.6); } else { sfx('pick'); if ((b.t === 'say' || b.t === 'think') && typeof musDuck === 'function') musDuck(0.7, 1.5); }
    this.autoT = b.t === 'sfx' ? 1.0 : b.t === 'tag' ? 0.9 : (SAVE.comicAuto ? 2.6 + balloonText(b).length * 0.085 : 1e9);
  },
  done() { const f = this.then; this.then = null; if (f) f(); },
  update(dt) {
    this.t += dt;
    if (!this.pages) { if (this.ready || this.t > 12) this.init(); return; }
    { const w = PIX.textW(T('skip'), 1) + 16; this.skipBtn = btn('skip', VW - w - 6, 4, w, 16, T('skip'), COLR.gray); }
    for (let i = 0; i < this.shown.length; i++) if (this.shown[i] > 0) this.shown[i] = Math.min(1, this.shown[i] + dt * 3.5);
    if (this.mode === 'panel') { this.bt += dt; if (this.bt > this.autoT) this.advance(); }
    else if (this.mode === 'overview') { this.mt += dt; if (SAVE.comicAuto && this.mt > 2.2) this.turn(); }
    else if (this.mode === 'turn') { this.mt += dt; if (this.mt > 0.5) { this.pi++; if (this.pi >= this.pages.length) { this.done(); return; } this.startPage(); } }
    /* camera */
    let tgt;
    const vh = VH - BAND; if (this.mode === 'panel') { const r = this.rects[this.ci]; const pad = 1.04; tgt = { x: r.x + r.w / 2, y: r.y + r.h / 2, w: r.w * pad, h: r.h * pad }; }
    else tgt = { x: VW / 2, y: vh / 2, w: VW, h: vh };
    const scT = Math.min(VW / tgt.w, vh / tgt.h); const k = Math.min(1, dt * 4.5);
    this.cam.sc = lerp(this.cam.sc || 1, scT, k); this.cam.cx = lerp(this.cam.cx == null ? VW / 2 : this.cam.cx, tgt.x, k); this.cam.cy = lerp(this.cam.cy == null ? vh / 2 : this.cam.cy, tgt.y, k);
  },
  turn() { this.mode = 'turn'; this.mt = 0; sfx('dash'); },
  /* dialogue band under the art: portrait + name + comic balloon, or a yellow caption — never covers a face */
  drawBand(g) {
    const y0 = VH - BAND, by = y0 + 4;
    g.fillStyle = 'rgba(6,3,10,0.92)'; g.fillRect(0, y0, VW, BAND); g.fillStyle = '#ff2a40'; g.fillRect(0, y0, VW, 1);
    if (this.mode !== 'panel') { if (Math.sin(this.t * 5) > -0.3) PIX.text(g, T('tapNext'), VW / 2, y0 + BAND / 2 - 4, { align: 'c', col: '#c8c0d8', out: null }); return; }
    const p = this.pg[this.ci]; let j = this.bi; while (j >= 0 && !['say', 'think', 'cap'].includes(p.beats[j].t)) j--;
    if (j < 0) return; const b = p.beats[j], txt = balloonText(b); if (!txt) return;
    const pop = j === this.bi ? Math.min(1, this.bt / 0.18) : 1; g.save(); g.globalAlpha = pop; g.translate(0, (1 - pop) * 6);
    if (b.t === 'cap') {
      const lines = PIX.wrap(txt, VW - 60, 1).slice(0, 4), h = lines.length * 11 + 10, yy = y0 + (BAND - h) / 2;
      g.fillStyle = '#000'; g.fillRect(18, yy - 2, VW - 36, h + 4); g.fillStyle = b.big ? '#c4001e' : '#ffd84a'; g.fillRect(20, yy, VW - 40, h);
      lines.forEach((l, i) => PIX.text(g, l, 30, yy + 6 + i * 11, { col: b.big ? '#fff' : '#141014', out: b.big ? '#000' : null }));
    } else {
      const spk0 = b.spk || SPK[b.k], hasFace = !!(spk0 && window.ITEMS && window.ITEMS['face_' + spk0]), spk = hasFace ? spk0 : null, fs = 52, fx = 14, fy = y0 + (BAND - fs) / 2 + 3;
      const bx = spk ? fx + fs + 18 : 24, bw = VW - bx - 16;
      if (spk) {
        const col = spkCol(spk); g.fillStyle = col; g.fillRect(fx - 2, fy - 2, fs + 4, fs + 4); g.fillStyle = '#000'; g.fillRect(fx, fy, fs, fs);
        drawFace(g, spk, fx, fy, fs);
        PIX.text(g, spkName(spk), bx + 4, by + 1, { col, out: '#000' });
      } else if (spk0) PIX.text(g, spkName(spk0), bx + 4, by + 1, { col: spkCol(spk0), out: '#000' });
      const lines = PIX.wrap(txt, bw - 20, 1).slice(0, 4), lh = 11, h = Math.min(BAND - 20, lines.length * lh + 10), yy = by + 12;
      g.lineJoin = 'round'; const shape = () => { g.beginPath(); const r = 8; g.moveTo(bx + r, yy); g.lineTo(bx + bw - r, yy); g.quadraticCurveTo(bx + bw, yy, bx + bw, yy + r); g.lineTo(bx + bw, yy + h - r); g.quadraticCurveTo(bx + bw, yy + h, bx + bw - r, yy + h); g.lineTo(bx + r, yy + h); g.quadraticCurveTo(bx, yy + h, bx, yy + h - r);
        if (spk && b.t !== 'think') { g.lineTo(bx, yy + h * 0.62); g.lineTo(bx - 12, yy + h * 0.5); g.lineTo(bx, yy + h * 0.36); }
        g.lineTo(bx, yy + r); g.quadraticCurveTo(bx, yy, bx + r, yy); g.closePath(); };
      g.fillStyle = '#000'; g.save(); g.translate(1.5, 1.5); shape(); g.fill(); g.restore();
      shape(); g.fillStyle = b.t === 'think' ? '#e6e2f0' : (b.weak ? '#ece8f2' : '#ffffff'); g.fill(); g.strokeStyle = '#000'; g.lineWidth = 1.5; g.stroke();
      if (b.t === 'think') { g.fillStyle = '#e6e2f0'; for (const [dx, r] of [[-6, 3], [-11, 2]]) { g.beginPath(); g.arc(bx + dx, yy + h * 0.5, r, 0, 7); g.fill(); g.stroke(); } }
      const shout = b.shout; lines.forEach((l, i) => PIX.text(g, l, bx + 10, yy + 6 + i * lh, { col: shout ? '#b0001c' : '#141014', out: null }));
    }
    g.restore();
    if (this.bt > 0.6 && Math.sin(this.t * 6) > 0) { g.fillStyle = '#f2eef8'; const x = VW - 12, y = VH - 9; g.beginPath(); g.moveTo(x - 4, y - 3); g.lineTo(x + 2, y); g.lineTo(x - 4, y + 3); g.fill(); }
  },
  advance() {
    if (this.mode === 'panel') { if (this.bt < 0.25) { this.bt = 0.25; return; } this.nextBeat(); }
    else if (this.mode === 'overview') this.turn();
  },
  draw(g) {
    g.fillStyle = '#0a0710'; g.fillRect(0, 0, VW, VH);
    if (!this.pages) { PIX.text(g, '...', VW / 2, VH / 2, { align: 'c', col: COLR.gray }); return; }
    /* page paper: dark with red halftone */
    g.fillStyle = 'rgba(160,0,30,0.10)'; for (let y = 0; y < VH; y += 6) for (let x = (y / 6 % 2) * 3; x < VW; x += 6) { const d = 0.4 + 0.9 * (y / VH); g.fillRect(x, y, d, d); }
    const c = this.cam, vh = VH - BAND; g.save(); g.translate(VW / 2, vh / 2); g.scale(c.sc, c.sc); g.translate(-c.cx, -c.cy);
    const S = (x, y) => [(x - c.cx) * c.sc + VW / 2, (y - c.cy) * c.sc + vh / 2];
    this.pg.forEach((p, i) => {
      const k = this.shown[i]; if (k <= 0) return; const r = this.rects[i], im = COMIC.img[p.img];
      const e = 1 - Math.pow(1 - k, 3); const off = (1 - e) * 40 * (i % 2 ? 1 : -1);
      g.save(); g.globalAlpha = e; g.translate(off, 0);
      g.fillStyle = '#000'; g.fillRect(r.x - 3, r.y - 3, r.w + 6, r.h + 6);
      /* ken burns inside the panel */
      const act = (this.mode === 'panel' && i === this.ci) ? 1 : 0; p._kb = lerp(p._kb || 0, act ? 1 : (p._kb || 0), 0.01);
      const z = 1 + 0.07 * (p._kb || 0) * Math.min(1, (this.t % 30) / 8) ; const sw = im.width / z, sh = im.height / z;
      const sx = (im.width - sw) * p.f[0], sy = (im.height - sh) * p.f[1];
      g.imageSmoothingEnabled = true; g.drawImage(im, sx, sy, sw, sh, r.x, r.y, r.w, r.h); g.imageSmoothingEnabled = false;
      g.strokeStyle = '#f2eef8'; g.lineWidth = 1 / c.sc; g.strokeRect(r.x + 1, r.y + 1, r.w - 2, r.h - 2);
      if (k < 1) { g.fillStyle = 'rgba(255,255,255,' + (1 - k) * 0.8 + ')'; g.fillRect(r.x, r.y, r.w, r.h); }
      if (this.mode === 'panel' && i !== this.ci) { g.fillStyle = 'rgba(0,0,0,0.45)'; g.fillRect(r.x, r.y, r.w, r.h); }
      g.restore();
    });
    g.restore();
    /* balloons of the active panel, in screen space */
    if (this.mode === 'panel') {
      const r = this.rects[this.ci]; const [x0, y0] = S(r.x, r.y), [x1, y1] = S(r.x + r.w, r.y + r.h); const pr = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
      const p = this.pg[this.ci]; const drawn = [];
      for (let j = 0; j <= this.bi && j < p.beats.length; j++) {
        const b = p.beats[j]; const kk = j === this.bi ? this.bt / 0.22 : 1;
        if (b.t !== 'sfx' && b.t !== 'tag') continue;
        /* hide older balloons that would collide with newer ones */
        let hide = false;
        if (b.t !== 'sfx' && b.t !== 'tag' && j < this.bi) { const est = drawBalloonRect(b, pr); for (let q = j + 1; q <= this.bi; q++) if (p.beats[q].t !== 'sfx' && p.beats[q].t !== 'tag' && overlap(est, drawBalloonRect(p.beats[q], pr))) hide = true; }
        if (!hide) drawBalloon(g, b, pr, kk);
      }
    }
    this.drawBand(g);
    if (this.mode === 'turn') { const k = this.mt / 0.5; g.fillStyle = '#000'; g.beginPath(); const xx = -60 + k * (VW + 160); g.moveTo(xx - 80, 0); g.lineTo(xx + 40, 0); g.lineTo(xx - 20, VH); g.lineTo(xx - 140, VH); g.closePath(); g.fill(); g.fillRect(0, 0, Math.max(0, xx - 110), VH); }
    if (this.skipBtn) drawBtn(g, this.skipBtn);
  },
  onDown(id, x, y) {
    if (this.skipBtn && hitB([this.skipBtn], x, y)) { sfx('ok'); this.done(); return; }
    if (this.pages) this.advance();
  },
  onKey(k) { if (k === 'ok' && this.pages) this.advance(); }
};
function drawBalloonRect(b, pr) {
  const txt = balloonText(b); if (!txt) return null;
  const maxW = b.t === 'cap' ? Math.min(220, pr.w * 0.6) : Math.min(170, pr.w * 0.46);
  const lines = PIX.wrap(txt, maxW - 12, 1); const tw = Math.max(...lines.map(l => PIX.textW(l, 1))) + 14, th = lines.length * 10 + 9;
  let bx = pr.x + pr.w * b.x, by = pr.y + pr.h * b.y; bx = Math.max(pr.x + 4, Math.min(bx, pr.x + pr.w - tw - 4)); by = Math.max(pr.y + 4, Math.min(by, pr.y + pr.h - th - 4));
  return { x: bx - 6, y: by - 6, w: tw + 12, h: th + 12 };
}
/* helper used by the rest of the game */
function playCut(id, then, music) { if (!COMIC.exists(id)) { then(); return; } Scene.go('comic', { id, then, music }); }
