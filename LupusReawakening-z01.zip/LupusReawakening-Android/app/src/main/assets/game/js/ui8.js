'use strict';
/* =====================================================================
   UI v8 — campaign flow for the 16 stages: loading per stage, partner
   picker, three-act map, choices, clear/next, lair (skills, looks,
   archives), endings.
   ===================================================================== */

/* ---------------- what each stage needs in memory ---------------- */
const MINI_KEYS = { vesp_mb: 'vespera', echo_mb: 'echo' };
function typesOf(st) {
  const T0 = new Set(); (st.waves || []).forEach(w => w.e.forEach(t => T0.add(t.replace('*', ''))));
  (st.pools || []).forEach(p => p.forEach(t => T0.add(t)));
  const B = BOSS[st.boss]; if (B && B.minions) B.minions.forEach(t => T0.add(t));
  if (st.mech === 'ritual') ['P', 'S', 'R', 'ZS', 'C', 'K', 'G'].forEach(t => T0.add(t));
  if (st.mech === 'sabotage') ['M', 'X'].forEach(t => T0.add(t));
  if (st.mech === 'final' || st.boss === 'beast' || st.boss === 'pack') T0.add('H');
  if (st.mech === 'giant') ['D', 'H'].forEach(t => T0.add(t));
  if (['voss', 'warden'].includes(st.boss)) ['ZS', 'Z'].forEach(t => T0.add(t));
  if (st.boss === 'prime' || st.boss === 'nacht') ['M', 'S', 'H'].forEach(t => T0.add(t));
  if (SAVE.ngp) for (const t of [...T0]) (NGP_MIX[t] || []).forEach(x => T0.add(x));
  return T0;
}
function playNeeds(o) {
  const st = STAGES[o.stage], keys = new Set(['lupus_h', 'lupus_f', 'lupus_a']), bgs = [];
  if ((st.l44 && !o.mode) || skinOn('lupus')) keys.add('lupus44'); if (st.l44 && !o.mode) keys.add('lupus44_f');
  if (st.mech === 'final' || st.boss === 'finalwolf') keys.add('fenrir');
  const ally = SAVE.ally; if (ally) keys.add(skinOn(ally) ? SKINS[ally].key : HERO[ally].key);
  if (o.mode === 'tutorial') keys.add('zealot');
  if (o.mode === 'endless') { EW_POOL[2].forEach(t => keys.add(ENEMY[t].key)); (o.bosses || []).forEach(b => { keys.add(BOSS[b].key); (BOSS[b].minions || []).forEach(t => keys.add(ENEMY[t].key)); }); ['S', 'H', 'M'].forEach(t => keys.add(ENEMY[t].key)); }
  else if (o.mode === 'rush') { const B = BOSS[st.boss]; keys.add(B.key); (B.minions || ['H', 'S', 'M', 'ZS', 'Z']).forEach(t => keys.add(ENEMY[t].key)); ['H', 'S', 'M', 'ZS', 'Z'].forEach(t => keys.add(ENEMY[t].key)); if (st.boss === 'nacht') keys.add('nacht_big'); if (st.boss === 'levgiant') keys.add('diver'); }
  else if (o.mode !== 'tutorial') {
    for (const t of typesOf(st)) if (ENEMY[t]) keys.add(ENEMY[t].key);
    const B = BOSS[st.boss]; keys.add(B.key); if (st.boss === 'nacht') keys.add('nacht_big');
    st.waves.forEach(w => { if (w.duel) keys.add(MINI_KEYS[w.duel]); });
    if (st.id === 2) keys.add('vespera'); if (st.mech === 'ritual') keys.add('brann'); if (st.mech === 'brew') keys.add('malakor'); if (st.mech === 'rescue') keys.add('mutant'); if (st.mech === 'chase') keys.add('zealot');
  }
  const bg = o.mode === 'endless' && o.bg ? o.bg : (st.bg || st.id); bgs.push('s' + bg + '_l3', 's' + bg + '_l4'); if (st.mech === 'climb' && !o.mode) bgs.push('s7_l2');
  return [...keys].filter(k => window.ATLAS[k]).map(k => 'c_' + k).concat(bgs);
}
const STAGE_PANELS = { 2: ['cs42'], 3: ['cs13'], 7: ['cs51', 'cs26'], 11: ['cs35'], 16: ['cs73'] };
Scenes.prep = {
  enter(o) { this.o = o; this.p = 0; this.t = 0; this.done = false; const keys = playNeeds(o); ART.free(keys); COMIC.free([]);
    const st = STAGES[o.stage]; const pan = (!o.mode && STAGE_PANELS[st.id]) || []; const sup = []; /* v9.2: the duo super uses its own cut-in art, loaded by super91.js */
    let n = 2; const fin = () => { if (--n <= 0) this.done = true; };
    COMIC.need(pan.concat(sup), fin); ART.need(keys, fin, p => { this.p = p; }); },
  update(dt) { this.t += dt; if (this.done && this.t > 0.25) { this.done = false; Scene._go('play', Object.assign({}, this.o, { __ready: true })); } },
  draw(g) {
    g.fillStyle = '#07040d'; g.fillRect(0, 0, VW, VH); const st = STAGES[this.o.stage];
    if (!this.o.mode) { PIX.text(g, T('stage') + ' ' + String(st.id).padStart(2, '0'), VW / 2, 92, { align: 'c', col: COLR.red }); PIX.text(g, st.name[SAVE.lang] || '', VW / 2, 108, { s: 2, align: 'c', grad: ['#ffffff', '#c8ccd8', '#8a8ea0'] }); }
    PIX.text(g, T('loading'), VW / 2, 160, { align: 'c', col: '#c8c0d8' }); PIX.bar(g, VW / 2 - 70, 176, 140, 5, this.p, COLR.red);
    const tips = T('tips'); if (Array.isArray(tips)) PIX.wrap(tips[(this.o.stage * 7 + 3) % tips.length], VW - 60, 1).forEach((l, i) => PIX.text(g, l, VW / 2, 206 + i * 11, { align: 'c', col: '#8a84a0', out: null }));
  }
};
Scene._go = Scene.go;
Scene.go = function (name, arg) { if (name === 'play' && !(arg && arg.__ready)) { const o = typeof arg === 'object' ? arg : { stage: arg }; Scene._go('prep', o); return; } Scene._go(name, arg); };

/* ---------------- choice modal (Triton and Nereus) ---------------- */
function openChoice(q, a, b, cb) { G.choice = { q, a, b, cb, t: 0 }; Inp.reset(); }
function choiceRects() { const w = 170, y = 160; return [{ id: 0, x: VW / 2 - w - 8, y, w, h: 30 }, { id: 1, x: VW / 2 + 8, y, w, h: 30 }]; }
function drawChoice(g) { const C = G.choice; dim(g, 0.8); PIX.wrap(T(C.q), VW - 80, 1).forEach((l, i) => PIX.text(g, l, VW / 2, 96 + i * 12, { align: 'c', col: COLR.white })); drawFace(g, 'triton', VW / 2 - 18, 52, 36);
  choiceRects().forEach((r, i) => { PIX.panel(g, r.x, r.y, r.w, r.h, { edge: i ? COLR.red : COLR.cyan, bg: 'rgba(10,6,18,0.9)' }); PIX.text(g, T(i ? C.b : C.a), r.x + r.w / 2, r.y + 11, { align: 'c', col: i ? '#ff8090' : '#9cf4ff' }); }); }
function choiceTap(x, y) { const C = G.choice; if (!C || C.t < 0.5) return; const r = choiceRects().find(r => x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h); if (!r) return; sfx('ok'); G.choice = null; C.cb(r.id); }

/* partner chatter between waves */
function waveCleared() {
  if (!storyOn()) return; const a = G.ally; if (a && !a.dead && Math.random() < 0.45) talk(ROSTER_KEY[a.id], 'q_' + a.id + Math.floor(Math.random() * 3), { dur: 2.8 });
  const M = MECH[G.mech]; if (M && M.waveClear) M.waveClear(G.waveIdx);
}

/* ---------------- finish a stage: progress, skins, affinity, the choice ---------------- */
Scenes.play.finish = function () {
  const st = G.st; if (G.mode) { this.modeEnd(true); return; }
  if (G.mech === 'giant' && !G.choiceDone) { G.choiceDone = true; voice('nereus_roar', 0); openChoice('ch10q', 'ch10a', 'ch10b', id => { SAVE.nereus = id ? 'end' : 'spare'; saveGame(); this.finish(); }); return; }
  const res = { score: Math.round(G.score), time: G.time, combo: G.maxCombo, stage: G.stage, shards: G.shards, xp: G.xpGain || 0, skins: [] };
  { const list = CHAL[st.id] || [], prev = (SAVE.stars || {})[st.id] || 0; let mask = prev, fresh = 0; res.chal = list.map((c, i) => { const ok = chalDone(c, G, true); if (ok && !(prev & (1 << i))) fresh++; if (ok) mask |= 1 << i; return { c, ok, was: !!(prev & (1 << i)) }; }); SAVE.stars = SAVE.stars || {}; SAVE.stars[st.id] = mask; res.fresh = fresh; res.bonus = fresh * 10; SAVE.shards = (SAVE.shards || 0) + res.bonus; }
  SAVE.best = SAVE.best || {}; if (!SAVE.best[st.id] || SAVE.best[st.id] < res.score) SAVE.best[st.id] = res.score;
  if (G.stage + 2 > SAVE.unlocked && G.stage < STAGES.length - 1) SAVE.unlocked = G.stage + 2;
  if (G.stage === STAGES.length - 1) { SAVE.unlocked = Math.max(SAVE.unlocked, STAGES.length + 1); SAVE.cleared = 16; }
  const partner = G.team.find(h => h.id !== 'lupus'); if (partner) { SAVE.aff = SAVE.aff || {}; SAVE.aff[partner.id] = (SAVE.aff[partner.id] || 0) + 1; if (SAVE.aff[partner.id] === 5) res.affUp = partner.id; }
  SAVE.skins = SAVE.skins || {}; const unlock = id => { if (!SAVE.skins[id]) { SAVE.skins[id] = true; res.skins.push(id); } };
  if (st.id === 11 && partner && partner.id === 'vespera') unlock('vespera');
  if (st.id === 10 && SAVE.nereus === 'spare') unlock('triton');
  if (st.id === 9 && (SAVE.stars[9] || 0) === 7) unlock('echo');
  if (st.id === 16 && (SAVE.diff === 'hard' || SAVE.diff === 'nightmare')) unlock('malakor');
  if (st.id === 16 && SAVE.diff === 'nightmare') unlock('brann');
  if (archCount() >= ARCH_N) unlock('lupus');
  saveGame(); playCut('s' + st.id + 'post', () => Scene.go('clear', res));
};
Scenes.clear.onDown = function (id, x, y) {
  if (!this.btn) return;
  if (this.step === 0) { if (hitB([this.btn], x, y) || this.t > 0.6) { sfx('ok'); this.step = this.opts.length ? 1 : 2; } return; }
  if (this.step === 1) { for (const k of this.cards) if (x >= k.x && x <= k.x + k.w && y >= k.y && y <= k.y + k.h) { SAVE.up[k.id] = (SAVE.up[k.id] || 0) + 1; saveGame(); sfx('ok'); this.step = 2; return; } return; }
  if (hitB([this.btn], x, y)) { sfx('ok'); const i = this.res.stage;
    if (i === ACT_START[2] - 1) playCut('act2', () => Scene.go('stages', { act: 2 }));
    else if (i === ACT_START[3] - 1) playCut('act3', () => Scene.go('stages', { act: 3 }));
    else if (i >= STAGES.length - 1) playCut('finale', () => Scene.go('end', { final: true }));
    else if (i === 0 && !this.res.mode && window.needsDiffPick && needsDiffPick()) Scene.go('diffPick');
    else Scene.go('stages'); }
};
{ const _cu = Scenes.clear.update; Scenes.clear.update = function (dt) { _cu.call(this, dt); if (this.btn && this.step !== 0) this.btn.label = this.res.stage >= STAGES.length - 1 ? T('theEnd') + ' >' : T('stages') + ' >'; };
  const _cd = Scenes.clear.draw; Scenes.clear.draw = function (g) { _cd.call(this, g); const R = this.res; if (this.step === 0) { let y = 222; if (R.affUp) { PIX.text(g, T('affUp').replace('{n}', HERO[R.affUp].name), VW / 2, y, { align: 'c', col: COLR.gold }); y += 11; } (R.skins || []).forEach(s => { PIX.text(g, T('skinUnlocked') + ': ' + HERO[s].name, VW / 2, y, { align: 'c', col: '#7dff9a' }); y += 11; }); } }; }

/* ---------------- game over: reasons, nightmare restarts the stage ---------------- */
{ const _ou = Scenes.over.update, _od = Scenes.over.draw;
  Scenes.over.update = function (dt) { _ou.call(this, dt); if (SAVE.diff === 'nightmare') this.btns = this.btns.filter(b => b.id !== 'ck'); };
  Scenes.over.draw = function (g) { _od.call(this, g); if (G && G.failMsg) PIX.text(g, T(G.failMsg), VW / 2, 102, { align: 'c', col: COLR.gold }); }; }

/* ---------------- partner picker (before each stage, and for the modes) ---------------- */
Scenes.select = {
  t: 0, cards: [], sel: null,
  enter(o) { this.o = Object.assign({}, o || {}); if (this.o.stage == null && SAVE.pendingMode) this.o.mode = SAVE.pendingMode; this.t = 0; BG.set(3); musicStart(5); const sid0 = this.o.stage != null ? STAGES[this.o.stage].id : 0;
    this.avail = this.o.stage != null ? partnersFor(sid0) : PARTNERS.filter(partnerJoined); if (!this.avail.length && this.o.stage == null) this.avail = ['vespera'];
    this.sel = this.avail.includes(SAVE.ally) ? SAVE.ally : this.avail[0] || null;
    if (this.o.stage != null && (STAGES[this.o.stage].solo || !this.avail.length)) { this.skip = true; } else this.skip = false; },
  update(dt) {
    if (this.skip) { this.skip = false; this.go(); return; }
    this.t += dt; this.back = btn('back', 6, 6, 62, 16, T('back'), COLR.gray); this.goB = btn('go', VW / 2 - 60, VH - 24, 120, 18, T('go') + ' >', COLR.red);
    const n = PARTNERS.length, gap = 6, cw = Math.floor((VW - 16 - gap * (n - 1)) / n), x0 = Math.round((VW - (cw * n + gap * (n - 1))) / 2);
    this.cards = PARTNERS.map((id, i) => ({ id, x: x0 + i * (cw + gap), y: 30, w: cw, h: 208 }));
  },
  draw(g) {
    BG.menu(g, 3, this.t, this.t * 10); dim(g, 0.45);
    const st = this.o.stage != null ? STAGES[this.o.stage] : null;
    PIX.text(g, 'THORNE  +  ' + T('selectAlly'), VW / 2, 8, { align: 'c', col: COLR.white }); if (st) PIX.text(g, T('stage') + ' ' + st.id + ': ' + (st.name[SAVE.lang] || ''), VW / 2, 18, { align: 'c', col: '#c8c0d8', out: null });
    for (const c of this.cards) {
      const H = HERO[c.id], sel = this.sel === c.id, ok = this.avail.includes(c.id);
      PIX.panel(g, c.x, c.y, c.w, c.h, { edge: sel ? H.color : PIX.shade(H.color, 0.55), bg: sel ? 'rgba(30,10,30,0.88)' : 'rgba(10,6,18,0.78)' });
      if (sel) { g.fillStyle = H.color; g.globalAlpha = 0.1 + 0.07 * Math.sin(this.t * 6); g.fillRect(c.x + 1, c.y + 1, c.w - 2, c.h - 2); g.globalAlpha = 1; }
      PIX.text(g, H.name, c.x + c.w / 2, c.y + 6, { align: 'c', col: H.color });
      const key = skinOn(c.id) && ART.img['c_' + SKINS[c.id].key] ? SKINS[c.id].key : ROSTER_KEY[c.id]; const fr = ART.frame(key, sel ? 'win' : 'idle', Math.floor(this.t * 7));
      g.save(); g.beginPath(); g.rect(c.x + 2, c.y + 16, c.w - 4, 104); g.clip(); RD.glow(g, c.x + c.w / 2, c.y + 80, 46, H.color, 0.28); ART.shadow(g, c.x + c.w / 2, c.y + 116, 18, 0.7);
      ART.useLook(MENU_LOOK); g.imageSmoothingEnabled = true; ART.draw(g, fr, c.x + c.w / 2, c.y + 116, { face: 1, sc: Math.min(1, 96 / window.ATLAS[key].h), rims: [[H.color, -2, -1, 0.7]] }); g.imageSmoothingEnabled = false; g.restore();
      PIX.wrap(H.role, c.w - 8, 1).slice(0, 2).forEach((l, n) => PIX.text(g, l, c.x + c.w / 2, c.y + 124 + n * 9, { align: 'c', col: COLR.gray, out: null }));
      T('stats').forEach((lab, n) => { const yy = c.y + 146 + n * 11; PIX.text(g, lab.slice(0, c.w < 80 ? 3 : 5), c.x + 4, yy, { col: '#c8c0d8', out: null }); PIX.bar(g, c.x + (c.w < 80 ? 24 : 40), yy, c.w - (c.w < 80 ? 28 : 46), 5, H.stats[n] / 5, H.color, '#1a0f22', 5); });
      { const af = (SAVE.aff || {})[c.id] || 0; PIX.text(g, T('affinity') + ' ' + Math.min(5, af) + '/5', c.x + c.w / 2, c.y + 200, { align: 'c', col: af >= 5 ? COLR.gold : '#8a84a0', out: null }); }
      if (!ok) { g.fillStyle = 'rgba(4,2,10,0.8)'; g.fillRect(c.x, c.y + 14, c.w, c.h - 14); const away = (AWAY[c.id] || []).includes(st ? st.id : -1) && JOIN[c.id] <= (st ? st.id : 0); PIX.text(g, away ? T('away') : T('locked'), c.x + c.w / 2, c.y + 64, { align: 'c', col: '#8a84a0' }); if (!away) PIX.wrap(T('joinsAt').replace('{n}', JOIN[c.id] - 1), c.w - 8, 1).forEach((l, n) => PIX.text(g, l, c.x + c.w / 2, c.y + 78 + n * 9, { align: 'c', col: '#6a6480', out: null })); }
    }
    drawBtn(g, this.back); if (this.sel) drawBtn(g, this.goB, Math.sin(this.t * 5) > 0);
  },
  go() {
    if (this.sel) { SAVE.ally = this.sel; } saveGame();
    const o = this.o;
    if (o.mode) { startMode(o.mode); return; }
    const st = STAGES[o.stage], run = () => playCut('s' + st.id + 'pre', () => Scene.go('play', o.stage), st.music);
    if (!SAVE.tutDone && !st.solo && this.sel) { SAVE.tutNextStage = o.stage; saveGame(); Scene.go('play', { stage: o.stage, mode: 'tutorial', next: 'stages' }); return; }
    if (o.stage === 0 && !SAVE.seenIntro) { SAVE.seenIntro = true; saveGame(); playCut('intro', run); return; }
    run();
  },
  onDown(id, x, y) {
    if (hitB([this.back], x, y)) { sfx('ui'); Scene.go(this.o.mode ? 'lair' : 'stages'); return; }
    if (this.sel && hitB([this.goB], x, y)) { sfx('ok'); this.go(); return; }
    for (const c of this.cards) { if (x < c.x || x > c.x + c.w || y < c.y || y > c.y + c.h) continue; if (!this.avail.includes(c.id)) { sfx('ui'); return; } if (this.sel === c.id) { sfx('ok'); this.go(); } else { this.sel = c.id; sfx('ui'); } return; }
  },
  onKey(k) { if (k === 'ok' && this.sel) this.go(); }
};

/* ---------------- the hunt map: prologue + three acts ---------------- */
Scenes.stages = {
  t: 0,
  enter(o) { this.t = 0; musicStart(5); const u = SAVE.unlocked || 1; this.act = (o && o.act) || (u > ACT_START[3] ? 3 : u > ACT_START[2] ? 2 : 1); this.newAct = !!(o && o.act); for (let s = 1; s <= 16; s++) ART.need(['th_s' + STAGES[s - 1].bg], () => { }); },
  update(dt) {
    this.t += dt; this.back = btn('back', 6, 6, 62, 16, T('back'), COLR.gray);
    const ws = [1, 2, 3].map(a => PIX.textW(T('act' + a), 1) + 16), tot = ws.reduce((a, b) => a + b, 0) + 8; let tx = VW / 2 - tot / 2; this.tabs = [1, 2, 3].map((a, i) => { const b = btn('act' + a, tx, 28, ws[i], 14, T('act' + a), a === this.act ? COLR.red : '#5a5470'); tx += ws[i] + 4; return b; });
    const lo = this.act === 1 ? 0 : ACT_START[this.act], hi = this.act === 3 ? STAGES.length : ACT_START[this.act + 1], n = hi - lo;
    const gap = 5, cw = Math.floor((VW - 14 - gap * (n - 1)) / n), x0 = Math.round((VW - (cw * n + gap * (n - 1))) / 2);
    this.cards = STAGES.slice(lo, hi).map((s, j) => ({ i: lo + j, x: x0 + j * (cw + gap), y: 48, w: cw, h: 182 }));
    this.ngpB = SAVE.cleared ? btn('ngp', VW - 132, VH - 22, 126, 16, T('ngp') + ': ' + (SAVE.ngp ? T('on') : T('off')), SAVE.ngp ? COLR.gold : '#5a5470') : null;
  },
  draw(g) {
    BG.menu(g, 2, this.t, this.t * 8); dim(g, 0.6);
    PIX.text(g, T('stages'), VW / 2, 10, { s: 2, align: 'c', col: COLR.red });
    { const dk = SAVE.diff || 'normal'; PIX.text(g, T('difficulty') + ': ' + T('d_' + dk), VW - 8, 10, { align: 'r', col: ({ easy: '#7dff9a', normal: '#ffcf3a', hard: '#ff8a3a', nightmare: '#ff3a50' })[dk], out: '#0a0612' }); }
    PIX.text(g, T('archive') + ' ' + archCount() + '/' + ARCH_N, 8, VH - 12, { col: '#ffd23a', out: '#0a0612' });
    for (const b of this.tabs) drawBtn(g, b);
    for (const k of this.cards) {
      const s = STAGES[k.i], lock = k.i + 1 > SAVE.unlocked, im = ART.img['th_s' + s.bg];
      if (im && im.ok) { g.save(); g.imageSmoothingEnabled = true; const th = 112, tw = k.w - 2, sw = Math.min(im.width, im.height * tw / th); g.drawImage(im, (im.width - sw) / 2, 0, sw, im.height, k.x + 1, k.y + 1, tw, th); g.restore(); }
      else { g.fillStyle = '#140c1c'; g.fillRect(k.x + 1, k.y + 1, k.w - 2, 112); }
      if (lock) { g.fillStyle = 'rgba(0,0,0,0.78)'; g.fillRect(k.x + 1, k.y + 1, k.w - 2, 112); }
      PIX.panel(g, k.x, k.y + 110, k.w, 72, { edge: lock ? '#3a3448' : COLR.red });
      g.fillStyle = lock ? '#3a3448' : COLR.red; g.fillRect(k.x, k.y, k.w, 1); g.fillRect(k.x, k.y, 1, 112); g.fillRect(k.x + k.w - 1, k.y, 1, 112);
      PIX.text(g, s.id === 1 ? '1944' : String(s.id).padStart(2, '0'), k.x + 4, k.y + 5, { s: 2, col: lock ? '#5a5470' : COLR.red });
      PIX.wrap(s.name[SAVE.lang] || '', k.w - 6, 1).slice(0, 3).forEach((l, n) => PIX.text(g, l, k.x + 3, k.y + 115 + n * 9, { col: lock ? '#6a6480' : COLR.white, out: null }));
      if (!lock) { drawFace(g, BOSS[s.boss].key, k.x + k.w - 24, k.y + 148, 20); const m = (SAVE.stars || {})[s.id] || 0; for (let n = 0; n < 3; n++) drawStar(g, k.x + 9 + n * 12, k.y + 152, 5, !!(m & (1 << n)));
        const ar = (s.arch || []).filter((_, j) => (SAVE.arch || {})[archId(s.id, j)]).length; PIX.text(g, ar + '/3', k.x + 4, k.y + 164, { col: ar === 3 ? '#ffd23a' : '#8a7a50', out: null });
        if (SAVE.best[s.id]) PIX.text(g, '' + SAVE.best[s.id], k.x + k.w - 4, k.y + 172, { align: 'r', col: COLR.gold, out: null }); }
      else PIX.text(g, T('locked'), k.x + k.w / 2, k.y + 50, { align: 'c', col: '#8a84a0' });
    }
    if (this.newAct && this.t < 4 && Math.sin(this.t * 6) > -0.5) PIX.text(g, T('act' + this.act), VW / 2, VH - 26, { s: 2, align: 'c', col: COLR.gold });
    drawBtn(g, this.back); if (this.ngpB) drawBtn(g, this.ngpB);
  },
  onDown(id, x, y) {
    if (hitB([this.back], x, y)) { sfx('ui'); Scene.go('title'); return; }
    if (this.ngpB && hitB([this.ngpB], x, y)) { SAVE.ngp = !SAVE.ngp; saveGame(); sfx('ok'); return; }
    { const b = hitB(this.tabs, x, y); if (b) { const a = +b.id.slice(3); if (a > 1 && SAVE.unlocked <= ACT_START[a]) { sfx('ui'); return; } sfx('ui'); this.act = a; this.newAct = false; return; } }
    for (const k of this.cards) if (x >= k.x && x <= k.x + k.w && y >= k.y && y <= k.y + k.h) { if (k.i + 1 > SAVE.unlocked) { sfx('ui'); return; } sfx('ok'); Scene.go('select', { stage: k.i }); return; }
  }
};
Scenes.title.start = function () { SAVE.pendingMode = null; if ((SAVE.unlocked || 1) <= 1) Scene.go('select', { stage: 0 }); else Scene.go('stages'); };
{ const _ta = Scenes.title.activate; Scenes.title.activate = function (id) { if (id === 'story') { sfx('ok'); playCut('intro', () => Scene.go('title')); return; } _ta.call(this, id); }; }
/* tutorial: after training, go on to the stage that was picked */
{ const _tut = tutStep; tutStep = function (dt) { const T0 = G.tut; if (T0 && T0.steps[T0.i] === 'done' && T0.t > 3 && !T0.left && SAVE.tutNextStage != null) { T0.left = true; SAVE.tutDone = true; const i = SAVE.tutNextStage; SAVE.tutNextStage = null; saveGame(); const st = STAGES[i]; playCut('s' + st.id + 'pre', () => Scene.go('play', i), st.music); return; } _tut(dt); }; }

/* ---------------- modes ---------------- */
const EW_BOSSES = ['warden', 'voss', 'prime', 'nacht', 'morrigan', 'kane', 'kreutz', 'construct', 'beast', 'firstwolf'];
RUSH_N = () => Math.max(1, Math.min(STAGES.length, (SAVE.unlocked || 1) - 1));
startMode = function (m) {
  SAVE.pendingMode = null; saveGame();
  if (m === 'rush') Scene.go('play', { stage: 0, mode: 'rush', rushIdx: 0 });
  else { const bosses = EW_BOSSES.slice().sort(() => Math.random() - 0.5).slice(0, 3); const pool = [1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 13, 14, 15, 16]; Scene.go('play', { stage: 1, mode: 'endless', bg: pick(pool), bosses }); }
};
/* endless: bosses come from the preloaded list */
{ const _es = endlessStep; endlessStep = function (dt) { if (G.ew % 10 === 9 && !G.ewActive && !G.ewPick) { G.ewPick = true; } const o = Scenes.play.arg || {}; const before = G.ewBoss; _es(dt); if (G.ewBoss && G.ewBoss !== before && o.bosses && !o.bosses.includes(G.ewBoss)) { G.ewBoss = o.bosses[Math.floor(G.ew / 10 - 1) % o.bosses.length]; G.banner = { t: 0, boss: BOSS[G.ewBoss] }; } }; }

/* ---------------- lair: upgrades, skills, looks (skins + colours), archives, gallery, modes ---------------- */
{
  const L = Scenes.lair, _layout = L.layout, _draw = L.draw, _down = L.onDown, _enter = L.enter;
  L.enter = function () { _enter.call(this); this.tab = 0; this.hero = 'lupus'; ART.need(Object.values(SKINS).map(s => 'c_' + s.key), () => { }); };
  L.layout = function () {
    const tabs = [T('upgrades'), T('skills'), T('looks'), T('archives'), T('gallery'), T('modes')];
    if (this.tab === 0 || this.tab === 4 || this.tab === 5) { const map = { 0: 0, 4: 2, 5: 3 }; const keep = this.tab; this.tab = map[keep]; _layout.call(this); this.tab = keep; }
    else { this.btns = [btn('back', 6, 6, 62, 16, T('back'), COLR.gray)]; this.items = []; }
    this.btns = this.btns.filter(b => !b.id.startsWith('tab')); const tw = Math.min(100, (VW - 20) / 6);
    tabs.forEach((l, i) => this.btns.push(btn('tab' + i, VW / 2 - tw * 3 + i * tw + 2, 28, tw - 4, 16, l, i === this.tab ? COLR.red : '#5a5470')));
    if (this.tab === 1) { const H = ROSTER, cw = (VW - 24) / H.length; H.forEach((id, i) => this.items.push({ kind: 'hsel', id, x: 12 + i * cw, y: 48, w: cw - 4, h: 16 }));
      ['atk', 'def', 'spc'].forEach((br, j) => { const n = skl(this.hero)[br], y = 72 + j * 58; this.items.push({ kind: 'sk', br, n, x: 24, y, w: VW - 48, h: 52, b: n < 4 ? btn('s_' + br, VW - 140, y + 18, 104, 16, SK_COST[n] + '', (SAVE.shards || 0) >= SK_COST[n] && heroLv(this.hero) >= SK_LV[n] ? COLR.gold : '#5a5470') : null }); }); }
    if (this.tab === 2) { const H = ROSTER, cw = (VW - 24) / H.length; H.forEach((id, i) => this.items.push({ kind: 'look', id, x: 12 + i * cw, y: 50, w: cw - 4, h: 212 })); }
    if (this.tab === 3) { const cols = 8, cw = (VW - 40) / cols; for (let i = 0; i < ARCH_N; i++) this.items.push({ kind: 'arch', i, x: 20 + (i % cols) * cw, y: 50 + Math.floor(i / cols) * 34, w: cw - 4, h: 30 }); }
  };
  L.draw = function (g) {
    if (this.tab === 0 || this.tab === 4 || this.tab === 5) { const map = { 0: 0, 4: 2, 5: 3 }; const keep = this.tab; this.tab = map[keep]; _draw.call(this, g); this.tab = keep; for (const b of this.btns) if (b.id.startsWith('tab')) drawBtn(g, b); if (this.archView != null) this.drawArch(g); return; }
    BG.menu(g, 3, this.t, this.t * 8); dim(g, 0.72); PIX.text(g, T('lair'), VW / 2, 8, { s: 2, align: 'c', col: COLR.red }); drawShard(g, VW - 70, 13); PIX.text(g, '' + (SAVE.shards || 0), VW - 60, 10, { col: '#b8e8ff' });
    for (const b of this.btns) drawBtn(g, b);
    for (const it of this.items) {
      if (it.kind === 'hsel') { const on = it.id === this.hero, H = HERO[it.id]; PIX.panel(g, it.x, it.y, it.w, it.h, { edge: on ? H.color : '#3a3448', cut: 2 }); PIX.text(g, H.name + ' ' + T('lv') + heroLv(it.id), it.x + it.w / 2, it.y + 4, { align: 'c', col: on ? H.color : '#8a84a0', out: null }); }
      else if (it.kind === 'sk') { PIX.panel(g, it.x, it.y, it.w, it.h, { edge: '#5a5470' }); PIX.text(g, T('br_' + it.br), it.x + 10, it.y + 6, { col: COLR.gold }); for (let n = 0; n < 4; n++) { const on = n < it.n; g.fillStyle = on ? COLR.gold : '#3a3448'; g.fillRect(it.x + 10 + n * 52, it.y + 20, 46, 5); PIX.text(g, T('sk_' + it.br + n), it.x + 10 + n * 52, it.y + 29, { col: on ? COLR.white : '#7a7490', out: null }); }
        if (it.b) { drawBtn(g, it.b); drawShard(g, it.b.x + 14, it.b.y + 8); if (heroLv(this.hero) < SK_LV[it.n]) PIX.text(g, T('lv') + ' ' + SK_LV[it.n], it.b.x + it.b.w / 2, it.b.y + 20, { align: 'c', col: '#8a84a0', out: null }); } else PIX.text(g, 'MAX', VW - 88, it.y + 22, { align: 'c', col: COLR.gold }); }
      else if (it.kind === 'look') { const H = HERO[it.id], sk = SKINS[it.id], own = skinOwned(it.id), on = skinOn(it.id), key = on && ART.img['c_' + sk.key] && ART.img['c_' + sk.key].ok ? sk.key : ROSTER_KEY[it.id], cur = (SAVE.pal || {})[it.id] || 0;
        PIX.panel(g, it.x, it.y, it.w, it.h, { edge: H.color }); PIX.text(g, H.name, it.x + it.w / 2, it.y + 5, { align: 'c', col: H.color });
        const fr = ART.frame(key, 'idle', Math.floor(this.t * 7)); ART.useLook(MENU_LOOK); g.imageSmoothingEnabled = true; ART.draw(g, fr, it.x + it.w / 2, it.y + 112, { face: 1, sc: Math.min(1, 92 / window.ATLAS[key].h), pal: on ? 0 : cur }); g.imageSmoothingEnabled = false;
        it.skB = btn('sk_' + it.id, it.x + 4, it.y + 118, it.w - 8, 16, own ? (on ? T('skin') + ': ' + T('on') : T('skin') + ': ' + T('off')) : T('locked'), own ? (on ? COLR.gold : COLR.cyan) : '#3a3448'); it.skB.s = 1; drawBtn(g, it.skB);
        if (!own) PIX.wrap(T(sk.how), it.w - 8, 1).slice(0, 3).forEach((l, n) => PIX.text(g, l, it.x + it.w / 2, it.y + 140 + n * 9, { align: 'c', col: '#8a84a0', out: null }));
        it.sw = []; if (!on) for (let n = 0; n < 4; n++) { const ownP = n === 0 || !!(SAVE.owned || {})['pal_' + it.id + '_' + n], sw = (it.w - 12) / 4 - 2, sx = it.x + 6 + n * (sw + 2), sy = it.y + (own ? 140 : 170); it.sw.push({ n, x: sx, y: sy, w: sw, h: 34, own: ownP }); PIX.panel(g, sx, sy, sw, 34, { edge: n === cur ? '#ffffff' : ownP ? H.color : '#3a3448', cut: 2 }); g.save(); g.beginPath(); g.rect(sx + 1, sy + 1, sw - 2, 32); g.clip(); g.imageSmoothingEnabled = true; ART.draw(g, ART.frame(ROSTER_KEY[it.id], 'idle', 0), sx + sw / 2, sy + 50, { face: 1, sc: 0.5, pal: n }); g.restore(); g.imageSmoothingEnabled = false; if (!ownP) { g.fillStyle = 'rgba(0,0,0,0.55)'; g.fillRect(sx + 1, sy + 1, sw - 2, 32); PIX.text(g, '' + PAL_COST, sx + sw / 2, sy + 13, { align: 'c', col: '#b8e8ff', out: null }); } } }
      else if (it.kind === 'arch') { const got = !!(SAVE.arch || {})[it.i]; PIX.panel(g, it.x, it.y, it.w, it.h, { edge: got ? '#ffd23a' : '#3a3448', cut: 2, bg: got ? 'rgba(40,30,10,0.85)' : 'rgba(10,6,18,0.8)' }); PIX.text(g, String(it.i + 1).padStart(2, '0'), it.x + it.w / 2, it.y + 5, { align: 'c', col: got ? '#ffd23a' : '#5a5470' }); PIX.text(g, got ? T('stage') + ' ' + (Math.floor(it.i / 3) + 1) : '?', it.x + it.w / 2, it.y + 17, { align: 'c', col: got ? '#c8b080' : '#3a3448', out: null }); }
    }
    if (this.tab === 3) PIX.text(g, archCount() + '/' + ARCH_N + '  —  ' + T('archHint'), VW / 2, VH - 12, { align: 'c', col: '#c8b080', out: null });
    if (this.msg) PIX.text(g, this.msg.txt, VW / 2, VH - 24, { align: 'c', col: this.msg.col });
    if (this.archView != null) this.drawArch(g);
  };
  L.drawArch = function (g) { const i = this.archView; dim(g, 0.9); PIX.panel(g, 30, 24, VW - 60, VH - 48, { edge: '#ffd23a', bg: 'rgba(30,22,12,0.97)' }); PIX.text(g, T('archive') + ' ' + String(i + 1).padStart(2, '0') + ' — ' + CT('arT' + i), VW / 2, 34, { align: 'c', col: '#ffd23a' }); PIX.wrap(CT('arB' + i), VW - 90, 1).slice(0, 16).forEach((l, n) => PIX.text(g, l, 45, 54 + n * 11, { col: '#e8dcc0', out: null })); PIX.text(g, T('tapNext'), VW / 2, VH - 38, { align: 'c', col: '#8a7a50', out: null }); };
  L.onDown = function (id, x, y) {
    if (this.archView != null) { this.archView = null; sfx('ui'); return; }
    const tb = hitB(this.btns.filter(b => b.id.startsWith('tab')), x, y); if (tb) { sfx('ui'); this.tab = +tb.id.slice(3); this.scroll = 0; this.view = -1; return; }
    if (this.tab === 0 || this.tab === 4 || this.tab === 5) { const map = { 0: 0, 4: 2, 5: 3 }; const keep = this.tab; this.tab = map[keep]; const r = _down.call(this, id, x, y); if (this.tab === map[keep]) this.tab = keep; return r; }
    if (hitB([this.btns[0]], x, y)) { sfx('ui'); Scene.go('title'); return; }
    for (const it of this.items) {
      if (it.kind === 'hsel' && x >= it.x && x <= it.x + it.w && y >= it.y && y <= it.y + it.h) { this.hero = it.id; sfx('ui'); return; }
      if (it.kind === 'sk' && it.b && hitB([it.b], x, y)) { if (heroLv(this.hero) < SK_LV[it.n]) { sfx('ui'); this.say(T('needLv').replace('{n}', SK_LV[it.n]), COLR.red); return; } if (this.buy(SK_COST[it.n])) { SAVE.sk = SAVE.sk || {}; SAVE.sk[this.hero] = Object.assign({}, SAVE.sk[this.hero]); SAVE.sk[this.hero][it.br] = it.n + 1; saveGame(); this.say(T('sk_' + it.br + it.n) + ' +'); } return; }
      if (it.kind === 'look') { if (it.skB && hitB([it.skB], x, y)) { if (!skinOwned(it.id)) { sfx('ui'); return; } SAVE.skinOn = SAVE.skinOn || {}; SAVE.skinOn[it.id] = !SAVE.skinOn[it.id]; saveGame(); sfx('ok'); return; }
        if (it.sw) for (const sw of it.sw) if (x >= sw.x && x <= sw.x + sw.w && y >= sw.y && y <= sw.y + sw.h) { if (!sw.own) { if (!this.buy(PAL_COST)) return; SAVE.owned = SAVE.owned || {}; SAVE.owned['pal_' + it.id + '_' + sw.n] = true; } SAVE.pal = SAVE.pal || {}; SAVE.pal[it.id] = sw.n; saveGame(); sfx('ok'); return; } }
      if (it.kind === 'arch' && x >= it.x && x <= it.x + it.w && y >= it.y && y <= it.y + it.h) { if ((SAVE.arch || {})[it.i]) { this.archView = it.i; sfx('ok'); } else sfx('ui'); return; }
    }
  };
}
/* gallery: every cutscene the player has unlocked, loaded on demand */
galleryPages = function () {
  const out = [], u = SAVE.unlocked || 1;
  const ok = id => { let m; if (id === 'intro') return true; if ((m = /^s(\d+)pre$/.exec(id))) return u >= +m[1]; if ((m = /^s(\d+)post$/.exec(id))) return u > +m[1]; if (id === 'act2') return u > 6; if (id === 'act3') return u > 11; if (id === 'finale') return !!SAVE.cleared; return false; };
  for (const id in CUTS) if (ok(id)) for (const pg of CUTS[id]) { if (pg.duo) continue; for (const p of pg) if (COMIC.has(p.img) && !out.includes(p.img) && !(p.trueEnd && archCount() < ARCH_N)) out.push(p.img); }
  for (const p of PARTNERS) for (const m in DUO_AT) { const at = DUO_AT[m][p]; if (!at) continue; const sidN = at === 'finale' ? 17 : +/\d+/.exec(at)[0]; if (u > sidN || (at.endsWith('pre') && u >= sidN)) out.push('duo_' + p + '_' + m); }
  COMIC.need(out.slice(0, 200)); return out;
};

/* ---------------- ending ---------------- */
Scenes.end.draw = function (g) {
  const cam = 200 + this.t * 6; BG.menu(g, 2, this.t, cam);
  menuCast(g, (this.fin ? TITLE_CAST.concat([['echo', -186, 238, 1, 4], ['brann', 196, 246, -1, 5]]) : TITLE_CAST).map(([k, dx, y, f, o]) => ({ k: skinOn(Object.keys(ROSTER_KEY).find(h => ROSTER_KEY[h] === k)) ? k : k, an: 'win', x: VW / 2 + dx, y, f, o })), this.t, 1, cam);
  BG.atmos(g, this.t);
  const gr = g.createLinearGradient(0, 0, 0, 140); gr.addColorStop(0, 'rgba(6,3,12,0.85)'); gr.addColorStop(1, 'rgba(6,3,12,0)'); g.fillStyle = gr; g.fillRect(0, 0, VW, 140);
  PIX.text(g, T('theEnd'), VW / 2, 14, { s: 4, align: 'c', col: COLR.red });
  PIX.text(g, T(this.fin ? 'end1b' : 'end1'), VW / 2, 56, { align: 'c', col: COLR.white }); PIX.wrap(T(this.fin ? 'end2b' : 'end2'), VW - 40, 1).forEach((l, i) => PIX.text(g, l, VW / 2, 70 + i * 11, { align: 'c', col: '#c8c0d8' }));
  PIX.text(g, T('thanks'), VW / 2, 104, { align: 'c', col: COLR.gold });
  if (this.fin) { PIX.text(g, T('ngpOpen'), VW / 2, 118, { align: 'c', col: '#7dff9a' }); PIX.text(g, T('archive') + ' ' + archCount() + '/' + ARCH_N + (archCount() >= ARCH_N ? '  ★' : ''), VW / 2, 130, { align: 'c', col: '#ffd23a' }); }
  if (this.t > 3 && Math.sin(this.t * 4) > 0) PIX.text(g, T('tapNext'), VW / 2, VH - 12, { align: 'c', col: '#c8c0d8' });
};
{ const _ee = Scenes.end.enter; Scenes.end.enter = function (o) { _ee.call(this, o); BG.set(2); }; }

/* ---------------- save migration: 10-stage saves map onto the 16-stage campaign ---------------- */
if (!SAVE.v8) {
  const OLD2NEW = [0, 2, 3, 4, 5, 6, 7, 9, 10, 11, 15];
  const u = SAVE.unlocked || 1, done = Math.min(10, u - 1); SAVE.unlocked = done > 0 ? Math.min(16, OLD2NEW[done] + 1) : 1;
  const st = {}, best = {}; for (let i = 1; i <= 10; i++) { if ((SAVE.stars || {})[i]) st[OLD2NEW[i]] = SAVE.stars[i]; if ((SAVE.best || {})[i]) best[OLD2NEW[i]] = SAVE.best[i]; }
  SAVE.stars = st; SAVE.best = Object.assign({}, SAVE.best, best); for (let i = 1; i <= 10; i++) if (!best[i] && SAVE.best[i] && !Object.values(OLD2NEW).includes(i)) delete SAVE.best[i];
  if (SAVE.unlocked > 1) SAVE.seenIntro = true;
  SAVE.v8 = true; saveGame();
}
