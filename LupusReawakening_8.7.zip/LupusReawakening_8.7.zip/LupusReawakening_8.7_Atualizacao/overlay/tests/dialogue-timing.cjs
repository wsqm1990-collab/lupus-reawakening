'use strict';
const assert = require('node:assert/strict');
const { createRuntime } = require('./runtime.cjs');

async function main() {
  const r = createRuntime(); await r.settle(); r.run('setLang("pt")'); await r.play(11);
  r.run('G.title=0;G.banner=null;G.panel=null;G.talkQ=[];talk(null,"r12d");talkStep(1/60)');
  const recording = r.run('Dialogue9.lines.r12d.duration'), oldTextEstimate = r.run('Math.max(3.4,1.8+CT("r12d").length*.055)');
  assert.ok(recording > oldTextEstimate + 1, 'fixture must contain a recording longer than its text estimate');
  assert.ok(r.run('G.talkQ[0].dur') >= recording + 0.25);
  function alphaAt(time) {
    return r.run(`(() => { const original=PIX.panel;let alpha=-1;G.talkQ[0].t=${time};
      PIX.panel=function(g){alpha=g.globalAlpha;return original.apply(this,arguments)};
      try { drawTalk(bg); } finally { PIX.panel=original; }return alpha; })()`);
  }
  assert.ok(alphaAt(oldTextEstimate + 0.25) > 0.99, 'subtitle faded while the real recording was still speaking');
  assert.ok(alphaAt(recording) > 0.99, 'subtitle was invisible at the recording end');
  r.run('Scenes.play.onKey("pause")'); const paused = r.run('G.talkQ[0].t');
  r.tick(20); assert.equal(r.run('G.talkQ[0].t'), paused, 'paused radio timing advanced');
  assert.equal(r.run('Dialogue9.state.paused'), true);
  r.run('Scenes.play.onKey("pause")');
  assert.equal(r.run('Dialogue9.state.paused'), false);
  r.run('Dialogue9.stop();G.talkQ[0].t=G.talkQ[0].dur+0.05;talkStep(1/60)');
  assert.equal(r.run('G.talkQ.length'), 0, 'finished radio line did not leave its queue');
  assert.deepEqual(r.json('window.__err||[]'), []);
  console.log('TAP version 13\nok 1 - long recorded radio dialogue keeps its subtitle visible through speech and pauses cleanly\n1..1\n# 1 passed, 0 failed');
}
main().catch(e => { console.error(e.stack); process.exitCode = 1; });
