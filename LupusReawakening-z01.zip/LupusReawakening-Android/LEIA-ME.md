# LUPUS: REAWAKENING — projeto Android

Versão 9.4. O jogo fica em `app/src/main/assets/game/` (HTML5 + Canvas) e roda dentro de um WebView.

## Novidades da 9.4 (luta mais limpa e mais forte)
- Troca e Forma pelos retratos lá em cima: toque na foto do parceiro (alto, à esquerda) para trocar
  e no rosto da forma (alto, no centro) para se transformar. Quem preferir os botões TROCA e FORMA
  pode trazê-los de volta em Controles > "Troca e Forma".
- Um toque no meio de um golpe ou na pausa do impacto não se perde: a troca ou a transformação
  acontece assim que o herói fica livre (até meio segundo depois).
- Tela mais limpa: botões e analógico ficam transparentes quando um lutador passa por trás; sem
  "fantasma" (os quadros não se misturam mais e o herói não pisca na invencibilidade); números de
  dano menores e somados por alvo; contador de combo compacto; Sentidos mostram o contorno vermelho.
- Lutadores mais visíveis: mais luz nos personagens, sem perder a cor de cada fase.
- Mais peso no golpe: o inimigo achata no impacto, treme na pausa e gira no ar quando é lançado.
- Pulo cancela o golpe que acertou: dá para perseguir o inimigo lançado e continuar o combo no ar.
- Golpes novos desenhados: o Lupus humano (jab, direto e gancho) e o lobisomem (garra, garra para
  cima e golpe duplo) ganharam 18 quadros novos cada, com preparação, golpe e volta
  (`assets/chars/lupus_h94.webp` e `lupus_f94.webp`).
- Efeitos em imagem no lugar dos desenhados por código: faíscas de impacto, defesa, nocaute, garras,
  corte em meia-lua, onda de choque, aparar, poeira, derrapagem, sangue e o aviso "!" em cima do
  inimigo que vai atacar (`assets/fx/fx94.webp`, lista em `js/fx94-atlas.js`).
- A faísca e o sangue saem na altura do golpe (peito), e o brilho do acerto é uma piscada rápida.
- Fala do rádio da fase 1 regravada: "toque no lobo lá em cima" (inglês e português).

## Vozes
- Falas da história: `assets/voice/dialogue/` (português) e `assets/voice/dialogue/en/` (inglês).
- Gritos de combate gravados com a voz de cada personagem: `assets/voice/pt/` e `assets/voice/en/`
  (lista em `js/voice-manifest93.js`). Jogo em português usa `pt/`; os outros idiomas usam `en/`.
- Vozes de monstros e soldados ficam em `assets/voice/`.

## Como o APK é gerado
O GitHub gera o APK sozinho. No repositório ficam as partes `LupusReawakening-zNN.zip`; o
GitHub Actions junta todas, compila e publica em **Releases** como "Lupus Reawakening - APK N".

## Instalação
- ID do app: `com.thorneindustries.lupus.preview` (o mesmo da 9.0), assinado com `app/lupus.keystore`.
  Por isso a 9.4 instala por cima da 9.0, 9.1, 9.2 e 9.3 e mantém o progresso.
- Nome no celular: "Lupus: Reawakening".
- Antes de publicar na Play Store, crie uma chave nova e particular: esta chave está visível no repositório.
