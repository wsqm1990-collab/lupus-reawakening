'use strict';
/* Authored 9.0 dialogue. English is primary; other UI languages fall back to it. */
(function () {
  const lines = {
  "i01a": {
    "speaker": "narrator",
    "en": "1944. A secret war erased from the history books.",
    "pt": "1944. Uma guerra secreta apagada dos livros de história."
  },
  "n05a": {
    "speaker": "nacht",
    "en": "The experiment is not over. Neither am I.",
    "pt": "O experimento não acabou. Nem eu."
  },
  "n05b": {
    "speaker": "nacht",
    "en": "Now... try to stop me.",
    "pt": "Agora... tente me parar."
  },
  "w90_alley_entry": {
    "speaker": "lupus_h",
    "en": "These deaths were not random. Start with the blood.",
    "pt": "Essas mortes não foram por acaso. Vou começar pelo sangue."
  },
  "w90_alley_blood": {
    "speaker": "lupus_h",
    "en": "Blood mixed with alchemical mercury. Still fresh.",
    "pt": "Sangue misturado com mercúrio alquímico. Ainda fresco."
  },
  "w90_alley_witness": {
    "speaker": "informant",
    "en": "I never saw their faces. Only the Cabala seal... and the road to the cathedral.",
    "pt": "Não vi o rosto deles. Só o selo da Cabala... e o caminho para a catedral."
  },
  "w90_alley_case": {
    "speaker": "lupus_h",
    "en": "A route to the Red Cathedral. The courier is our next lead.",
    "pt": "Uma rota até a Catedral Vermelha. O mensageiro é a nossa próxima pista."
  },
  "w90_alley_done": {
    "speaker": "lupus_h",
    "en": "We have a trail. Back to the street.",
    "pt": "Temos um rastro. De volta à rua."
  },
  "w90_cistern_entry": {
    "speaker": "lupus_h",
    "en": "This pumping station still feeds the flooded tunnels.",
    "pt": "Esta estação de bombeamento ainda abastece os túneis alagados."
  },
  "w90_cistern_hint": {
    "speaker": "lupus_h",
    "en": "Three valves. The maintenance plate shows the order.",
    "pt": "Três válvulas. A placa de manutenção mostra a ordem."
  },
  "w90_cistern_done": {
    "speaker": "lupus_h",
    "en": "Pressure stable. Nacht brought his serum shipments through here.",
    "pt": "Pressão estável. Nacht trouxe suas remessas de soro por aqui."
  },
  "w90_relay_entry": {
    "speaker": "lupus_h",
    "en": "The Cabala is still transmitting from this tower.",
    "pt": "A Cabala ainda está transmitindo desta torre."
  },
  "w90_relay_hint": {
    "speaker": "lupus_h",
    "en": "The recorded pulse is the key. Match it to the signal.",
    "pt": "O pulso gravado é a chave. Preciso alinhar o sinal."
  },
  "w90_relay_done": {
    "speaker": "lupus_h",
    "en": "Transmission decoded. I will mark their next rendezvous.",
    "pt": "Transmissão decifrada. Vou marcar o próximo ponto de encontro."
  },
  "w90_hub_entry": {
    "speaker": "lupus_h",
    "en": "A moment to breathe. Then we follow the next lead.",
    "pt": "Um momento para respirar. Depois seguimos a próxima pista."
  }
};
  for (const key in lines) {
    I18N.en.comic[key] = lines[key].en;
    I18N.pt.comic[key] = lines[key].pt;
  }
  window.LUPUS_STORY90_LINES = lines;
})();
