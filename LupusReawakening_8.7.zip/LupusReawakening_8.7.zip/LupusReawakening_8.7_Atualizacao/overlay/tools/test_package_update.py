#!/usr/bin/env python3
"""Exercise source-update application in disposable repositories, without Git or network."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

from package_update import PROJECT, package_update


class UpdatePackages(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo = self.root / 'source'
        self.project = self.repo / PROJECT
        (self.project / 'app').mkdir(parents=True)
        self.archive = self.repo / 'LupusReawakening-z01.zip'
        legacy = {
            'settings.gradle': "rootProject.name='Lupus'\n",
            'app/build.gradle': 'versionName "8.1"\n',
            'app/src/main/assets/game/core.js': 'original\n',
            'gradlew': '#!/bin/sh\nexit 0\n',
        }
        with zipfile.ZipFile(self.archive, 'w') as bundle:
            for rel, content in legacy.items():
                bundle.writestr('LupusReawakening-Android/' + rel, content)
                self.write(rel, content)
        self.write('app/build.gradle', 'versionName "8.2"\n')
        self.write('app/src/main/assets/game/core.js', 'version 8.2\n')
        self.write('app/src/main/assets/game/voice/pt.ogg', 'Portuguese recording')
        self.write('app/lupus.keystore', 'private local key')
        (self.project / 'signing.properties').write_text('private credentials')
        self.previous = self.root / 'update-8.2.zip'
        package_update(self.repo, self.previous)
        self.write('app/build.gradle', 'versionName "8.3"\n')
        self.write('app/src/main/assets/game/core.js', 'version 8.3\n')
        self.write('app/src/main/assets/game/voice/en.ogg', 'English recording')

    def write(self, rel, content):
        path = self.project / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)

    def destination(self, name):
        dest = self.root / name
        dest.mkdir()
        shutil.copy2(self.archive, dest / self.archive.name)
        return dest

    def apply(self, archive, dest, name):
        overlay = self.root / name
        with zipfile.ZipFile(archive) as bundle:
            bundle.extractall(overlay)
        return subprocess.run([sys.executable, str(overlay / 'APLICAR_ATUALIZACAO.py'), '--repo', str(dest)],
                              capture_output=True, text=True)

    def test_cumulative_updates_original_without_prior_package(self):
        archive = self.root / 'cumulative.zip'
        result = package_update(self.repo, archive)
        self.assertEqual((result['version'], result['package_type']), ('8.3', 'cumulative'))
        dest = self.destination('original')
        applied = self.apply(archive, dest, 'cumulative-extracted')
        self.assertEqual(applied.returncode, 0, applied.stderr)
        game = dest / PROJECT / 'app/src/main/assets/game'
        self.assertEqual((game / 'core.js').read_text(), 'version 8.3\n')
        self.assertTrue((game / 'voice/pt.ogg').is_file())
        self.assertTrue((game / 'voice/en.ogg').is_file())
        self.assertTrue((dest / PROJECT / 'gradlew').stat().st_mode & 0o111)
        with zipfile.ZipFile(archive) as bundle:
            self.assertFalse(any(n.endswith(('.keystore', 'signing.properties')) for n in bundle.namelist()))

    def test_delta_requires_prior_update_and_preserves_local_changes(self):
        archive = self.root / 'delta.zip'
        result = package_update(self.repo, archive, previous=self.previous)
        self.assertEqual(result['package_type'], 'delta')
        self.assertEqual(result['base_version'], '8.2')
        dest = self.destination('with-base')
        initial = self.apply(self.previous, dest, 'previous-extracted')
        self.assertEqual(initial.returncode, 0, initial.stderr)
        core = dest / PROJECT / 'app/src/main/assets/game/core.js'
        core.write_text('my local edit\n')
        applied = self.apply(archive, dest, 'delta-extracted')
        self.assertEqual(applied.returncode, 0, applied.stderr)
        self.assertEqual(core.read_text(), 'version 8.3\n')
        backups = list(dest.glob('backup-lupus-8.3-*/' + PROJECT + '/app/src/main/assets/game/core.js'))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_text(), 'my local edit\n')
        with zipfile.ZipFile(archive) as bundle:
            self.assertNotIn('overlay/' + PROJECT + '/app/src/main/assets/game/voice/pt.ogg', bundle.namelist())

    def test_incomplete_base_is_rejected_before_writing(self):
        archive = self.root / 'delta.zip'
        package_update(self.repo, archive, previous=self.previous)
        dest = self.destination('missing-base')
        applied = self.apply(archive, dest, 'rejected-extracted')
        self.assertNotEqual(applied.returncode, 0)
        self.assertIn('8.2', applied.stderr)
        self.assertFalse((dest / 'src').exists())

    def test_corrupted_overlay_is_rejected_before_writing(self):
        archive = self.root / 'cumulative.zip'
        package_update(self.repo, archive)
        extracted = self.root / 'corrupted'
        with zipfile.ZipFile(archive) as bundle:
            bundle.extractall(extracted)
        manifest = json.loads((extracted / 'manifest.json').read_text())
        (extracted / 'overlay' / manifest['files'][0]['path']).write_text('tampered')
        dest = self.destination('tampered-destination')
        applied = subprocess.run([sys.executable, str(extracted / 'APLICAR_ATUALIZACAO.py'), '--repo', str(dest)],
                                 capture_output=True, text=True)
        self.assertNotEqual(applied.returncode, 0)
        self.assertFalse((dest / 'src').exists())


if __name__ == '__main__':
    unittest.main()
