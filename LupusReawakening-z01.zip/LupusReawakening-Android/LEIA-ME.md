# LUPUS: REAWAKENING — projeto Android

Versão 9.3. O jogo fica em `app/src/main/assets/game/` (HTML5 + Canvas) e roda dentro de um WebView.

## Vozes
- Falas da história: `assets/voice/dialogue/` (português) e `assets/voice/dialogue/en/` (inglês).
- Gritos de combate gravados com a voz de cada personagem: `assets/voice/pt/` e `assets/voice/en/`
  (lista em `js/voice-manifest93.js`). Jogo em português usa `pt/`; os outros idiomas usam `en/`.
- Vozes de monstros e soldados ficam em `assets/voice/`.

## Como o APK é gerado
O GitHub gera o APK sozinho. No repositório ficam as partes `LupusReawakening-zNN.zip`; o
GitHub Actions junta todas, compila e publica em **Releases** como "Lupus Reawakening - APK N".

## Instalação
- ID do app: `com.thorneindustries.lupus.preview` (o mesmo da 9.0), assinado com `app/lupus.keystore`.
  Por isso a 9.3 instala por cima da 9.0, da 9.1 e da 9.2 e mantém o progresso.
- Nome no celular: "Lupus: Reawakening".
- Antes de publicar na Play Store, crie uma chave nova e particular: esta chave está visível no repositório.
