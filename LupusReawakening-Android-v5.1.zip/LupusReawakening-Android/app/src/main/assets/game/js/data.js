'use strict';
/* ===== DATA: text, heroes, enemies, bosses, stages ===== */
const STR = {
  pt: {
    tapStart: 'TOQUE PARA COMEÇAR', skip: 'PULAR >', tapNext: 'TOQUE PARA CONTINUAR', selectHero: 'ESCOLHA SEU CAÇADOR', selectAlly: 'ESCOLHA SEU ALIADO (IA)',
    tapAgain: 'TOQUE DE NOVO PARA CONFIRMAR', back: '< VOLTAR', stages: 'MAPA DA CAÇADA', locked: 'BLOQUEADA', best: 'RECORDE', stage: 'FASE', go: 'VAI', paused: 'PAUSA', resume: 'CONTINUAR', restart: 'REINICIAR FASE',
    quit: 'MAPA', music: 'MÚSICA', sfx: 'EFEITOS', lang: 'IDIOMA: PORTUGUÊS', on: 'SIM', off: 'NÃO', gameOver: 'VOCÊ CAIU', retry: 'TENTAR DE NOVO', menu: 'MAPA',
    clear: 'FASE COMPLETA', score: 'PONTOS', time: 'TEMPO', maxCombo: 'COMBO', pickUp: 'ESCOLHA UMA MELHORIA', up_dmg: 'GARRAS AFIADAS', up_dmg_d: '+15% DE DANO',
    up_hp: 'VITALIDADE', up_hp_d: '+20% DE VIDA', up_fury: 'SEDE DE SANGUE', up_fury_d: '+25% DE FÚRIA', up_cd: 'INSTINTO', up_cd_d: '-20% RECARGA',
    human: 'HUMANO', feral: 'FERAL', ascended: 'ASCENDIDO', form: 'FORMA', fury: 'FÚRIA', hits: 'GOLPES', combo: ['', 'BOM', 'BRUTAL', 'SELVAGEM!', 'IMPARÁVEL!'], counter: 'CONTRA-ATAQUE!',
    bossWarn: 'ALERTA DE CHEFE', theEnd: 'FIM', end1: 'A BESTA PRIMORDIAL CAIU.', end2: 'A CABALA SANGRA... MAS ALGUMAS FERAS NUNCA MORREM.', thanks: 'OBRIGADO POR JOGAR', newGame: 'APAGAR PROGRESSO', rotate: 'GIRE O APARELHO',
    down: 'CAÍDO', hint1: 'SEGURE ATK PARA COMBO', hint2: 'FÚRIA CHEIA? TOQUE FORMA!', objective: 'OBJETIVO', options: 'OPÇÕES', start: 'COMEÇAR', loading: 'INVOCANDO A FERA...',
    sp_h: 'CORRENTE', sp_f: 'URRO', sp_a: 'DILACERAR', sp_vespera: 'ESPIRAL', sp_triton: 'MARÉ', sp_malakor: 'BARREIRA', p2: 'ENFURECIDO', block: 'BLOQUEIO', heal: 'CURA',
    stats: ['FORÇA', 'VELOCIDADE', 'ALCANCE', 'DEFESA', 'SUPORTE'], ai: 'IA'
  },
  en: {
    tapStart: 'TAP TO START', skip: 'SKIP >', tapNext: 'TAP TO CONTINUE', selectHero: 'SELECT YOUR HUNTER', selectAlly: 'CHOOSE YOUR ALLY (AI)',
    tapAgain: 'TAP AGAIN TO CONFIRM', back: '< BACK', stages: 'HUNT MAP', locked: 'LOCKED', best: 'BEST', stage: 'STAGE', go: 'GO', paused: 'PAUSED', resume: 'RESUME', restart: 'RESTART STAGE',
    quit: 'MAP', music: 'MUSIC', sfx: 'SFX', lang: 'LANGUAGE: ENGLISH', on: 'ON', off: 'OFF', gameOver: 'YOU FELL', retry: 'TRY AGAIN', menu: 'MAP',
    clear: 'STAGE CLEAR', score: 'SCORE', time: 'TIME', maxCombo: 'COMBO', pickUp: 'PICK AN UPGRADE', up_dmg: 'SHARP CLAWS', up_dmg_d: '+15% DAMAGE',
    up_hp: 'VITALITY', up_hp_d: '+20% HEALTH', up_fury: 'BLOODLUST', up_fury_d: '+25% FURY', up_cd: 'INSTINCT', up_cd_d: '-20% COOLDOWN',
    human: 'HUMAN', feral: 'FERAL', ascended: 'ASCENDED', form: 'FORM', fury: 'FURY', hits: 'HITS', combo: ['', 'NICE', 'BRUTAL', 'SAVAGE!', 'UNSTOPPABLE!'], counter: 'COUNTER!',
    bossWarn: 'BOSS WARNING', theEnd: 'THE END', end1: 'THE PRIMORDIAL BEAST HAS FALLEN.', end2: 'THE CABALA BLEEDS... BUT SOME BEASTS NEVER DIE.', thanks: 'THANKS FOR PLAYING', newGame: 'ERASE PROGRESS', rotate: 'ROTATE YOUR DEVICE',
    down: 'DOWN', hint1: 'HOLD ATK FOR COMBOS', hint2: 'FURY FULL? TAP FORM!', objective: 'OBJECTIVE', options: 'OPTIONS', start: 'START', loading: 'SUMMONING THE BEAST...',
    sp_h: 'CHAIN', sp_f: 'HOWL', sp_a: 'REND', sp_vespera: 'SPIRAL', sp_triton: 'TIDE', sp_malakor: 'BARRIER', p2: 'ENRAGED', block: 'BLOCK', heal: 'HEAL',
    stats: ['POWER', 'SPEED', 'RANGE', 'DEFENSE', 'SUPPORT'], ai: 'AI'
  }
};
const T = k => { const v = STR[SAVE.lang][k]; return v != null ? v : k; };

/* intro story slides */
const STORY = [
  { stage: 5, pt: ['1944.', 'A DIVISÃO THULE CAÇAVA O QUE NÃO ENTENDIA.', 'ELES ME ENCONTRARAM.'], en: ['1944.', 'THE THULE DIVISION HUNTED WHAT THEY', 'COULD NOT UNDERSTAND. THEY FOUND ME.'], cast: 'lab' },
  { stage: 5, pt: ['DNA HUMANO. DNA DE LOBO ANCESTRAL.', 'AÇO NA MINHA CARNE.', 'ELES FIZERAM UMA ARMA.'], en: ['HUMAN DNA. ANCIENT WOLF DNA.', 'STEEL IN MY FLESH.', 'THEY MADE ME A WEAPON.'], cast: 'rage' },
  { stage: 1, pt: ['2242. A CIDADE NUNCA DORME.', 'NEM EU.', 'MESMOS OLHOS. PRESA DIFERENTE.'], en: ['2242. THE CITY NEVER SLEEPS.', 'NEITHER DO I.', 'SAME EYES. DIFFERENT PREY.'], cast: 'city' },
  { stage: 1, pt: ['OUTRO CORPO. OUTRA MENSAGEM.', 'A CABALA AINDA ESTÁ AQUI.', 'E SOLTOU ALGO PRIMORDIAL.'], en: ['ANOTHER BODY. ANOTHER MESSAGE.', 'THE CABALA IS STILL HERE.', 'AND IT UNLEASHED SOMETHING PRIMAL.'], cast: 'sigil' },
  { stage: 3, pt: ['ALGUNS MONSTROS LUTAM NAS SOMBRAS.', 'NÓS REVIDAMOS.', 'A CAÇADA COMEÇA.'], en: ['SOME MONSTERS FIGHT IN THE SHADOWS.', 'WE FIGHT BACK.', 'THE HUNT BEGINS.'], cast: 'team' }
];

/* ---------- heroes ---------- */
const HERO = {
  lupus: { name: 'LUPUS', color: '#ff2a40', hp: 1400, spd: 100, jump: 300, role: 'DETETIVE / BERSERKER', stats: [4, 3, 2, 3, 2], quote: 'ALGUNS MONSTROS USAM DISTINTIVO.' },
  vespera: { name: 'VESPERA', color: '#ff3ad0', hp: 1200, spd: 118, jump: 330, role: 'PUNK DE SANGUE / AÉREA', stats: [3, 5, 3, 2, 2], quote: 'LIBERDADE SEMPRE MORDE.', key: 'vespera', reach: 42, dmg: 36, dur: 0.22, cd: 6.5 },
  triton: { name: 'TRITON', color: '#3af0ff', hp: 1900, spd: 78, jump: 260, role: 'TANQUE / GUARDIÃO', stats: [4, 2, 4, 5, 3], quote: 'MAIS FORTES. JUNTOS.', key: 'triton', reach: 59, dmg: 58, dur: 0.34, cd: 7.5, armor: 0.22 },
  malakor: { name: 'MALAKOR', color: '#a7ff1a', hp: 1000, spd: 86, jump: 270, role: 'NECRO-TECH / SUPORTE', stats: [2, 3, 5, 2, 5], quote: 'CIÊNCIA. MORTE. ORDEM.', key: 'malakor', reach: 0, dmg: 30, dur: 0.42, cd: 9 }
};
const FORM = {
  h: { key: 'lupus_h', dmg: 44, reach: 38, dur: 0.24, armor: 0, regen: 0, spd: 100, cd: 5, label: 'human' },
  f: { key: 'lupus_f', dmg: 70, reach: 42, dur: 0.3, armor: 0.25, regen: 9, spd: 106, cd: 8, label: 'feral' },
  a: { key: 'lupus_a', dmg: 60, reach: 50, dur: 0.18, armor: 0.5, regen: 14, spd: 124, cd: 4, label: 'ascended' }
};

/* ---------- enemies (sprite key, size, ai) ---------- */
const ENEMY = {
  Z: { name: 'CABALA ZEALOT', key: 'zealot', hp: 120, spd: 44, ai: 'ranged', dmg: 24, pts: 100, hr: 13 },
  ZS: { name: 'ZEALOT BULWARK', key: 'bulwark', hp: 210, spd: 36, ai: 'melee', shield: true, dmg: 24, pts: 160, reach: 35, hr: 14 },
  S: { name: 'CYBER-GHOUL', key: 'slasher', hp: 140, spd: 80, ai: 'melee', dmg: 21, pts: 120, reach: 38, wind: 0.28, hr: 13 },
  H: { name: 'PLAGUE HOUND', key: 'hound', hp: 84, spd: 90, ai: 'lunge', dmg: 17, pts: 80, hr: 14, quad: true },
  K: { name: 'GENE-KNIGHT', key: 'knight', hp: 480, spd: 40, ai: 'melee', shield: true, heavy: true, dmg: 44, pts: 320, reach: 50, wind: 0.5, hr: 17 },
  V: { name: 'VAMPIRE HUNTER', key: 'hunter', hp: 220, spd: 56, ai: 'beam', dmg: 34, pts: 220, hr: 13 },
  A: { name: 'ABOMINATION', key: 'abom', hp: 560, spd: 35, ai: 'brute', heavy: true, dmg: 52, pts: 400, reach: 52, wind: 0.55, hr: 21 },
  M: { name: 'FAILED EXPERIMENT', key: 'mutant', hp: 170, spd: 52, ai: 'melee', dmg: 24, pts: 130, reach: 35, hr: 14 }
};
const BOSS = {
  warden: { name: 'GENE-KNIGHT WARDEN', sub: 'A PUREZA DE FERRO', key: 'warden', hp: 2100, spd: 42, pats: ['slash', 'charge', 'slash', 'guard', 'charge'], pts: 2000, hr: 24, reach: 66 },
  voss: { name: 'INQUISIDORA SERAPH VOSS', sub: 'A LÂMINA FIEL', key: 'voss', hp: 3500, spd: 62, pats: ['slash', 'wave', 'guard', 'slash', 'wave'], pts: 3500, hr: 21, reach: 73 },
  prime: { name: 'ABOMINAÇÃO PRIMA', sub: 'EXPERIMENTAR. MUTAR. REPETIR.', key: 'prime', hp: 3200, spd: 36, pats: ['slash', 'slam', 'charge', 'slam', 'slash'], pts: 3500, hr: 31, reach: 76 },
  nacht: { name: 'DOKTOR NACHT', sub: 'O ARQUITETO LOUCO', key: 'nacht', big: 'nacht_big', hp: 3900, spd: 52, pats: ['shoot', 'summon', 'shoot', 'blink', 'shoot'], pts: 4500, hr: 17, reach: 47 },
  beast: { name: 'A BESTA PRIMORDIAL', sub: 'A PRIMEIRA FOME', key: 'beast', hp: 7600, spd: 50, pats: ['slash', 'charge', 'slam', 'roar', 'charge', 'slash'], pts: 8000, hr: 57, reach: 106, wide: true }
};

/* ---------- stages ---------- */
const WORLD_W = 1620;
const STAGES = [
  { id: 1, music: 0, name: { pt: 'FAVELAS DE NEON', en: 'NEON SLUMS' }, sub: { pt: 'A CIDADE SANGRA, MAS AINDA RESPIRA.', en: 'THE CITY BLEEDS. BUT IT STILL BREATHES.' }, obj: { pt: 'PURGAR AS PATRULHAS', en: 'PURGE THE PATROLS' },
    waves: [{ x: 300, e: ['S', 'S', 'Z'] }, { x: 660, e: ['Z', 'Z', 'S', 'H', 'H'] }, { x: 1020, e: ['ZS', 'S', 'S', 'Z'] }], boss: 'warden', props: [180, 520, 860, 1220], say: { w: 'lupus', pt: 'A NOITE SE LEMBRA.', en: 'THE NIGHT REMEMBERS.' } },
  { id: 2, music: 1, name: { pt: 'TELHADOS DA CATEDRAL', en: 'CATHEDRAL ROOFTOPS' }, sub: { pt: 'A FÉ OBSERVA. NÓS TAMBÉM.', en: 'FAITH WATCHES. SO DO WE.' }, obj: { pt: 'ALCANÇAR A CATEDRAL', en: 'REACH THE CATHEDRAL' },
    waves: [{ x: 300, e: ['Z', 'Z', 'V'] }, { x: 660, e: ['S', 'S', 'S', 'ZS', 'Z'] }, { x: 1020, e: ['K', 'Z', 'V', 'S'] }], boss: 'voss', props: [240, 600, 980], say: { w: 'vespera', pt: 'ELES NOS ESPERAM LÁ EM CIMA.', en: 'THEY ARE WAITING UP THERE.' } },
  { id: 3, music: 2, name: { pt: 'ESCONDERIJO SUBTERRÂNEO', en: 'UNDERCITY HIDEOUT' }, sub: { pt: 'EXILADOS. REJEITADOS. AINDA HUMANOS.', en: 'EXILES. OUTCASTS. STILL HUMAN.' }, obj: { pt: 'DEFENDER O REFÚGIO', en: 'DEFEND THE REFUGE' },
    waves: [{ x: 300, e: ['H', 'H', 'H', 'S'] }, { x: 660, e: ['V', 'V', 'Z', 'Z'] }, { x: 1020, e: ['A', 'S', 'S', 'H'] }], boss: 'prime', props: [160, 420, 760, 1100, 1300], say: { w: 'malakor', pt: 'NEM TODA MORTE É UM FIM.', en: 'NOT ALL DEATHS ARE ENDS.' } },
  { id: 4, music: 3, name: { pt: 'METRÔ ALAGADO', en: 'FLOODED METRO' }, sub: { pt: 'O VELHO MUNDO AINDA SUSSURRA.', en: 'THE OLD WORLD STILL WHISPERS.' }, obj: { pt: 'CAÇAR O DOKTOR NACHT', en: 'HUNT DOKTOR NACHT' },
    waves: [{ x: 300, e: ['H', 'H', 'H', 'H', 'S'] }, { x: 660, e: ['A', 'K'] }, { x: 1020, e: ['V', 'Z', 'Z', 'S', 'S', 'ZS'] }], boss: 'nacht', props: [400, 900], say: { w: 'triton', pt: 'MAIS FUNDO. MAIS FORTE. JUNTOS.', en: 'DEEPER. STRONGER. TOGETHER.' } },
  { id: 5, music: 4, name: { pt: 'BIO-LAB DA CABALA', en: 'CABALA BIO-LAB' }, sub: { pt: 'CIÊNCIA. FÉ. MESMO RESULTADO.', en: 'SCIENCE. FAITH. SAME RESULT.' }, obj: { pt: 'DESTRUIR O NÚCLEO', en: 'DESTROY THE CORE' },
    waves: [{ x: 300, e: ['K', 'K', 'V', 'Z'] }, { x: 660, e: ['A', 'A', 'S', 'S', 'H', 'H'] }, { x: 1020, e: ['K', 'V', 'V', 'ZS', 'ZS', 'A'] }], boss: 'beast', props: [260, 620, 1000], say: { w: 'lupus', pt: 'MESMA CIDADE. MONSTROS MAIORES.', en: 'SAME CITY. BIGGER MONSTERS.' } }
];
