'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { createRuntime } = require('./runtime.cjs');

/* Campaign integration coverage, not a balance/playability evaluation. The bot
 * has infinite health, repositions between fights and deals scripted damage
 * through hurt(). Real updates, spawn queues, waves, gates, objectives, boss
 * phases, surrender callbacks and completion scenes remain responsible for
 * advancing the campaign. It never writes locked/clearT or calls finish().
 */
async function main() {
  const r = createRuntime({ seed: 4096 });
  const results = [];
  await r.settle();
  r.run(`SAVE.music=false; SAVE.sfx=false; SAVE.hero='lupus'; SAVE.ally='vespera'; SAVE.diff='normal';
    window.campaignBot = function () {
      const C = G.campaignTest || (G.campaignTest = { gates: 0, objectives: 0, phases: {}, maxWave: 0 });
      C.maxWave = Math.max(C.maxWave, G.waveIdx);
      for (const h of G.team) { if (!h.dead) { h.hp = h.maxhp; h.inv = 100; } }
      if (G.guest && !G.guest.dead) { G.guest.hp = G.guest.maxhp; G.guest.inv = 100; }
      if (G.over > 0) throw new Error('Campaign bot failed: ' + (G.failMsg || 'hero death'));
      if (G.panel || G.choice || G.cine || G.superFx || G.hitstop > 0 || G.title > 0 || G.clearT) return;

      // Accelerate only the long defense timers. Their real update hooks still
      // ring every bell / finish each brewing stage and trigger their callbacks.
      if (G.ritual && !G.ritual.done) G.ritual.t = G.ritual.next - 1 / 120;
      if (G.mech === 'brew' && G.brew < 3) G.brewT = G.brewDur - 1 / 120;
      if (G.mech === 'climb' && !G.spawnQ.length && !enemiesAlive()) G.nextWave = Math.min(G.nextWave, 1 / 120);

      // Leave normal simulation frames between attacks; injecting another hit
      // on the exact frame hitstop ends would starve the boss phase update.
      const attack = G.time >= (C.attackAt || 0);
      if (attack) C.attackAt = G.time + 0.2;
      for (const e of attack ? G.enemies.slice() : []) {
        if (e.dead) continue;
        if (e.kind !== 'boss') { hurt(G.player, e, e.maxhp * 3, { ignoreInv: true, brk: true, ground: true }); continue; }
        if (e.phase) C.phases[e.phase] = true;
        if (e.fleeing || e.yielding || e.bossIn > 0) continue;
        // Moderate chunks exercise phase thresholds; giant vulnerability and
        // transformation invulnerability are honored by the damage engine.
        hurt(G.player, e, e.maxhp * 0.14, { brk: true, ground: true });
      }
      if (G.locked || G.bossSpawned || G.bossPending || G.arena || G.clearT) return;
      const p = G.player, M = MECH[G.mech], w = G.st.waves[G.waveIdx];
      const position = (x, y) => { p.x = x; if (y != null) p.y = y; p.vx = p.vy = 0; G.camX = clamp(x - VW * 0.36, 0, WORLD_W - VW); };
      const gate = M && M.gate && M.gate();
      if (!w && gate) {
        if (!C.gateProbe) {
          C.gateProbe = true; position(WORLD_W - VW * 0.62 + 8); return;
        }
        if (!C.gates) {
          if (G.bossPending || G.bossSpawned || !G.gateT) throw new Error('Exit gate did not reject an incomplete objective');
          C.gates++;
        }
        if (G.clues) {
          const clue = G.clues.find(c => !c.got); if (clue) position(clue.x, clue.y);
        } else {
          const target = (G.objs || []).find(o => o.team === 'e' && !o.dead);
          if (target) { position(target.x - 20, target.y); hurt(p, target, target.maxhp * 3, { brk: true }); C.objectives++; }
        }
        return;
      }
      position(w ? w.x + 1 : WORLD_W - VW * 0.62 + 8);
    };
    window.campaignState = () => ({ scene:Scene.name, stage:G&&G.st.id, wave:G&&G.waveIdx,
      locked:G&&G.locked, pending:G&&G.bossPending, spawned:G&&G.bossSpawned,
      enemies:G&&G.enemies.filter(e=>!e.dead).map(e=>({type:e.type,hp:e.hp,bossIn:e.bossIn,phase:e.phase,gst:e.gst,inv:e.inv,yielding:e.yielding,fleeing:e.fleeing})),
      queue:G&&G.spawnQ.length, duel:G&&G.duelHold, clear:G&&G.clearT,
      panel:G&&G.panel&&G.panel.img, choice:!!(G&&G.choice), cine:!!(G&&G.cine),
      metrics:G&&G.campaignTest });`);

  async function advanceNarrative() {
    const scene = r.run('Scene.name');
    if (scene === 'comic') {
      await r.settle();
      // A manual continue is allowed to skip a playing dialogue recording.
      r.run("if(Scenes.comic.pages && (Scenes.comic.mode !== 'panel' || Scenes.comic.bt >= 0.3)) Scenes.comic.onKey('ok')");
    } else if (scene === 'play') {
      r.run(`if (G.panel && G.panel.t >= 0.4) panelAdvance();
        if (G.choice && G.choice.t >= 0.6) { const rect=choiceRects()[0]; choiceTap(rect.x+rect.w/2,rect.y+rect.h/2); }`);
    }
  }

  console.log('TAP version 13');
  for (let stage = 0; stage < 16; stage++) {
    const name = `campaign stage ${String(stage + 1).padStart(2, '0')} completes through waves and boss progression`;
    try {
      const partners = r.json(`partnersFor(${stage + 1})`);
      if (partners.length) r.run(`SAVE.ally=${JSON.stringify(partners.includes('vespera') ? 'vespera' : partners[0])}`);
      await r.play(stage);
      let steps = 0;
      for (; steps < 12000 && r.run('Scene.name') !== 'clear'; steps++) {
        await advanceNarrative();
        if (r.run('Scene.name') === 'play') r.run('campaignBot()');
        r.tick();
        if (steps % 120 === 0) { await r.settle(); assert.deepEqual(r.json('window.__err || []'), []); }
        assert.notEqual(r.run('Scene.name'), 'over', 'campaign entered game over');
      }
      const state = r.json('campaignState()');
      assert.equal(state.scene, 'clear', `completion timed out: ${JSON.stringify(state)}`);
      assert.equal(r.run('Scenes.clear.res.stage'), stage, 'wrong stage completion result');
      assert.ok(r.run('SAVE.unlocked') >= stage + 2, 'completion did not unlock the next stage');
      assert.ok(r.run('G.boss && G.boss.dead'), 'clear scene reached without defeating/escaping the boss');
      assert.ok(state.metrics.maxWave >= r.run('G.st.waves.length'), 'some campaign waves were skipped');
      if ([1, 5, 13, 14].includes(stage)) assert.equal(state.metrics.gates, 1, 'mandatory objective gate was not exercised');
      if ([5, 13, 14].includes(stage)) assert.equal(state.metrics.objectives, 3, 'all three destructible objectives must use hurt()');
      if (stage === 7) assert.equal(r.run('G.bell'), 3, 'ritual did not complete three bells');
      if (stage === 12) assert.equal(r.run('G.brew'), 3, 'antidote did not finish all brewing stages');
      if (stage === 15) {
        assert.deepEqual(Object.keys(state.metrics.phases).sort(), ['1', '2', '3'], 'final boss skipped a scripted phase');
        assert.equal(r.run('G.player.form'), 'x', 'Fenrir Awakening did not occur');
        assert.equal(r.run('SAVE.cleared'), 16, 'campaign completion was not saved');
      }
      results.push({ name, pass: true, frames: steps, metrics: state.metrics });
      console.log(`ok ${results.length} - ${name}`);
    } catch (e) {
      results.push({ name, pass: false, message: e.message, state: r.json('campaignState()') });
      console.log(`not ok ${results.length} - ${name}\n  ---\n  message: ${JSON.stringify(e.message)}\n  ...`);
    }
  }

  const name = 'final clear screen reaches the campaign epilogue and end screen';
  try {
    assert.equal(r.run('Scene.name'), 'clear');
    r.tick();
    r.run('Scenes.clear.onDown(1,Scenes.clear.btn.x+4,Scenes.clear.btn.y+4)'); r.tick();
    if (r.run('Scenes.clear.step') === 1) {
      r.run('const card=Scenes.clear.cards[0];Scenes.clear.onDown(1,card.x+4,card.y+4)'); r.tick();
    }
    r.run('Scenes.clear.onDown(1,Scenes.clear.btn.x+4,Scenes.clear.btn.y+4)');
    let sawFinale = false;
    for (let steps = 0; steps < 3000 && r.run('Scene.name') !== 'end'; steps++) {
      if (r.run('Scene.name') === 'comic' && r.run('Scenes.comic.id') === 'finale') sawFinale = true;
      await advanceNarrative(); r.tick();
    }
    assert(sawFinale, 'finale cutscene was skipped');
    assert.equal(r.run('Scene.name'), 'end');
    assert.deepEqual(r.json('window.__err || []'), []);
    results.push({ name, pass: true }); console.log(`ok ${results.length} - ${name}`);
  } catch (e) {
    results.push({ name, pass: false, message: e.message });
    console.log(`not ok ${results.length} - ${name}\n  ---\n  message: ${JSON.stringify(e.message)}\n  ...`);
  }
  console.log(`1..${results.length}`);
  console.log(`# ${results.filter(t => t.pass).length} passed, ${results.filter(t => !t.pass).length} failed`);
  if (process.env.LUPUS_CAMPAIGN_REPORT) fs.writeFileSync(process.env.LUPUS_CAMPAIGN_REPORT,
    JSON.stringify({ timestamp: new Date().toISOString(), host: 'Node vm; combat bot with health/reposition/timer assists; audio mocked', results }, null, 2));
  if (results.some(t => !t.pass)) process.exitCode = 1;
}
main().catch(e => { console.error(e.stack); process.exitCode = 1; });
