'use strict';
/* =====================================================================
   DATA v8 — the approved Story Bible: prologue (1944) + 3 acts, 16 stages,
   each with its own mechanic. Replaces the 10-stage campaign.
   Text lives in i18n8.js (keys st<id>n / st<id>s / st<id>o ...).
   ===================================================================== */

/* ---------- looks for the new backgrounds (bg 11-16) ---------- */
Object.assign(LOOK, {
  11: { amb: '#b8c8bc', tint: '#40ff60', tintA: 0.05, refl: 0.3, fog: 'rgba(40,110,50,0.10)', rim: '#9aff40', rimA: 0.5, fx: 'drips',
    lights: [[100, 70, '#8aff2a', 110], [185, 70, '#8aff2a', 110], [355, 70, '#8aff2a', 110], [455, 70, '#8aff2a', 110], [700, 70, '#8aff2a', 110], [50, 120, '#ff1a2a', 90], [520, 120, '#ff1a2a', 90]] },
  12: { amb: '#d8c0b0', tint: '#ff5020', tintA: 0.05, refl: 0.24, fog: 'rgba(110,40,30,0.10)', rim: '#ffb060', rimA: 0.5, fx: 'embers',
    lights: [[120, 90, '#ff8a30', 120], [245, 90, '#ff8a30', 120], [400, 100, '#ff1a3a', 150], [560, 90, '#ff8a30', 120], [700, 90, '#ff8a30', 120], [30, 60, '#ff1a3a', 110], [780, 60, '#ff1a3a', 110]] },
  13: { amb: '#d8b0b4', tint: '#ff1030', tintA: 0.08, refl: 0.36, fog: 'rgba(120,20,30,0.12)', rim: '#ff5070', rimA: 0.6, fx: 'redrain',
    lights: [[70, 110, '#ff8a30', 120], [140, 120, '#ff8a30', 110], [415, 100, '#ff8a30', 120], [560, 120, '#ff8a30', 120], [210, 80, '#30e8ff', 110], [750, 80, '#30e8ff', 110]] },
  14: { amb: '#bcccb8', tint: '#30ff90', tintA: 0.05, refl: 0.3, fog: 'rgba(40,110,70,0.10)', rim: '#7affd0', rimA: 0.55, fx: 'spores',
    lights: [[60, 80, '#a7ff1a', 110], [240, 80, '#a7ff1a', 110], [430, 70, '#30f0ff', 160], [580, 90, '#a7ff1a', 110], [700, 80, '#a7ff1a', 110]] },
  15: { amb: '#dcb8a8', tint: '#ff3010', tintA: 0.08, refl: 0.3, fog: 'rgba(130,30,10,0.12)', rim: '#ffb040', rimA: 0.6, fx: 'redrain',
    lights: [[40, 50, '#ff8a30', 120], [215, 50, '#ff8a30', 120], [320, 50, '#ff8a30', 120], [405, 60, '#ff1a3a', 150], [490, 50, '#ff8a30', 120], [590, 50, '#ff8a30', 120], [770, 50, '#ff8a30', 120]] },
  16: { amb: '#e4c0a8', tint: '#ff4010', tintA: 0.08, refl: 0.4, fog: 'rgba(140,40,10,0.12)', rim: '#ffd060', rimA: 0.65, fx: 'embers',
    lights: [[60, 90, '#ff3010', 130], [205, 90, '#ff3010', 130], [400, 110, '#ffb020', 170], [600, 90, '#ff3010', 130], [750, 90, '#ff3010', 130]] }
});

/* ---------- new enemies (pack 3 art + code variants) ---------- */
Object.assign(ENEMY, {
  T: { name: 'THULE SOLDIER', key: 'tsold', hp: 130, spd: 50, ai: 'melee', dmg: 24, pts: 110, reach: 46, wind: 0.32, hr: 13 },
  X: { name: 'BLOOD BOMBER', key: 'mutant', hp: 90, spd: 78, ai: 'bomber', dmg: 70, pts: 140, hr: 14, tint: '#ff7a1a' },
  G: { name: 'IRON GUARDIAN', key: 'bulwark', hp: 260, spd: 34, ai: 'melee', shield: true, guardian: true, dmg: 28, pts: 260, reach: 36, hr: 15, tint: '#c8d8ff' },
  N: { name: 'ROOFTOP SNIPER', key: 'zealot', hp: 110, spd: 30, ai: 'sniper', dmg: 46, pts: 180, hr: 13, tint: '#40d0ff' },
  K2: { name: 'CABALA RAIDER', key: 'zealot', hp: 140, spd: 62, ai: 'capture', dmg: 20, pts: 150, hr: 13, tint: '#ff3050' }
});

/* ---------- bosses ---------- */
Object.assign(BOSS, {
  kreutz44: { name: 'LIEUTENANT KREUTZ', sub: 'THULE DIVISION, 1944', key: 'kreutz44', hp: 2300, spd: 66, pats: ['combo', 'shoot', 'slash', 'blink', 'combo', 'shoot'], pats2: ['combo', 'blink', 'shoot', 'charge', 'volley'], extra: ['sweep'], shootAn: 'atk2', muzzle: [44, 44], shot: '#ffd24a', col: '#e8f0ff', minions: ['T', 'T'], pts: 2200, hr: 15, reach: 60, flee: 0.32, music: 'boss_kreutz' },
  vesp_mb: { name: 'VESPERA', sub: '???', key: 'vespera', hp: 1500, spd: 90, pats: ['combo', 'blink', 'shoot', 'slash'], shootAn: 'spec', muzzle: [30, 40], shot: '#ff3ad0', col: '#ff3ad0', pts: 1000, hr: 12, reach: 48, mini: true, yieldAt: 0.3 },
  echo_mb: { name: 'ECHO', sub: '???', key: 'echo', hp: 2400, spd: 80, pats: ['shoot', 'volley', 'blink', 'combo', 'shoot'], shootAn: 'atk1', muzzle: [36, 40], shot: '#3ae6ff', col: '#3ae6ff', pts: 1500, hr: 12, reach: 46, mini: true, yieldAt: 0.3 },
  voss_r: { name: 'SERAPH VOSS, REVIVED', sub: 'DEATH WAS ONLY A PAUSE', key: 'voss', hp: 4700, spd: 66, pats: ['slash', 'wave', 'combo', 'blink', 'cross', 'summon'], pats2: ['combo', 'cross', 'volley', 'blink', 'wave', 'rain', 'summon'], extra: ['leap'], rain: 'gas', minions: ['R', 'P'], col: '#7aff4a', tint: '#5aff7a', tintA: 0.22, pts: 5000, hr: 21, reach: 73, vox: 'voss' },
  kane2: { name: 'KANE MK-II', sub: 'RE-CONTRACTED. RE-BUILT.', key: 'kane', hp: 6400, spd: 66, pats: ['shoot', 'combo', 'charge', 'volley', 'grab', 'rain'], pats2: ['volley', 'grab', 'shoot', 'charge', 'rain', 'cross', 'sweep'], extra: ['leap'], shootAn: 'atk2', muzzle: [62, 40], rain: 'debris', minions: ['Z', 'ZS', 'N'], col: '#ff8a20', shot: '#ffcf3a', tint: '#ffb020', tintA: 0.16, pts: 7000, hr: 18, reach: 66, vox: 'kane' },
  construct: { name: 'THE CONSTRUCT OF THE DEAD', sub: 'THE PATIENTS HE COULD NOT SAVE', key: 'construct', hp: 7400, spd: 40, pats: ['slash', 'slam', 'volley', 'charge', 'rain'], pats2: ['slam', 'rain', 'charge', 'grab', 'volley', 'roar'], extra: ['sweep'], shootAn: 'atk2', muzzle: [50, 60], shot: '#9a9088', rain: 'gas', minions: ['M', 'M', 'P'], col: '#9aff4a', pts: 8000, hr: 38, reach: 100, wide: true, vox: 'construct' },
  kreutzw: { name: 'KREUTZ, THE GREY WOLF', sub: 'NO MORE MASKS', key: 'kreutz', hp: 8600, spd: 80, pats: ['combo', 'blink', 'cross', 'leap', 'slash', 'grab'], pats2: ['combo', 'blink', 'grab', 'cross', 'wave', 'leap', 'rain', 'sweep'], extra: ['volley'], rain: 'spike', minions: ['R', 'R', 'G'], col: '#e8f0ff', tint: '#d8e4ff', tintA: 0.2, pts: 9000, hr: 20, reach: 76, music: 'boss_kreutz', vox: 'kreutz' },
  pack: { name: 'THE PACK', sub: 'TWO BEASTS, ONE HUNGER', key: 'beast', hp: 5600, spd: 54, pats: ['slash', 'charge', 'leap', 'combo', 'roar'], pats2: ['charge', 'grab', 'leap', 'slam', 'roar', 'combo'], extra: ['sweep'], rain: 'debris', minions: ['H', 'H'], pts: 7000, hr: 57, reach: 106, wide: true, pair: true, vox: 'beast' },
  levgiant: { name: 'THE LEVIATHAN', sub: 'NEREUS, BROTHER OF THE TIDE', key: 'levgiant', hp: 9800, spd: 0, pats: [], giant: true, col: '#3af0ff', pts: 9000, hr: 40, reach: 0, music: 'boss_leviathan', vox: 'leviathan' },
  finalwolf: { name: 'THE FIRST WOLF', sub: 'ALBRECHT THULE, GRAND MASTER', key: 'firstwolf', hp: 15500, spd: 54, pats: ['slash', 'slam', 'leap', 'wave', 'combo', 'roar'], pats2: ['charge', 'grab', 'sweep', 'wave', 'leap', 'rain', 'cross', 'combo', 'roar'], extra: ['volley'], rain: 'debris', minions: ['H', 'H', 'R'], col: '#ffb020', pts: 15000, hr: 34, reach: 98, phases: true, music: 'finalboss', vox: 'firstwolf' }
});
BOSS.kreutz.music = 'boss_kreutz'; BOSS.beast.music = 'finalboss';

/* ---------- Lupus's secret fourth form ---------- */
FORM.x = { key: 'fenrir', dmg: 118, reach: 58, dur: 0.2, armor: 0.55, regen: 0, spd: 132, cd: 3, label: 'fenrir' };

/* ---------- partners: when they join, when they are away ---------- */
const JOIN = { vespera: 3, triton: 5, malakor: 5, echo: 8, brann: 9 };   /* first stage id where they can be picked */
const AWAY = { malakor: [10, 11, 12, 13] };                              /* he leaves after Thorne Tower, returns after the antidote */
const PARTNERS = ['vespera', 'triton', 'malakor', 'echo', 'brann'];
function partnerOk(id, sid) { return JOIN[id] <= sid && !(AWAY[id] || []).includes(sid); }
function partnersFor(sid) { return PARTNERS.filter(p => partnerOk(p, sid)); }
/* outside the story (endless, boss rush, training) everyone who has joined can be picked */
function partnerJoined(id) { return SAVE.unlocked >= JOIN[id] || (SAVE.cleared || 0) >= 16; }

/* ---------- skins (pack 3C) and how to unlock them ---------- */
const SKINS = {
  lupus: { key: 'lupus44', how: 'sk_lupus' }, vespera: { key: 'vespera_s', how: 'sk_vespera' }, triton: { key: 'triton_s', how: 'sk_triton' },
  malakor: { key: 'malakor_s', how: 'sk_malakor' }, echo: { key: 'echo_s', how: 'sk_echo' }, brann: { key: 'brann_s', how: 'sk_brann' }
};
const skinOwned = id => !!(SAVE.skins || {})[id];
const skinOn = id => skinOwned(id) && !!(SAVE.skinOn || {})[id];

/* ---------- 16 stages ----------
   bg: background set, mech: stage mechanic (game8.js), music: track, arch: x of the 3 Thule Archives */
const W8 = (x, e, o) => Object.assign({ x, e }, o || {});
const STAGES8 = [
  { id: 1, act: 0, bg: 11, music: 'stage_prologue', mech: 'escape', solo: true, l44: true, w: 2700, hz: 'none', boss: 'kreutz44', arch: [520, 1430, 2280],
    waves: [W8(300, ['T', 'T']), W8(760, ['T', 'T', 'H']), W8(1220, ['T', 'H', 'H', 'T'], { amb: 1 }), W8(1680, ['M', 'M', 'T', 'T']), W8(2140, ['T*', 'H', 'T'])], props: [480, 980, 1500, 1950] },
  { id: 2, act: 1, bg: 1, music: 'stage1', mech: 'investigate', solo: true, w: 3400, hz: 'none', boss: 'warden', arch: [380, 1320, 2620], clues: [620, 1460, 2420],
    waves: [W8(300, ['S', 'S', 'Z']), W8(760, ['Z', 'Z', 'H', 'H', 'S']), W8(1220, ['S', 'ZS', 'M', 'Z']), W8(1700, [], { duel: 'vesp_mb' }), W8(2180, ['X', 'X', 'S', 'Z']), W8(2660, ['ZS', 'ZS', 'S', 'Z', 'H'])], props: [180, 520, 1100, 1900, 2350, 2900] },
  { id: 3, act: 1, bg: 2, music: 'stage2', mech: 'chase', w: 3600, hz: 'debris', boss: 'voss', arch: [450, 1600, 2700],
    waves: [W8(420, ['Z', 'Z', 'V']), W8(1060, ['S', 'S', 'ZS', 'Z']), W8(1700, ['N', 'V', 'S', 'S'], { amb: 1, hz: 1 }), W8(2340, ['K', 'Z', 'Z']), W8(2900, ['V*', 'S', 'S'], { hz: 1 })], props: [] },
  { id: 4, act: 1, bg: 3, music: 'stage3', mech: 'defend', w: 3240, hz: 'debris', boss: 'prime', arch: [260, 1500, 2480], gens: [820, 1740],
    waves: [W8(300, ['H', 'H', 'S']), W8(760, ['V', 'Z', 'Z', 'M', 'M'], { gen: 0 }), W8(1220, ['A', 'S', 'S'], { amb: 1 }), W8(1680, ['M', 'M', 'X', 'H', 'H'], { gen: 1 }), W8(2140, ['A*', 'V'], { hz: 1 }), W8(2600, ['V', 'Z', 'M', 'M', 'X'])], props: [160, 420, 1100, 1300, 2300, 2900] },
  { id: 5, act: 1, bg: 4, music: 'stage4', mech: 'flood', w: 3240, hz: 'shock', boss: 'nacht', arch: [560, 1380, 2500],
    waves: [W8(300, ['H', 'H', 'H', 'S']), W8(760, ['A', 'K']), W8(1220, ['V', 'Z', 'Z', 'S', 'X'], { hz: 1, flood: 1 }), W8(1680, ['M', 'M', 'S', 'S', 'H', 'H'], { amb: 1, flood: 1 }), W8(2140, ['K*', 'V'], { hz: 1, flood: 1 }), W8(2600, ['V', 'Z', 'Z', 'S', 'ZS'], { hz: 1, flood: 1 })], props: [400, 900, 1500, 2050, 2700] },
  { id: 6, act: 1, bg: 5, music: 'stage5', mech: 'sabotage', w: 3400, hz: 'gas', boss: 'beast', arch: [420, 1500, 2350], incub: [940, 1880, 2780], timer: 330,
    waves: [W8(300, ['K', 'V', 'Z']), W8(760, ['A', 'S', 'S', 'H', 'H']), W8(1260, ['M', 'M', 'M', 'V', 'X'], { hz: 1 }), W8(1720, ['K', 'ZS', 'ZS', 'G'], { amb: 1 }), W8(2200, ['A*', 'K*'], { hz: 1 }), W8(2660, ['K', 'V', 'X', 'ZS', 'A'], { hz: 1 })], props: [260, 620, 1500, 2000, 2950] },
  { id: 7, act: 2, bg: 6, music: 'stage6', mech: 'fog', w: 3400, hz: 'gas', boss: 'morrigan', arch: [300, 1560, 2760],
    waves: [W8(300, ['C', 'C', 'Z']), W8(760, ['P', 'C', 'C', 'S']), W8(1220, ['P', 'P', 'Z', 'N'], { amb: 1 }), W8(1700, [], { duel: 'echo_mb' }), W8(2180, ['P*', 'C', 'C', 'M'], { hz: 1 }), W8(2660, ['P', 'P', 'K', 'C', 'G'], { hz: 1 })], props: [220, 560, 1380, 1880, 2380, 2900] },
  { id: 8, act: 2, bg: 12, music: 'stage_cathedral', mech: 'ritual', w: 2800, hz: 'debris', boss: 'voss_r', arch: [420, 1260, 2380], statue: 1500,
    waves: [W8(300, ['R', 'R', 'Z']), W8(760, ['P', 'S', 'S', 'ZS']), W8(1260, [], { ritual: 1 }), W8(1920, ['K', 'R', 'G', 'P'], { hz: 1 })], props: [200, 600, 1000, 2100] },
  { id: 9, act: 2, bg: 7, music: 'stage7', mech: 'climb', w: 1620, hz: 'none', boss: 'kane', arch: [140, 760, 1300], arena: true,
    waves: [W8(0, ['Z', 'Z', 'ZS']), W8(0, ['C', 'C', 'C', 'V']), W8(0, ['K', 'Z', 'N']), W8(0, ['V', 'V', 'S', 'S', 'C']), W8(0, ['K*', 'ZS', 'G']), W8(0, ['C', 'C', 'V', 'N', 'Z'])], props: [] },
  { id: 10, act: 2, bg: 8, music: 'stage8', mech: 'giant', w: 3240, hz: 'debris', boss: 'levgiant', arch: [480, 1640, 2500],
    waves: [W8(300, ['D', 'S', 'S']), W8(760, ['D', 'H', 'H', 'H', 'M']), W8(1220, ['D', 'D', 'Z', 'X'], { amb: 1 }), W8(1680, ['A', 'M', 'M', 'D'], { hz: 1 }), W8(2140, ['D*', 'S', 'S', 'H'], { hz: 1 })], props: [200, 560, 980, 1320, 1840, 2300] },
  { id: 11, act: 2, bg: 9, music: 'stage9', mech: 'train', w: 3400, hz: 'none', boss: 'kreutz', arch: [600, 1500, 2700],
    waves: [W8(300, ['R', 'R', 'Z']), W8(840, ['R', 'ZS', 'ZS', 'V']), W8(1380, ['K', 'R', 'R', 'C', 'C'], { amb: 1 }), W8(1920, ['R', 'R', 'V', 'N']), W8(2460, ['R*', 'K', 'C', 'C'])], props: [] },
  { id: 12, act: 3, bg: 13, music: 'stage_cityfire', mech: 'rescue', w: 3400, hz: 'debris', boss: 'kane2', arch: [360, 1460, 2560],
    waves: [W8(300, ['Z', 'Z', 'S', 'K2'], { civ: 2 }), W8(780, ['S', 'S', 'H', 'H', 'X'], { civ: 2 }), W8(1260, ['V', 'V', 'Z', 'ZS', 'K2'], { amb: 1, civ: 3 }), W8(1740, ['A', 'M', 'M', 'K2', 'K2'], { civ: 3, hz: 1 }), W8(2220, ['K*', 'V', 'X', 'K2'], { civ: 3, hz: 1 }), W8(2700, ['ZS', 'N', 'S', 'S', 'K2', 'K2'], { civ: 3 })], props: [500, 1100, 2000, 2900] },
  { id: 13, act: 3, bg: 14, music: 'stage_refuge', mech: 'brew', w: 1620, hz: 'gas', boss: 'construct', arch: [180, 820, 1420], arena: true,
    pools: [['S', 'Z', 'H', 'M'], ['M', 'M', 'X', 'R', 'P'], ['A', 'K', 'P', 'C', 'G', 'R']], waves: [], props: [] },
  { id: 14, act: 3, bg: 15, music: 'stage_gates', mech: 'siege', w: 3400, hz: 'debris', boss: 'kreutzw', arch: [500, 1700, 2850], towers: [900, 1900, 2800],
    waves: [W8(300, ['R', 'R', 'Z']), W8(760, ['K', 'ZS', 'ZS', 'N'], { tower: 0 }), W8(1300, ['R', 'R', 'G', 'C', 'C']), W8(1760, ['A', 'R', 'X', 'X'], { tower: 1 }), W8(2260, ['K*', 'R', 'R', 'N'], { hz: 1 }), W8(2660, ['R', 'R', 'G', 'X', 'C'], { tower: 2 })], props: [] },
  { id: 15, act: 3, bg: 10, music: 'stage10', mech: 'reactors', w: 3400, hz: 'gas', boss: 'pack', arch: [420, 1560, 2600], reactors: [900, 1880, 2800],
    waves: [W8(300, ['R', 'R', 'P', 'P']), W8(760, ['A', 'K', 'R', 'C', 'C'], { reactor: 0 }), W8(1260, ['P', 'P', 'D', 'R', 'R'], { amb: 1, hz: 1 }), W8(1740, ['A*', 'R', 'R', 'M', 'M'], { reactor: 1 }), W8(2220, ['K*', 'D*', 'C', 'C'], { hz: 1 }), W8(2680, ['G', 'R', 'R', 'X', 'P'], { reactor: 2 })], props: [260, 1000, 2000, 2950] },
  { id: 16, act: 3, bg: 16, music: 'stage_fenrir', mech: 'final', w: 2200, hz: 'none', boss: 'finalwolf', arch: [380, 980, 1560],
    waves: [W8(300, ['R', 'R', 'A', 'P']), W8(820, ['K', 'K', 'R', 'R', 'C', 'C'], { amb: 1 }), W8(1340, ['G', 'A', 'R', 'X', 'P'])], props: [] }
];
/* the old 10-stage table is replaced in place (other code keeps referencing STAGES) */
STAGES.length = 0; STAGES8.forEach(s => { s.name = {}; s.sub = {}; s.obj = {}; STAGES.push(s); });
const ACT_START = [0, 1, 6, 11];            /* index of the first stage of prologue / act I / II / III */
const actOf = i => STAGES[i].act;
Object.keys(CHAL).forEach(k => delete CHAL[k]);
Object.assign(CHAL, {
  1: [{ k: 'clear' }, { k: 'combo', n: 20 }, { k: 'nohit', n: 8 }],
  2: [{ k: 'clear' }, { k: 'clues' }, { k: 'combo', n: 30 }],
  3: [{ k: 'clear' }, { k: 'time', n: 330 }, { k: 'nohit', n: 10 }],
  4: [{ k: 'clear' }, { k: 'gens' }, { k: 'combo', n: 40 }],
  5: [{ k: 'clear' }, { k: 'noko' }, { k: 'time', n: 420 }],
  6: [{ k: 'clear' }, { k: 'timeleft', n: 90 }, { k: 'combo', n: 60 }],
  7: [{ k: 'clear' }, { k: 'combo', n: 50 }, { k: 'nohit', n: 12 }],
  8: [{ k: 'clear' }, { k: 'statue', n: 50 }, { k: 'tags', n: 6 }],
  9: [{ k: 'clear' }, { k: 'noko' }, { k: 'combo', n: 60 }],
  10: [{ k: 'clear' }, { k: 'nohit', n: 14 }, { k: 'time', n: 480 }],
  11: [{ k: 'clear' }, { k: 'dodge', n: 3 }, { k: 'combo', n: 60 }],
  12: [{ k: 'clear' }, { k: 'civ', n: 12 }, { k: 'noko' }],
  13: [{ k: 'clear' }, { k: 'vat', n: 60 }, { k: 'combo', n: 70 }],
  14: [{ k: 'clear' }, { k: 'time', n: 480 }, { k: 'nohit', n: 14 }],
  15: [{ k: 'clear' }, { k: 'noko' }, { k: 'combo', n: 80 }],
  16: [{ k: 'clear' }, { k: 'noko' }, { k: 'nohit', n: 20 }]
});
/* the 48 Thule Archives: stage s, slot j -> index (s-1)*3+j */
const ARCH_N = 48;
const archId = (sid, j) => (sid - 1) * 3 + j;
const archCount = () => Object.keys(SAVE.arch || {}).length;
