'use strict';
/* Every new narrative moment has its own illustration. Legacy art stays intact. */
(function () {
  const pt = {
    x09a: 'O CONTRATO... AINDA VALE...',
    ch01a: 'As correntes eram a última garantia de que a arma obedeceria.',
    ch01b: 'Estas algemas respondem ao seu sistema nervoso. Quanto mais lutar, mais apertam.',
    ch02a: 'Ninguém vai fazer isso comigo de novo.',
    ch02b: 'John arrancou as correntes da parede da cela. Guardou o aço como lembrança de quem jamais voltaria a prendê-lo.',
    ch03a: 'Hoje elas seguem a minha mão. Servem para atingir um inimigo e abrir caminho. Nunca mais para me manter de joelhos.',
    ch03b: 'O instrumento do cativeiro tornou-se uma escolha. Uma corrente, uma promessa: ninguém fica para trás.',
    lu01a: 'Lunário: prata alquímica fundida com ferro de meteorito.',
    lu01b: 'A prata deveria matar um lobo. A regeneração dele vai fundi-la aos ossos.',
    lu01c: 'Então que a dor seja a coleira dele.',
    lu02a: 'As garras de Lunário rasgam a pele. A prata queima.',
    lu02b: 'Queima... e quanto mais queima, mais forte eu fico.'
  };
  const en = {
    x09a: 'THE CONTRACT... STILL STANDS...',
    ch01a: 'The chains were the final guarantee that the weapon would obey.',
    ch01b: 'These restraints respond to your nervous system. The harder you fight, the tighter they become.',
    ch02a: 'No one will ever do this to me again.',
    ch02b: 'John tore the chains from the cell wall. He kept the steel as a reminder that no one would imprison him again.',
    ch03a: 'Now they follow my hand. I use them to strike an enemy and clear a path. Never to keep me on my knees again.',
    ch03b: 'The instrument of captivity became a choice. One chain, one promise: no one gets left behind.',
    lu01a: 'Lunarium: alchemical silver fused with meteoric iron.',
    lu01b: 'Silver should kill a wolf. His regeneration will fuse it to the bone instead.',
    lu01c: 'Then let the pain be his leash.',
    lu02a: 'The Lunarium claws tear through his skin. The silver burns.',
    lu02b: 'It burns... and the more it burns, the stronger I get.'
  };
  Object.assign(I18N.pt.comic, pt);
  Object.assign(I18N.en.comic, en);
  ['cs82', 'cs83', 'cs84', 'cs85', 'cs86', 'cs87', 'cs88', 'cs89'].forEach(k => COMIC_LIST.add(k));
  // Restraints are introduced before the experiment, retained in the cell,
  // and torn from the cell wall before the player starts the escape.
  CUTS.intro.splice(2, 0, [PG('cs83', [cap('ch01a'), say('thule44', 'ch01b')], [.5, .42], { mood: 'cue_villain', amb: 'lab44' })]);
  CUTS.intro.push([PG('cs84', [say('lupus44', 'ch02a'), cap('ch02b')], [.5, .42], { mood: 'cue_1944', amb: 'cell' })]);
  // v9.2: where the claws come from. The Lunarium alloy is shown before the
  // procedure (cs78), so his scream there is the fusion itself.
  { const at = CUTS.intro.findIndex(pg => pg[0] && pg[0].img === 'cs78');
    CUTS.intro.splice(at < 0 ? CUTS.intro.length - 1 : at, 0, [PG('cs88', [cap('lu01a', { snd: 'glass' }), say('thule44', 'lu01b'), say('kreutz44', 'lu01c')], [.5, .42], { mood: 'cue_villain', amb: 'lab44' })]); }
  CUTS.s2pre.push([PG('cs85', [say('lupus_h', 'ch03a'), cap('ch03b')], [.5, .42], { mood: 'cue_mystery', amb: 'rain_city' })]);
  // The beginning of Act III and the secret ending no longer recycle earlier art.
  CUTS.act3[0][0].img = 'cs86';
  CUTS.finale[CUTS.finale.length - 1][0].img = 'cs87';
  STAGE_PANELS[2] = ['cs82'];
  STAGE_PANELS[1] = ['cs89'];   // v9.2: the claws page, shown at the first feral transformation of the prologue
  window.LUPUS_STORY_VERSION = '9.5';
})();
