'use strict';
/* Duo actions are staged in world space. The active hero remains the initiator;
 * the partner has a visible, authored preparation/action/recovery of their own.
 * No fullscreen illustration stands in for the action. */
(function () {
  const LENGTH = 3.2;
  const SHEETS = {
    vespera: 'assets/v90/super_vespera.webp',
    triton: 'assets/v90/super_triton.webp',
    malakor: 'assets/v90/super_malakor.webp',
    echo: 'assets/v90/super_echo.webp',
    brann: 'assets/v90/super_brann.webp'
  };
  const HEIGHT = { vespera: 91, triton: 106, malakor: 96, echo: 91, brann: 120 };
  const ROW_SPLIT = { vespera: 450 / 887, echo: 510 / 887, brann: 510 / 887, triton: 470 / 887, malakor: 540 / 887 };
  const FX_START = { echo: 550 / 887, brann: 550 / 887 };
  const BODY_RECTS = { malakor: [[84, 169, 303, 313], [516, 86, 306, 397], [930, 159, 430, 323], [1426, 165, 278, 317]] };
  const FX_RECTS = {
    echo: [[70, 630, 220, 230], [360, 630, 440, 230], [825, 625, 500, 245], [1365, 650, 390, 200]],
    malakor: [[37, 618, 390, 199], [477, 616, 371, 211], [918, 617, 388, 208], [1375, 614, 365, 214]]
  };
  const cache = new Map();
  function sheet(id) {
    const path = SHEETS[id]; if (!path) return null;
    let im = cache.get(path);
    if (!im) {
      im = new Image(); im._super90id = id;
      im.onload = () => { im.ok = true; measureBodies(im); if (FX_RECTS[id]) for (let n = 0; n < 4; n++) effectRect(im, n); }; im.onerror = () => { im.bad = true; };
      im.src = path; cache.set(path, im);
    }
    return im;
  }
  function ready(im) { return !!(im && im.ok && im.width > 0 && im.height > 0); }
  function keepSheet(id) {
    for (const [path, im] of cache) if (path !== SHEETS[id]) { im.src = ''; cache.delete(path); }
  }
  function rowBand(im, row) {
    const split = Math.round(im.height * ((row ? FX_START[im._super90id] : null) || ROW_SPLIT[im._super90id] || 0.5));
    return row ? { y: split, h: im.height - split } : { y: 0, h: split };
  }
  function measureBodies(im) {
    // Read authored alpha only to remove export padding. This preserves the
    // artist's relative pose scale and avoids stretching the character artwork.
    const cw = im.width / 4, ch = rowBand(im, 0).h, c = document.createElement('canvas');
    c.width = im.width; c.height = ch;
    try {
      const g = c.getContext('2d'); g.drawImage(im, 0, 0);
      const px = g.getImageData(0, 0, c.width, c.height).data, bounds = [];
      for (let col = 0; col < 4; col++) {
        let lo = ch, hi = -1;
        for (let y = 0; y < Math.floor(ch); y++) for (let x = Math.ceil(col * cw); x < Math.floor((col + 1) * cw); x++)
          if (px[(y * c.width + x) * 4 + 3] > 40) { lo = Math.min(lo, y); hi = Math.max(hi, y); }
        bounds.push({ lo, hi });
      }
      const first = bounds[0];
      if (first.hi > first.lo) {
        const height = first.hi - first.lo + 1, anchors = bounds.map((b, col) => {
          let l = Infinity, r = -Infinity;
          for (let y = Math.max(0, Math.floor(b.hi - height * 0.08)); y <= b.hi; y++)
            for (let x = Math.ceil(col * cw); x < Math.floor((col + 1) * cw); x++) if (px[(y * c.width + x) * 4 + 3] > 40) { l = Math.min(l, x); r = Math.max(r, x); }
          return Number.isFinite(l) ? (l + r + 1) / 2 - col * cw : cw / 2;
        });
        im._super90body = { cw, ch, height, anchors, baseline: Math.max(...bounds.map(b => b.hi)) + 1 };
      }
    } catch (_) { /* Conservative cell bounds also work in restricted canvases. */ }
    c.width = c.height = 0;
  }
  const ease = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
  const mix = (a, b, t) => a + (b - a) * ease(t);
  const active = () => G && G.superFx && G.superFx.v90 ? G.superFx : null;
  const ground = h => window.Traversal90 && Traversal90.floorY ? Traversal90.floorY(h) : 0;
  function insideX(x, pad) { return clamp(x, G.camX + pad, G.camX + VW - pad); }
  function eachLive(S) { return G.enemies.filter(e => !e.dead && e.x >= G.camX - 40 && e.x <= G.camX + VW + 40); }
  function power(S) {
    const form = FORM[S.L.form] || FORM.h;
    return (form.dmg + HERO[S.P.id].dmg) * upMul() * (skl(S.p.id).spc >= 4 ? 1.25 : 1)
      * (((SAVE.aff || {})[S.duo] || 0) >= 5 ? 1.25 : 1);
  }
  function hit(S, source, e, multiplier, options) {
    if (!e || e.dead) return;
    const accepted = hurt(source, e, power(S) * multiplier * (e.kind === 'boss' ? 0.55 : 1),
      Object.assign({ launch: e.kind !== 'boss', kx: 160, kz: 230, brk: true, ignoreInv: true }, options || {}));
    if (accepted) S.reactions.add(e);
  }
  function sweep(S, source, multiplier, options) {
    for (const e of eachLive(S)) hit(S, source, e, multiplier, options);
    for (const q of G.props) if (!q.dead && q.x >= G.camX && q.x <= G.camX + VW) breakProp(q);
    for (const ob of G.objs || []) if (ob.team === 'e' && !ob.dead && ob.x >= G.camX && ob.x <= G.camX + VW)
      objHurt(source, ob, power(S) * multiplier * 0.6, {});
  }
  function landSound() { sfx('impact'); shake(5); vibe(65, 150); }
  function clearActor(h) { if (!h) return; delete h._super90; h.z = ground(h); h.vx = h.vy = h.vz = 0; h.air = false; h._trail = []; }
  function echoMuzzle(S) {
    const im = sheet('echo'), m = im && im._super90body;
    if (!m) return { x: S.P.x + S.face * 36, y: S.P.y, z: 64 };
    const size = HEIGHT.echo * depthScale(S.P.y) / m.height;
    return { x: S.P.x + S.face * (400 / 1774 * im.width - m.anchors[2]) * size,
      y: S.P.y, z: (m.baseline - 182 / 887 * im.height) * size };
  }
  function finish(S, interrupted) {
    if (!G || G !== S.game || G.superFx !== S) return;
    G.superFx = null;
    for (const h of [S.p, S.a]) {
      clearActor(h); h.x = insideX(h.x, 38); h.y = clamp(h.y, LANE_T + 8, LANE_B - 8);
      if (!h.dead) { setSt(h, 'idle'); h.inv = 0.7; }
    }
    S.a.assist = false; S.a.bench = true; S.a.astPh = null;
    G.heroes = G.heroes.filter(h => h !== S.a);
    // A short, real exit uses the existing tag-out actor, with no duplicated body.
    if (!interrupted && !S.a.dead && !G.leaving.includes(S.a)) { S.a.bench = false; S.a.assist = true; S.a.astPh = 'out'; jumpOut(S.a); }
    if (window.Flood90 && Flood90.resume) Flood90.resume({ rearm: true });
  }
  startSuper = function () {
    if (!G || !canSuper()) return false;
    const p = G.player, a = G.ally, duo = duoOf();
    if (!a || !DUO[duo]) return false;
    const L = p.id === 'lupus' ? p : a, P = L === p ? a : p;
    if (!L || !P || P.id === 'lupus') return false;
    sheet(duo);
    // Keep one duo sheet resident. Characters already use the normal stage atlases.
    keepSheet(duo);
    const foes0 = G.enemies.filter(e => !e.dead && e.x >= G.camX && e.x <= G.camX + VW);
    const target = foes0.sort((x, y) => Math.abs(x.x - p.x) - Math.abs(y.x - p.x))[0];
    const face = target ? Math.sign(target.x - p.x) || p.face : p.face;
    const anchor = insideX(p.x, 100), y = clamp(p.y, LANE_T + 18, LANE_B - 12);
    const S = { v90: true, game: G, t: 0, duration: LENGTH, p, a, L, P, duo, face,
      x: anchor, y, targetX: insideX(target ? target.x : anchor + face * 95, 48),
      start: new Map([[p, { x: insideX(p.x, 40), y: p.y }], [a, { x: insideX(anchor - face * 95, 44), y: y + 5 }]]),
      marks: new Set(), reactions: new Set(), stage: 'entry', pose: 0, hit: false, wolves: [], impactT: null, img: null };
    G.syn = 0; G.hitstop = 0; a.bench = false; a.assist = true; a.astPh = 'super'; a.isPlayer = false;
    G.leaving = G.leaving.filter(h => h !== a);
    if (!G.heroes.includes(a)) G.heroes.push(a);
    for (const h of [p, a]) {
      if (window.Traversal90 && Traversal90.detach) Traversal90.detach(h);
      h._super90 = true; h.inv = LENGTH + 1; h.spCd = 0; h.t = 0; h.specDur = LENGTH; h.specAt = 99;
      h.vx = h.vy = h.vz = 0; h.z = 0; h.face = face; h._trail = []; setSt(h, 'spec');
    }
    p.x = S.start.get(p).x; a.x = S.start.get(a).x; a.y = S.start.get(a).y;
    G.superFx = S; Inp.edge = {};
    if (window.Flood90 && Flood90.pause) Flood90.pause();
    sfx('special'); playSting('sting_duo'); vibe(80, 170);
    voice(duo + '_duo', 0);
    return true;
  };
  updSuper = function (dt) {
    const S = active(); if (!S) return;
    if (G !== S.game || S.p.dead || S.a.dead || G.over > 0) { finish(S, true); return; }
    dt = clamp(Number.isFinite(dt) ? dt : 0, 0, 0.08);
    S.t += dt; const t = S.t, L = S.L, P = S.P, f = S.face;
    for (const h of [S.p, S.a]) { h.t = t; h.inv = Math.max(h.inv || 0, 0.8); h.flash = 0; h.vx = h.vy = h.vz = 0; h.face = f; }
    const l0 = S.start.get(L), p0 = S.start.get(P);
    const entry = ease(t / 0.43);
    L.x = mix(l0.x, S.x + f * 14, entry); L.y = mix(l0.y, S.y, entry); L.z = 0;
    P.x = mix(p0.x, S.x - f * 28, entry); P.y = mix(p0.y, S.y + 3, entry); P.z = 0;
    S.pose = t < 0.43 ? 0 : t < 0.92 ? 1 : t < 2.25 ? 2 : 3;
    if (S.duo === 'echo') S.pose = t < 0.43 ? 0 : t < 1.78 ? 1 : t < 2.35 ? 2 : 3;
    S.stage = t < 0.43 ? 'entry' : t < 0.92 ? 'prepare' : t < 2.25 ? 'action' : 'recover';
    if (S.duo === 'vespera') {
      if (t >= 0.43 && t < 1.35) {
        const k = ease((t - 0.43) / 0.92);
        P.x = S.x - f * 12; P.z = 26 * Math.sin(k * Math.PI * 0.5);
        L.x = P.x + f * 19; L.z = 88 * Math.sin(k * Math.PI * 0.5);
      } else if (t >= 1.35 && t < 1.78) {
        const k = ease((t - 1.35) / 0.43);
        P.x = mix(S.x - f * 12, S.x - f * 38, k); P.z = 26 * (1 - k);
        L.x = mix(S.x + f * 7, S.targetX - f * 12, k); L.z = 88 * (1 - k);
      } else if (t >= 1.78) { L.x = S.targetX - f * 12; P.x = mix(S.x - f * 38, L.x - f * 40, (t - 1.78) / 1.2); }
      if (t >= 1.78 && !S.hit) { S.hit = true; S.impactT = t; sweep(S, L, 6, { bleed: true }); P.hp = Math.min(P.maxhp, P.hp + P.maxhp * 0.2); landSound(); }
    } else if (S.duo === 'triton') {
      if (t >= 0.85 && t < 2.25) {
        const k = clamp((t - 0.85) / 1.4, 0, 1);
        S.waveX = mix(S.x - f * 35, insideX(S.x + f * 235, 35), k);
        P.x = mix(S.x - f * 28, S.x + f * 35, k); P.z = Math.sin(k * Math.PI) * 7;
        L.x = insideX(S.waveX + f * 7, 40); L.z = 28 + 9 * Math.sin(k * Math.PI);
        for (const e of eachLive(S)) if (!S.marks.has(e) && Math.abs(e.x - S.waveX) < 56) {
          S.marks.add(e); hit(S, P, e, 5.2, { kx: 240 });
        }
      } else if (t >= 2.25) { L.x = insideX(S.x + f * 210, 42); P.x = mix(S.x + f * 35, L.x - f * 44, (t - 2.25) / 0.8); }
      if (t >= 2.25 && !S.hit) { S.hit = true; S.impactT = t; for (const h of [L, P]) { h.shieldHP = Math.max(h.shieldHP || 0, 300); h.shieldT = Math.max(h.shieldT || 0, 6); } sfx('land'); }
    } else if (S.duo === 'malakor') {
      P.x = mix(S.x - f * 28, S.x + f * 12, (t - 0.43) / 1.8);
      if (t >= 0.92 && !S.hit) {
        S.hit = true; S.wolves = Array.from({ length: 6 }, (_, i) => ({ x: P.x - f * (30 + i * 27), y: clamp(S.y + (i % 3 - 1) * 12, LANE_T + 4, LANE_B - 4), t: -i * 0.07, hit: new Set() }));
        storySnd('howl'); for (const h of G.team) if (!h.dead) h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.3);
      }
      for (const w of S.wolves) {
        w.t += dt; if (w.t < 0) continue; w.x += f * 350 * dt;
        for (const e of eachLive(S)) if (!w.hit.has(e) && Math.abs(e.x - w.x) < 30 && Math.abs(e.y - w.y) < 32) { w.hit.add(e); hit(S, P, e, 0.95, { kx: 140 }); }
      }
      if (S.wolves.length) L.x = insideX(S.wolves[0].x - f * 26, 42);
      L.z = t >= 0.92 && t < 2.25 ? Math.abs(Math.sin(t * 12)) * 5 : 0;
    } else if (S.duo === 'echo') {
      P.x = mix(S.x - f * 28, S.x + f * 14, (t - 0.43) / 1.8);
      if (t >= 0.92 && !S.hit) { S.hit = true; S.list = eachLive(S).slice(0, 6); S.next = 0.92; S.i = 0; storySnd('holo'); }
      if (S.list && t >= S.next && t < 1.9 && S.i < S.list.length) {
        const e = S.list[S.i++]; if (!e.dead) { S.blinkX = insideX(e.x - f * 25, 40); S.blinkY = e.y; hit(S, L, e, 0.9, { kx: 60 }); sfx('slash'); } S.next = t + 0.16;
      }
      if (S.blinkX != null && t < 2.25) { L.x = S.blinkX; L.y = S.blinkY; }
      if (t >= 1.9 && !S.beam) { S.beam = Object.assign(echoMuzzle(S), { t0: t }); S.impactT = t; sweep(S, P, 3.2); storySnd('laser'); shake(3); }
      if (S.beam) Object.assign(S.beam, echoMuzzle(S));
      if (t >= 2.25) { L.x = mix(S.blinkX || S.targetX, S.x + f * 40, (t - 2.25) / 0.8); L.y = mix(S.blinkY || S.y, S.y, (t - 2.25) / 0.8); }
    } else if (S.duo === 'brann') {
      P.x = S.x - f * 12;
      if (t >= 0.43 && t < 1.02) { const k = ease((t - 0.43) / 0.59); L.x = P.x + f * 15; L.z = 46 * k; }
      else if (t >= 1.02 && t < 1.78) { const k = clamp((t - 1.02) / 0.76, 0, 1); L.x = mix(S.x + f * 3, S.targetX - f * 10, k); L.z = 46 * (1 - k) + Math.sin(k * Math.PI) * 78; P.x = mix(S.x - f * 12, S.x + f * 28, k); }
      else if (t >= 1.78) { L.x = S.targetX - f * 10; P.x = mix(S.x + f * 28, L.x - f * 45, (t - 1.78) / 1.1); }
      if (t >= 1.78 && !S.hit) { S.hit = true; S.impactT = t; sweep(S, L, 6.2, { stun: 1.2 }); landSound(); }
    }
    for (const h of [L, P]) { h.x = insideX(h.x, 32); h.y = clamp(h.y, LANE_T + 6, LANE_B - 6); h.z = Math.max(0, h.z); }
    // Struck enemies use native knockdown/gravity while the rest of their AI is
    // held. This keeps contact and landing visible inside the staged action.
    for (const e of S.reactions) if (e.kind !== 'boss' && (e.dead || ['hurt', 'knock', 'down', 'getup'].includes(e.st))) updEnemy(e, dt);
    // A volley of wolf contacts must not repeatedly stall the cinematic clock.
    // The authored impact poses, camera shake and sound carry the hit response.
    G.hitstop = 0;
    if (t >= LENGTH) finish(S, false);
  };

  function bodyPose(S, h) {
    if (h === S.P) return ['spec', S.pose];
    if (S.t < 0.43) return ['run', Math.floor(S.t * 12)];
    if (S.duo === 'vespera' || S.duo === 'brann') {
      if (h.z > 20) return [S.t < 1.2 ? 'rise' : 'air', S.t < 1.2 ? 1 : 1];
      if (S.t >= 1.75 && S.t < 2.3) return ['atk3', 3];
      return ['guard', 0];
    }
    if (S.duo === 'triton' && S.t > 0.85 && S.t < 2.25) return ['air', 1];
    if (S.duo === 'malakor' && S.t > 0.92 && S.t < 2.25) return ['run', Math.floor(S.t * 14)];
    if (S.duo === 'echo' && S.t > 0.92 && S.t < 1.9) return ['atk' + (1 + (S.i || 0) % 3), 2];
    return [S.t > 2.25 ? 'win' : 'guard', S.t > 2.25 ? 0 : 0];
  }
  function spriteCell(g, im, col, row, x, y, w, h, face, alpha) {
    if (!ready(im)) return false;
    const cw = im.width / 4, band = rowBand(im, row);
    g.save(); g.imageSmoothingEnabled = false; g.globalAlpha = alpha == null ? 1 : alpha;
    g.translate(Math.round(x), Math.round(y)); if (face < 0) g.scale(-1, 1);
    g.drawImage(im, col * cw, band.y, cw, band.h, -w / 2, -h, w, h); g.restore(); return true;
  }
  function effectRect(im, col) {
    const rects = im._super90effects || (im._super90effects = []);
    if (rects[col]) return rects[col];
    const cw = im.width / 4, band = rowBand(im, 1), c = document.createElement('canvas');
    const custom = FX_RECTS[im._super90id] && FX_RECTS[im._super90id][col];
    const source = custom ? { x: custom[0] * im.width / 1774, y: custom[1] * im.height / 887, w: custom[2] * im.width / 1774, h: custom[3] * im.height / 887 } : { x: col * cw, y: band.y, w: cw, h: band.h };
    c.width = Math.ceil(source.w); c.height = Math.ceil(source.h);
    let rect = source;
    try {
      const g = c.getContext('2d'); g.drawImage(im, source.x, source.y, source.w, source.h, 0, 0, c.width, c.height);
      const px = g.getImageData(0, 0, c.width, c.height).data; let l = c.width, r = -1, t = c.height, b = -1;
      for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) if (px[(y * c.width + x) * 4 + 3] > 30) { l = Math.min(l, x); r = Math.max(r, x); t = Math.min(t, y); b = Math.max(b, y); }
      if (r > l && b > t) rect = { x: source.x + l * source.w / c.width, y: source.y + t * source.h / c.height, w: (r - l + 1) * source.w / c.width, h: (b - t + 1) * source.h / c.height };
    } catch (_) {}
    c.width = c.height = 0; return rects[col] = rect;
  }
  function handles(e) { const S = active(); return !!(S && (e === S.p || e === S.a)); }
  function drawActor(g, e, cam) {
    const S = active(); if (!S || !handles(e)) return false;
    const sc = depthScale(e.y), im = sheet(S.duo);
    if (e === S.P && ready(im)) {
      const m = im._super90body || { cw: im.width / 4, ch: im.height / 2, height: im.height / 2, baseline: im.height / 2 };
      const size = HEIGHT[e.id] * sc / m.height;
      const authored = BODY_RECTS[e.id] && BODY_RECTS[e.id][S.pose];
      const source = authored ? { x: authored[0] * im.width / 1774, y: authored[1] * im.height / 887, w: authored[2] * im.width / 1774, h: authored[3] * im.height / 887 } : { x: S.pose * m.cw, y: 0, w: m.cw, h: m.ch };
      g.save(); g.imageSmoothingEnabled = false; g.translate(Math.round(e.x - cam), Math.round(e.y - e.z));
      if (e.face < 0) g.scale(-1, 1);
      g.drawImage(im, source.x, source.y, source.w, source.h,
        (source.x - S.pose * m.cw - (m.anchors ? m.anchors[S.pose] : m.cw / 2)) * size,
        (source.y - m.baseline) * size, source.w * size, source.h * size);
      g.restore();
      return true;
    }
    const pose = bodyPose(S, e), key = heroKey(e), fr = ART.frame(key, pose[0], pose[1], false) || ART.frame(key, 'spec', S.pose, false);
    if (fr) ART.draw(g, fr, e.x - cam, e.y - e.z, { face: e.face, sc });
    return true;
  }
  function drawWorld(g, cam) {
    const S = active(), im = S && sheet(S.duo); if (!S || !ready(im)) return;
    const t = S.t, f = S.face;
    if (S.duo === 'vespera' && t >= 0.43 && t < 1.8) {
      const k = clamp((t - 0.43) / 1.37, 0, 1);
      spriteCell(g, im, Math.min(3, Math.floor(k * 4)), 1, S.P.x - cam + f * 12, S.P.y - S.P.z + 12, 126, 130, f, 0.9);
    } else if (S.duo === 'triton' && t >= 0.85 && t < 2.32) {
      const k = clamp((t - 0.85) / 1.47, 0, 1);
      spriteCell(g, im, Math.min(3, Math.floor(k * 4)), 1, (S.waveX || S.x) - cam, S.y + 12, 150, 98, f, Math.min(1, (2.32 - t) / 0.15));
    } else if (S.duo === 'malakor') {
      for (const w of S.wolves) if (w.t >= 0 && w.x > cam - 80 && w.x < cam + VW + 80) {
        const r = effectRect(im, Math.floor(w.t * 11) % 4), scale = 74 / (390 * im.width / 1774), width = r.w * scale, height = r.h * scale;
        g.save(); g.imageSmoothingEnabled = false; g.globalAlpha = Math.min(0.95, w.t * 8);
        g.translate(Math.round(w.x - cam), Math.round(w.y + 1)); if (f < 0) g.scale(-1, 1);
        g.drawImage(im, r.x, r.y, r.w, r.h, -width / 2, -height, width, height); g.restore();
      }
    } else if (S.duo === 'echo' && t >= 1.78 && t < 1.9) {
      const r = effectRect(im, 0), m = echoMuzzle(S), size = 22 + (t - 1.78) / 0.12 * 8;
      g.save(); g.imageSmoothingEnabled = false; g.drawImage(im, r.x, r.y, r.w, r.h, m.x - cam - size / 2, m.y - m.z - size / 2, size, size); g.restore();
    } else if (S.duo === 'echo' && S.beam && t - S.beam.t0 < 0.45) {
      const k = (t - S.beam.t0) / 0.45, len = Math.max(40, f > 0 ? G.camX + VW - S.beam.x : S.beam.x - G.camX);
      const r = effectRect(im, 1 + Math.min(2, Math.floor(k * 3)));
      g.save(); g.imageSmoothingEnabled = false; g.globalAlpha = 1 - k * k;
      g.translate(Math.round(S.beam.x - cam), Math.round(S.beam.y - S.beam.z)); if (f < 0) g.scale(-1, 1);
      g.drawImage(im, r.x, r.y, r.w, r.h, 0, -14, len, 28); g.restore();
    } else if (S.duo === 'brann' && S.impactT != null && t - S.impactT < 0.7) {
      const k = (t - S.impactT) / 0.7;
      spriteCell(g, im, Math.min(3, Math.floor(k * 4)), 1, S.L.x - cam, S.L.y + 16, 120 + k * 100, 74 + k * 35, f, 1 - k * k);
    }
  }
  // Deliberately no fullscreen Splash or duplicated portraits. Names remain at
  // the stage's usual HUD locations; the action itself identifies the pair.
  drawSuperSplash = function () {};
  function drawHUD(g) { /* World choreography replaces the old title-card overlay. */ }
  const baseCanSuper = canSuper;
  canSuper = function () {
    if (!G || G.nachtBeat90 || G.choice || G.rpgScene || document.hidden || Scene.name !== 'play' || Scenes.play.menu) return false;
    const id = duoOf(), im = DUO[id] ? sheet(id) : null;
    const yes = baseCanSuper();
    if (!yes) return false;
    // Never spend synergy on an attack whose authored power is not visible.
    return !!(DUO[id] && ready(im) && G.team.some(h => h.id === 'lupus') && !G.team.some(h => h.id === 'lupus' && h.form === 'x'));
  };
  const newGame0 = newGame;
  newGame = function () {
    const game = newGame0.apply(this, arguments), id = game && game.team.find(h => h.id !== 'lupus');
    keepSheet(id && id.id); if (id && DUO[id.id]) sheet(id.id);
    return game;
  };
  window.Super90 = {
    handles, drawActor, drawWorld, drawHUD,
    cancel() { const S = active(); if (S) finish(S, true); },
    snapshot() { const S = active(); return S ? { duo: S.duo, t: S.t, stage: S.stage, pose: S.pose, initiator: S.p.id, partner: S.a.id, lupus: S.L.id, powerSource: S.P.id, wolves: S.wolves.length } : null; },
    configureAssets(paths) { Object.assign(SHEETS, paths || {}); },
    configureRows(splits) { Object.assign(ROW_SPLIT, splits || {}); },
    assets: SHEETS,
    preload(id) { return sheet(id || (G && duoOf())); }
  };
})();
