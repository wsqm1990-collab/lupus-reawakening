'use strict';
/* One interruptible speech channel, shared by story and combat voices.
   Recorded dialogue is keyed to the subtitle, never to a similar-sounding
   combat bark. The generated manifest lists only files actually in the build. */
(function () {
  /* Text follows the selected UI language; recorded speech is PT-BR for
     Portuguese and English for every other UI language. Never substitute a
     Portuguese recording into an English scene when a file is unavailable. */
  const language = () => /^pt(?:-|$)/i.test(SAVE.lang || '') ? 'pt-BR' : 'en';
  const lines = () => language() === 'pt-BR' ? (window.LUPUS_DIALOGUE || {}) : (window.LUPUS_DIALOGUE_EN || {});
  const lineFor = key => lines()[key];
  const known = key => !!((window.LUPUS_DIALOGUE || {})[key] || (window.LUPUS_DIALOGUE_EN || {})[key]);
  const state = { audio: null, token: 0, active: null, pending: null, native: false, paused: false };
  const native = () => window.LupusAudio && typeof window.LupusAudio.playVoice === 'function' ? window.LupusAudio : null;
  const stop = () => {
    state.token++; state.pending = null; state.active = null; state.paused = false;
    const bridge = native(); if (bridge) try { bridge.stopVoices(); } catch (e) { }
    if (state.audio) { state.audio.pause(); try { state.audio.currentTime = 0; } catch (e) { } }
    // Silence any elements left by a legacy browser-voice path as well.
    for (const name in VOX.pool) { const a = VOX.pool[name]; if (a) { a.pause(); try { a.currentTime = 0; } catch (e) { } } }
  };
  const busy = () => {
    if (!state.active) return false;
    if (state.pending || state.paused) return true;
    if (state.native) { const bridge = native(); try { if (bridge && bridge.isVoicePlaying()) return true; } catch (e) { } }
    else if (state.audio && !state.audio.ended && !state.audio.paused) return true;
    state.active = null; return false;
  };
  const play = (file, owner, authored) => {
    if (!SAVE.sfx || !file) return false;
    if (!authored && busy() && state.active.authored) return false;
    stop(); const token = state.token;
    state.active = { file, owner, authored: !!authored };
    const bridge = native(); state.native = false;
    if (bridge) try { if (bridge.playVoice(file, 0.9)) { state.native = true; return true; } } catch (e) { }
    const a = state.audio || (state.audio = new Audio());
    a.preload = 'auto'; a.src = file; a.volume = 0.9;
    a.onended = a.onerror = () => { if (token === state.token) { state.active = null; state.pending = null; } };
    try {
      const p = a.play(); if (p && p.catch) p.catch(e => {
        if (token !== state.token) return;
        if (e && e.name === 'NotAllowedError') state.pending = { token, owner };
        else state.active = null;
      });
    } catch (e) { state.active = null; return false; }
    return true;
  };
  const authored = (key, owner) => {
    const line = lineFor(key), accepted = line && line.file ? play(line.file, owner, true) : false;
    if (accepted && state.active) { state.active.key = key; state.active.language = language(); }
    return accepted;
  };
  const hydrate = b => { if (b && known(b.k)) b.vo = 'dlg_' + b.k; return b; };
  const expected = key => lineFor(key) && Number(lineFor(key).duration) || 0;
  const pause = () => {
    if (!state.active) return;
    state.paused = true; const bridge = native();
    if (state.native && bridge) try { bridge.pauseVoices(); } catch (e) { }
    else if (state.audio) state.audio.pause();
  };
  const resume = () => {
    if (!state.active || !state.paused || !SAVE.sfx || document.hidden) return;
    state.paused = false; const bridge = native();
    if (state.native && bridge) try { bridge.resumeVoices(); } catch (e) { }
    else if (state.audio) { const p = state.audio.play(); if (p && p.catch) p.catch(() => { state.active = null; }); }
  };
  const languageChanged = previous => {
    if (previous === SAVE.lang) return;
    stop();
    // Replay an interrupted subtitle in the newly selected recording language.
    if (typeof G !== 'undefined' && G) {
      if (G.talkQ && G.talkQ[0]) { G.talkQ[0]._speechStarted = false; G.talkQ[0].t = 0; }
      if (G.panel) G.panel.t = 0;
    }
    const comic = Scenes.comic, panel = comic.pg && comic.pg[comic.ci], beat = panel && panel.beats[comic.bi];
    if (Scene.name === 'comic' && comic.mode === 'panel' && beat) {
      comic.bt = 0; if (known(beat.k)) authored(beat.k, 'dlg_' + beat.k);
      if (SAVE.comicAuto) comic.autoT = Math.max(2.6 + CT(beat.k).length * 0.085, expected(beat.k) + 0.35);
    }
  };
  window.Dialogue9 = { stop, busy, play: authored, pause, resume, state, languageChanged,
    get lines() { return lines(); }, get language() { return language(); } };

  // gap=0 explicitly means no cooldown. Only repeatable combat barks use one.
  window.voice = function (name, gap) {
    if (!name || !SAVE.sfx || VOX.ok[name] === false) return false;
    if (name.indexOf('dlg_') === 0) return authored(name.slice(4), name);
    if (busy() && state.active.authored) return false;
    const who = name.split('_')[0], time = performance.now(), delay = gap == null ? 900 : Math.max(0, gap);
    if (time - (VOX.last[who] == null ? -1e9 : VOX.last[who]) < delay) return false;
    if (typeof VOX_FILES !== 'undefined' && !VOX_FILES.has(name)) return false;
    const accepted = play('assets/voice/' + name + '.ogg', name, false);
    if (accepted) VOX.last[who] = time;
    return accepted;
  };

  const C = Scenes.comic;
  const enter = C.enter, next = C.nextBeat, done = C.done, turn = C.turn, update = C.update;
  C.enter = function () { stop(); const result = enter.apply(this, arguments); for (const page of this.pg0 || []) for (const panel of page) panel.beats.forEach(hydrate); return result; };
  C.nextBeat = function () {
    stop(); const result = next.apply(this, arguments);
    const panel = this.pg && this.pg[this.ci], beat = panel && panel.beats[this.bi];
    if (this.mode === 'panel' && beat && SAVE.comicAuto && lineFor(beat.k)) this.autoT = Math.max(this.autoT, expected(beat.k) + 0.35);
    return result;
  };
  C.update = function (dt) {
    // Automatic reading must not cut off the recording. A manual tap can skip it.
    if (this.mode === 'panel' && SAVE.comicAuto && busy() && state.active.authored) this.autoT = Math.max(this.autoT, this.bt + dt + 0.15);
    return update.apply(this, arguments);
  };
  C.done = function () { stop(); return done.apply(this, arguments); };
  C.turn = function () { stop(); return turn.apply(this, arguments); };

  const oldShowPanel = window.showPanel, oldPanelAdvance = window.panelAdvance, oldPanelStep = window.panelStep;
  window.showPanel = function (img, beats, then) { stop(); beats.forEach(hydrate); return oldShowPanel.call(this, img, beats, then); };
  window.panelStep = function (dt) { return oldPanelStep.apply(this, arguments); };
  window.panelAdvance = function () {
    if (!G || !G.panel || G.panel.t < 0.35) return;
    stop(); return oldPanelAdvance.apply(this, arguments);
  };

  const oldTalk = window.talk;
  window.talk = function (speaker, key, opts) {
    return oldTalk.call(this, speaker, key, Object.assign({}, opts || {}, known(key) ? { vo: 'dlg_' + key } : {}));
  };
  window.talkStep = function (dt) {
    if (!G || !G.talkQ || !G.talkQ.length || G.title > 0.4 || G.banner || G.panel) return;
    const current = G.talkQ[0];
    if (!current._speechStarted) {
      current._speechStarted = true;
      // The radio's renderer reads dur too: keep its subtitle visible for
      // the recording, rather than fading it at the shorter text estimate.
      current.dur = Math.max(current.dur || 0, expected(current.k) + 0.25);
      if (known(current.k)) authored(current.k, current);
      else if (current.vo) voice(current.vo, 0);
    }
    current.t += dt;
    const duration = Math.max(current.dur, 1.8 + CT(current.k).length * 0.055, expected(current.k) + 0.25);
    if (current.t > duration && !(state.active && state.active.owner === current && busy())) G.talkQ.shift();
  };

  const sceneGo = Scene.go;
  Scene.go = function () { stop(); return sceneGo.apply(this, arguments); };
  const options = window.setAudioOpts;
  window.setAudioOpts = function () { if (!SAVE.sfx) stop(); return options.apply(this, arguments); };
  const playKey = Scenes.play.onKey;
  Scenes.play.onKey = function () { const result = playKey.apply(this, arguments); if (this.menu) pause(); else resume(); return result; };
  const playUpdate = Scenes.play.update;
  Scenes.play.update = function () { if (this.menu) pause(); else resume(); return playUpdate.apply(this, arguments); };
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); });
  window.addEventListener('lupus:pause', stop);
  const unlock = () => {
    if (!state.pending || !state.active || state.pending.token !== state.token || document.hidden) return;
    state.pending = null; const p = state.audio && state.audio.play();
    if (p && p.catch) p.catch(() => { state.active = null; });
  };
  document.addEventListener('pointerdown', unlock, true);
  document.addEventListener('keydown', unlock, true);

  // The score follows actual speech completion, including long recordings.
  setInterval(() => {
    const speaking = busy();
    if (speaking && typeof musDuck === 'function') musDuck(0.38, 0.25);
    if (typeof ambienceSpeechDuck === 'function') ambienceSpeechDuck(speaking);
  }, 100);
})();
