'use strict';
/* =====================================================================
   v8.1 — fixes from the first phone test
   - sound on time: inside the APK every short sound (effects, voices,
     stingers, comic one-shots) plays through Android's native low-latency
     player (SoundPool, window.LupusAudio). WebView audio stays only for
     music and ambience loops, where a few ms do not matter.
   - clues that can always be found (visible glint, walk over to pick up,
     the camera can go back, an arrow points to the missing one)
   - a block that reads as a block (energy shield + guard sound)
   - the player is marked on the floor; boss fights dim the scenery
   - John in 1944: olive uniform in the feral form, no rifle in his combo
   - Vespera's truce is now a real cutscene
   - automatic low-quality mode when the phone cannot hold the frame rate
   ===================================================================== */

/* ---------- guard pose: frame 26 (arms up in front) reads as a block; frame 41 looked like an idle/attack ---------- */
['lupus_h', 'lupus_f', 'lupus_a'].forEach(k => { const A = window.ATLAS[k]; if (A && A.a.atk1 && A.f[26]) A.a.guard = [26]; });
/* ---------- 1944 look ---------- */
if (window.ATLAS.lupus_f && !window.ATLAS.lupus44_f) window.ATLAS.lupus44_f = Object.assign({}, window.ATLAS.lupus_f);
FACE_ALIAS.lupus44_f = 'lupus_f';
/* the 1944 sheet's second hit swung a rifle he never picked up: it is now a straight punch */
if (window.ATLAS.lupus44) window.ATLAS.lupus44.a = Object.assign({}, window.ATLAS.lupus44.a, { atk2: [26, 23, 24, 25, 22] });

/* ---------- native audio ---------- */
const NAT = { on: !!(window.LupusAudio && window.LupusAudio.play), req: new Set(), keep: new Set() };
const SFXN = new Set(['hit', 'hit2', 'slash', 'jump', 'land', 'dash', 'hurt', 'shot', 'special', 'howl', 'transform', 'pick', 'boom', 'die', 'ui', 'ok', 'roar', 'heal', 'sting', 'stingBoss', 'heart', 'impact', 'alarm', 'guard']);
const VOX_FILES = new Set(["beast_defeat", "beast_intro", "brann_assist", "brann_atk1", "brann_atk2", "brann_duo", "brann_hurt", "brann_john", "brann_ko", "brann_special", "brann_tagin", "brann_victory", "construct_intro", "construct_ko", "echo_assist", "echo_atk1", "echo_atk2", "echo_duo", "echo_hurt", "echo_john", "echo_ko", "echo_special", "echo_tagin", "echo_victory", "fenrir_atk", "fenrir_hurt", "fenrir_special", "fenrir_transform", "fenrir_victory", "firstwolf_defeat", "firstwolf_intro", "kane_defeat", "kane_intro", "kreutz44_defeat", "kreutz44_intro", "kreutz44_line", "kreutz_defeat", "kreutz_intro", "leviathan_defeat", "leviathan_giant_roar", "leviathan_intro", "lupus44_atk1", "lupus44_atk2", "lupus44_hurt", "lupus44_ko", "lupus44_line1", "lupus44_line2", "lupus44_special", "lupus_assist", "lupus_atk1", "lupus_atk2", "lupus_hurt", "lupus_ko", "lupus_line_final", "lupus_line_rage", "lupus_line_remember", "lupus_senses", "lupus_special", "lupus_super", "lupus_tagin", "lupus_transform", "lupus_victory", "malakor_assist", "malakor_atk1", "malakor_atk2", "malakor_duo", "malakor_hurt", "malakor_john", "malakor_ko", "malakor_special", "malakor_tagin", "malakor_victory", "morrigan_defeat", "morrigan_intro", "nacht_defeat", "nacht_intro", "narrator_act2", "narrator_act3", "narrator_end", "narrator_open", "nereus_line1", "nereus_line2", "nereus_roar", "prime_defeat", "prime_intro", "soldier_alert", "soldier_ko", "thule_laugh", "thule_line1", "thule_line2", "thule_line3", "thule_reveal", "triton_assist", "triton_atk1", "triton_atk2", "triton_duo", "triton_hurt", "triton_john", "triton_ko", "triton_special", "triton_tagin", "triton_victory", "vespera_assist", "vespera_atk1", "vespera_atk2", "vespera_duo", "vespera_hurt", "vespera_john", "vespera_ko", "vespera_special", "vespera_tagin", "vespera_victory", "voss_defeat", "voss_intro", "warden_defeat", "warden_intro"]);
const STINGS = ['sting_boss', 'sting_clear', 'sting_duo', 'sting_fenrir', 'sting_impact', 'sting_reveal', 'sting_transform', 'sting_wave'];
const pSfx = n => 'assets/sfxn/' + n + '.ogg', pVox = n => 'assets/voice/' + n + '.ogg', pSnd = n => 'assets/sfx/' + n + '.ogg', pSting = n => 'assets/music/' + n + '.ogg';
function natPre(paths, keep) {
  if (!NAT.on) return; const want = [];
  for (const p of paths) { if (keep) NAT.keep.add(p); if (!NAT.req.has(p)) { NAT.req.add(p); want.push(p); } }
  if (want.length) try { window.LupusAudio.preload(want.join(',')); } catch (e) { }
}
/* free the voices and one-shots the next scene does not use (effects and stingers stay loaded) */
function natOnly(paths) {
  if (!NAT.on) return; const need = new Set(paths), drop = [];
  for (const p of NAT.req) if (!NAT.keep.has(p) && !need.has(p)) drop.push(p);
  drop.forEach(p => NAT.req.delete(p));
  if (drop.length) try { window.LupusAudio.unload(drop.join(',')); } catch (e) { }
  natPre(paths);
}
function natPlay(path, vol, rate) {
  if (!NAT.on) return false;
  if (!NAT.req.has(path)) { natPre([path]); return false; }
  try { return !!window.LupusAudio.play(path, vol, rate || 1); } catch (e) { return false; }
}
if (NAT.on) natPre([...SFXN].map(pSfx).concat(STINGS.map(pSting)), true);

/* v8.1: a short shimmer when the guard goes up */
SFX.guard = function () { tone(300, 0.09, 'triangle', 0.13, 220); noise(0.07, 0.16, 5200, null, null, 'highpass'); };
const _sfx0 = window.sfx;
window.sfx = function (n) {
  if (!SAVE.sfx) return;
  if (NAT.on && SFXN.has(n)) { const r = (n === 'hit' || n === 'hit2' || n === 'slash') ? 0.94 + Math.random() * 0.12 : 1; if (natPlay(pSfx(n), 1, r)) return; }
  _sfx0(n);
};
const _voice0 = window.voice;
window.voice = function (n, gap) {
  if (!n || !SAVE.sfx || VOX.ok[n] === false) return;
  if (NAT.on && VOX_FILES.has(n)) {
    const now = performance.now(), who = n.split('_')[0];
    if (now - (VOX.last[who] || -1e9) < (gap || 900)) return;
    if (natPlay(pVox(n), 0.9)) { VOX.last[who] = now; return; }
  }
  _voice0(n, gap);
};
const _sting0 = window.playSting;
window.playSting = function (n) { if (!SAVE.music) return; if (NAT.on && STINGS.includes(n) && natPlay(pSting(n), 0.8)) return; _sting0(n); };
const _story0 = window.storySnd;
window.storySnd = function (n) { if (!n || !SAVE.sfx) return; if (NAT.on && SFX_FILES.has(n) && !n.startsWith('amb_') && natPlay(pSnd(n), 0.65)) return; _story0(n); };

/* what each scene will need, loaded ahead of time */
(function () {
  const C = Scenes.comic, pre = C.preSnd;
  C.preSnd = function () {
    if (NAT.on) { const L = []; for (const pg of this.pg0) for (const p of pg) for (const b of p.beats) { if (b.vo && VOX_FILES.has(b.vo)) L.push(pVox(b.vo)); if (b.snd && SFX_FILES.has(b.snd)) L.push(pSnd(b.snd)); } natOnly(L); }
    return pre.call(this);
  };
  const P = Scenes.play, enter = P.enter;
  P.enter = function (arg) {
    const r = enter.apply(this, arguments);
    if (NAT.on && G) {
      const L = [], add = n => VOX_FILES.has(n) && L.push(pVox(n));
      const ids = new Set(G.team.map(h => h.id)); if (G.st && G.st.id === 2) ids.add('vespera');
      for (const id of ids) {
        const sets = id === 'lupus' ? ['lupus', 'lupus44', 'fenrir'] : [id];
        for (const s of sets) ['atk', 'atk1', 'atk2', 'hurt', 'ko', 'special', 'tagin', 'assist', 'victory', 'transform', 'super', 'senses', 'john', 'duo', 'line1', 'line2', 'line_rage', 'line_final', 'line_remember'].forEach(l => add(s + '_' + l));
      }
      const B = G.st && BOSS[G.st.boss]; if (B) { const v = B.vox || G.st.boss; add(v + '_intro'); add(v + '_defeat'); add(v + '_ko'); }
      ['soldier_alert', 'soldier_ko', 'kreutz44_defeat', 'kreutz44_intro', 'leviathan_giant_roar', 'nereus_roar', 'warden_intro', 'warden_defeat'].forEach(add);
      natOnly(L);
    }
    return r;
  };
})();

/* ---------- the player is always easy to spot; the guard reads as a guard ---------- */
const _setSt0 = window.setSt;
window.setSt = function (e, st, t) { if (st === 'guard' && e && e.kind === 'hero' && e.st !== 'guard' && e.isPlayer) sfx('guard'); return _setSt0(e, st, t); };
function drawPlayerMark(g, e, cam) {
  const x = e.x - cam, y = e.y + 1, k = 0.5 + 0.5 * Math.sin(G.time * 5), col = e.id === 'lupus' ? '#ffd23a' : (HERO[e.id] || {}).color || '#ffd23a';
  g.save(); g.globalAlpha = (G.boss && !G.boss.dead) || G.mini || G.locked ? 0.8 : 0.5; g.strokeStyle = col; g.lineWidth = 1.5;
  g.beginPath(); g.ellipse(x, y, 17 + k * 1.5, 5.5 + k * 0.5, 0, 0, 6.283); g.stroke();
  g.globalAlpha *= 0.35; g.fillStyle = col; g.beginPath(); g.ellipse(x, y, 15, 4.6, 0, 0, 6.283); g.fill(); g.restore();
}
function drawGuard(g, e, cam) {
  const sc = depthScale(e.y), hh = entHeight(e) * 0.5 * sc, x = e.x - cam + e.face * 15 * sc, y = e.y - e.z - hh * 0.5;
  const hit = e.guardHitT && G.time - e.guardHitT < 0.2, k = 0.5 + 0.5 * Math.sin(G.time * 12), ry = hh * 0.6, rx = 10 * sc;
  g.save(); g.globalCompositeOperation = 'lighter';
  const gr = g.createRadialGradient(x, y, 1, x, y, ry); gr.addColorStop(0, 'rgba(154,180,255,0.6)'); gr.addColorStop(1, 'rgba(154,180,255,0)');
  g.globalAlpha = hit ? 1 : 0.85; g.fillStyle = gr; g.beginPath(); g.ellipse(x, y, rx, ry, 0, -Math.PI / 2, Math.PI / 2, e.face < 0); g.closePath(); g.fill();
  g.strokeStyle = hit ? '#ffffff' : '#b8ccff'; g.lineWidth = hit ? 2.5 : 2; g.globalAlpha = hit ? 1 : 0.7 + 0.3 * k;
  g.beginPath(); g.ellipse(x, y, rx, ry, 0, -Math.PI / 2, Math.PI / 2, e.face < 0); g.stroke();
  g.globalAlpha *= 0.6; g.beginPath(); g.ellipse(x - e.face * 3, y, rx * 0.7, ry * 0.8, 0, -Math.PI / 2, Math.PI / 2, e.face < 0); g.stroke();
  g.restore();
}
const _drawEnt0 = window.drawEnt;
window.drawEnt = function (g, e, cam) {
  if (Scene.name === 'play' && G && e === G.player && e.kind === 'hero' && !e.dead && !G.superFx) drawPlayerMark(g, e, cam);
  const r = _drawEnt0(g, e, cam);
  if (Scene.name === 'play' && G && e.kind === 'hero' && e.st === 'guard' && !e.dead) drawGuard(g, e, cam);
  return r;
};

/* ---------- boss fights: calmer scenery so the fighters stand out ---------- */
const fightOn = () => Scene.name === 'play' && G && ((G.boss && !G.boss.dead && G.boss.bossIn <= 0) || (G.mini && !G.mini.dead));
const _bgBack0 = BG.back;
BG.back = function (g, camX, dt) {
  _bgBack0.call(this, g, camX, dt);
  if (Scene.name !== 'play' || !G) return;
  G.dimK = clamp((G.dimK || 0) + (fightOn() ? 0.025 : -0.025), 0, 1);
  if (G.dimK > 0) { g.save(); g.fillStyle = 'rgba(4,2,10,' + (0.28 * G.dimK).toFixed(3) + ')'; g.fillRect(-40, -40, VW + 80, VH + 80); g.restore(); }
};
BG.front = function (g, camX) {
  const n = BG.n; let c = BG.frontC[n];
  if (!c) { const im = ART.img['s' + n + '_l4']; if (!im || !im.ok) return; c = document.createElement('canvas'); c.width = im.width; c.height = im.height; const x = c.getContext('2d'); x.drawImage(im, 0, 0);
    x.globalCompositeOperation = 'destination-out'; const gr = x.createLinearGradient(0, im.height * 0.8, 0, im.height); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,1)'); x.fillStyle = gr; x.fillRect(0, im.height * 0.8, im.width, im.height * 0.2);
    x.globalCompositeOperation = 'source-atop'; x.fillStyle = 'rgba(4,2,10,0.55)'; x.fillRect(0, 0, im.width, im.height); BG.frontC[n] = c; }
  /* foreground pillars fade out while a fight is on, so they never hide the action */
  const fight = Scene.name === 'play' && G && (G.locked || fightOn());
  if (G) G.frontA = lerp(G.frontA == null ? 0.9 : G.frontA, fight ? 0.22 : 0.9, 0.06);
  drawTiled(g, c, camX, 1.35, 0, TILE_W, VIEW_H, G ? G.frontA : 0.9, 2);
};

/* ---------- stage 2: clues ---------- */
(function () {
  const M = MECH.investigate; if (!M) return;
  const nextClue = () => { const p = G.player; let best = null, bd = 1e9; for (const c of G.clues || []) { if (c.got) continue; const d = Math.abs(c.x - p.x); if (d < bd) { bd = d; best = c; } } return best; };
  M.update = function () {
    const p = G.player;
    for (const c of G.clues) {
      if (c.got || p.dead) continue;
      /* walking over it is enough; the senses show the way */
      if (Math.abs(p.x - c.x) < 30 && Math.abs(p.y - c.y) < 22) { c.got = true; G.clueN++; sfx('ok'); ringFx(c.x, c.y, 6, 60, '#ff2040', 0.5); textFx(c.x, c.y - 60, T('clue') + ' ' + G.clueN + '/3', '#ff4060', 2); talk('lupus_h', ['r02c', 'r02d', 'r02e'][G.clueN - 1]); }
    }
    if (G.clueN === 1 && !G.wingHint) { G.wingHint = true; later(() => talk('lupus_h', 'r02b'), 2500); }
  };
  M.drawBack = function (g, cam) {
    const k = G.senseK || 0, p = G.player;
    /* always visible: a pulsing red glint where something can be found */
    for (const c of G.clues) {
      if (c.got) continue; const x = c.x - cam; if (x < -40 || x > VW + 40) continue; const tw = 0.5 + 0.5 * Math.sin(G.time * 4 + c.i * 2.1);
      const ph = (G.time * 0.9 + c.i * 0.33) % 1, by = c.y - 14 - Math.sin(G.time * 3 + c.i) * 2;
      g.save(); RD.glow(g, x, c.y - 8, 22 + 6 * tw, '#ff2040', 0.5 + 0.3 * tw);
      /* a ring on the floor that keeps pulsing outward: "something is here" */
      g.strokeStyle = '#ff3050'; g.lineWidth = 1.5; g.globalAlpha = 0.8 * (1 - ph); g.beginPath(); g.ellipse(x, c.y, 6 + ph * 22, 2 + ph * 7, 0, 0, 6.283); g.stroke();
      g.globalAlpha = 0.95; g.fillStyle = '#000'; g.fillRect(x - 7, by - 2, 14, 17); g.fillStyle = '#ff3a50'; g.fillRect(x - 6, by - 1, 12, 15); g.fillStyle = '#b0001c'; g.fillRect(x - 5, by, 10, 13);
      /* a magnifying glass: this is evidence, not a health pack */
      g.strokeStyle = '#ffffff'; g.lineWidth = 1.5; g.beginPath(); g.arc(x - 0.5, by + 5, 3, 0, 6.283); g.stroke(); g.beginPath(); g.moveTo(x + 1.6, by + 7.2); g.lineTo(x + 3.6, by + 10.5); g.stroke();
      const s = 2 + 4 * tw; g.globalAlpha = 0.45 + 0.55 * tw; g.fillStyle = '#ffffff'; g.fillRect(x + 7 - s, by - 4, s * 2, 1.5); g.fillRect(x + 7 - 0.75, by - 4 - s, 1.5, s * 2);
      g.restore();
    }
    if (k < 0.05) return; const next = nextClue();
    g.save(); g.globalAlpha = k;
    if (next) { const n = 18, dx = next.x - p.x, dy = next.y - p.y; for (let i = 1; i <= n; i++) { const q = i / n, x = p.x + dx * q - cam, y = p.y + dy * q + Math.sin(i * 1.7) * 3; if (i % 2) { g.fillStyle = '#c0001c'; g.fillRect(x - 1.5, y - 0.5, 3, 1.5); } } }
    for (const c of G.clues) { if (c.got) continue; const x = c.x - cam; RD.glow(g, x, c.y - 6, 22, '#ff2040', 0.6 + 0.3 * Math.sin(G.time * 6)); }
    g.restore();
  };
  M.hud = function (g) { PIX.text(g, T('clue') + ' ' + G.clueN + '/3', VW - 8, 56, { align: 'r', col: '#ff4060', out: '#0c0710' }); };
  /* Vespera stops mid-fight: now shown as a cutscene, so the alliance has its reason on screen */
  M.yieldMini = function (e) {
    later(() => {
      if (G.over) return;
      showPanel('cs42', [{ t: 'cap', k: 'r02x' }, { t: 'say', spk: 'vespera', k: 'r02f' }, { t: 'say', spk: 'lupus_h', k: 'r02g' }, { t: 'say', spk: 'vespera', k: 'r02h' }], () => {
        if (!G) return; e.dead = true; e.deadT = 100; e.hp = 0; G.mini = null; ringFx(e.x, e.y, 10, 60, '#ff3ad0', 0.5);
        const a = makeHero('vespera', false, e.x, e.y); a.bench = true; G.ally = a; G.team.push(a); G.duelHold = false; G.banner2 = { t: 0, txt: T('joined').replace('{n}', 'VESPERA') }; sfx('ok');
      });
    }, 500);
  };
})();

/* ---------- every stage whose exit needs 3 things (clues, incubators, towers, reactors):
   while one is missing the camera can scroll back, and an arrow at the screen edge points to it ---------- */
(function () {
  const LEFT = {
    investigate: [() => (G.clues || []).filter(c => !c.got), 'clue', '#ff4060'],
    sabotage: [() => (G.incubs || []).filter(o => !o.dead), 'obj_incub', '#a7ff1a'],
    siege: [() => (G.towers || []).filter(o => !o.dead), 'obj_tower', '#ff8a3a'],
    reactors: [() => (G.reacts || []).filter(o => !o.dead), 'obj_reactor', '#ff5a2a']
  };
  function edgeArrow(g, list, label, col) {
    if (!list.length || G.locked || G.bossSpawned) return; const p = G.player;
    let c = list[0]; for (const o of list) if (Math.abs(o.x - p.x) < Math.abs(c.x - p.x)) c = o;
    const sx = c.x - G.camX; if (sx > 12 && sx < VW - 12) return;
    const left = sx <= 12, ax = left ? 14 : VW - 14, ay = 128; if (Math.sin(G.time * 7) < -0.2) return;
    g.save(); g.fillStyle = '#000'; g.beginPath(); if (left) { g.moveTo(ax - 9, ay); g.lineTo(ax + 5, ay - 9); g.lineTo(ax + 5, ay + 9); } else { g.moveTo(ax + 9, ay); g.lineTo(ax - 5, ay - 9); g.lineTo(ax - 5, ay + 9); } g.fill();
    g.fillStyle = col; g.beginPath(); if (left) { g.moveTo(ax - 6, ay); g.lineTo(ax + 3, ay - 6); g.lineTo(ax + 3, ay + 6); } else { g.moveTo(ax + 6, ay); g.lineTo(ax - 3, ay - 6); g.lineTo(ax - 3, ay + 6); } g.fill(); g.restore();
    PIX.text(g, T(label), left ? ax + 8 : ax - 8, ay - 4, { align: left ? 'l' : 'r', col, out: '#000' });
  }
  for (const k in LEFT) {
    const M = MECH[k]; if (!M) continue; const [list, label, col] = LEFT[k], hud0 = M.hud;
    M.backtrack = () => list().length > 0;
    M.hud = function (g) { if (hud0) hud0.call(this, g); edgeArrow(g, list(), label, col); };
  }
})();

/* ---------- keep the frame rate: drop the heaviest effects on slow phones ---------- */
const PERF = { last: 0, ema: 1 / 60, slowT: 0, low: !!SAVE.perfLow };
if (PERF.low) { window.DPR_CAP = 2; resize(); }
const _reflect0 = ART.reflect;
ART.reflect = function () { if (PERF.low) return; return _reflect0.apply(this, arguments); };
(function () {
  const P = Scenes.play, up = P.update;
  P.update = function (dt) {
    const now = performance.now(), d = PERF.last ? (now - PERF.last) / 1000 : 1 / 60; PERF.last = now;
    if (d < 0.25) { PERF.ema += (d - PERF.ema) * 0.05; if (!PERF.low && G && !G.panel && PERF.ema > 1 / 42) { PERF.slowT += d; if (PERF.slowT > 4) { PERF.low = true; SAVE.perfLow = true; saveGame(); window.DPR_CAP = 2; resize(); } } else PERF.slowT = Math.max(0, PERF.slowT - d * 0.5); }
    return up.call(this, dt);
  };
})();
