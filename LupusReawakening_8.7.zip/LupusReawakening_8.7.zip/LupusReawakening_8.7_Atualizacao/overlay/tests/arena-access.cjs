'use strict';
const assert = require('node:assert/strict');
const { createRuntime } = require('./runtime.cjs');

/* Integration fixtures place a stationary enemy at each edge permitted by real
 * enemy physics, then use actual keyboard input and a normal attack. No player
 * teleport is used during combat. Enemy AI is paused only to keep the target at
 * the boundary; real updates, movement, bounds and damage still run. */
async function main() {
  const r = createRuntime(); await r.settle();
  let checks = 0;
  console.log('TAP version 13');
  for (const width of [480, 600, 624]) for (const side of [-1, 1]) for (const y of [196, 232, 262]) {
    r.resize(width * 2, 540); await r.play(0);
    r.run(`{
      SAVE.sfx=false; SAVE.music=false; G.title=0; G.props=[];
      startWave(G.st.waves[0]); G.spawnQ=[]; G.enemies=[];
      Object.assign(G.player,{x:VW/2,y:${y},inv:999});
      const e=spawnEnemy('S',${side});
      Object.assign(e,{x:${side}<0?-999:9999,y:${y},arrive:false,ai:'audit',hp:1000,maxhp:1000,cd:999});
      window.reachTarget=e;
    }`);
    r.tick();
    const cam = r.run('G.camX'), wave = r.run('G.waveIdx');
    const key = side < 0 ? 'ArrowLeft' : 'ArrowRight';
    r.dispatch('keydown', { key });
    let frames = 0;
    for (; frames < 500 && r.run('Math.abs(G.player.x-reachTarget.x)>20'); frames++) r.tick();
    r.dispatch('keyup', { key });
    assert.ok(frames < 500, `Player cannot reach an edge enemy: width ${width}, side ${side}, depth ${y}`);
    r.dispatch('keydown', { key: 'j' }); r.tick(); r.dispatch('keyup', { key: 'j' }); r.tick(30);
    assert.ok(r.run('reachTarget.hp<1000'), `A normal attack cannot damage the edge enemy: ${width}/${side}/${y}`);
    assert.equal(r.run('G.camX'), cam, 'Combat movement scrolled into the next block');
    assert.equal(r.run('G.waveIdx'), wave, 'Combat movement skipped a pending enemy');
    assert.ok(r.run('G.locked'), 'A living target released the block');
    console.log(`ok ${++checks} - keyboard movement and normal attack reach the ${side < 0 ? 'left' : 'right'} edge enemy at width ${width}, depth ${y}, without advancing pending combat`);
  }
  assert.deepEqual(r.json('window.__err||[]'), []);
  assert.deepEqual([...r.missing], []);
  console.log(`1..${checks}\n# ${checks} passed, 0 failed`);
}
main().catch(error => { console.error(error.stack); process.exitCode = 1; });
