/* Retired in 8.4: procedural chain accessories removed. */
