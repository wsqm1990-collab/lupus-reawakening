'use strict';
/* ===== CORE: screen scaling, input, save, scenes, audio ===== */
const VH = 270;
let VW = 480;
const cv = document.getElementById('c');
const ctx = cv.getContext('2d');
const [BUF, bg] = PIX.canvas(1248, VH * 2);   // 2x frame buffer (540 px tall)
let SCALE = 1, OX = 0, OY = 0, PORTRAIT = false;
function resize() {
  const dpr = Math.min(window.devicePixelRatio || 1, 3);
  const iw = window.innerWidth, ih = window.innerHeight;
  PORTRAIT = ih > iw * 1.05;
  VW = Math.round(Math.min(624, Math.max(480, VH * iw / ih)));
  cv.width = Math.round(iw * dpr); cv.height = Math.round(ih * dpr);
  cv.style.width = iw + 'px'; cv.style.height = ih + 'px';
  SCALE = Math.min(cv.width / VW, cv.height / VH);
  OX = Math.round((cv.width - VW * SCALE) / 2); OY = Math.round((cv.height - VH * SCALE) / 2);
  cv._dpr = dpr;
}
window.addEventListener('resize', resize);
window.addEventListener('orientationchange', () => setTimeout(resize, 200));
resize();

const rnd = (a, b) => a + Math.random() * (b - a);
const rndi = (a, b) => Math.floor(rnd(a, b + 1));
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const pick = a => a[Math.floor(Math.random() * a.length)];
const dist = (a, b) => Math.hypot(a.x - b.x, (a.y - b.y) * 1.7);

/* ---------- save ---------- */
const SAVE_KEY = 'lupus_reawakening_v2';
let SAVE = { unlocked: 1, hero: 'lupus', ally: 'vespera', up: { dmg: 0, hp: 0, fury: 0, cd: 0 }, seenIntro: false, lang: 'en', music: true, sfx: true, best: {} };
function loadSave() { try { const s = JSON.parse(localStorage.getItem(SAVE_KEY)); if (s) SAVE = Object.assign(SAVE, s, { up: Object.assign(SAVE.up, s.up || {}) }); } catch (e) { } }
function saveGame() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(SAVE)); } catch (e) { } }
loadSave();

/* ---------- scenes ---------- */
const Scenes = {};
const Scene = { cur: null, name: '', fade: 0, go(name, arg) { Scene.name = name; Scene.cur = Scenes[name]; Scene.fade = 1; Inp.reset(); Scene.cur.enter && Scene.cur.enter(arg); } };

/* ---------- input ---------- */
const Inp = {
  keys: {}, edge: {}, held: {}, joy: { id: null, ox: 0, oy: 0, x: 0, y: 0, ax: 0, ay: 0 }, btnIds: {},
  reset() { this.edge = {}; this.held = {}; this.keys = {}; this.joy.id = null; this.joy.ax = this.joy.ay = 0; this.btnIds = {}; }
};
const keyMap = { ArrowLeft: 'l', ArrowRight: 'r', ArrowUp: 'u', ArrowDown: 'd', a: 'l', d: 'r', w: 'u', s: 'd', A: 'l', D: 'r', W: 'u', S: 'd',
  j: 'atk', J: 'atk', z: 'atk', Z: 'atk', k: 'jump', K: 'jump', x: 'jump', X: 'jump', l: 'spec', L: 'spec', c: 'spec', C: 'spec', ' ': 'dash', Shift: 'dash', e: 'form', E: 'form', Tab: 'form', v: 'form', V: 'form', q: 'tag', Q: 'tag', f: 'assist', F: 'assist' };
window.addEventListener('keydown', e => {
  audioInit();
  if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') { Scene.cur && Scene.cur.onKey && Scene.cur.onKey('pause'); }
  if (e.key === 'Enter') { Scene.cur && Scene.cur.onKey && Scene.cur.onKey('ok'); }
  const m = keyMap[e.key]; if (!m) return; e.preventDefault();
  if (!Inp.keys[m]) Inp.edge[m] = true; Inp.keys[m] = true; Inp.held[m] = true;
});
window.addEventListener('keyup', e => { const m = keyMap[e.key]; if (m) { Inp.keys[m] = false; Inp.held[m] = false; } });
function toLogical(e) { return { x: (e.clientX * cv._dpr - OX) / SCALE, y: (e.clientY * cv._dpr - OY) / SCALE }; }
cv.addEventListener('pointerdown', e => { e.preventDefault(); audioInit(); try { cv.setPointerCapture(e.pointerId); } catch (_) { } const p = toLogical(e); Scene.cur && Scene.cur.onDown && Scene.cur.onDown(e.pointerId, p.x, p.y); });
cv.addEventListener('pointermove', e => { e.preventDefault(); const p = toLogical(e); Scene.cur && Scene.cur.onMove && Scene.cur.onMove(e.pointerId, p.x, p.y); });
cv.addEventListener('pointerup', e => { e.preventDefault(); const p = toLogical(e); Scene.cur && Scene.cur.onUp && Scene.cur.onUp(e.pointerId, p.x, p.y); });
cv.addEventListener('pointercancel', e => { Scene.cur && Scene.cur.onUp && Scene.cur.onUp(e.pointerId, -1, -1); });
cv.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('visibilitychange', () => { if (document.hidden && Scene.cur && Scene.cur.onKey) Scene.cur.onKey('hide'); if (AU.c) { if (document.hidden) AU.c.suspend(); else AU.c.resume(); } });

/* ---------- audio (procedural) ---------- */
const AU = { c: null, master: null, mus: null, sfx: null, step: 0, next: 0, timer: null, stage: 0, playing: false };
function audioInit() {
  if (AU.c) { if (AU.c.state === 'suspended') AU.c.resume(); return; }
  try {
    AU.c = new (window.AudioContext || window.webkitAudioContext)();
    AU.master = AU.c.createGain(); AU.master.gain.value = 0.7; AU.master.connect(AU.c.destination);
    AU.mus = AU.c.createGain(); AU.mus.gain.value = SAVE.music ? 0.32 : 0; AU.mus.connect(AU.master);
    AU.sfx = AU.c.createGain(); AU.sfx.gain.value = SAVE.sfx ? 0.8 : 0; AU.sfx.connect(AU.master);
    const len = AU.c.sampleRate; AU.nbuf = AU.c.createBuffer(1, len, AU.c.sampleRate);
    const d = AU.nbuf.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    if (AU.wantMusic != null) musicStart(AU.wantMusic);
  } catch (e) { AU.c = null; }
}
function setAudioOpts() { if (!AU.c) return; AU.mus.gain.value = SAVE.music ? 0.32 : 0; AU.sfx.gain.value = SAVE.sfx ? 0.8 : 0; }
function tone(f, d, type, v, slide, dest, when) {
  if (!AU.c) return; const t = when || AU.c.currentTime;
  const o = AU.c.createOscillator(), g = AU.c.createGain();
  o.type = type || 'square'; o.frequency.setValueAtTime(f, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f + slide), t + d);
  g.gain.setValueAtTime(v || 0.2, t); g.gain.exponentialRampToValueAtTime(0.0008, t + d);
  o.connect(g); g.connect(dest || AU.sfx); o.start(t); o.stop(t + d + 0.02);
}
function noise(d, v, fq, dest, when, type) {
  if (!AU.c) return; const t = when || AU.c.currentTime;
  const s = AU.c.createBufferSource(); s.buffer = AU.nbuf; const f = AU.c.createBiquadFilter(); f.type = type || 'lowpass'; f.frequency.value = fq || 2000;
  const g = AU.c.createGain(); g.gain.setValueAtTime(v || 0.3, t); g.gain.exponentialRampToValueAtTime(0.0008, t + d);
  s.connect(f); f.connect(g); g.connect(dest || AU.sfx); s.start(t, Math.random() * 0.5); s.stop(t + d + 0.02);
}
const SFX = {
  hit() { noise(0.09, 0.5, 2400); tone(150, 0.09, 'square', 0.22, -90); },
  hit2() { noise(0.14, 0.7, 1600); tone(90, 0.16, 'sawtooth', 0.3, -50); },
  slash() { noise(0.12, 0.25, 6000, null, null, 'highpass'); tone(600, 0.1, 'sawtooth', 0.08, -400); },
  jump() { tone(260, 0.12, 'triangle', 0.14, 260); },
  land() { noise(0.06, 0.2, 500); },
  dash() { noise(0.18, 0.25, 3000, null, null, 'bandpass'); },
  hurt() { tone(220, 0.18, 'sawtooth', 0.25, -150); noise(0.1, 0.3, 1200); },
  shot() { tone(900, 0.12, 'square', 0.1, -700); noise(0.05, 0.2, 4000, null, null, 'highpass'); },
  special() { tone(110, 0.5, 'sawtooth', 0.3, 330); noise(0.4, 0.3, 1200); },
  howl() { tone(240, 0.9, 'sawtooth', 0.28, 160); tone(235, 0.9, 'triangle', 0.22, 150); noise(0.5, 0.3, 800); },
  transform() { tone(70, 0.8, 'sawtooth', 0.35, 200); noise(0.7, 0.4, 500); tone(400, 0.5, 'square', 0.1, -300); },
  pick() { tone(660, 0.1, 'triangle', 0.2); tone(990, 0.16, 'triangle', 0.2, 0, null, AU.c ? AU.c.currentTime + 0.08 : 0); },
  boom() { noise(0.6, 0.8, 400); tone(60, 0.6, 'sawtooth', 0.4, -30); },
  die() { tone(180, 0.35, 'sawtooth', 0.25, -150); noise(0.25, 0.4, 900); },
  ui() { tone(520, 0.07, 'square', 0.12); },
  ok() { tone(440, 0.07, 'square', 0.13); tone(880, 0.1, 'square', 0.13, 0, null, AU.c ? AU.c.currentTime + 0.07 : 0); },
  roar() { tone(80, 1.2, 'sawtooth', 0.4, 60); noise(1.0, 0.5, 600); },
  heal() { tone(520, 0.2, 'sine', 0.2, 300); tone(780, 0.3, 'sine', 0.2, 300); },
  alarm() { tone(440, 0.2, 'square', 0.12); tone(330, 0.3, 'square', 0.12, 0, null, AU.c ? AU.c.currentTime + 0.2 : 0); }
};
function sfx(n) { if (AU.c && SAVE.sfx && SFX[n]) SFX[n](); }

/* music: tiny step-sequencer, darker per stage */
const MUS = [
  { root: 45, scale: [0, 3, 5, 7, 10], bpm: 104 }, { root: 43, scale: [0, 3, 5, 6, 10], bpm: 100 }, { root: 40, scale: [0, 2, 3, 7, 8], bpm: 92 },
  { root: 38, scale: [0, 1, 5, 7, 10], bpm: 108 }, { root: 36, scale: [0, 1, 3, 6, 7], bpm: 116 }, { root: 41, scale: [0, 3, 5, 7, 10], bpm: 84 }
];
const mf = n => 440 * Math.pow(2, (n - 69) / 12);
const BASSP = [0, -1, 0, 2, 0, -1, 3, 2, 0, -1, 0, 4, 2, -1, 3, 1];
function musicStart(i) {
  AU.wantMusic = i; if (!AU.c) return; AU.stage = i; AU.playing = true; AU.step = 0; AU.next = AU.c.currentTime + 0.1;
  if (!AU.timer) AU.timer = setInterval(musicTick, 80);
}
function musicStop() { AU.playing = false; AU.wantMusic = null; }
function musicTick() {
  if (!AU.c || !AU.playing) return;
  const m = MUS[AU.stage % MUS.length], dur = 60 / m.bpm / 2;
  while (AU.next < AU.c.currentTime + 0.25) {
    const s = AU.step, t = AU.next;
    const b = BASSP[s % 16];
    if (b >= 0) { const n = m.root + m.scale[b % m.scale.length]; tone(mf(n), dur * 1.4, 'sawtooth', 0.22, 0, AU.mus, t); tone(mf(n + 12), dur * 0.5, 'square', 0.04, 0, AU.mus, t); }
    if (s % 8 === 0) { tone(120, 0.18, 'sine', 0.5, -80, AU.mus, t); }
    if (s % 8 === 4) { noise(0.12, 0.28, 2500, AU.mus, t, 'bandpass'); }
    if (s % 2 === 1) { noise(0.03, 0.1, 8000, AU.mus, t, 'highpass'); }
    if (s % 16 === 0) { for (const k of [0, 2, 4]) tone(mf(m.root + 24 + m.scale[k]), dur * 14, 'triangle', 0.035, 0, AU.mus, t); }
    if (s % 16 === 8 && AU.stage >= 1) { tone(mf(m.root + 36 + m.scale[(s / 8 | 0) % 5]), dur * 3, 'sine', 0.05, 0, AU.mus, t + dur); }
    AU.step++; AU.next += dur;
  }
}

