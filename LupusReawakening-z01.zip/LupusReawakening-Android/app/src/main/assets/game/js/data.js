'use strict';
/* ===== DATA: text, heroes, enemies, bosses, stages ===== */
const STR = {
  pt: {
    tapStart: 'TOQUE PARA COMEÇAR', skip: 'PULAR >', tapNext: 'TOQUE PARA CONTINUAR', selectHero: 'ESCOLHA SEU CAÇADOR', selectAlly: 'ESCOLHA SEU ALIADO (IA)',
    tapAgain: 'TOQUE DE NOVO PARA CONFIRMAR', back: '< VOLTAR', stages: 'MAPA DA CAÇADA', locked: 'BLOQUEADA', best: 'RECORDE', stage: 'FASE', go: 'VAI', paused: 'PAUSA', resume: 'CONTINUAR', restart: 'REINICIAR FASE',
    quit: 'MAPA', music: 'MÚSICA', sfx: 'EFEITOS', lang: 'IDIOMA: PORTUGUÊS', on: 'SIM', off: 'NÃO', gameOver: 'VOCÊ CAIU', retry: 'TENTAR DE NOVO', menu: 'MAPA',
    clear: 'FASE COMPLETA', score: 'PONTOS', time: 'TEMPO', maxCombo: 'COMBO', pickUp: 'ESCOLHA UMA MELHORIA', up_dmg: 'GARRAS AFIADAS', up_dmg_d: '+15% DE DANO',
    up_hp: 'VITALIDADE', up_hp_d: '+20% DE VIDA', up_fury: 'SEDE DE SANGUE', up_fury_d: '+25% DE FÚRIA', up_cd: 'INSTINTO', up_cd_d: '-20% RECARGA',
    human: 'HUMANO', feral: 'FERAL', ascended: 'ASCENDIDO', form: 'FORMA', fury: 'FÚRIA', hits: 'GOLPES', combo: ['', 'BOM', 'BRUTAL', 'SELVAGEM!', 'IMPARÁVEL!'], counter: 'CONTRA-ATAQUE!',
    bossWarn: 'ALERTA DE CHEFE', theEnd: 'FIM', end1: 'A BESTA PRIMORDIAL CAIU.', end2: 'A CABALA SANGRA... MAS ALGUMAS FERAS NUNCA MORREM.', thanks: 'OBRIGADO POR JOGAR', newGame: 'APAGAR PROGRESSO', rotate: 'GIRE O APARELHO',
    down: 'CAÍDO', hint1: 'SEGURE ATK PARA COMBO', hint2: 'FÚRIA CHEIA? TOQUE FORMA!', objective: 'OBJETIVO', options: 'OPÇÕES', start: 'COMEÇAR', loading: 'INVOCANDO A FERA...',
    sp_h: 'CORRENTE', sp_f: 'URRO', sp_a: 'DILACERAR', sp_vespera: 'ESPIRAL', sp_triton: 'MARÉ', sp_malakor: 'BARREIRA', p2: 'ENFURECIDO', block: 'BLOQUEIO', heal: 'CURA',
    stats: ['FORÇA', 'VELOCIDADE', 'ALCANCE', 'DEFESA', 'SUPORTE'], ai: 'IA'
  },
  en: {
    tapStart: 'TAP TO START', skip: 'SKIP >', tapNext: 'TAP TO CONTINUE', selectHero: 'SELECT YOUR HUNTER', selectAlly: 'CHOOSE YOUR ALLY (AI)',
    tapAgain: 'TAP AGAIN TO CONFIRM', back: '< BACK', stages: 'HUNT MAP', locked: 'LOCKED', best: 'BEST', stage: 'STAGE', go: 'GO', paused: 'PAUSED', resume: 'RESUME', restart: 'RESTART STAGE',
    quit: 'MAP', music: 'MUSIC', sfx: 'SFX', lang: 'LANGUAGE: ENGLISH', on: 'ON', off: 'OFF', gameOver: 'YOU FELL', retry: 'TRY AGAIN', menu: 'MAP',
    clear: 'STAGE CLEAR', score: 'SCORE', time: 'TIME', maxCombo: 'COMBO', pickUp: 'PICK AN UPGRADE', up_dmg: 'SHARP CLAWS', up_dmg_d: '+15% DAMAGE',
    up_hp: 'VITALITY', up_hp_d: '+20% HEALTH', up_fury: 'BLOODLUST', up_fury_d: '+25% FURY', up_cd: 'INSTINCT', up_cd_d: '-20% COOLDOWN',
    human: 'HUMAN', feral: 'FERAL', ascended: 'ASCENDED', form: 'FORM', fury: 'FURY', hits: 'HITS', combo: ['', 'NICE', 'BRUTAL', 'SAVAGE!', 'UNSTOPPABLE!'], counter: 'COUNTER!',
    bossWarn: 'BOSS WARNING', theEnd: 'THE END', end1: 'THE PRIMORDIAL BEAST HAS FALLEN.', end2: 'THE CABALA BLEEDS... BUT SOME BEASTS NEVER DIE.', thanks: 'THANKS FOR PLAYING', newGame: 'ERASE PROGRESS', rotate: 'ROTATE YOUR DEVICE',
    down: 'DOWN', hint1: 'HOLD ATK FOR COMBOS', hint2: 'FURY FULL? TAP FORM!', objective: 'OBJECTIVE', options: 'OPTIONS', start: 'START', loading: 'SUMMONING THE BEAST...',
    sp_h: 'CHAIN', sp_f: 'HOWL', sp_a: 'REND', sp_vespera: 'SPIRAL', sp_triton: 'TIDE', sp_malakor: 'BARRIER', p2: 'ENRAGED', block: 'BLOCK', heal: 'HEAL',
    stats: ['POWER', 'SPEED', 'RANGE', 'DEFENSE', 'SUPPORT'], ai: 'AI'
  }
};
const T = k => { const v = STR[SAVE.lang][k]; return v != null ? v : k; };

/* intro story slides */
const STORY = [
  { stage: 5, pt: ['1944.', 'A DIVISÃO THULE CAÇAVA O QUE NÃO ENTENDIA.', 'ELES ME ENCONTRARAM.'], en: ['1944.', 'THE THULE DIVISION HUNTED WHAT THEY', 'COULD NOT UNDERSTAND. THEY FOUND ME.'], cast: 'lab' },
  { stage: 5, pt: ['DNA HUMANO. DNA DE LOBO ANCESTRAL.', 'AÇO NA MINHA CARNE.', 'ELES FIZERAM UMA ARMA.'], en: ['HUMAN DNA. ANCIENT WOLF DNA.', 'STEEL IN MY FLESH.', 'THEY MADE ME A WEAPON.'], cast: 'rage' },
  { stage: 1, pt: ['2242. A CIDADE NUNCA DORME.', 'NEM EU.', 'MESMOS OLHOS. PRESA DIFERENTE.'], en: ['2242. THE CITY NEVER SLEEPS.', 'NEITHER DO I.', 'SAME EYES. DIFFERENT PREY.'], cast: 'city' },
  { stage: 1, pt: ['OUTRO CORPO. OUTRA MENSAGEM.', 'A CABALA AINDA ESTÁ AQUI.', 'E SOLTOU ALGO PRIMORDIAL.'], en: ['ANOTHER BODY. ANOTHER MESSAGE.', 'THE CABALA IS STILL HERE.', 'AND IT UNLEASHED SOMETHING PRIMAL.'], cast: 'sigil' },
  { stage: 3, pt: ['ALGUNS MONSTROS LUTAM NAS SOMBRAS.', 'NÓS REVIDAMOS.', 'A CAÇADA COMEÇA.'], en: ['SOME MONSTERS FIGHT IN THE SHADOWS.', 'WE FIGHT BACK.', 'THE HUNT BEGINS.'], cast: 'team' }
];

/* ---------- heroes ---------- */
const HERO = {
  lupus: { name: 'LUPUS', color: '#ff2a40', hp: 1400, spd: 100, jump: 300, role: 'DETETIVE / BERSERKER', stats: [4, 3, 2, 3, 2], quote: 'ALGUNS MONSTROS USAM DISTINTIVO.' },
  vespera: { name: 'VESPERA', color: '#ff3ad0', hp: 1200, spd: 118, jump: 330, role: 'PUNK DE SANGUE / AÉREA', stats: [3, 5, 3, 2, 2], quote: 'LIBERDADE SEMPRE MORDE.', key: 'vespera', reach: 42, dmg: 36, dur: 0.22, cd: 6.5 },
  triton: { name: 'TRITON', color: '#3af0ff', hp: 1900, spd: 78, jump: 260, role: 'TANQUE / GUARDIÃO', stats: [4, 2, 4, 5, 3], quote: 'MAIS FORTES. JUNTOS.', key: 'triton', reach: 59, dmg: 58, dur: 0.34, cd: 7.5, armor: 0.22 },
  malakor: { name: 'MALAKOR', color: '#a7ff1a', hp: 1000, spd: 86, jump: 270, role: 'NECRO-TECH / SUPORTE', stats: [2, 3, 5, 2, 5], quote: 'CIÊNCIA. MORTE. ORDEM.', key: 'malakor', reach: 0, dmg: 30, dur: 0.42, cd: 9 }
};
const FORM = {
  h: { key: 'lupus_h', dmg: 44, reach: 38, dur: 0.24, armor: 0, regen: 0, spd: 100, cd: 5, label: 'human' },
  f: { key: 'lupus_f', dmg: 70, reach: 42, dur: 0.3, armor: 0.25, regen: 9, spd: 106, cd: 8, label: 'feral' },
  a: { key: 'lupus_a', dmg: 60, reach: 50, dur: 0.18, armor: 0.5, regen: 14, spd: 124, cd: 4, label: 'ascended' }
};

/* ---------- enemies (sprite key, size, ai) ---------- */
const ENEMY = {
  Z: { name: 'CABALA ZEALOT', key: 'zealot', hp: 120, spd: 44, ai: 'ranged', dmg: 24, pts: 100, hr: 13 },
  ZS: { name: 'ZEALOT BULWARK', key: 'bulwark', hp: 210, spd: 36, ai: 'melee', shield: true, dmg: 24, pts: 160, reach: 35, hr: 14 },
  S: { name: 'CYBER-GHOUL', key: 'slasher', hp: 140, spd: 80, ai: 'melee', dmg: 21, pts: 120, reach: 38, wind: 0.28, hr: 13 },
  H: { name: 'PLAGUE HOUND', key: 'hound', hp: 84, spd: 90, ai: 'lunge', dmg: 17, pts: 80, hr: 14, quad: true },
  K: { name: 'GENE-KNIGHT', key: 'knight', hp: 480, spd: 40, ai: 'melee', shield: true, heavy: true, dmg: 44, pts: 320, reach: 50, wind: 0.5, hr: 17 },
  V: { name: 'VAMPIRE HUNTER', key: 'hunter', hp: 220, spd: 56, ai: 'beam', dmg: 34, pts: 220, hr: 13 },
  A: { name: 'ABOMINATION', key: 'abom', hp: 560, spd: 35, ai: 'brute', heavy: true, dmg: 52, pts: 400, reach: 52, wind: 0.55, hr: 21 },
  M: { name: 'FAILED EXPERIMENT', key: 'mutant', hp: 170, spd: 52, ai: 'melee', dmg: 24, pts: 130, reach: 35, hr: 14 }
};
const BOSS = {
  warden: { name: 'GENE-KNIGHT WARDEN', sub: 'A PUREZA DE FERRO', key: 'warden', hp: 2100, spd: 42, pats: ['slash', 'charge', 'leap', 'guard', 'slash', 'rain'], pats2: ['combo', 'leap', 'charge', 'slam', 'rain', 'guard'], extra: ['sweep'], rain: 'spike', pts: 2000, hr: 24, reach: 66 },
  voss: { name: 'INQUISIDORA SERAPH VOSS', sub: 'A LÂMINA FIEL', key: 'voss', hp: 3500, spd: 62, pats: ['slash', 'wave', 'combo', 'cross', 'blink'], pats2: ['combo', 'cross', 'volley', 'blink', 'wave', 'rain'], extra: ['leap'], rain: 'debris', pts: 3500, hr: 21, reach: 73 },
  prime: { name: 'ABOMINAÇÃO PRIMA', sub: 'EXPERIMENTAR. MUTAR. REPETIR.', key: 'prime', hp: 3200, spd: 36, pats: ['slash', 'slam', 'charge', 'leap', 'rain'], pats2: ['slam', 'leap', 'sweep', 'summon', 'charge', 'rain'], extra: ['grab'], rain: 'gas', pts: 3500, hr: 31, reach: 76 },
  nacht: { name: 'DOKTOR NACHT', sub: 'O ARQUITETO LOUCO', key: 'nacht', big: 'nacht_big', hp: 3900, spd: 52, pats: ['shoot', 'summon', 'volley', 'blink', 'rain'], pats2: ['slam', 'leap', 'charge', 'sweep', 'rain', 'summon'], extra: ['volley'], rain: 'debris', pts: 4500, hr: 17, reach: 47 },
  beast: { name: 'A BESTA PRIMORDIAL', sub: 'A PRIMEIRA FOME', key: 'beast', hp: 7600, spd: 50, pats: ['slash', 'charge', 'leap', 'roar', 'combo'], pats2: ['charge', 'grab', 'leap', 'slam', 'roar', 'rain', 'combo'], extra: ['sweep'], rain: 'debris', pts: 8000, hr: 57, reach: 106, wide: true }
};

/* ---------- stages ---------- */
let WORLD_W = 3240;
const STAGES = [
  { id: 1, music: 0, name: { pt: 'FAVELAS DE NEON', en: 'NEON SLUMS' }, sub: { pt: 'A CIDADE SANGRA, MAS AINDA RESPIRA.', en: 'THE CITY BLEEDS. BUT IT STILL BREATHES.' }, obj: { pt: 'PURGAR AS PATRULHAS', en: 'PURGE THE PATROLS' },
    w: 3240, hz: 'none', waves: [{ x: 300, e: ['S', 'S', 'Z'] }, { x: 760, e: ['Z', 'Z', 'S', 'H', 'H'] }, { x: 1220, e: ['S', 'S', 'H', 'H', 'Z', 'Z'], amb: 1 }, { x: 1680, e: ['ZS', 'S', 'Z', 'M'] }, { x: 2140, e: ['S*', 'Z', 'Z'] }, { x: 2600, e: ['ZS', 'ZS', 'S', 'Z', 'H', 'H'] }], boss: 'warden', props: [180, 520, 860, 1100, 1450, 1900, 2350, 2800], say: { w: 'lupus', pt: 'A NOITE SE LEMBRA.', en: 'THE NIGHT REMEMBERS.' } },
  { id: 2, music: 1, name: { pt: 'TELHADOS DA CATEDRAL', en: 'CATHEDRAL ROOFTOPS' }, sub: { pt: 'A FÉ OBSERVA. NÓS TAMBÉM.', en: 'FAITH WATCHES. SO DO WE.' }, obj: { pt: 'ALCANÇAR A CATEDRAL', en: 'REACH THE CATHEDRAL' },
    w: 3240, hz: 'debris', waves: [{ x: 300, e: ['Z', 'Z', 'V'] }, { x: 760, e: ['S', 'S', 'S', 'ZS', 'Z'] }, { x: 1220, e: ['V', 'V', 'Z', 'S'], hz: 1 }, { x: 1680, e: ['K', 'Z', 'Z', 'S'], amb: 1 }, { x: 2140, e: ['V*', 'S', 'S'] }, { x: 2600, e: ['K', 'Z', 'V', 'S', 'ZS'], hz: 1 }], boss: 'voss', props: [240, 600, 980, 1400, 1950, 2450], say: { w: 'vespera', pt: 'ELES NOS ESPERAM LÁ EM CIMA.', en: 'THEY ARE WAITING UP THERE.' } },
  { id: 3, music: 2, name: { pt: 'ESCONDERIJO SUBTERRÂNEO', en: 'UNDERCITY HIDEOUT' }, sub: { pt: 'EXILADOS. REJEITADOS. AINDA HUMANOS.', en: 'EXILES. OUTCASTS. STILL HUMAN.' }, obj: { pt: 'DEFENDER O REFÚGIO', en: 'DEFEND THE REFUGE' },
    w: 3240, hz: 'debris', waves: [{ x: 300, e: ['H', 'H', 'H', 'S'] }, { x: 760, e: ['V', 'V', 'Z', 'Z'] }, { x: 1220, e: ['M', 'M', 'M', 'H', 'H'], amb: 1 }, { x: 1680, e: ['A', 'S', 'S'], hz: 1 }, { x: 2140, e: ['A*', 'H', 'H'] }, { x: 2600, e: ['A', 'V', 'Z', 'Z', 'M'], hz: 1 }], boss: 'prime', props: [160, 420, 760, 1100, 1300, 1800, 2300, 2900], say: { w: 'malakor', pt: 'NEM TODA MORTE É UM FIM.', en: 'NOT ALL DEATHS ARE ENDS.' } },
  { id: 4, music: 3, name: { pt: 'METRÔ ALAGADO', en: 'FLOODED METRO' }, sub: { pt: 'O VELHO MUNDO AINDA SUSSURRA.', en: 'THE OLD WORLD STILL WHISPERS.' }, obj: { pt: 'CAÇAR O DOKTOR NACHT', en: 'HUNT DOKTOR NACHT' },
    w: 3240, hz: 'shock', waves: [{ x: 300, e: ['H', 'H', 'H', 'H', 'S'] }, { x: 760, e: ['A', 'K'] }, { x: 1220, e: ['V', 'Z', 'Z', 'S'], hz: 1 }, { x: 1680, e: ['M', 'M', 'S', 'S', 'H', 'H'], amb: 1 }, { x: 2140, e: ['K*', 'V'], hz: 1 }, { x: 2600, e: ['V', 'Z', 'Z', 'S', 'S', 'ZS'], hz: 1 }], boss: 'nacht', props: [400, 900, 1500, 2050, 2700], say: { w: 'triton', pt: 'MAIS FUNDO. MAIS FORTE. JUNTOS.', en: 'DEEPER. STRONGER. TOGETHER.' } },
  { id: 5, music: 4, name: { pt: 'BIO-LAB DA CABALA', en: 'CABALA BIO-LAB' }, sub: { pt: 'CIÊNCIA. FÉ. MESMO RESULTADO.', en: 'SCIENCE. FAITH. SAME RESULT.' }, obj: { pt: 'DESTRUIR O NÚCLEO', en: 'DESTROY THE CORE' },
    w: 3240, hz: 'gas', waves: [{ x: 300, e: ['K', 'K', 'V', 'Z'] }, { x: 760, e: ['A', 'A', 'S', 'S', 'H', 'H'] }, { x: 1220, e: ['M', 'M', 'M', 'V', 'V'], hz: 1 }, { x: 1680, e: ['K', 'ZS', 'ZS', 'Z', 'Z'], amb: 1 }, { x: 2140, e: ['A*', 'K*'], hz: 1 }, { x: 2600, e: ['K', 'V', 'V', 'ZS', 'ZS', 'A'], hz: 1 }], boss: 'beast', props: [260, 620, 1000, 1500, 2000, 2500, 2950], say: { w: 'lupus', pt: 'MESMA CIDADE. MONSTROS MAIORES.', en: 'SAME CITY. BIGGER MONSTERS.' } }
];

/* ---------- stage challenges (3 stars each) ---------- */
const CHAL = {
  1: [{ k: 'clear' }, { k: 'combo', n: 25 }, { k: 'nohit', n: 8 }],
  2: [{ k: 'clear' }, { k: 'time', n: 360 }, { k: 'tags', n: 5 }],
  3: [{ k: 'clear' }, { k: 'noko' }, { k: 'combo', n: 40 }],
  4: [{ k: 'clear' }, { k: 'nohit', n: 10 }, { k: 'time', n: 420 }],
  5: [{ k: 'clear' }, { k: 'noko' }, { k: 'combo', n: 60 }]
};
const fmtTime = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
function chalText(c) { const t = T('ch_' + c.k); return c.n == null ? t : t.replace('{n}', c.k === 'time' ? fmtTime(c.n) : c.n); }
function chalDone(c, G, cleared) {
  if (!cleared) return false;
  if (c.k === 'clear') return true; if (c.k === 'combo') return G.maxCombo >= c.n; if (c.k === 'time') return G.time <= c.n;
  if (c.k === 'nohit') return G.hurtCount <= c.n; if (c.k === 'noko') return G.koCount === 0; if (c.k === 'tags') return G.tags >= c.n; return false;
}
/* ---------- hero levels ---------- */
const LV_MAX = 15;
const xpFor = lv => Math.round(220 * Math.pow(lv - 1, 1.45));   // total xp needed to reach lv
function heroLv(id) { const xp = (SAVE.xp || {})[id] || 0; let lv = 1; while (lv < LV_MAX && xp >= xpFor(lv + 1)) lv++; return lv; }


/* ===================== v7: ACT II — new heroes, enemies, bosses and stages 6-10 ===================== */
Object.assign(HERO, {
  echo: { name: 'ECHO', color: '#3ae6ff', hp: 1100, spd: 104, jump: 300, role: 'CYBORG SNIPER / RANGED', stats: [3, 4, 5, 2, 2], quote: 'ONE SHOT. ONE ANSWER.', key: 'echo', reach: 40, dmg: 40, dur: 0.24, cd: 6.5, act: 2 },
  brann: { name: 'BRANN', color: '#ff5a3a', hp: 2200, spd: 72, jump: 240, role: 'STONE GARGOYLE / GRAPPLER', stats: [5, 1, 3, 5, 2], quote: 'I GUARDED THIS CITY FOR CENTURIES.', key: 'brann', reach: 50, dmg: 64, dur: 0.36, cd: 8, armor: 0.3, act: 2 }
});
Object.assign(ENEMY, {
  C: { name: 'CYBER-CROW SWARM', key: 'crow', hp: 72, spd: 104, ai: 'lunge', dmg: 16, pts: 90, hr: 13, fly: 14 },
  P: { name: 'NECROPOLIS PHANTOM', key: 'phantom', hp: 200, spd: 62, ai: 'melee', dmg: 27, pts: 190, reach: 44, wind: 0.3, hr: 14 },
  D: { name: 'CABALA DIVER', key: 'diver', hp: 320, spd: 40, ai: 'beam', dmg: 34, pts: 250, hr: 16, heavy: true },
  R: { name: 'THULE REVENANT', key: 'revenant', hp: 250, spd: 46, ai: 'melee', dmg: 31, pts: 210, reach: 62, wind: 0.45, hr: 13 }
});
Object.assign(BOSS, {
  morrigan: { name: 'MORRIGAN, THE CROW QUEEN', sub: 'EVERY GRAVE HAS WINGS', key: 'morrigan', hp: 4300, spd: 54, pats: ['shoot', 'volley', 'summon', 'slash', 'rain', 'blink'], pats2: ['volley', 'blink', 'rain', 'combo', 'summon', 'wave'], extra: ['sweep'], rain: 'gas', minions: ['C', 'C', 'P'], col: '#a7ff1a', pts: 5000, hr: 20, reach: 62 },
  kane: { name: 'EXECUTOR KANE', sub: 'THE CABALA SIGNS IN BLOOD', key: 'kane', hp: 4800, spd: 58, pats: ['shoot', 'combo', 'charge', 'guard', 'volley'], pats2: ['volley', 'grab', 'shoot', 'charge', 'rain', 'cross'], extra: ['leap'], shootAn: 'atk2', muzzle: [62, 40], rain: 'debris', minions: ['Z', 'ZS', 'V'], col: '#ff2040', shot: '#ffcf3a', pts: 5500, hr: 18, reach: 66 },
  leviathan: { name: 'THE LEVIATHAN', sub: 'THE DEEP REMEMBERS', key: 'leviathan', hp: 8400, spd: 46, pats: ['charge', 'wave', 'slam', 'leap', 'combo'], pats2: ['wave', 'grab', 'charge', 'sweep', 'roar', 'rain'], extra: ['volley'], rain: 'debris', minions: ['D', 'D'], col: '#3af0ff', pts: 7000, hr: 72, reach: 150, wide: true },
  kreutz: { name: 'HAUPTMANN KREUTZ', sub: 'THE WAR NEVER ENDED', key: 'kreutz', hp: 6200, spd: 72, pats: ['combo', 'slash', 'cross', 'leap', 'blink'], pats2: ['combo', 'blink', 'grab', 'cross', 'wave', 'leap', 'rain'], extra: ['sweep'], rain: 'spike', minions: ['R', 'R'], col: '#e8f0ff', pts: 7500, hr: 20, reach: 72 },
  firstwolf: { name: 'THE FIRST WOLF', sub: 'ALBRECHT THULE, GRAND MASTER', key: 'firstwolf', hp: 11500, spd: 52, pats: ['slash', 'slam', 'leap', 'wave', 'combo', 'roar'], pats2: ['charge', 'grab', 'sweep', 'wave', 'leap', 'rain', 'cross', 'combo'], extra: ['volley'], rain: 'debris', minions: ['R', 'P', 'A'], col: '#ffb020', pts: 12000, hr: 34, reach: 98 }
});
const ACT2 = 5;   /* stage index where Act II begins */
STAGES.push(
  { id: 6, music: 'stage6', act: 2, name: { pt: 'NECRÓPOLE DE NEON', en: 'NEON NECROPOLIS' }, sub: { pt: 'OS MORTOS AQUI NUNCA DESLIGAM.', en: 'THE DEAD HERE NEVER SWITCH OFF.' }, obj: { pt: 'ENCONTRAR A RAINHA CORVO', en: 'FIND THE CROW QUEEN' },
    w: 3240, hz: 'gas', waves: [{ x: 300, e: ['C', 'C', 'Z'] }, { x: 760, e: ['P', 'C', 'C', 'S'] }, { x: 1220, e: ['P', 'P', 'Z', 'Z', 'C'], amb: 1 }, { x: 1680, e: ['M', 'M', 'P', 'C', 'C'], hz: 1 }, { x: 2140, e: ['P*', 'C', 'C'] }, { x: 2600, e: ['P', 'P', 'K', 'C', 'C', 'Z'], hz: 1 }], boss: 'morrigan', props: [220, 560, 940, 1380, 1880, 2380, 2900], say: { w: 'echo', pt: 'SINTO OS SINAIS DELES. ESTÃO EM TODA PARTE.', en: 'I CAN HEAR THEIR SIGNALS. THEY ARE EVERYWHERE.' } },
  { id: 7, music: 'stage7', act: 2, name: { pt: 'TORRE THORNE', en: 'THORNE TOWER' }, sub: { pt: 'O DINHEIRO ALCANÇA O CÉU. O SANGUE TAMBÉM.', en: 'MONEY REACHES THE SKY. SO DOES BLOOD.' }, obj: { pt: 'ALCANÇAR O TERRAÇO', en: 'REACH THE ROOFTOP' },
    w: 3240, hz: 'debris', waves: [{ x: 300, e: ['Z', 'Z', 'ZS', 'V'] }, { x: 760, e: ['V', 'V', 'C', 'C'] }, { x: 1220, e: ['K', 'ZS', 'Z', 'Z'], hz: 1 }, { x: 1680, e: ['V', 'V', 'S', 'S', 'C', 'C'], amb: 1 }, { x: 2140, e: ['K*', 'V', 'Z'], hz: 1 }, { x: 2600, e: ['K', 'ZS', 'ZS', 'V', 'C', 'C'], hz: 1 }], boss: 'kane', props: [240, 640, 1000, 1450, 1950, 2450, 2950], say: { w: 'brann', pt: 'ALTO DEMAIS PARA HOMENS. NÃO PARA GÁRGULAS.', en: 'TOO HIGH FOR MEN. NOT FOR GARGOYLES.' } },
  { id: 8, music: 'stage8', act: 2, name: { pt: 'DOCAS AFOGADAS', en: 'DROWNED DOCKS' }, sub: { pt: 'ONDE O TRITON NASCEU. E QUASE MORREU.', en: 'WHERE TRITON WAS BORN. AND NEARLY DIED.' }, obj: { pt: 'AFUNDAR A PLATAFORMA', en: 'SINK THE RIG' },
    w: 3240, hz: 'debris', waves: [{ x: 300, e: ['D', 'S', 'S'] }, { x: 760, e: ['D', 'H', 'H', 'H', 'M'] }, { x: 1220, e: ['D', 'D', 'Z', 'Z'], amb: 1 }, { x: 1680, e: ['A', 'M', 'M', 'D'], hz: 1 }, { x: 2140, e: ['D*', 'S', 'S', 'H'] }, { x: 2600, e: ['D', 'D', 'A', 'M', 'M', 'H'], hz: 1 }], boss: 'leviathan', props: [200, 560, 980, 1320, 1840, 2300, 2880], say: { w: 'triton', pt: 'ESTE MAR AINDA LEMBRA DE MIM.', en: 'THIS SEA STILL REMEMBERS ME.' } },
  { id: 9, music: 'stage9', act: 2, name: { pt: 'MAGLEV DA CABALA', en: 'CABALA MAGLEV' }, sub: { pt: 'QUATROCENTOS QUILÔMETROS POR HORA. SEM FREIO.', en: 'FOUR HUNDRED KILOMETRES AN HOUR. NO BRAKES.' }, obj: { pt: 'PARAR O TREM', en: 'STOP THE TRAIN' },
    w: 3240, hz: 'debris', waves: [{ x: 300, e: ['R', 'R', 'Z'] }, { x: 760, e: ['R', 'ZS', 'ZS', 'V'] }, { x: 1220, e: ['K', 'R', 'R', 'C', 'C'], amb: 1, hz: 1 }, { x: 1680, e: ['R', 'R', 'V', 'V', 'Z'] }, { x: 2140, e: ['R*', 'K', 'C', 'C'], hz: 1 }, { x: 2600, e: ['R', 'R', 'K', 'ZS', 'V', 'V'], hz: 1 }], boss: 'kreutz', props: [300, 700, 1100, 1550, 2050, 2500], say: { w: 'lupus', pt: 'KREUTZ. EU SENTI ESSE CHEIRO EM 1944.', en: 'KREUTZ. I SMELLED THIS IN 1944.' } },
  { id: 10, music: 'stage10', act: 2, name: { pt: 'CIDADELA THULE', en: 'THULE CITADEL' }, sub: { pt: 'ONDE TUDO COMEÇOU. ONDE TUDO TERMINA.', en: 'WHERE IT ALL BEGAN. WHERE IT ALL ENDS.' }, obj: { pt: 'DERRUBAR O PRIMEIRO LOBO', en: 'BRING DOWN THE FIRST WOLF' },
    w: 3240, hz: 'gas', waves: [{ x: 300, e: ['R', 'R', 'P', 'P'] }, { x: 760, e: ['A', 'K', 'R', 'C', 'C'] }, { x: 1220, e: ['P', 'P', 'D', 'R', 'R'], amb: 1, hz: 1 }, { x: 1680, e: ['A*', 'R', 'R', 'M', 'M'] }, { x: 2140, e: ['K*', 'D*', 'C', 'C'], hz: 1 }, { x: 2600, e: ['A', 'A', 'K', 'R', 'P', 'D'], hz: 1 }], boss: 'firstwolf', props: [260, 620, 1000, 1500, 2000, 2500, 2950], say: { w: 'lupus', pt: 'O LABORATÓRIO. EU JUREI QUE NUNCA VOLTARIA.', en: 'THE LAB. I SWORE I WOULD NEVER COME BACK.' } }
);
Object.assign(CHAL, {
  6: [{ k: 'clear' }, { k: 'combo', n: 50 }, { k: 'nohit', n: 12 }],
  7: [{ k: 'clear' }, { k: 'time', n: 420 }, { k: 'tags', n: 6 }],
  8: [{ k: 'clear' }, { k: 'noko' }, { k: 'combo', n: 60 }],
  9: [{ k: 'clear' }, { k: 'nohit', n: 12 }, { k: 'time', n: 450 }],
  10: [{ k: 'clear' }, { k: 'noko' }, { k: 'combo', n: 80 }]
});
