'use strict';
/* =====================================================================
   GAME v8 — systems of the Story Bible:
   talk band, in-stage comic panels, Wolf Senses, Thule Archives,
   objectives (generators, incubators, statue, vat, towers, reactors),
   new enemy AIs, mini-boss duels, fleeing / phased bosses, the giant
   Leviathan, Fenrir Awakened, duo supers, skill tree, story moves,
   and one mechanic per stage.
   ===================================================================== */

/* ---------------- helpers ---------------- */
const foes = () => G.objs && G.objs.length ? G.enemies.concat(G.props, G.objs.filter(o => o.team === 'e' && !o.dead)) : G.enemies.concat(G.props);
const objsP = () => G.objs && G.objs.length ? G.objs.filter(o => o.team === 'p' && !o.dead) : [];
const storyOn = () => G && !G.mode;
const sid = () => G && G.st ? G.st.id : 0;
const airDashOk = () => !storyOn() || sid() >= 5 || (SAVE.unlocked || 1) > 5;
const throwOk = () => !storyOn() || sid() >= 8 || (SAVE.unlocked || 1) > 8;
const senseOk = () => !storyOn() || sid() >= 2 || (SAVE.unlocked || 1) > 2;

/* ---------------- skill tree ---------------- */
const SK_COST = [30, 60, 100, 150], SK_LV = [2, 4, 7, 10];
function skl(id) { const s = (SAVE.sk || {})[id] || {}; return { atk: s.atk || 0, def: s.def || 0, spc: s.spc || 0 }; }
/* extra damage multipliers: skill crits, the finisher node, Wolf Senses weak points, hope (rescue), affinity */
function dmgBonus(att, tg, o) {
  let m = 1; const hero = att.kind === 'hero' ? att : null;
  if (hero) { const K = skl(hero.id); if (K.atk >= 2 && hero.idx === 3) m *= 1.15; if (K.atk >= 4 && Math.random() < 0.08) { m *= 1.7; textFx(tg.x, tg.y - 92, T('crit'), '#ffe08a', 1); } }
  if (G.sensing) m *= 1.25;
  if (tg.kind === 'boss' && G.hope) m *= 1 + Math.min(0.6, G.hope * 0.05);
  return m;
}

/* ---------------- talk band (radio lines with a portrait, never pauses the game) ---------------- */
function talk(spk, k, o) { if (!G) return; G.talkQ.push(Object.assign({ spk, k, t: 0, dur: 3.4 }, o || {})); }
function talkStep(dt) {
  const q = G.talkQ; if (!q || !q.length || G.title > 0.4 || G.banner) return; const c = q[0];
  if (c.t === 0 && c.vo && typeof voice === 'function') voice(c.vo, 0);
  c.t += dt; const dur = Math.max(c.dur, 1.8 + CT(c.k).length * 0.055);
  if (c.t > dur) q.shift();
}
function drawTalk(g) {
  const q = G.talkQ; if (!q || !q.length || G.title > 0.4 || G.banner) return; const c = q[0], txt = CT(c.k); if (!txt) { q.shift(); return; }
  const w = Math.min(330, VW - 200), x = Math.round(VW / 2 - w / 2 + 12), y = 72, a = Math.min(1, c.t * 5, (Math.max(c.dur, 1.8 + txt.length * 0.055) - c.t) * 4);
  const lines = PIX.wrap(txt, w - 44, 1).slice(0, 3), h = Math.max(30, lines.length * 10 + 16);
  g.save(); g.globalAlpha = Math.max(0, a);
  const col = c.spk ? spkCol(c.spk) : COLR.gold;
  PIX.panel(g, x, y, w, h, { edge: col, bg: 'rgba(8,4,14,0.86)' });
  if (c.spk && window.ITEMS['face_' + c.spk]) { drawFace(g, c.spk, x + 3, y + 3, 24); PIX.text(g, spkName(c.spk), x + 31, y + 3, { col, out: '#000' }); }
  else PIX.text(g, T('radio'), x + 6, y + 3, { col, out: '#000' });
  lines.forEach((l, i) => PIX.text(g, l, x + (c.spk ? 31 : 6), y + 14 + i * 10, { col: COLR.white, out: null }));
  g.restore();
}

/* ---------------- in-stage comic panel (pauses the game; tap to advance) ---------------- */
function showPanel(img, beats, then) { if (!G) return; COMIC.need([img]); G.panel = { img, beats, i: 0, t: 0, then }; Inp.reset(); }
function panelStep(dt) { const P = G.panel; P.t += dt; const b = P.beats[P.i]; if (b && P.t < dt * 1.5) { if (b.vo) voice(b.vo, 0); if (b.sfx) { sfx('impact'); } } }
function panelAdvance() {
  const P = G.panel; if (!P || P.t < 0.35) return; sfx('pick'); P.i++; P.t = 0;
  if (P.i >= P.beats.length) { G.panel = null; Inp.reset(); if (P.then) P.then(); }
}
function drawPanel(g) {
  const P = G.panel, im = COMIC.img[P.img]; dim(g, 0.82);
  const band = 62, ah = VH - band - 16;
  if (im && im.ok) { const sc = Math.min((VW - 24) / im.width, ah / im.height), w = im.width * sc, h = im.height * sc, x = (VW - w) / 2, y = 8 + (ah - h) / 2;
    const z = 1 + 0.03 * Math.min(1, P.t / 3); g.fillStyle = '#000'; g.fillRect(x - 3, y - 3, w + 6, h + 6); g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip(); g.imageSmoothingEnabled = true; g.drawImage(im, x - w * (z - 1) / 2, y - h * (z - 1) / 2, w * z, h * z); g.restore(); g.imageSmoothingEnabled = false; g.strokeStyle = '#f2eef8'; g.lineWidth = 1; g.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1); }
  else PIX.text(g, '...', VW / 2, VH / 2, { align: 'c', col: COLR.gray });
  const b = P.beats[P.i]; if (!b) return; const y0 = VH - band;
  g.fillStyle = 'rgba(6,3,10,0.95)'; g.fillRect(0, y0, VW, band); g.fillStyle = '#ff2a40'; g.fillRect(0, y0, VW, 1);
  if (b.sfx) PIX.text(g, b.sfx, VW / 2, y0 + band / 2 - 10, { s: 3, align: 'c', col: '#ffd23a', out: '#000' });
  else {
    const txt = CT(b.k), spk = b.spk, hasF = spk && window.ITEMS['face_' + spk], bx = hasF ? 64 : 22;
    if (hasF) { const col = spkCol(spk); g.fillStyle = col; g.fillRect(10, y0 + 6, 46, 46); drawFace(g, spk, 12, y0 + 8, 42); PIX.text(g, spkName(spk), bx, y0 + 6, { col, out: '#000' }); }
    PIX.wrap(txt, VW - bx - 20, 1).slice(0, 4).forEach((l, i) => PIX.text(g, l, bx, y0 + (spk ? 18 : 10) + i * 11, { col: b.t === 'cap' ? '#ffd84a' : COLR.white, out: '#000' }));
  }
  if (P.t > 0.5 && Math.sin(G.time * 6 + P.t * 6) > 0) { g.fillStyle = '#f2eef8'; const x = VW - 12, y = VH - 9; g.beginPath(); g.moveTo(x - 4, y - 3); g.lineTo(x + 2, y); g.lineTo(x - 4, y + 3); g.fill(); }
}

/* ---------------- Wolf Senses ---------------- */
function senseStep(dt, c) {
  if (G.sense == null) G.sense = 100;
  const want = !!(c && c.sense) && senseOk() && G.sense > 2 && !G.panel;
  if (want && !G.sensing) { sfx('howl'); G.senseCd = 0; if (!G.senseVo) { G.senseVo = true; if (G.player.id === 'lupus') voice('lupus_senses', 0); } }
  G.sensing = want;
  if (want) { G.sense = Math.max(0, G.sense - 26 * dt); G.senseCd = 0.9; }
  else { G.senseCd = Math.max(0, (G.senseCd || 0) - dt); if (G.senseCd <= 0) G.sense = Math.min(100, G.sense + 14 * dt); }
  G.senseK = lerp(G.senseK || 0, want ? 1 : 0, Math.min(1, dt * 8));
}
function drawSenses(g, cam) {
  const k = G.senseK || 0; if (k < 0.02) return;
  g.save(); g.globalAlpha = 0.85 * k; g.globalCompositeOperation = 'saturation'; g.fillStyle = '#808080'; g.fillRect(-VW, -VH, VW * 3, VH * 3);
  g.globalCompositeOperation = 'multiply'; g.fillStyle = '#8a92b8'; g.fillRect(-VW, -VH, VW * 3, VH * 3); g.restore();
  /* enemies glow red, weak point marked */
  g.save(); g.globalAlpha = k;
  for (const e of G.enemies) { if (e.dead) continue; const x = e.x - cam, y = e.y - e.z, h = entHeight(e) * 0.5; RD.glow(g, x, y - h * 0.55, 26 + h * 0.3, '#ff1030', 0.35); const fr = e._lastFr; if (fr) ART.draw(g, fr, x, y, { face: e.face, sc: depthScale(e.y), tint: '#ff2040', tintA: 0.55, alpha: 0.85 }); const wy = y - h * 0.62; g.fillStyle = '#ffffff'; g.fillRect(x - 1.5, wy - 1.5, 3, 3); g.strokeStyle = '#ff2040'; g.lineWidth = 1; g.strokeRect(x - 4, wy - 4, 8, 8); }
  g.restore();
}

/* ---------------- Thule Archives ---------------- */
function archPosition(a) {
  if (a.arenaAt == null) return a.x;
  /* Follow the playable lane when the viewport changes, without changing the archive's ID. */
  return G.camX + 32 + a.arenaAt * Math.max(0, VW - 152);
}
function archInit() {
  G.archs = []; if (!storyOn() || !G.st.arch) return; SAVE.arch = SAVE.arch || {};
  G.st.arch.forEach((x, j) => { const id = archId(G.st.id, j), a = { id, x: Math.min(WORLD_W - 60, x), arenaAt: G.st.archArena ? clamp(x, 0, 1) : null, y: LANE_T + 12 + ((id * 37) % 44), got: !!SAVE.arch[id] }; a.x = archPosition(a); G.archs.push(a); });
}
function archStep() {
  if (!G.archs) return;
  const activeSense = !!(G.sensing || (G.senseGrace || 0) > 0 || (G.senseTapT || 0) > 0);
  for (const a of G.archs) { a.x = archPosition(a); if (a.got || !activeSense) continue; for (const h of G.heroes) { if (h.dead) continue; if (Math.abs(h.x - a.x) < 28 && Math.abs(h.y - a.y) < 18) { a.got = true; SAVE.arch[a.id] = 1; saveGame(); sfx('pick'); sfx('ok'); ringFx(a.x, a.y, 8, 60, '#ffd23a', 0.5); const n = archCount(); textFx(a.x, a.y - 60, T('archive') + ' ' + n + '/' + ARCH_N, '#ffd23a', 2); talk(null, 'arT' + a.id, { dur: 3 }); if (n >= ARCH_N) { SAVE.skins = SAVE.skins || {}; if (!SAVE.skins.lupus) { SAVE.skins.lupus = true; saveGame(); G.banner2 = { t: 0, txt: T('skinUnlocked') + ': LUPUS 1944' }; } } } } }
}
function drawArchives(g, cam) {
  if (!G.archs) return; const k = Math.max(G.senseK || 0, clamp((G.senseGrace || 0) / 2.2, 0, 0.85));
  for (const a of G.archs) { a.x = archPosition(a); if (a.got) continue; const x = a.x - cam, y = a.y; if (x < -20 || x > VW + 20) continue;
    if (k < 0.05) { if (Math.sin(G.time * 2 + a.id) > 0.97) { g.fillStyle = 'rgba(255,220,120,0.35)'; g.fillRect(x, y - 10, 1, 1); } continue; }
    g.save(); g.globalAlpha = k; RD.glow(g, x, y - 8, 18, '#ffd23a', 0.6 + 0.2 * Math.sin(G.time * 6)); const bob = Math.sin(G.time * 3 + a.id) * 2;
    g.fillStyle = '#000'; g.fillRect(x - 6, y - 17 + bob, 12, 15); g.fillStyle = '#e8dcc0'; g.fillRect(x - 5, y - 16 + bob, 10, 13); g.fillStyle = '#8a1020'; g.fillRect(x - 5, y - 16 + bob, 10, 2); g.fillStyle = '#6a6070'; for (let i = 0; i < 4; i++) g.fillRect(x - 3, y - 12 + bob + i * 2.5, 6 - (i % 2) * 2, 1); g.restore(); }
}

/* ---------------- objectives ---------------- */
function addObj(sub, x, y, hp, team, o) { const ob = Object.assign({ kind: 'obj', sub, x, y, z: 0, hp, maxhp: hp, team, hr: 16, flash: 0, dead: false, face: 1, vx: 0, def: { name: '' } }, o || {}); G.objs.push(ob); return ob; }
function objHurt(att, tg, dmg, o) {
  if (tg.dead || tg.inv) return false;
  if (tg.team === 'p' && att.team === 'p') return false; if (tg.team === 'e' && att.team !== 'p') return false;
  const d = Math.max(1, Math.round(dmg * (tg.team === 'p' ? 0.8 : 1))); tg.hp -= d; tg.flash = 1; sparks(tg.x, tg.y, 26, 6, tg.team === 'p' ? '#ffb02a' : '#a7ff1a'); sfx('hit');
  if (tg.team === 'e' && att.team === 'p') { G.combo++; G.comboT = 2.4; G.maxCombo = Math.max(G.maxCombo, G.combo); textFx(tg.x, tg.y - 64, '' + d, '#ffffff', 1); }
  if (tg.team === 'p' && (!tg.warnT || G.time - tg.warnT > 3)) { tg.warnT = G.time; G.banner2 = { t: 0, txt: T('obj_' + tg.sub) + ' ' + T('underAttack') }; }
  if (tg.hp <= 0) { tg.hp = 0; tg.dead = true; objDown(tg); }
  return true;
}
function objDown(ob) {
  shake(9); sfx('boom'); ringFx(ob.x, ob.y, 10, 90, ob.team === 'p' ? '#ff5a2a' : '#a7ff1a', 0.6); hitFlash(ob.x, ob.y, 30, true, '#ffffff'); debris(ob.x, ob.y, 'db', 8); dust(ob.x, ob.y, 12); G.flashScr = Math.max(G.flashScr, 0.3);
  const M = MECH[G.mech]; if (M && M.objDown) M.objDown(ob);
}
function drawObj(g, ob, cam) {
  const x = Math.round(ob.x - cam), y = Math.round(ob.y), t = G.time, fl = ob.flash > 0 ? 1 : 0; ob.flash = Math.max(0, ob.flash - 1 / 30);
  g.save();
  const box = (x0, y0, w, h, c, edge) => { g.fillStyle = '#05030a'; g.fillRect(x0 - 1, y0 - 1, w + 2, h + 2); g.fillStyle = fl ? '#ffffff' : c; g.fillRect(x0, y0, w, h); if (edge) { g.fillStyle = edge; g.fillRect(x0, y0, w, 1); } };
  if (ob.dead) { g.globalAlpha = 0.85; box(x - 14, y - 8, 28, 8, '#2a2430', '#3a3448'); g.fillStyle = '#ff5a2a'; if (Math.random() < 0.3) g.fillRect(x - 10 + Math.random() * 20, y - 10, 1, 1); g.restore(); return; }
  if (ob.sub === 'gen') {
    box(x - 15, y - 34, 30, 34, '#2c2a36', '#5a5870'); box(x - 11, y - 30, 22, 12, '#14121a'); const on = 0.6 + 0.4 * Math.sin(t * 9 + x);
    g.fillStyle = 'rgba(255,200,60,' + on + ')'; g.fillRect(x - 9, y - 28, 18 * (ob.hp / ob.maxhp), 8); RD.glow(g, x, y - 24, 22, '#ffc040', 0.35 * on);
    g.fillStyle = '#ffb02a'; for (let i = 0; i < 3; i++) g.fillRect(x - 10 + i * 8, y - 14, 4, 2); box(x - 18, y - 6, 36, 6, '#1a1822');
    if (Math.random() < 0.2) sparks(ob.x + rnd(-10, 10), ob.y, 30, 1, '#ffd060');
  } else if (ob.sub === 'incub') {
    box(x - 13, y - 58, 26, 6, '#2a3a2a', '#5a7a5a'); box(x - 13, y - 6, 26, 6, '#2a3a2a', '#5a7a5a');
    g.fillStyle = '#05030a'; g.fillRect(x - 12, y - 52, 24, 46); const gr = g.createLinearGradient(0, y - 52, 0, y - 6); gr.addColorStop(0, 'rgba(120,255,60,0.55)'); gr.addColorStop(1, 'rgba(40,140,20,0.85)'); g.fillStyle = fl ? '#ffffff' : gr; g.fillRect(x - 11, y - 51, 22, 44);
    g.fillStyle = 'rgba(10,30,10,0.85)'; g.beginPath(); g.ellipse(x, y - 30 + Math.sin(t * 1.5) * 2, 6, 11, 0, 0, 7); g.fill(); g.fillRect(x - 2, y - 44 + Math.sin(t * 1.5) * 2, 4, 6);
    g.fillStyle = 'rgba(220,255,200,0.6)'; for (let i = 0; i < 4; i++) g.fillRect(x - 8 + i * 5, y - 10 - ((t * 20 + i * 13) % 38), 1, 1); g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillRect(x - 10, y - 50, 2, 42);
    RD.glow(g, x, y - 30, 30, '#a7ff1a', 0.3);
  } else if (ob.sub === 'vat') {
    box(x - 22, y - 44, 44, 44, '#3a2a1a', '#8a6a3a'); g.fillStyle = '#05030a'; g.fillRect(x - 18, y - 40, 36, 30); const lv = (G.brew || 0) / 3;
    g.fillStyle = 'rgba(40,255,220,0.8)'; g.fillRect(x - 17, y - 11 - 28 * Math.max(0.15, lv), 34, 28 * Math.max(0.15, lv)); RD.glow(g, x, y - 26, 40, '#30ffd0', 0.35 + 0.15 * Math.sin(t * 4));
    g.fillStyle = 'rgba(220,255,250,0.7)'; for (let i = 0; i < 5; i++) { const by = y - 12 - ((t * 18 + i * 11) % 26); g.fillRect(x - 14 + i * 7, by, 2, 2); }
    box(x - 26, y - 6, 52, 6, '#2a1a10'); g.fillStyle = '#ffb02a'; g.fillRect(x - 24, y - 48, 4, 4); g.fillRect(x + 20, y - 48, 4, 4);
  } else if (ob.sub === 'tower') {
    box(x - 16, y - 92, 32, 92, '#2a2026', '#5a4048'); for (let i = 0; i < 5; i++) { g.fillStyle = '#140e12'; g.fillRect(x - 14, y - 84 + i * 17, 28, 2); g.fillRect(x - 14 + (i % 2) * 20, y - 84 + i * 17, 2, 17); }
    const arm = ob.fire > 0 ? -0.2 - ob.fire * 1.6 : -1.3 + Math.sin(t * 2) * 0.05; g.save(); g.translate(x, y - 92); g.rotate(arm); g.fillStyle = '#3a2a22'; g.fillRect(-2, -40, 4, 44); g.fillStyle = '#ff5a1a'; g.fillRect(-4, -44, 8, 6); g.restore();
    RD.glow(g, x, y - 60, 26, '#ff4010', 0.3 + 0.2 * Math.sin(t * 7)); g.fillStyle = '#c4001e'; g.fillRect(x - 10, y - 74, 20, 12);
  } else if (ob.sub === 'reactor') {
    const p = 0.6 + 0.4 * Math.sin(t * 5 + x); box(x - 18, y - 70, 36, 8, '#3a2a1a', '#8a6a3a'); box(x - 18, y - 8, 36, 8, '#3a2a1a', '#8a6a3a');
    g.fillStyle = '#05030a'; g.fillRect(x - 14, y - 62, 28, 54); const gr = g.createRadialGradient(x, y - 35, 2, x, y - 35, 22); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.3, '#ffb020'); gr.addColorStop(1, '#a00010'); g.fillStyle = fl ? '#ffffff' : gr; g.fillRect(x - 13, y - 61, 26, 52);
    RD.glow(g, x, y - 35, 44 * p, '#ff3010', 0.45); for (let i = -1; i <= 1; i += 2) { g.fillStyle = '#2a2026'; g.fillRect(x + i * 18 - 2, y - 62, 4, 54); }
  } else if (ob.sub === 'statue') {
    const fr = ART.frame('brann', 'idle', 0); const wake = Math.min(1, (G.bell || 0) / 3);
    if (fr) { ART.draw(g, fr, x, y, { face: 1, sc: depthScale(ob.y), tint: '#7a7a84', tintA: 0.82 - wake * 0.45, flash: fl * 0.5 }); if (wake > 0) RD.glow(g, x, y - 50, 30 + wake * 30, '#ff2a2a', 0.15 + wake * 0.25 * (0.6 + 0.4 * Math.sin(t * 6))); }
    g.strokeStyle = '#3a3440'; g.lineWidth = 2; g.beginPath(); g.moveTo(x - 30, y - 60); g.lineTo(x - 22, y - 20); g.moveTo(x + 30, y - 60); g.lineTo(x + 22, y - 20); g.stroke();
  }
  g.restore();
  if (!ob.dead && ob.hp < ob.maxhp) { PIX.bar(g, x - 18, y - (ob.sub === 'tower' ? 100 : ob.sub === 'statue' ? 110 : 72), 36, 3, ob.hp / ob.maxhp, ob.team === 'p' ? '#ffb02a' : '#a7ff1a', '#1a1020'); }
}

/* ---------------- new enemy behaviours ---------------- */
function aiExtra(e, tg, dt) {
  const def = e.def; phys(e, dt); const dx = tg.x - e.x, dy = tg.y - e.y; e.face = dx >= 0 ? 1 : -1;
  if (def.ai === 'bomber') {   /* rushes in, flashes, explodes */
    if (e.fuse == null) { moveTo(e, tg.x, tg.y, def.spd, dt); if (Math.hypot(dx, dy * 1.6) < 26) { e.fuse = 0.9; sfx('alarm'); } }
    else { e.fuse -= dt; e.moving = false; if (Math.random() < 0.5) sparks(e.x, e.y, 30, 1, '#ffb02a'); if (e.fuse <= 0) { bomberBlast(e); } }
  } else if (def.ai === 'sniper') {   /* stays far back, aims a laser, then fires a heavy bolt */
    const want = clamp(tg.x + (e.x < tg.x ? -220 : 220), G.camX + 20, G.camX + VW - 130);
    if (!e.aim) { moveTo(e, want, LANE_T + 2, def.spd, dt); e.cd -= dt * 0.35; if (e.cd <= 0 && Math.abs(e.x - tg.x) > 90) { e.aim = 1.2 * DF().wind; e.ty = tg.y; } }
    else { e.aim -= dt; e.ty = lerp(e.ty, tg.y, dt * 2); e.moving = false; e.ai = 'wind'; if (e.aim <= 0) { e.aim = 0; e.ai = 'hit'; e.ct = 0; shoot({ x: e.x + e.face * 26, y: clamp(e.ty, LANE_T, LANE_B), z: 30, vx: e.face * 520, dmg: def.dmg * e.dm, team: 'e', r: 7, life: 1.4, type: 'bolt', col: '#40d0ff', pierce: false }); sfx('shot'); hitFlash(e.x + e.face * 26, e.y, 32, false, '#40d0ff'); e.cd = rnd(2.2, 3.2) * DF().cd; later(() => { if (e) e.ai = 'move'; }, 300); } }
  } else if (def.ai === 'capture') {   /* grabs a civilian and drags them away */
    const civs = (G.civs || []).filter(c => !c.saved && !c.lost && (!c.by || c.by === e));
    if (e.carry) { const c = e.carry; const ex = e.exitX; moveTo(e, ex, e.y, def.spd * 0.65, dt); c.x = e.x - e.face * 8; c.y = e.y + 1; if (Math.abs(e.x - ex) < 6) { c.lost = true; c.by = null; e.carry = null; G.civLost = (G.civLost || 0) + 1; e.dead = true; e.deadT = 2; textFx(e.x, e.y - 70, T('civLost'), '#ff4060', 1); } }
    else if (civs.length) { const c = civs.reduce((a, b) => Math.abs(b.x - e.x) < Math.abs(a.x - e.x) ? b : a); moveTo(e, c.x, c.y, def.spd, dt); if (Math.hypot(c.x - e.x, c.y - e.y) < 12) { e.carry = c; c.by = e; e.exitX = e.x < G.camX + VW / 2 ? G.camX - 40 : G.camX + VW + 40; e.arrive = false; sfx('alarm'); } }
    else { /* nothing to take: fight */ e.def = Object.assign({}, def, { ai: 'melee', reach: 32, wind: 0.3 }); }
  }
}
function bomberBlast(e) {
  ringFx(e.x, e.y, 6, 80, '#ff7a1a', 0.45); ringFx(e.x, e.y, 6, 50, '#ffffff', 0.3); hitFlash(e.x, e.y, 20, true, '#ff7a1a'); shake(8); sfx('boom'); G.flashScr = Math.max(G.flashScr, 0.2);
  for (const h of G.heroes.concat(objsP())) if (!h.dead && Math.hypot(h.x - e.x, (h.y - e.y) * 1.6) < 62) hurt(e, h, e.def.dmg * e.dm, { launch: true, kx: 170, kz: 220 });
  for (const o of G.enemies) if (o !== e && !o.dead && o.kind === 'enemy' && Math.hypot(o.x - e.x, (o.y - e.y) * 1.6) < 62) hurt({ x: e.x, y: e.y, team: 'p', id: 'blast' }, o, 60, { launch: true, kx: 140, kz: 200, brk: true });
  e.hp = 0; e.blasted = true; kill(e, 1, e); blood(e.x, e.y, 30, 20, '#ff7a1a');
}
/* grab & throw (unlocked at stage 8) */
function tryThrow(h) {
  if (!throwOk()) return false;
  const e = G.enemies.find(e => !e.dead && e.kind === 'enemy' && e.st === 'hurt' && !e.def.heavy && Math.abs(e.x - h.x) < 24 && Math.abs(e.y - h.y) < 9 && (e.x - h.x) * h.face > -4);
  if (!e) return false;
  setSt(h, 'atk'); h.idx = 3; h.atkDur = 0.34; h.atkT = 0.34; h.hitDone = true; h.air = false; h.queued = false;
  e.x = h.x + h.face * 6; e.thrown = true; hurt(h, e, hs(h).dmg * 1.4, { launch: true, kx: 280, kz: 190, brk: true }); textFx(h.x, h.y - 96, T('throwTxt'), '#ffd23a', 1); sfx('roar'); shake(5);
  return true;
}
function thrownStep() {
  for (const e of G.enemies) { if (!e.thrown || e.dead && e.z <= 0) continue; if (e.st !== 'knock' && !e.dead) { e.thrown = false; continue; }
    for (const o of G.enemies) { if (o === e || o.dead || o.kind !== 'enemy' || (e.hitT && e.hitT.has(o))) continue; if (Math.abs(o.x - e.x) < 20 && Math.abs(o.y - e.y) < 12) { e.hitT = e.hitT || new Set(); e.hitT.add(o); hurt({ x: e.x - Math.sign(e.vx) * 8, y: e.y, team: 'p', id: 'throw' }, o, 70 * upMul(), { launch: true, kx: 150, kz: 200, brk: true }); shake(4); } } }
}

/* ---------------- hero tick: senses, Fenrir drain, Last Stand ---------------- */
function heroTick(h, dt, c) {
  if (h.form === 'x' && !h.dead) { h.hp -= h.maxhp * 0.021 * dt * (SAVE.diff === 'easy' ? 0.6 : 1); if (Math.random() < dt * 20) G.parts.push({ x: h.x + rnd(-14, 14), y: h.y, z: rnd(10, 70), vx: rnd(-20, 20), vy: 0, vz: rnd(30, 80), life: 0.5, t: 0, col: Math.random() < 0.5 ? '#fff4c0' : '#ffb020', size: 2, grav: -40, glowP: true }); if (h.hp <= 0) { h.hp = 0; kill(h, -h.face, h); return true; } }
  return false;
}
function killHook(f, dir, att) {
  /* Bleeding and other direct kill paths must also respect mandatory story exits. */
  if (holdBossExit(f)) return true;
  /* Last Stand (defense node 4): once per stage the active hero gets back up */
  if (f.kind === 'hero' && f.isPlayer && f.form !== 'x' && skl(f.id).def >= 4 && !G.lastStand) { G.lastStand = true; f.hp = f.maxhp * 0.3; f.inv = 2; textFx(f.x, f.y - 100, T('lastStand'), '#7dff9a', 2); ringFx(f.x, f.y, 10, 90, '#7dff9a', 0.6); sfx('howl'); return true; }
  if (f.kind === 'hero' && f.isPlayer && G.ally && !G.ally.dead) later(() => voice(G.ally.id + '_john', 0), 500);
  if (f.kind === 'enemy' && f.type === 'T' && Math.random() < 0.5) voice('soldier_ko', 600);
  if (f.kind === 'enemy' && f.carry) { f.carry.by = null; f.carry = null; }
  return false;
}

/* ---------------- bosses: spawn hook, flee, yield, phases ---------------- */
function bossExitProtected(e) { return !!(G && !G.mode && e.kind === 'boss' && (e.fleeing || e.yielding || e.duelBeat)); }
function holdBossExit(e) {
  if (!G || G.mode || e.kind !== 'boss' || !e.def) return false;
  const M = G.mech && MECH[G.mech];
  if (e.type === 'vesp_mb' && M && M.holdDuel && M.holdDuel(e)) return true;
  const def = e.def, flee = def.flee && e.bossIn <= 0 && e.hp <= e.maxhp * def.flee, yieldAt = def.yieldAt && e.hp <= e.maxhp * def.yieldAt;
  if (!bossExitProtected(e) && !flee && !yieldAt) return false;
  e.hp = Math.max(1, e.hp); e.inv = 99; e.pat = null; e.bleedT = 0; e.bleedD = 0; e.windup = false; e.guard = false; e.charging = false; e.vx = e.vy = e.vz = 0; e.z = 0; setSt(e, 'idle');
  if (flee && !e.fleeing) { e.fleeing = 0.001; e.frame = 'run'; voice('kreutz44_defeat', 0); talk('kreutz44', 'r01h'); talk('kreutz44', 'r01f'); }
  if (yieldAt && !e.yielding) { e.yielding = 0.001; G.locked = true; }
  return true;
}
function bossSpawned(e) {
  const def = e.def;
  if (def.pair && !G.mode) { G.bosses = [e]; const b = newE(Object.assign({}, e, { x: G.camX - 80, face: 1, _trail: [], hitSet: null })); b.hp = b.maxhp = e.maxhp; G.enemies.push(b); G.bosses.push(b); b.tintTwin = true; }
  if (def.giant) giantInit(e);
  const M = MECH[G.mech]; if (M && M.boss) M.boss(e);
}
function spawnMini(id) {
  const def = BOSS[id]; const e = newE({ kind: 'boss', mini: true, type: id, def, key: def.key, x: G.camX + VW + 50, y: 232, face: -1, hp: def.hp * (0.6 + 0.4 * DF().hp), maxhp: def.hp * (0.6 + 0.4 * DF().hp), pat: null, pi: 0, cd: 1, hr: def.hr, poiseMax: def.hp * 0.14, frame: 'idle', dm: (1 + 0.06 * G.stage) * DF().dmg, bossIn: 1.2, fade: 1 });
  G.enemies.push(e); G.mini = e; return e;
}
function bossScript(e, dt) {
  const def = e.def;
  /* tints for variants */
  holdBossExit(e);
  if (e.duelBeat) return true;
  if (e.fleeing) { e.fleeing += dt; e.face = 1; e.frame = e.fleeing < 0.9 ? 'idle' : 'run'; if (e.fleeing > 0.9) { e.x += 260 * dt; e.moving = true; if (Math.random() < 0.5) dust(e.x - 14, e.y, 1); } if (e.fleeing > 0.6 && !e.smoke) { e.smoke = true; ringFx(e.x, e.y, 6, 70, '#cfcfcf', 0.6); for (let i = 0; i < 18; i++) G.parts.push({ x: e.x + rnd(-20, 20), y: e.y + rnd(-6, 6), z: rnd(0, 40), vx: rnd(-30, 30), vy: 0, vz: rnd(10, 40), life: 1.2, t: 0, col: '#9a94a4', size: 3, grav: 0, dust: true }); }
    if (e.x > G.camX + VW + 60) { e.dead = true; e.deadT = 100; e.hp = 0; G.clearT = 0.001; G.slow = 0.5; musicStop(); sfx('boom'); }
    return true; }
  if (e.yielding) { e.yielding += dt; e.frame = 'idle'; e.vx = 0; bossFace(e, G.player); if (e.yielding > 0.8 && !e.yDone) { e.yDone = true; const M = MECH[G.mech]; if (M && M.yieldMini) M.yieldMini(e); } return true; }
  if (def.phases) return finalPhases(e, dt);
  return false;
}

/* ---------------- final boss: three phases + Fenrir Awakened ---------------- */
function finalPhases(e, dt) {
  if (!e.phase) e.phase = 1;
  if (e.phase === 1 && e.hp < e.maxhp * 0.66) { e.phase = 2; e.p2 = true; e.pat = null; e.morph = 1.6; e.morphDur = 1.6; e.inv = 1.6; e.def = Object.assign({}, e.def, { pats: e.def.pats2, spd: e.def.spd * 1.15 }); e.pi = 0; e.big = 1.18; e.hr = 40; sfx('roar'); G.flashScr = 0.4; talk('thule', 'r16b', { vo: 'thule_line3' }); for (let i = 0; i < 3; i++) later(() => { if (G && !G.over) { const h = spawnEnemy('H', i % 2 ? 1 : -1); h.packWolf = true; } }, 600 + i * 300); }
  if (e.phase === 2 && e.hp < e.maxhp * 0.33 && !G.fenrirT) { e.phase = 3; e.pat = null; e.inv = 99; G.fenrirT = 0.001; startFenrir(e); }
  if (e.morph > 0) { e.morph -= dt; e.frame = 'spec'; e.windup = true; shake(2); if (Math.random() < dt * 25) sparks(e.x + rnd(-30, 30), e.y, rnd(20, 90), 2, '#ffb020'); if (e.morph <= 0) { e.windup = false; e.frame = 'idle'; e.cd = 0.4; ringFx(e.x, e.y, 30, 150, '#ffb020', 0.7); } return true; }
  return false;
}
function startFenrir(boss) {
  const go = () => {
    let L = G.team.find(h => h.id === 'lupus'); if (!L) return;
    if (G.player !== L) { G.tagCd = 0; G.autoTag = 0; tagSwap(true); L = G.player; }
    L.maxhp = Math.round(L.maxhp * 1.4); L.hp = L.maxhp; L.fury = 300; setSt(L, 'idle'); startXform(L, 'x'); L.xdur = 1.9; G.cine = { h: L, t: 0, dur: 1.9 }; voice('fenrir_transform', 0); playSting('sting_fenrir');
    later(() => { if (G && boss && !boss.dead) { boss.inv = 0; boss.cd = 0.8; } }, 1900);
    G.fenrirShout = 6; musicStart('boss_fenrir'); MUS.lock = 'boss_fenrir';
    talk('lupus_h', 'm16b');
  };
  later(() => { if (!G || G.over) return; voice('lupus_line_rage', 0); showPanel('cs73', [{ t: 'say', spk: 'lupus_a', k: 'm16a' }, { t: 'cap', k: 'm16c' }], go); }, 400);
}
function fenrirStep(dt) {
  if (!G.fenrirT) return; G.fenrirT += dt;
  if (G.fenrirShout != null && G.ally && !G.ally.dead) { G.fenrirShout -= dt; if (G.fenrirShout <= 0) { G.fenrirShout = 9; voice(G.ally.id + '_john', 0); talk(ROSTER_KEY[G.ally.id], 'fj_' + G.ally.id, { dur: 2.6 }); } }
}
/* Fenrir's special: RAGNAROK HOWL */
const _hsf = heroSpecFire;
heroSpecFire = function (h) {
  if (h.id === 'lupus' && h.form === 'x') {
    const dm = hs(h).dmg; ringFx(h.x, h.y, 4, 170, '#ffe080', 0.7); ringFx(h.x, h.y, 4, 120, '#ffffff', 0.45); shake(14); freeze(0.14); G.flashScr = 0.5; sfx('boom'); voice('fenrir_special', 0);
    for (let i = 0; i < 30; i++) { const a = rnd(0, 6.28), s = rnd(120, 300); G.parts.push({ x: h.x, y: h.y, z: 10, vx: Math.cos(a) * s, vy: rnd(-20, 20), vz: rnd(60, 220), life: rnd(0.5, 1), t: 0, col: i % 2 ? '#fff4c0' : '#ffb020', size: 2, grav: 300, glowP: true }); }
    for (const e of foes()) { if (e.dead || dist(e, h) > 170) continue; hurt(h, e, dm * 2.2, { launch: e.kind !== 'boss', kx: 220, kz: 260, brk: true }); }
    return;
  }
  _hsf(h);
};

/* ---------------- giant Leviathan (stage 10) ---------------- */
function giantInit(e) {
  e.bossIn = 2.4; e.gx = G.camX + VW * 0.7; e.x = e.gx; e.y = LANE_T - 4; e.rise = 0; e.gst = 'rise'; e.gt = 0; e.vuln = false; e.inv = 0; e.hr = 0; e.atkI = 0;
  sfx('roar'); shake(10); voice('leviathan_giant_roar', 0);
}
function updGiant(e, dt) {
  const tg = G.player; e.gt += dt; e.ct += dt; e.flash = Math.max(0, e.flash - dt * 5);
  if (e.dead) return;
  e.gx = G.camX + VW * 0.72;
  const atks = e.hp < e.maxhp * 0.5 ? ['bite', 'claw', 'beam', 'bite', 'roar', 'claw', 'beam'] : ['bite', 'claw', 'bite', 'beam', 'roar'];
  const setG = (s) => { e.gst = s; e.gt = 0; };
  if (e.gst === 'rise') { e.rise = Math.min(1, e.gt / 2.2); e.vuln = false; e.x = e.gx; e.y = 400; if (e.gt > 2.4) { e.bossIn = 0; setG('idle'); talk('nereus', 'r10n', { vo: 'nereus_line1' }); } return; }
  if (e.p2 !== true && e.hp < e.maxhp * 0.5) { e.p2 = true; sfx('roar'); shake(10); textFx(e.gx, LANE_T - 120, T('p2'), '#ff3050', 2); talk('triton', 'r10b'); }
  if (e.gst === 'idle') { e.vuln = false; e.y = 400; if (e.gt > (e.p2 ? 0.9 : 1.4) * DF().cd) { const n = atks[e.atkI++ % atks.length]; setG(n + '0'); e.tx = clamp(tg.x, G.camX + 40, G.camX + VW * 0.6); e.ty = clamp(tg.y, LANE_T + 4, LANE_B - 4); if (n === 'bite' || n === 'claw') G.hz.push({ kind: 'debris', boss: true, x: e.tx, y: e.ty, r: n === 'bite' ? 46 : 40, t: 0, warn: 0.95 * DF().wind + 0.15, live: 0.2, dmg: (n === 'bite' ? 70 : 60) * e.dm, quiet: true }); if (n === 'beam') { e.ty = tg.y; G.hz.push({ kind: 'beam', boss: true, x: G.camX, y: e.ty, r: 12, t: 0, warn: 1.1, live: 0.6, dmg: 55 * e.dm }); sfx('alarm'); } } }
  else if (e.gst === 'bite0' || e.gst === 'claw0') { if (e.gt > 0.95 * DF().wind + 0.15) { setG(e.gst[0] === 'b' ? 'bite1' : 'claw1'); shake(12); sfx('boom'); dust(e.tx, e.ty, 20, '#9cf4ff'); ringFx(e.tx, e.ty, 0, 70, '#3af0ff', 0.5); for (let i = 0; i < 14; i++) G.parts.push({ x: e.tx + rnd(-30, 30), y: e.ty, z: 2, vx: rnd(-60, 60), vy: 0, vz: rnd(80, 200), life: 0.8, t: 0, col: '#9cf4ff', size: 2, grav: 500 }); } }
  else if (e.gst === 'bite1' || e.gst === 'claw1') { /* stuck down: the head / claw can be hit */ e.vuln = true; e.x = e.tx + (e.gst === 'bite1' ? 0 : -6); e.y = e.ty; e.hr = 30; if (e.gt > (e.p2 ? 1.3 : 1.8)) { e.vuln = false; e.y = 400; setG('idle'); } }
  else if (e.gst === 'beam0') { if (e.gt > 1.1) { setG('beam1'); sfx('special'); shake(6); } }
  else if (e.gst === 'beam1') { if (e.gt > 0.6) setG('idle'); }
  else if (e.gst === 'roar0') { if (e.gt > 0.6) { setG('roar1'); sfx('roar'); shake(10); for (const h of G.heroes) if (!h.dead) { h.vx += -90; } if (enemiesAlive() < 4) { spawnEnemy('D', -1); if (e.p2) spawnEnemy('H', -1); } for (const oy of [-18, 18]) shoot({ x: e.gx - 60, y: clamp(tg.y + oy, LANE_T, LANE_B), z: 8, vx: -230, dmg: 40 * e.dm, team: 'e', r: 22, life: 2.4, type: 'wave', col: '#3af0ff', pierce: true, kx: 100 }); } }
  else if (e.gst === 'roar1') { if (e.gt > 1) setG('idle'); }
}
function giantFrame(e) {
  const T0 = G.time, g = e.gst, k = e.gt;
  if (e.dead) return ['sink', 0]; if (g === 'rise') return ['rise', k < 1.2 ? 0 : 1, false];
  if (g === 'bite0') return ['bite', 0, false]; if (g === 'bite1') return ['bite', k < 0.2 ? 1 : 2, false];
  if (g === 'claw0') return ['raise', 0, false]; if (g === 'claw1') return ['slam', 0, false];
  if (g === 'beam0') return ['roar', 0, false]; if (g === 'beam1') return ['beam', 0, false];
  if (g === 'roar0' || g === 'roar1') return ['roar', Math.floor(T0 * 8), true];
  if (e.st === 'hurt' || e.flash > 0.6) return ['hurt', Math.floor(T0 * 10)];
  return ['idle', Math.floor(T0 * 3)];
}
function drawGiant(g, e, cam) {
  const r = giantFrame(e); if (e.dead && e.deadT > 3.5) return; const fr = ART.frame('levgiant', r[0], r[1], r[2]); if (!fr) return;
  let x = e.gx - cam, y = LANE_T - 2, sc = 1;
  if (e.gst === 'rise') y += (1 - e.rise) * 160;
  if (e.dead) { y += Math.min(160, Math.max(0, e.deadT - 1.2) * 70); }
  if (e.gst === 'bite1' || e.gst === 'claw1' || e.gst === 'bite0') { /* lunge toward the target spot */ const k = e.gst === 'bite0' ? Math.min(1, e.gt / 0.9) * 0.35 : 1; x = lerp(e.gx - cam, e.tx - cam + 70, k); y = lerp(LANE_T - 2, e.ty + 8, k); sc = lerp(1, 1.12, k); }
  g.save(); g.beginPath(); g.rect(0, 0, VW, VH); g.clip();
  ART.draw(g, fr, x, y, { face: 1, sc, flash: Math.min(0.22, e.flash * 0.3), tint: e.p2 ? '#ff2040' : null, tintA: 0.08 + 0.06 * Math.sin(G.time * 5) });
  /* water line in front of it */
  g.fillStyle = 'rgba(20,80,90,0.55)'; g.fillRect(x - 160, y - 4, 330, 6); g.fillStyle = 'rgba(180,250,255,0.5)'; for (let i = 0; i < 18; i++) g.fillRect(x - 150 + i * 18 + Math.sin(G.time * 4 + i) * 3, y - 4 + Math.sin(G.time * 3 + i) * 1.5, 8, 1);
  if (e.vuln && Math.sin(G.time * 12) > 0) { PIX.text(g, '!', e.x - cam, e.y - 70, { s: 2, align: 'c', col: '#ffd23a' }); }
  g.restore();
}

/* ---------------- duo supers ---------------- */
const DUO = { vespera: { col: '#ff2050', name: 'du_vespera' }, triton: { col: '#3af0ff', name: 'du_triton' }, malakor: { col: '#a7ff1a', name: 'du_malakor' }, echo: { col: '#3ae6ff', name: 'du_echo' }, brann: { col: '#ff5a3a', name: 'du_brann' } };
const duoOf = () => { const a = G.team.find(h => h.id !== 'lupus'); return a ? a.id : null; };
startSuper = function () {
  const p = G.player, a = G.ally; G.syn = 0; vibe(140, 220); const d = duoOf();
  a.bench = false; a.assist = true; a.astPh = 'super'; a.isPlayer = false; a.face = p.face; a.x = clamp(p.x - p.face * 40, G.camX + 20, G.camX + VW - 110); a.y = clamp(p.y + 10, LANE_T, LANE_B); a.z = 0; a.vz = 0; a._trail = []; G.heroes.push(a);
  for (const h of [p, a]) { h.inv = 4; h.spCd = 0; startSpec(h); h.specDur = 2.4; h.specAt = 99; h.vx = 0; }
  const L = p.id === 'lupus' ? p : a; G.superFx = { t: 0, p, a, L, duo: d, hit: false, marks: [], img: 'super_' + d }; COMIC.need(['super_' + d]);
  sfx('howl'); sfx('special'); playSting('sting_duo'); shake(6); freeze(0.05); if (d) voice(d + '_duo', 0);
};
updSuper = function (dt) {
  const S = G.superFx; S.t += dt; const D = DUO[S.duo] || DUO.vespera, L = S.L, P = L === S.p ? S.a : S.p;
  for (const h of [S.p, S.a]) { h.t += dt; if (h !== L || !S.air) phys(h, dt); h.flash = 0; }
  const live = G.enemies.filter(e => !e.dead && e.x > G.camX - 20 && e.x < G.camX + VW + 20);
  const dm = ((L.form ? FORM[L.form].dmg : 60) + HERO[P.id].dmg) * upMul() * (skl(G.player.id).spc >= 4 ? 1.25 : 1) * (((SAVE.aff || {})[S.duo] || 0) >= 5 ? 1.25 : 1);
  const hitAll = (mult, o) => { for (const e of live) hurt(L, e, dm * mult * (e.kind === 'boss' ? 0.55 : 1), Object.assign({ launch: e.kind !== 'boss', kx: 200, kz: 260, brk: true, ignoreInv: true }, o || {})); for (const q of G.props) if (!q.dead && q.x > G.camX && q.x < G.camX + VW) breakProp(q); for (const ob of G.objs || []) if (ob.team === 'e' && !ob.dead && ob.x > G.camX && ob.x < G.camX + VW) objHurt(L, ob, dm * mult * 0.6, {}); };
  const T0 = 1.0; /* splash first */
  if (S.t < T0) return;
  const t = S.t - T0;
  if (S.duo === 'vespera') { /* BLOOD MOON: she lifts him, a blood spiral, he dives claws first */
    if (t < 0.5) { S.air = true; L.z = t / 0.5 * 120; L.x = lerp(L.x, G.camX + VW * 0.45, 0.05); for (let i = 0; i < 3; i++) { const an = G.time * 9 + i * 2.1, r = 60 - t * 40; G.parts.push({ x: L.x + Math.cos(an) * r, y: L.y, z: L.z + Math.sin(an) * r * 0.6, vx: 0, vy: 0, vz: 0, life: 0.3, t: 0, col: '#ff2050', size: 2, grav: 0, glowP: true }); } }
    else if (!S.hit) { L.z = Math.max(0, L.z - dt * 900); if (L.z <= 0) { S.hit = true; S.air = false; shake(18); freeze(0.12); G.flashScr = 0.9; G.slow = 0.35; sfx('boom'); ringFx(L.x, L.y, 10, 260, '#ff2050', 1); ringFx(L.x, L.y, 10, 170, '#ffffff', 0.6); hitAll(6, { bleed: true }); P.hp = Math.min(P.maxhp, P.hp + P.maxhp * 0.2); } }
  } else if (S.duo === 'triton') { /* HOWLING TIDE: a giant wave across the screen, he surfs it */
    if (!S.hit) { S.hit = true; S.air = true; S.wx = G.camX - 40; sfx('special'); shake(8); }
    S.wx += dt * 520; L.x = S.wx + 10; L.z = 40 + Math.sin(t * 12) * 4; for (let i = 0; i < 6; i++) G.parts.push({ x: S.wx + rnd(-10, 30), y: rnd(LANE_T, LANE_B), z: rnd(0, 50), vx: rnd(40, 160), vy: 0, vz: rnd(20, 120), life: 0.6, t: 0, col: i % 2 ? '#3af0ff' : '#e8ffff', size: 2, grav: 300 });
    for (const e of live) if (!S.marks.includes(e) && Math.abs(e.x - S.wx) < 30) { S.marks.push(e); hurt(L, e, dm * 5.2 * (e.kind === 'boss' ? 0.55 : 1), { launch: e.kind !== 'boss', kx: 260, kz: 260, brk: true, ignoreInv: true }); }
    if (S.wx > G.camX + VW + 40 && !S.done) { S.done = true; S.air = false; L.z = 0; L.x = G.camX + VW * 0.6; P.shieldHP = 300; P.shieldT = 6; L.shieldHP = 300; L.shieldT = 6; G.flashScr = 0.5; shake(10); }
  } else if (S.duo === 'malakor') { /* SPECTRAL PACK: ghost wolves charge, the team heals */
    if (!S.hit) { S.hit = true; S.wolves = Array.from({ length: 7 }, (_, i) => ({ x: G.camX - 30 - i * 30, y: LANE_T + 8 + i * 9, t: 0, hit: new Set() })); sfx('howl'); for (const h of G.team) if (!h.dead) { h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.3); textFx(h.x, h.y - 90, '+' + T('heal'), '#a7ff1a', 1); } }
    for (const w of S.wolves) { w.x += dt * 420; for (let i = 0; i < 2; i++) G.parts.push({ x: w.x + rnd(-8, 8), y: w.y, z: rnd(6, 30), vx: -60, vy: 0, vz: 10, life: 0.4, t: 0, col: '#a7ff1a', size: 2, grav: 0, glowP: true }); for (const e of live) if (!w.hit.has(e) && Math.abs(e.x - w.x) < 22 && Math.abs(e.y - w.y) < 26) { w.hit.add(e); hurt(L, e, dm * 0.95 * (e.kind === 'boss' ? 0.55 : 1), { launch: e.kind !== 'boss', kx: 160, kz: 200, brk: true, ignoreInv: true }); } }
    L.x = Math.min(G.camX + VW - 110, (S.wolves[0] ? S.wolves[0].x : L.x) - 10);
  } else if (S.duo === 'echo') { /* PREDATOR LOCK: every enemy marked, he blinks from target to target, she fires */
    if (!S.hit) { S.hit = true; S.list = live.slice(0, 10); S.i = 0; S.nt = 0.1; sfx('alarm'); }
    S.nt -= dt; if (S.nt <= 0 && S.i < S.list.length) { const e = S.list[S.i++]; if (!e.dead) { L.x = e.x - L.face * 20; L.y = e.y; slashFx(e.x, e.y, 34, L.face, '#3ae6ff', 40, -0.4, 0.2); hurt(L, e, dm * 0.9 * (e.kind === 'boss' ? 0.55 : 1), { kx: 60, ignoreInv: true, brk: true }); sfx('slash'); } S.nt = 0.11; }
    if (S.i >= S.list.length && !S.done) { S.done = true; G.lines.push({ x: P.x, y: P.y, z: 32, len: VW, face: P.face, t: 0, dur: 0.6, col: '#3ae6ff', w: 9 }); shake(12); G.flashScr = 0.6; sfx('shot'); hitAll(3.2); }
  } else if (S.duo === 'brann') { /* CATHEDRAL FALL: hurled like a meteor, then a stone quake */
    if (t < 0.45) { S.air = true; L.z = 30 + t * 400; }
    else if (!S.hit) { S.air = true; L.x = lerp(L.x, G.camX + VW * 0.45, 0.2); L.z = Math.max(0, L.z - dt * 1100); for (let i = 0; i < 3; i++) G.parts.push({ x: L.x + rnd(-8, 8), y: L.y, z: L.z + rnd(0, 20), vx: rnd(-20, 20), vy: 0, vz: 80, life: 0.4, t: 0, col: i % 2 ? '#ff5a1a' : '#ffd060', size: 3, grav: 0, glowP: true }); if (L.z <= 0) { S.hit = true; S.air = false; shake(20); freeze(0.14); G.flashScr = 0.95; G.slow = 0.35; sfx('boom'); ringFx(L.x, L.y, 4, 280, '#ff5a3a', 1); ringFx(L.x, L.y, 4, 180, '#d8d0c8', 0.7); dust(L.x, L.y, 30, '#9a9088'); hitAll(6.2, { stun: 1.5 }); } }
  } else if (!S.hit && t > 0) { S.hit = true; hitAll(6); }
  if (S.t >= 2.6) { const a = S.a; G.superFx = null; L.z = 0; for (const h of [S.p, a]) { setSt(h, 'idle'); h.inv = 0.6; h.z = 0; } a.astPh = 'out'; jumpOut(a); }
};
function drawSuperSplash(g) {
  const S = G.superFx; if (!S || S.t > 1.05) return; const im = COMIC.img[S.img], k = S.t / 1.0, a = Math.min(1, S.t * 6, (1.05 - S.t) * 6);
  g.save(); g.globalAlpha = Math.max(0, a); g.fillStyle = '#000'; g.fillRect(0, 0, VW, VH);
  if (im && im.ok) { const sc = Math.max(VW / im.width, VH / im.height) * (1.08 + 0.1 * k), w = im.width * sc, h = im.height * sc; g.imageSmoothingEnabled = true; g.drawImage(im, (VW - w) / 2 + (k - 0.5) * 16, (VH - h) / 2, w, h); g.imageSmoothingEnabled = false; }
  const D = DUO[S.duo] || DUO.vespera; g.fillStyle = 'rgba(0,0,0,0.6)'; g.fillRect(0, VH - 44, VW, 30); g.fillStyle = D.col; g.fillRect(0, VH - 44, VW, 2);
  PIX.text(g, T(D.name), VW / 2 - (1 - Math.min(1, S.t * 4)) * 200, VH - 40, { s: 2, align: 'c', grad: ['#ffffff', '#ffe08a', D.col], out: '#000' });
  g.restore();
}

/* ---------------- mechanics per stage ---------------- */
const MECH = {};
/* PROLOGUE: alarms, the first transformation, Kreutz flees */
MECH.escape = {
  init() { talk('lupus44', 'r01a', { vo: 'lupus44_line1' }); },
  update(dt) {
    const p = G.player; if (p.id === 'lupus' && p.fury >= 60 && !G.furyHint) { G.furyHint = true; talk(null, 'r01c'); }
    if (p.form === 'f' && !G.firstX) { G.firstX = true; talk('lupus44', 'r01d'); }
  },
  waveStart(i) { if (i === 0 || i === 2) voice('soldier_alert', 0); if (i === 3) talk('lupus44', 'r01g', { vo: 'lupus44_line2' }); },
  boss() { talk('kreutz44', 'r01e'); },
  drawOver(g) { if (!G.bossSpawned || G.boss && !G.boss.dead) { const a = (0.08 + 0.08 * Math.max(0, Math.sin(G.time * 4))) * (G.boss && !G.boss.dead ? 0.3 : 1); g.fillStyle = 'rgba(255,0,30,' + a.toFixed(3) + ')'; g.fillRect(0, 0, VW, VH); } }
};
/* STAGE 2: investigation + Vespera's duel */
MECH.investigate = {
  init(opt) {
    G.clues = G.st.clues.map((x, i) => ({ x, y: LANE_T + 16 + i * 14, got: false, i })); G.clueN = 0; later(() => talk(null, 'r02a'), 3200);
    const duel = G.st.waves.findIndex(w => w.duel === 'vesp_mb');
    if (opt && opt.fromWave > duel && duel >= 0) { const a = makeHero('vespera', false, G.player.x, G.player.y); a.bench = true; G.ally = a; G.team.push(a); }
  },
  update(dt) {
    for (const c of G.clues) { if (c.got || !G.sensing) continue; const p = G.player; if (Math.abs(p.x - c.x) < 26 && Math.abs(p.y - c.y) < 16) { c.got = true; G.clueN++; sfx('ok'); ringFx(c.x, c.y, 6, 60, '#ff2040', 0.5); textFx(c.x, c.y - 60, T('clue') + ' ' + G.clueN + '/3', '#ff4060', 2); talk('lupus_h', ['r02c', 'r02d', 'r02e'][G.clueN - 1]); } }
    if (G.clueN === 1 && !G.wingHint) { G.wingHint = true; later(() => talk('lupus_h', 'r02b'), 2500); }
  },
  gate() { return G.clueN >= 3 ? null : 'gateClues'; },
  duel() { showPanel('cs42', [{ t: 'say', spk: 'vespera', k: 'm02a' }, { t: 'say', spk: 'lupus_h', k: 'm02b' }], () => { spawnMini('vesp_mb'); }); },
  yieldMini(e) {
    talk('vespera', 'r02f'); talk('lupus_h', 'r02g'); talk('vespera', 'r02h');
    later(() => { if (!G || G.over) return; e.dead = true; e.deadT = 100; e.hp = 0; G.mini = null; ringFx(e.x, e.y, 10, 60, '#ff3ad0', 0.5);
      const a = makeHero('vespera', false, e.x, e.y); a.bench = true; G.ally = a; G.team.push(a); G.duelHold = false; G.banner2 = { t: 0, txt: T('joined').replace('{n}', 'VESPERA') }; sfx('ok'); }, 900);
  },
  drawBack(g, cam) {
    const k = G.senseK || 0; if (k < 0.05) return; const p = G.player; const next = G.clues.find(c => !c.got);
    g.save(); g.globalAlpha = k;
    if (next) { const n = 18, dx = next.x - p.x, dy = next.y - p.y; for (let i = 1; i <= n; i++) { const q = i / n, x = p.x + dx * q - cam, y = p.y + dy * q + Math.sin(i * 1.7) * 3; if (i % 2) { g.fillStyle = '#c0001c'; g.fillRect(x - 1.5, y - 0.5, 3, 1.5); } } }
    for (const c of G.clues) { if (c.got) continue; const x = c.x - cam; RD.glow(g, x, c.y - 6, 20, '#ff2040', 0.6 + 0.3 * Math.sin(G.time * 6)); g.fillStyle = '#000'; g.fillRect(x - 5, c.y - 12, 10, 12); g.fillStyle = '#b0001c'; g.fillRect(x - 4, c.y - 11, 8, 10); g.fillStyle = '#ffffff'; g.fillRect(x - 1, c.y - 9, 2, 6); }
    g.restore();
  },
  hud(g) { PIX.text(g, T('clue') + ' ' + G.clueN + '/3', VW - 8, 56, { align: 'r', col: '#ff4060', out: '#0c0710' }); }
};
/* STAGE 3: street chase after the Cabala Courier (v9.1: rooftop platforms and grapple removed) */
const MODES_ART = window.MODES_ART = window.MODES_ART || {};
(function loadModesArt() {
  const names = ['courier'];
  for (const n of names) {
    if (MODES_ART[n]) continue;
    const im = new Image();
    im.onload = () => { im.ok = true; };
    im.onerror = () => { im.bad = true; };
    im.src = 'assets/modes/' + n + '.webp';
    MODES_ART[n] = im;
  }
})();

MECH.chase = {
  init() {
    G.auto = 1;
    G.courier = { x: 260, y: LANE_T + 8, z: 0, t: 0, lastWave: -1, state: 'wait', tauntT: 0, offscreen: false, trail: [], gone: false };
    if (window.Traversal90) Traversal90.init(); else G.mvPlats = [];
    later(() => talk(null, 'r03a'), 3000);
  },
  update(dt) {
    const p = G.player;
    if (!G.locked && !G.bossPending && !G.bossSpawned && G.title <= 0) {
      G.camX = Math.min(WORLD_W - VW, G.camX + 38 * dt);
      if (p.x < G.camX + 26) {
        p.x = G.camX + 26;
        if (!G.burnT || G.time - G.burnT > 0.6) {
          G.burnT = G.time;
          hurt({ x: p.x - 20, y: p.y, team: 'e' }, p, p.maxhp * 0.035, { ignoreInv: true });
          textFx(p.x, p.y - 80, T('tooSlow'), '#ff5060', 1);
        }
      }
    }
    const c = G.courier;
    if (!c) return;
    c.t += dt;
    if (G.bossPending || G.bossSpawned) { c.gone = true; return; }
    // Trigger a fresh escape appearance at the start of each block (when unlocked and waveIdx changed)
    if (!G.locked && G.title <= 0.3 && c.lastWave !== G.waveIdx) {
      c.lastWave = G.waveIdx;
      if (G.waveIdx <= (G.st.waves ? G.st.waves.length : 5)) {
        c.x = clamp(Math.max(G.camX + VW * 0.52, p.x + 115), G.camX + 140, WORLD_W - 80);
        c.y = LANE_T + 8;
        c.z = 0;
        c.state = 'taunt';
        c.tauntT = 0.48;
        c.offscreen = false;
        c.trail = [];
        ringFx(c.x, c.y, 10, 48, '#3af0ff', 0.38);
      }
    }
    if (!c.offscreen && c.state !== 'wait') {
      if (c.state === 'taunt') {
        c.tauntT -= dt;
        if (c.tauntT <= 0 || G.locked) {
          c.state = 'flee';
          sfx('dash');
          dust(c.x, c.y, 6, '#3af0ff');
        }
      } else if (c.state === 'flee') {
        const base = G.locked ? 265 : 195, spd = window.Traversal90 ? Traversal90.courierSpeed(c, base) : base;
        c.x += spd * dt;
        const hop = Math.sin(c.t * 11);
        c.z = hop > 0.35 ? (hop - 0.35) * 28 : 0;
        if (!c._trT || c.t - c._trT > 0.045) {
          c._trT = c.t;
          c.trail.push({ x: c.x, y: c.y, z: c.z, t: c.t });
          if (c.trail.length > 5) c.trail.shift();
        }
        if (Math.random() < dt * 18) {
          G.parts.push({ x: c.x - 8, y: c.y, z: 22 + c.z, vx: rnd(-45, -15), vy: rnd(-6, 6), vz: rnd(10, 35), life: 0.32, t: 0, col: Math.random() < 0.5 ? '#3af0ff' : '#ffd23a', size: 1.5, grav: 0, glowP: true });
        }
        if (c.x > G.camX + VW + 75) {
          c.offscreen = true;
          c.trail = [];
        }
      }
    }
    if (G.waveIdx === 2 && !G.c3) { G.c3 = true; talk('vespera', 'r03b'); }
    if (G.waveIdx === 4 && !G.c4) { G.c4 = true; talk('lupus_h', 'r03c'); }
    if (window.Traversal90) Traversal90.update(dt);
  },
  /* The old fixed 38px/s camera let a running hero leave the screen and
     then snapped him backward when a wave locked. Run after hero movement
     and before wave detection so the next arena is framed around him. */
  camera(dt) {
    if (G.locked || G.bossPending || G.bossSpawned || G.title > 0 || G.over > 0 || G.clearT) return;
    const p = G.player, end = Math.max(0, WORLD_W - VW);
    const lead = Math.max(0, p.vx) * 0.12;
    const target = clamp(p.x - VW * 0.38 + lead, G.camX, end);
    G.camX = clamp(Math.max(lerp(G.camX, target, Math.min(1, dt * 7)), p.x - VW + 96), 0, end);
    // A dash, tag-in or resize must not leave an active hero outside the frame.
    for (const h of G.heroes) if (!h.dead) h.x = clamp(h.x, G.camX + 12, G.camX + VW - 96);
  },
  boss() { showPanel('cs13', [{ t: 'say', spk: 'voss', k: 'm03a' }, { t: 'say', spk: 'voss', k: 'm03b' }]); },
  drawBack(g, cam) {
    if (window.Traversal90) Traversal90.drawBack(g, cam);

    const c = G.courier;
    if (!c || c.gone || c.offscreen || c.state === 'wait') return;
    const x = Math.round(c.x - cam), y = Math.round(c.y - (c.z || 0));
    if (x < -60 || x > VW + 90) return;
    const imCour = MODES_ART.courier;
    const frameIdx = c.state === 'taunt' ? 0 : (c.z || 0) > 6 ? 3 : (1 + (Math.floor(G.time * 12) % 2));
    g.save();
    // 1. Glowing ground target ring & shadow
    ART.shadow(g, x, c.y + 1, 15, 0.55);
    g.strokeStyle = '#3af0ff'; g.lineWidth = 1.2; g.globalAlpha = 0.65 + 0.25 * Math.sin(G.time * 10);
    g.beginPath(); g.ellipse(x, c.y + 1, 17, 5, 0, 0, Math.PI * 2); g.stroke();
    g.globalAlpha = 1;

    if (imCour && imCour.ok) {
      // Real illustrated Cabala Courier sprite sheet (4 frames of 220x220)
      const sx = frameIdx * 220, dw = 84, dh = 84;
      for (const q of c.trail || []) {
        const age = c.t - q.t;
        if (age > 0.24) continue;
        g.globalAlpha = 0.34 * (1 - age / 0.24);
        g.drawImage(imCour, sx, 0, 220, 220, Math.round(q.x - cam - dw / 2), Math.round(q.y - (q.z || 0) - dh + 4), dw, dh);
      }
      g.globalAlpha = 1;
      RD.glow(g, x, y - 30, 30, '#3af0ff', 0.38);
      g.drawImage(imCour, sx, 0, 220, 220, x - dw / 2, y - dh + 4, dw, dh);
    } else {
      const fkey = window.ATLAS && window.ATLAS.echo ? 'echo' : 'zealot';
      const anim = c.state === 'taunt' ? 'idle' : 'run';
      const face = c.state === 'taunt' ? -1 : 1;
      const fr = ART.frame(fkey, anim, Math.floor(G.time * 15));
      if (fr) {
        RD.glow(g, x, y - 26, 28, '#3af0ff', 0.35);
        ART.draw(g, fr, x, y, { face, sc: 0.96, tint: '#ffd23a', tintA: 0.28, rims: [['#3af0ff', -2, -1, 0.85]] });
      }
    }

    // Floating Target Badge above head
    const ty = y - 66 + Math.sin(G.time * 8) * 2;
    const label = (/^pt/i.test(SAVE.lang || '') ? 'MENSAGEIRO >>' : 'COURIER >>');
    const lw = PIX.textW(label, 1) + 10;
    g.fillStyle = 'rgba(8, 6, 18, 0.88)';
    g.fillRect(x - lw / 2, ty - 3, lw, 11);
    g.strokeStyle = '#ffd23a'; g.lineWidth = 1;
    g.strokeRect(x - lw / 2 + 0.5, ty - 2.5, lw - 1, 10);
    PIX.text(g, label, x, ty, { align: 'c', col: '#3af0ff', out: '#000' });
    g.restore();
  },
  drawOver(g) { if (!G.locked && !G.bossSpawned) { const gr = g.createLinearGradient(0, 0, 50, 0); gr.addColorStop(0, 'rgba(255,40,40,' + (0.35 + 0.15 * Math.sin(G.time * 8)) + ')'); gr.addColorStop(1, 'rgba(255,40,40,0)'); g.fillStyle = gr; g.fillRect(0, 0, 50, VH); } }
};
/* STAGE 4: defend the refuge's generators */
MECH.defend = {
  init() { G.gens = G.st.gens.map(x => addObj('gen', x, LANE_T + 6, 1500, 'p')); G.gensLost = 0; later(() => talk('malakor', 'r04a'), 3000); },
  waveStart(i, w) { if (w.gen != null) { const gen = G.gens[w.gen]; G.objTarget = gen.dead ? null : gen; } else G.objTarget = null; },
  spawned(e) { if (G.objTarget && !G.objTarget.dead && Math.random() < 0.45 && e.def.ai !== 'ranged' && e.def.ai !== 'beam') e.objT = G.objTarget; },
  objDown(ob) { G.gensLost++; G.dark = Math.min(1, (G.dark || 0) + 1); talk('triton', 'r04b'); },
  boss() { talk('triton', 'r04d'); },
  drawOver(g, cam) { if (!G.dark) return; darkness(g, cam, 0.78); }
};
/* darkness with light around the heroes; Wolf Senses see through it */
const DARK = {};
function darkness(g, cam, a) {
  const k = 1 - (G.senseK || 0) * 0.85; if (k <= 0.02) return;
  if (!DARK.c || DARK.c.width !== Math.ceil(VW)) { [DARK.c, DARK.x] = PIX.canvas(Math.ceil(VW), VH); } const c = DARK.c, x = DARK.x; x.globalCompositeOperation = 'source-over'; x.clearRect(0, 0, c.width, c.height); x.fillStyle = 'rgba(2,0,6,' + (a * k).toFixed(3) + ')'; x.fillRect(0, 0, VW, VH); x.globalCompositeOperation = 'destination-out';
  for (const h of G.heroes) { if (h.dead) continue; const hx = h.x - cam, hy = h.y - 40; const gr = x.createRadialGradient(hx, hy, 10, hx, hy, 95); gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = gr; x.fillRect(hx - 100, hy - 100, 200, 200); }
  for (const p of G.proj) { const gr = x.createRadialGradient(p.x - cam, p.y - p.z, 2, p.x - cam, p.y - p.z, 30); gr.addColorStop(0, 'rgba(0,0,0,0.9)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = gr; x.fillRect(p.x - cam - 30, p.y - p.z - 30, 60, 60); }
  g.drawImage(c, 0, 0);
  /* enemy eyes glint in the dark */
  for (const e of G.enemies) if (!e.dead) { const ex = e.x - cam, ey = e.y - e.z - entHeight(e) * 0.42; g.fillStyle = '#ff2040'; g.fillRect(ex - 2, ey, 1.5, 1); g.fillRect(ex + 1, ey, 1.5, 1); }
}
/* STAGE 5: rising water + live cables */
MECH.flood = {
  init() { G.wl = 0; later(() => talk('triton', 'r05a'), 3000); },
  update(dt) { const w = G.st.waves[G.waveIdx], want = G.locked && w && w.flood ? 1 : G.bossSpawned ? 0.55 : 0; G.wl = lerp(G.wl, want, dt * 0.35); if (G.wl > 0.5) for (const h of G.heroes) { h.vx *= 1 - dt * 2.2; if (h.st === 'walk' && Math.random() < dt * 8) G.parts.push({ x: h.x + rnd(-6, 6), y: h.y, z: 2, vx: rnd(-30, 30), vy: 0, vz: rnd(30, 70), life: 0.4, t: 0, col: '#9cf4ff', size: 1, grav: 400 }); } if (G.waveIdx === 3 && !G.f3) { G.f3 = true; talk('malakor', 'r05c'); } },
  waveStart(i, w) { if (w.flood) { G.hzOn = 'shock'; G.hzT = 1.2; } if (i === 1) talk('lupus_h', 'r05b'); },
  boss(e) { G.hzOn = 'shock'; G.hzT = 3; },
  drawBack(g, cam) { const wl = G.wl || 0; if (wl < 0.02) return; const top = VIEW_H - (VIEW_H - WALL_Y + 4) * wl; g.save(); g.fillStyle = 'rgba(30,120,130,' + (0.32 * wl).toFixed(3) + ')'; g.fillRect(0, top, VW, VIEW_H - top); g.fillStyle = 'rgba(190,250,255,' + (0.4 * wl).toFixed(3) + ')'; for (let i = 0; i < 40; i++) { const x = ((i * 47.3 - cam * 0.9 + G.time * 12) % (VW + 20) + VW + 20) % (VW + 20) - 10; g.fillRect(x, top + (i % 4) * 9 + Math.sin(G.time * 3 + i) * 1.5, 10 + (i % 3) * 6, 0.5); } g.restore(); }
};
/* STAGE 6: destroy 3 incubators before the timer ends */
MECH.sabotage = {
  init() { G.incubs = G.st.incub.map(x => addObj('incub', x, LANE_T + 8, 950, 'e')); G.timer = G.st.timer * ({ easy: 1.3, normal: 1, hard: 0.92, nightmare: 0.85 })[SAVE.diff || 'normal']; G.incDown = 0; later(() => talk(null, 'r06a'), 3000); later(() => talk('malakor', 'r06b'), 7000); },
  update(dt) { if (G.title <= 0 && !G.bossSpawned && G.over <= 0 && !G.panel) { G.timer -= dt; if (G.timer <= 0) { G.timer = 0; G.failMsg = 'failTime'; G.over = 0.001; musicStop(); } } },
  objDown(ob) {
    G.incDown++; talk('lupus_h', ['r06c', 'r06d', 'r06e'][G.incDown - 1]);
    // Hatching is part of this encounter, including the delay before the first
    // mutant appears. An incubator broken between waves must not consume one.
    if (!G.locked) { G.locked = true; G.sideEncounter = true; }
    G.goT = 0;
    for (let i = 0; i < 3; i++) G.spawnQ.push({ t: 0.3 + i * 0.2, type: i === 2 ? 'X' : 'M', side: 1, x: ob.x + (i - 1) * 16, y: clamp(ob.y + 18, LANE_T, LANE_B), arrive: false });
    G.timer += 20; G.banner2 = { t: 0, txt: T('obj_incub') + ' ' + G.incDown + '/3  +0:20' };
  },
  gate() { return G.incDown >= 3 ? null : 'gateIncub'; },
  hud(g) { if (G.bossSpawned) return; const t = Math.max(0, G.timer), red = t < 60 && Math.sin(G.time * 8) > 0; PIX.text(g, fmtTime(t), VW / 2, 50, { align: 'c', s: 2, col: red ? '#ff2a40' : COLR.white, out: '#000' }); PIX.text(g, T('obj_incub') + ' ' + G.incDown + '/3', VW - 8, 56, { align: 'r', col: '#a7ff1a', out: '#0c0710' }); }
};
/* STAGE 7: ghost fog + Echo's duel */
MECH.fog = {
  init() { later(() => talk('malakor', 'r07a'), 3000); },
  update(dt) { if (G.waveIdx === 3 && !G.f7) { G.f7 = true; talk('lupus_h', 'r07b'); } },
  duel() { showPanel('cs51', [{ t: 'say', spk: 'echo', k: 'm07a' }, { t: 'say', spk: 'lupus_h', k: 'm07b' }], () => spawnMini('echo_mb')); },
  yieldMini(e) { later(() => { if (!G || G.over) return; e.dead = true; e.deadT = 100; e.hp = 0; G.mini = null; showPanel('cs26', [{ t: 'say', spk: 'echo', k: 'm07c' }, { t: 'say', spk: 'lupus_h', k: 'm07d' }, { t: 'say', spk: 'echo', k: 'm07e' }], () => { G.duelHold = false; }); }, 700); },
  boss() { talk('vespera', 'r07c'); talk('morrigan', 'r07d'); },
  entAlpha(e) { if (e.kind === 'enemy' && e.type === 'P' && !e.dead) { const n = Math.min(...G.heroes.map(h => Math.abs(h.x - e.x))); return G.sensing ? 1 : n < 70 ? 0.9 : 0.12; } return null; },
  drawOver(g, cam) { g.save(); g.fillStyle = 'rgba(20,60,50,0.28)'; g.fillRect(0, 0, VW, VH); for (let i = 0; i < 5; i++) { const x = ((i * 233 - cam * 0.6 + G.time * 10) % (VW + 300) + VW + 300) % (VW + 300) - 150; const gr = g.createRadialGradient(x, 210, 10, x, 210, 140); gr.addColorStop(0, 'rgba(160,255,220,0.10)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(x - 150, 60, 300, 210); } g.restore(); }
};
/* STAGE 8: the ritual — defend the stone gargoyle until the third bell */
MECH.ritual = {
  init() { G.bell = 0; },
  waveStart(i, w) {
    if (!w.ritual) return; G.ritual = { t: 0, next: 22, spawnT: 1 }; G.statue = addObj('statue', G.camX + VW * 0.5 - 20, LANE_T + 16, 2600, 'p', { hr: 20 }); G.objTarget = G.statue; G.duelHold = true; talk(null, 'r08a');
  },
  spawned(e) { if (G.statue && !G.statue.dead && Math.random() < 0.45 && e.def.ai === 'melee') e.objT = G.statue; },
  update(dt) {
    const R = G.ritual; if (!R || R.done) return; R.t += dt;
    if (R.t >= R.next && G.statue) { G.bell++; R.next += 22; sfx('boom'); playSting('sting_reveal'); shake(6); ringFx(G.statue.x, G.statue.y, 20, 200, '#ffb060', 1); talk(null, ['r08b', 'r08c', 'r08d'][G.bell - 1]); if (G.statue) G.statue.hp = Math.min(G.statue.maxhp, G.statue.hp + 300); }
    if (G.bell >= 3) { R.done = true; G.spawnQ = []; later(() => this.awaken(), 1200); return; }
    R.spawnT -= dt; if (R.spawnT <= 0 && enemiesAlive() < 3 + G.bell + DF().extra) { R.spawnT = rnd(1.4, 2.6) * (G.bell >= 2 ? 0.8 : 1); const pool = [['P', 'S', 'R'], ['P', 'S', 'R', 'ZS', 'C'], ['P', 'R', 'ZS', 'C', 'K', 'G']][G.bell]; const e = spawnEnemy(pick(pool), Math.random() < 0.5 ? -1 : 1); this.spawned(e); }
  },
  awaken() {
    if (!G || G.over || !G.statue) return; const s = G.statue; G.statuePct = Math.round(100 * s.hp / s.maxhp); s.dead = true; G.objs = G.objs.filter(o => o !== s); G.statue = null; G.duelHold = false;
    shake(14); sfx('roar'); G.flashScr = 0.6; ringFx(s.x, s.y, 10, 220, '#ff2a2a', 1); voice('brann_tagin', 0);
    const b = makeHero('brann', false, s.x, s.y); b.guest = true; b.inv = 2; G.heroes.push(b); G.guest = b; talk('brann', 'r08e');
  },
  objDown(ob) { if (ob.sub === 'statue') { G.failMsg = 'failStatue'; G.over = 0.001; musicStop(); } },
  boss() { talk('malakor', 'r08f'); talk('voss', 'r08g'); },
  hud(g) { if (!G.ritual || G.ritual.done) return; for (let i = 0; i < 3; i++) { const on = i < G.bell, x = VW / 2 - 30 + i * 30; g.fillStyle = on ? '#ffb02a' : '#3a3448'; g.beginPath(); g.moveTo(x - 7, 66); g.quadraticCurveTo(x, 48, x + 7, 66); g.fill(); g.fillRect(x - 1, 66, 2, 3); } PIX.bar(g, VW / 2 - 40, 72, 80, 3, (G.ritual.t % 22) / 22, '#ffb02a', '#1a1020'); }
};
/* STAGE 9: the maintenance platform climbing Thorne Tower */
MECH.climb = {
  init() { G.arena = true; G.locked = true; G.camX = (WORLD_W - VW) / 2; G.player.x = G.camX + 120; if (G.ally) G.ally.x = G.player.x; G.waveIdx = 0; G.nextWave = 1.8; G.alt = 0; G.boltT = 5; G.windT = 14; G.props = []; },
  update(dt) {
    G.alt += dt * (G.bossSpawned ? 0 : 3.2);
    if (!G.bossSpawned && !G.bossPending) {
      if (G.spawnQ.length === 0 && enemiesAlive() === 0) { G.nextWave -= dt; if (G.nextWave <= 0) { const w = G.st.waves[G.waveIdx]; if (w) { startWave(w); G.waveIdx++; G.nextWave = 2.2; if (G.waveIdx === 2) talk('echo', 'r09b'); if (G.waveIdx === 4) talk('brann', 'r09c'); } else { G.bossPending = true; G.bossT = 2; G.banner = { t: 0, boss: BOSS[G.st.boss] }; sfx('alarm'); } } }
    }
    G.boltT -= dt; if (G.boltT <= 0 && G.title <= 0) { G.boltT = rnd(3.2, 5.2) * (G.bossSpawned ? 1.3 : 1); const p = G.player; G.hz.push({ kind: 'bolt', x: clamp(p.x + rnd(-40, 60), G.camX + 30, G.camX + VW - 110), y: clamp(p.y + rnd(-10, 10), LANE_T + 6, LANE_B - 4), r: 26, t: 0, warn: 1.1, live: 0.25, dmg: 62 }); }
    G.windT -= dt; if (G.windT <= 0) { G.windT = rnd(12, 18); G.wind = { t: 0, dir: Math.random() < 0.5 ? -1 : 1 }; G.banner2 = { t: 0, txt: T('wind') }; sfx('dash'); }
    if (G.wind) { G.wind.t += dt; for (const e of G.heroes.concat(G.enemies)) if (!e.dead && e.kind !== 'boss') e.x += G.wind.dir * 46 * dt; if (G.wind.t > 2.2) G.wind = null; }
  },
  bg(g, cam) {
    const im = ART.img['s7_l3'], im2 = ART.img['s7_l2']; const off = (G.alt * 9) % 360;
    if (im2 && im2.width) { const h = VIEW_H, w = TILE_W; for (let i = -1; i < 2; i++) { g.drawImage(im2, 0, 0, im2.width, im2.height * 0.7, -((cam * 0.3) % w), (off * 0.4) + i * h * 0.7 - 30, w, h * 0.7); g.drawImage(im2, 0, 0, im2.width, im2.height * 0.7, w - ((cam * 0.3) % w), (off * 0.4) + i * h * 0.7 - 30, w, h * 0.7); } }
    if (im && im.width) { const sh = im.height * 0.58, dh = WALL_Y; for (let i = -1; i < 2; i++) { const y = ((off) % dh) + i * dh; for (let j = 0; j < 2; j++) g.drawImage(im, 0, 0, im.width, sh, j * TILE_W - (cam % TILE_W), y, TILE_W, dh); } }
    /* the platform */
    g.fillStyle = '#0c0a12'; g.fillRect(0, WALL_Y - 4, VW, VIEW_H - WALL_Y + 4); g.fillStyle = '#2a2836'; for (let x = -((cam) % 16); x < VW; x += 16) { g.fillRect(x, WALL_Y, 1, VIEW_H - WALL_Y); } for (let y = WALL_Y + 6; y < VIEW_H; y += 10) { g.fillStyle = y % 20 ? '#1a1822' : '#24222e'; g.fillRect(0, y, VW, 1); }
    g.fillStyle = '#ffcf3a'; for (let x = 0; x < VW; x += 20) g.fillRect(x, WALL_Y - 4, 10, 3); g.fillStyle = '#3a3848'; g.fillRect(0, WALL_Y - 22, VW, 3); for (let x = 6; x < VW; x += 40) g.fillRect(x, WALL_Y - 22, 3, 22);
    if (Math.random() < 0.004) G.flashScr = Math.max(G.flashScr, 0.15);
  },
  hud(g) { PIX.text(g, Math.floor(G.alt) + ' M', VW - 8, 56, { align: 'r', col: '#9cd8ff', out: '#0c0710' }); }
};
/* STAGE 10: the giant Leviathan + Triton's choice */
MECH.giant = {
  init() { },
  boss(e) { talk('triton', 'r10a'); },
  gate() { return null; }
};
/* STAGE 11: maglev roof — poles (jump) and tunnels (duck = hold block) */
MECH.train = {
  init() { G.trainT = 6; G.dodgeHits = 0; G.speedFx = true; later(() => talk(null, 'r11a'), 2500); later(() => talk(null, 'r11b'), 6000); },
  update(dt) {
    if (G.title > 0 || G.clearT) return; G.trainT -= dt;
    if (G.trainT <= 0) { G.trainT = rnd(5.5, 8) * (G.bossSpawned ? 1.4 : 1); const kind = Math.random() < 0.5 ? 'pole' : 'tunnel'; G.obst = { kind, t: 0, warn: 1.3 * DF().wind + 0.3, x: VW + 40, hit: new Set() }; sfx('alarm'); }
    const O = G.obst; if (!O) return; O.t += dt;
    if (O.t > O.warn) { O.x -= 900 * dt; const wx = O.x + G.camX;
      for (const e of G.heroes.concat(G.enemies)) { if (e.dead || O.hit.has(e) || e.kind === 'boss') continue; if (Math.abs(e.x - wx) > (O.kind === 'tunnel' ? 30 : 10)) continue; const safe = O.kind === 'pole' ? e.z > 14 : (e.st === 'guard' || e.st === 'down'); if (safe) { if (e.kind === 'hero' && e.isPlayer && !O.ok) { O.ok = true; textFx(e.x, e.y - 90, T('dodge'), '#7dff9a', 1); } continue; } O.hit.add(e); if (e.kind === 'hero') G.dodgeHits++; hurt({ x: e.x + 30, y: e.y, team: e.team === 'p' ? 'e' : 'n' }, e, (e.kind === 'hero' ? e.maxhp * 0.13 : 90), { launch: true, kx: -240, kz: 200, ignoreInv: e.kind !== 'hero', brk: true }); shake(6); }
      if (O.x < -120) G.obst = null; }
  },
  boss() { showPanel('cs35', [{ t: 'say', spk: 'kreutz', k: 'm11a' }, { t: 'say', spk: 'lupus_h', k: 'm11b' }]); },
  drawOver(g) {
    const O = G.obst; if (!O) return;
    if (O.t < O.warn) { if (Math.floor(O.t * 8) % 2) { g.fillStyle = '#ffd23a'; g.beginPath(); g.moveTo(VW - 10, 150); g.lineTo(VW - 34, 140); g.lineTo(VW - 34, 160); g.fill(); PIX.text(g, T(O.kind === 'pole' ? 'jumpNow' : 'duckNow'), VW - 40, 146, { align: 'r', col: '#ffd23a', out: '#000' }); } return; }
    if (O.kind === 'pole') { g.fillStyle = '#0a0812'; g.fillRect(O.x - 6, 0, 12, VIEW_H); g.fillStyle = '#3a3448'; g.fillRect(O.x - 6, 0, 2, VIEW_H); g.fillStyle = '#ff2a40'; g.fillRect(O.x - 6, LANE_T - 4, 12, 4); }
    else { g.fillStyle = 'rgba(4,2,8,0.92)'; g.fillRect(O.x - 30, 0, 360, LANE_T + 26); g.fillStyle = '#1a1622'; g.fillRect(O.x - 30, LANE_T + 22, 360, 4); RD.glow(g, O.x - 20, LANE_T + 20, 30, '#ffd23a', 0.4); }
  },
  hud(g) { }
};
/* STAGE 12: rescue the half-transformed civilians */
MECH.rescue = {
  init() { G.civs = []; G.civSaved = 0; G.civLost = 0; G.hope = 0; later(() => talk(null, 'r12a'), 2600); },
  waveStart(i, w) { for (let k = 0; k < (w.civ || 0); k++) G.civs.push({ x: G.camX + 90 + k * ((VW - 220) / Math.max(1, w.civ - 1 || 1)) + rnd(-10, 10), y: rnd(LANE_T + 6, LANE_B - 6), hold: 0, saved: false, lost: false, by: null, face: Math.random() < 0.5 ? 1 : -1, ph: Math.random() * 6 }); if (i === 1) talk('vespera', 'r12b'); },
  update(dt) {
    for (const c of G.civs) { if (c.saved) { c.x -= 70 * dt; c.fade = Math.max(0, (c.fade == null ? 1 : c.fade) - dt * 0.8); continue; } if (c.lost || c.by) continue;
      const near = G.heroes.find(h => !h.dead && Math.abs(h.x - c.x) < 22 && Math.abs(h.y - c.y) < 12);
      if (near) { c.hold += dt; if (c.hold > 0.5) { c.saved = true; G.civSaved++; G.hope = G.civSaved; sfx('pick'); ringFx(c.x, c.y, 6, 40, '#7dff9a', 0.4); textFx(c.x, c.y - 60, T('saved') + ' ' + G.civSaved, '#7dff9a', 1); if (G.civSaved === 6) talk('lupus_h', 'r12c'); } } else c.hold = Math.max(0, c.hold - dt); }
    G.civs = G.civs.filter(c => !(c.saved && c.fade <= 0) && !c.lost);
  },
  boss() { talk('kane', 'r12d'); },
  drawEnts(g, cam) { for (const c of G.civs) { const fr = ART.frame('mutant', c.by || c.saved ? 'walk' : 'hurt', c.by || c.saved ? Math.floor(G.time * 10) : (Math.sin(G.time * 3 + c.ph) > 0 ? 0 : 1)); if (!fr) continue; const x = c.x - cam; ART.shadow(g, x, c.y + 1, 12, 0.5); if (!c.saved && !c.by) { g.save(); g.globalAlpha = 0.5 + 0.2 * Math.sin(G.time * 5 + c.ph); g.strokeStyle = '#7dff9a'; g.lineWidth = 1; g.beginPath(); g.ellipse(x, c.y + 1, 15, 4.5, 0, 0, 7); g.stroke(); g.restore(); } ART.draw(g, fr, x, c.y, { face: c.saved ? -1 : c.face, sc: depthScale(c.y) * 0.84, alpha: c.saved ? c.fade : 1, tint: '#a8e0ff', tintA: 0.5 }); if (!c.by && !c.saved) { if (c.hold > 0) PIX.bar(g, x - 10, c.y - 52, 20, 3, c.hold / 0.5, '#7dff9a', '#1a1020'); else if (Math.sin(G.time * 5 + c.ph) > 0) PIX.text(g, '!', x, c.y - 56, { align: 'c', col: '#7dff9a' }); } } },
  hud(g) { PIX.text(g, T('hope') + ' ' + G.civSaved, VW - 8, 56, { align: 'r', col: '#7dff9a', out: '#0c0710' }); }
};
/* STAGE 13: hold the line while the antidote brews (3 stages) */
MECH.brew = {
  init() { G.arena = true; G.locked = true; G.camX = (WORLD_W - VW) / 2; G.player.x = G.camX + 110; if (G.ally) G.ally.x = G.player.x - 20; G.vat = addObj('vat', G.camX + VW * 0.5 - 10, LANE_T + 8, 3200, 'p', { hr: 22 }); G.objTarget = G.vat; G.brew = 0; G.brewT = 0; G.brewDur = ({ easy: 26, normal: 30, hard: 33, nightmare: 36 })[SAVE.diff || 'normal']; G.spawnT = 2.5; G.props = []; later(() => talk(null, 'r13a'), 2200); },
  update(dt) {
    if (G.title > 0 || G.bossSpawned || G.bossPending) return;
    if (G.brew < 3) { G.brewT += dt; if (G.brewT >= G.brewDur) { G.brewT = 0; G.brew++; sfx('ok'); playSting('sting_clear'); ringFx(G.vat.x, G.vat.y, 10, 80, '#30ffd0', 0.6); if (G.brew < 3) talk('malakor', G.brew === 1 ? 'r13b' : 'r13c'); G.vat.hp = Math.min(G.vat.maxhp, G.vat.hp + 400); } }
    if (G.brew < 3) { G.spawnT -= dt; if (G.spawnT <= 0 && enemiesAlive() < 3 + G.brew + DF().extra) { G.spawnT = rnd(1.2, 2.4); const e = spawnEnemy(pick(G.st.pools[Math.min(2, G.brew)]), Math.random() < 0.5 ? -1 : 1); if (Math.random() < 0.45 && e.def.ai !== 'ranged') e.objT = G.vat; } }
    else if (enemiesAlive() === 0) { G.vatPct = Math.round(100 * G.vat.hp / G.vat.maxhp); G.bossPending = true; G.bossT = 2; G.banner = { t: 0, boss: BOSS[G.st.boss] }; sfx('alarm'); }
  },
  objDown(ob) { G.failMsg = 'failVat'; G.over = 0.001; musicStop(); },
  boss() { talk('malakor', 'r13d'); },
  drawBack(g, cam) { const fr = ART.frame('malakor', 'idle', Math.floor(G.time * 6)); if (fr && G.vat && !G.vat.dead && !(G.ally && G.ally.id === 'malakor')) ART.draw(g, fr, G.vat.x + 34 - cam, G.vat.y - 2, { face: -1, sc: 0.92 }); },
  hud(g) { if (G.bossSpawned) return; PIX.text(g, T('antidote'), VW / 2, 48, { align: 'c', col: '#30ffd0', out: '#000' }); for (let i = 0; i < 3; i++) PIX.bar(g, VW / 2 - 60 + i * 41, 59, 38, 5, i < G.brew ? 1 : i === G.brew ? G.brewT / G.brewDur : 0, '#30ffd0', '#1a1020'); }
};
/* STAGE 14: siege — destroy the three catapult towers to open the gate */
MECH.siege = {
  init() { G.towers = G.st.towers.map(x => addObj('tower', x, LANE_T + 2, 1200, 'e', { fireT: rnd(2, 4), fire: 0, hr: 18 })); G.towDown = 0; later(() => talk(null, 'r14a'), 2600); },
  update(dt) {
    for (const t of G.towers) { if (t.dead) continue; t.fire = Math.max(0, t.fire - dt * 2); if (t.x < G.camX - 40 || t.x > G.camX + VW + 40) continue; t.fireT -= dt; if (t.fireT <= 0) { t.fireT = rnd(3.6, 5.2) * DF().cd; t.fire = 1; sfx('shot'); const p = G.player; G.hz.push({ kind: 'debris', x: clamp(p.x + rnd(-50, 70), G.camX + 30, G.camX + VW - 110), y: clamp(p.y + rnd(-14, 14), LANE_T + 6, LANE_B - 4), r: 30, t: 0, warn: 1.15, live: 0.25, dmg: 66 }); } }
  },
  objDown(ob) { G.towDown++; if (G.towDown === 1) talk('brann', 'r14b'); if (G.towDown === 3) { talk('echo', 'r14c'); G.banner2 = { t: 0, txt: T('gateOpen') }; } },
  gate() { return G.towDown >= 3 ? null : 'gateTowers'; },
  boss() { talk('kreutz', 'r14d'); },
  hud(g) { PIX.text(g, T('obj_tower') + ' ' + G.towDown + '/3', VW - 8, 56, { align: 'r', col: '#ff8a3a', out: '#0c0710' }); }
};
/* STAGE 15: shut down the three reactors feeding the red rain */
MECH.reactors = {
  init() { G.reacts = G.st.reactors.map(x => addObj('reactor', x, LANE_T + 6, 1400, 'e', { hr: 18 })); G.reDown = 0; later(() => talk('echo', 'r15a'), 2600); },
  objDown(ob) { G.reDown++; talk('lupus_h', G.reDown < 3 ? 'r15b' : 'r15d'); },
  gate() { return G.reDown >= 3 ? null : 'gateReactors'; },
  boss() { talk('vespera', 'r15c'); },
  hud(g) { PIX.text(g, T('obj_reactor') + ' ' + G.reDown + '/3', VW - 8, 56, { align: 'r', col: '#ff5a2a', out: '#0c0710' }); },
  rain() { return 1 - (G.reDown || 0) / 3; }
};
/* STAGE 16: the Heart of Fenrir */
MECH.final = {
  init() { },
  boss(e) { talk('thule', 'r16a', { vo: 'thule_line2' }); talk('lupus_h', 'r16c', { vo: 'lupus_line_final' }); },
  update(dt) { fenrirStep(dt); }
};

/* ---------------- glue called from the engine ---------------- */
function mechInit(G0, opt) {
  G.talkQ = []; G.objs = G.objs || []; G.sense = 100; G.sensing = false; G.senseK = 0;
  if (G.mode || !G.mech) { archInit(); return; }
  const M = MECH[G.mech]; if (M && M.init) M.init(opt); archInit();
  if (G.st.l44 && G.player) G.player.fury = 0;
}
function startWave(w) {
  G.locked = true; G.sideEncounter = false; G.goT = 0; const we = w.e.concat(w.e.length ? Array.from({ length: DF().extra }, (_, i) => w.e[i % w.e.length].replace('*', '')) : []);
  G.spawnQ = we.map((t, i) => ({ t: (w.amb ? 0.1 + i * 0.25 : 0.2 + i * 0.5), type: ngpSwap(t.replace('*', '')), elite: t.endsWith('*'), side: w.amb ? (i % 2 ? -1 : 1) : (i % 3 === 2 ? -1 : 1) }));
  playSting('sting_wave'); if (w.amb) { G.banner2 = { t: 0, txt: T('ambush') }; shake(4); } if (w.hz && G.st.hz !== 'none') { G.hzOn = G.st.hz; G.hzT = 1.5; }
  const M = MECH[G.mech]; if (M && M.waveStart) M.waveStart(G.waveIdx, w);
  if (w.duel && M && M.duel) { G.duelHold = true; M.duel(); }
}
/* New Game+: enemies are remixed */
const NGP_MIX = { S: ['P', 'R'], Z: ['N', 'ZS'], H: ['C', 'X'], M: ['X', 'P'], ZS: ['G'], V: ['D', 'N'], K: ['A', 'G'], A: ['K'], T: ['T'] };
function ngpSwap(t) { if (!SAVE.ngp || !G || G.mode || !NGP_MIX[t] || Math.random() > 0.35) return t; return pick(NGP_MIX[t]); }

/* stingers (short one-shot cues from Audio Pack 4) */
const STING = {};
function playSting(n) { if (!SAVE.music) return; let a = STING[n]; if (!a) { a = new Audio('assets/music/' + n + '.ogg'); a.addEventListener('error', () => { a.bad = true; }); STING[n] = a; } if (a.bad) { sfx(n === 'sting_boss' ? 'stingBoss' : 'sting'); return; } try { a.currentTime = 0; a.volume = 0.8; const p = a.play(); if (p && p.catch) p.catch(() => { }); } catch (e) { } }

/* challenges added by v8 */
const _chalDone = chalDone;
chalDone = function (c, G0, cleared) {
  if (!cleared) return false;
  switch (c.k) {
    case 'clues': return (G0.clueN || 0) >= 3;
    case 'gens': return (G0.gensLost || 0) === 0;
    case 'timeleft': return (G0.timer || 0) >= c.n;
    case 'statue': return (G0.statuePct || 0) >= c.n;
    case 'dodge': return (G0.dodgeHits || 0) <= c.n;
    case 'civ': return (G0.civSaved || 0) >= c.n;
    case 'vat': return (G0.vatPct || 0) >= c.n;
  }
  return _chalDone(c, G0, cleared);
};
