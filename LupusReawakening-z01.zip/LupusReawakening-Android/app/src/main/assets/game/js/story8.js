'use strict';
/* =====================================================================
   STORY v8 — every cutscene of the approved bible, page by page.
   cap = yellow caption, say/think = dialogue band with the speaker's
   portrait, fx = sound effect lettered on the art, vo = voice line.
   Duo pages (Lupus + the chosen partner) are inserted at five moments.
   ===================================================================== */
const cap = (k, o) => Object.assign({ t: 'cap', k, x: .03, y: .05 }, o || {});
const say = (spk, k, o) => Object.assign({ t: 'say', k, spk, x: .05, y: .05 }, o || {});
const th = (spk, k, o) => Object.assign({ t: 'think', k, spk, x: .05, y: .05 }, o || {});
const fx = (txt, x, y, col, rot) => ({ t: 'sfx', txt, x, y, col: col || '#ffcf3a', rot: rot || -0.15 });
const PG = (img, beats, f, o) => Object.assign(P(img, beats, f), o || {});
const DUO_SLOT = { duo: true };
Object.keys(CUTS).forEach(k => delete CUTS[k]);
Object.assign(CUTS, {
  /* every page: image, focus, then { mood: music, amb: ambience loop }; beats may carry snd: one-shot sound */
  intro: [
    [PG('cs77', [cap('i01a', { vo: 'narrator_open', snd: 'explosion' }), cap('i01b', { snd: 'gunshot' })], [.5, .4], { mood: 'cue_1944', amb: 'battle', alt: 'cs39', altMood: 'cue_villain', altAmb: 'lab44' })],
    [PG('cs39', [cap('i02a'), say('kreutz44', 'i02c', { vo: 'kreutz44_line', snd: 'strap' }), say('thule44', 'i02b'), say('thule44', 'i03a'), say('thule44', 'i03b'), th('lupus44', 'i03c')], [.4, .45], { mood: 'cue_villain', amb: 'lab44' })],
    [PG('cs78', [fx('ZZZAK!', .62, .30, '#7aff3a', -.15), say('lupus44', 'i04a', { shout: true, snd: 'scream' })], [.5, .4], { mood: 'cue_tension', amb: 'lab44' })],
    [PG('cs40', [say('kreutz44', 'i05a', { vo: 'kreutz44_intro', snd: 'keys' }), th('lupus44', 'i05b')], [.5, .4], { mood: 'cue_tension', amb: 'cell' })]
  ],
  /* v8.1: cs04 (long hair + white streak) left the prologue — in 1944 John still has short hair;
     cs41 now shows the beast in the torn olive uniform, the lab exploding behind him */
  s1post: [
    [PG('cs41', [fx('KRA-KOOOM!', .54, .09, '#ffcf3a', -.06), cap('p01a', { snd: 'explosion' }), cap('p01b', { snd: 'howl' })], [.5, .5], { mood: 'cue_1944', amb: 'snow' })],
    [PG('cs05', [cap('p01c'), cap('p01d')], [.5, .3], { mood: 'cue_mystery', amb: 'rain_city' })]
  ],
  s2pre: [
    [PG('cs06', [cap('s02a'), say('lupus_h', 's02b'), say('lupus_h', 's02c')], [.45, .5], { mood: 'cue_mystery', amb: 'rain_city' })],
    [PG('cs07', [th('lupus_h', 's02d')], [.6, .4], { mood: 'cue_mystery', amb: 'rain_city' })]
  ],
  s2post: [
    [PG('cs11', [say('warden', 'x02a', { weak: true }), cap('x02b')], [.5, .6], { mood: 'cue_tension', amb: 'rain_city' })],
    [PG('cs10', [cap('x02c'), say('vespera', 'x02d')], [.5, .5], { mood: 'cue_heroic', amb: 'rain_city' })]
  ],
  s3pre: [
    [PG('cs12', [cap('s03a'), say('vespera', 's03b', { snd: 'wings' })], [.5, .35], { mood: 'cue_heroic', amb: 'rooftop' })],
    [PG('cs43', [cap('s03c')], [.6, .4], { mood: 'cue_mystery', amb: 'rooftop' })]
  ],
  s3post: [
    [PG('cs44', [say('voss', 'x03a', { snd: 'engine' }), cap('x03b'), say('lupus_h', 'x03c', { shout: true })], [.6, .4], { mood: 'cue_tension', amb: 'rooftop' })],
    [PG('cs45', [cap('x03d', { snd: 'stone' })], [.5, .4], { reveal: true, mood: 'cue_sorrow', amb: 'rooftop' })]
  ],
  s4pre: [
    [PG('cs46', [cap('s04a'), say('vespera', 's04b'), say('triton', 's04c'), say('malakor', 's04d')], [.5, .4], { mood: 'cue_mystery', amb: 'refuge' })],
    [PG('cs15', [cap('s04e', { snd: 'gunfire' }), fx('BLAM!', .28, .30, '#ff6a2a', -.2), say('triton', 's04f', { shout: true, snd: 'crowd' })], [.5, .5], { mood: 'cue_tension', amb: 'chaos' })]
  ],
  s4post: [
    [PG('cs16', [say('malakor', 'x04a'), say('triton', 'x04b')], [.5, .4], { mood: 'cue_sorrow', amb: 'refuge' })],
    [PG('cs47', [cap('x04c'), th('malakor', 'x04d')], [.5, .4], { reveal: true, mood: 'cue_betrayal', amb: 'refuge' })],
    [PG('cs08', [cap('x04e')], [.5, .5], { mood: 'cue_heroic', amb: 'refuge' })],
    [PG('cs09', [say('lupus_h', 'x04f', { snd: 'howl' }), cap('x04g', { big: true })], [.5, .4], { mood: 'cue_heroic', amb: 'rooftop' })]
  ],
  s5pre: [
    [PG('cs17', [cap('s05a', { snd: 'splash' }), say('malakor', 's05b'), say('nacht', 's05c')], [.5, .4], { mood: 'cue_villain', amb: 'metro' })]
  ],
  s5post: [
    [PG('cs19', [say('nacht', 'x05a', { weak: true }), fx('GRRRAAH!', .72, .22, '#ff3a3a', -.1)], [.5, .4], { mood: 'cue_betrayal', amb: 'metro' })],
    [PG('cs48', [say('nacht', 'x05b', { weak: true, snd: 'holo' }), say('lupus_h', 'x05c'), say('nacht', 'x05d', { weak: true, snd: 'roar' })], [.5, .4], { reveal: true, mood: 'cue_villain', amb: 'metro' })]
  ],
  s6pre: [DUO_SLOT,
    [PG('cs20', [cap('s06a')], [.5, .4], { mood: 'cue_tension', amb: 'biolab' })],
    [PG('cs21', [say('lupus_a', 's06b'), say('lupus_a', 's06c', { shout: true, snd: 'roar' })], [.5, .4], { mood: 'cue_heroic', amb: 'biolab' })]
  ],
  s6post: [
    [PG('cs22', [cap('x06a'), fx('J-O-H-N!!', .55, .25, '#ff2a40', -.1), say('vespera', 'x06c')], [.5, .5], { mood: 'cue_sorrow', amb: 'biolab' })],
    [PG('cs23', [cap('x06d')], [.5, .5], { mood: 'cue_dawn', amb: 'dawn' })],
    [PG('cs49', [cap('x06e', { snd: 'glass' }), say('kreutz', 'x06f'), cap('x06g', { big: true })], [.5, .45], { reveal: true, mood: 'cue_villain', amb: 'biolab' })]
  ],
  act2: [
    [PG('cs24', [cap('a02a', { big: true, vo: 'narrator_act2' }), cap('a02b')], [.5, .55], { mood: 'cue_tension', amb: 'rain_city' })]
  ],
  s7pre: [
    [PG('cs50', [cap('s07a'), say('vespera', 's07b'), cap('s07c', { snd: 'laser' })], [.5, .4], { mood: 'cue_mystery', amb: 'necropolis' })]
  ],
  s7post: [
    [PG('cs52', [cap('x07a'), cap('x07b')], [.5, .4], { mood: 'cue_sorrow', amb: 'london' })],
    [PG('cs29', [say('morrigan', 'x07c', { weak: true }), cap('x07d', { snd: 'crows' }), say('vespera', 'x07e')], [.5, .5], { mood: 'cue_sorrow', amb: 'necropolis' })], DUO_SLOT
  ],
  s8pre: [
    [PG('cs53', [cap('s08a', { snd: 'door' }), say('malakor', 's08b'), say('lupus_h', 's08c')], [.5, .4], { mood: 'cue_tension', amb: 'crypt' })]
  ],
  s8post: [
    [PG('cs14', [say('voss', 'x08b', { weak: true })], [.5, .4], { mood: 'cue_villain', amb: 'crypt' })],
    [PG('cs54', [th('malakor', 'x08a')], [.5, .4], { reveal: true, mood: 'cue_betrayal', amb: 'crypt' })],
    [PG('cs27', [say('brann', 'x08c', { shout: true, snd: 'stone' }), say('brann', 'x08d')], [.5, .35], { mood: 'cue_heroic', amb: 'storm' })],
    [PG('cs28', [cap('x08e', { big: true })], [.5, .4], { mood: 'cue_heroic', amb: 'necropolis' })], DUO_SLOT
  ],
  s9pre: [
    [PG('cs30', [cap('s09a', { snd: 'thunder' }), say('lupus_h', 's09b'), say('echo', 's09c')], [.5, .3], { mood: 'cue_heroic', amb: 'storm' })]
  ],
  s9post: [
    [PG('cs31', [say('kane', 'x09a', { weak: true, snd: 'zap' })], [.5, .5], { mood: 'cue_villain', amb: 'storm' })],
    [PG('cs55', [cap('x09b', { snd: 'holo' }), say('triton', 'x09c'), say('malakor', 'x09d')], [.5, .4], { reveal: true, mood: 'cue_betrayal', amb: 'storm' })],
    [PG('cs56', [say('malakor', 'x09e'), cap('x09f')], [.5, .4], { mood: 'cue_sorrow', amb: 'rain_city' })],
    [PG('cs57', [cap('x09g', { snd: 'beep' }), fx('SKRRTCH!', .62, .55, '#3ae6ff', .12), say('echo', 'x09h', { snd: 'rip' })], [.5, .4], { reveal: true, mood: 'cue_betrayal', amb: 'rain_city' })], DUO_SLOT
  ],
  s10pre: [
    [PG('cs79', [say('triton', 's10a'), say('lupus_h', 's10b')], [.5, .4], { mood: 'cue_sorrow', amb: 'docks', alt: 'cs32' })],
    [PG('cs58', [cap('s10c'), say('triton', 's10d')], [.5, .4], { mood: 'cue_sorrow', amb: 'tanks' })],
    [PG('cs80', [fx('SKRAAAA!', .55, .14, '#3af0ff', -.1), say('triton', 's10f', { shout: true, snd: 'searoar' })], [.5, .3], { mood: 'cue_tension', amb: 'docks', alt: 'cs33' })]
  ],
  s10post: [
    [PG('cs59', [say('triton', 'x10a', { choice: 'spare' }), say('nereus', 'x10n', { choice: 'spare', vo: 'nereus_line2' }), say('triton', 'x10b', { choice: 'end' })], [.5, .5], { mood: 'cue_sorrow', amb: 'docks' })],
    [PG('cs60', [cap('x10c', { snd: 'holo' }), say('echo', 'x10d')], [.5, .5], { mood: 'cue_mystery', amb: 'docks' })], DUO_SLOT
  ],
  s11pre: [
    [PG('cs34', [cap('s11a'), say('vespera', 's11b', { shout: true })], [.5, .5], { mood: 'cue_heroic', amb: 'train' })]
  ],
  s11post: [
    [PG('cs61', [say('kreutz', 'x11a', { shout: true, snd: 'fall' })], [.5, .5], { mood: 'cue_villain', amb: 'train' })],
    [PG('cs62', [cap('x11b'), say('lupus_h', 'x11c')], [.5, .5], { mood: 'cue_tension', amb: 'train' })],
    [PG('cs63', [cap('x11d', { snd: 'thunder' }), cap('x11e', { big: true })], [.5, .5], { reveal: true, mood: 'cue_villain', amb: 'redrain' })]
  ],
  act3: [
    [PG('cs63', [cap('a03a', { big: true, vo: 'narrator_act3' }), cap('a03b')], [.5, .5], { mood: 'cue_villain', amb: 'redrain' })]
  ],
  s12pre: [DUO_SLOT,
    [PG('cs64', [cap('s12a', { snd: 'crowd' }), say('lupus_h', 's12b', { shout: true })], [.5, .5], { mood: 'cue_tension', amb: 'chaos' })]
  ],
  s12post: [
    [PG('cs65', [cap('x12a', { snd: 'holo' }), say('lupus_h', 'x12b')], [.5, .5], { mood: 'cue_mystery', amb: 'redrain' })]
  ],
  s13pre: [
    [PG('cs66', [cap('s13a'), say('malakor', 's13b')], [.5, .4], { mood: 'cue_sorrow', amb: 'chapel' })],
    [PG('cs81', [cap('s13c'), say('malakor_y', 's13d'), say('malakor', 's13e')], [.5, .4], { mood: 'cue_betrayal', amb: 'biolab', alt: 'cs67' })],
    [PG('duo_malakor_m4', [say('malakor', 'dm4a', { snd: 'crowd' }), say('lupus_h', 'dm4b'), say('malakor', 's13f')], [.5, .4], { mood: 'cue_heroic', amb: 'chaos' })]
  ],
  s13post: [
    [PG('cs68', [say('lupus_h', 'x13a'), say('malakor', 'x13b'), cap('x13c')], [.5, .4], { mood: 'cue_heroic', amb: 'chapel' })]
  ],
  s14pre: [
    [PG('cs69', [cap('s14a', { snd: 'cannon' }), say('brann', 's14b', { shout: true })], [.5, .4], { mood: 'cue_heroic', amb: 'siege' })]
  ],
  s14post: [
    [PG('cs70', [say('kreutz', 'x14a', { weak: true }), th('lupus_h', 'x14b'), say('lupus_h', 'x14c', { vo: 'lupus_line_remember' })], [.5, .4], { mood: 'cue_sorrow', amb: 'redrain' })]
  ],
  s15pre: [
    [PG('cs36', [cap('s15a', { snd: 'door' })], [.5, .35], { mood: 'cue_tension', amb: 'citadel' })],
    [PG('cs71', [cap('s15b'), say('echo', 's15c')], [.5, .4], { mood: 'cue_tension', amb: 'citadel' })]
  ],
  s15post: [
    [PG('cs72', [say('thule', 'x15a', { vo: 'thule_laugh' }), say('thule', 'x15b', { vo: 'thule_line1', snd: 'heartbeat' })], [.5, .3], { reveal: true, mood: 'cue_villain', amb: 'citadel' })],
    [PG('cs37', [fx('FWOOOM!', .50, .60, '#ffb020', -.15), say('firstwolf', 'x15c', { shout: true, vo: 'thule_reveal', snd: 'roar' })], [.5, .3], { mood: 'cue_villain', amb: 'citadel' })]
  ],
  s16pre: [DUO_SLOT],
  finale: [
    [PG('cs74', [cap('f01a', { snd: 'heartstop' }), cap('f01b'), say('lupus_h', 'f01c')], [.5, .5], { mood: 'cue_heroic', amb: 'citadel' })],
    [PG('cs75', [cap('f01d'), cap('f01e')], [.5, .5], { mood: 'cue_dawn', amb: 'dawn' })],
    [PG('cs38', [say('lupus_h', 'f01f'), cap('f01g', { snd: 'rumble' })], [.5, .45], { mood: 'cue_dawn', amb: 'dawn' })], DUO_SLOT,
    [PG('cs76', [cap('f01h'), th('lupus_h', 'f01i'), th('lupus_h', 'f01j'), cap('f01k', { big: true, vo: 'narrator_end' })], [.5, .45], { mood: 'cue_dawn', amb: 'office' })],
    [PG('cs76', [cap('f01l', { big: true }), cap('f01m')], [.5, .45], { trueEnd: true, mood: 'cue_mystery', amb: 'office' })]
  ]
});
/* duo scenes: moment -> where it plays for each partner (stage-cut id) */
const DUO_AT = {
  m1: { vespera: 's6pre', triton: 's6pre', malakor: 's6pre', echo: 's7post', brann: 's8post' },
  m2: { vespera: 's9post', triton: 's9post', malakor: 's9post', echo: 's9post', brann: 's9post' },
  m3: { vespera: 's10post', triton: 's10post', echo: 's10post', brann: 's10post', malakor: 'finale' },
  m4: { vespera: 's12pre', triton: 's12pre', echo: 's12pre', brann: 's12pre' },
  m5: { vespera: 's16pre', triton: 's16pre', malakor: 's16pre', echo: 's16pre', brann: 's16pre' }
};
const DUO_FEEL = { m1: { mood: 'cue_sorrow', amb: 'rain_city' }, m2: { mood: 'cue_sorrow', amb: 'rain_city' }, m3: { mood: 'cue_dawn', amb: 'dawn' }, m4: { mood: 'cue_heroic', amb: 'chaos' }, m5: { mood: 'cue_heroic', amb: 'citadel' } };
const DUO_N = { m1: 3, m2: 3, m3: 2, m4: 2, m5: 3 };
const DUO_LET = { vespera: 'v', triton: 't', malakor: 'm', echo: 'e', brann: 'b' };
function duoPage(cut, ally) {
  for (const m in DUO_AT) if (DUO_AT[m][ally] === cut) {
    const L = DUO_LET[ally], beats = []; const keys = ['a', 'b', 'c'];
    for (let i = 0; i < 3; i++) { const k = 'd' + L + m.slice(1) + keys[i]; if (!CT(k)) continue; beats.push(say(i % 2 ? 'lupus_h' : ROSTER_KEY[ally], k)); }
    if (cut === 's16pre') beats.unshift(cap('s16a'));
    return [PG('duo_' + ally + '_' + m, beats, [.5, .4], DUO_FEEL[m])];
  }
  return null;
}
/* who speaks (portrait) and their display names */
Object.assign(SPK_NAME, { lupus44: 'JOHN THORNE', thule44: 'DR. ALBRECHT THULE', thule: 'ALBRECHT THULE', kreutz44: 'LT. KREUTZ', nereus: 'NEREUS', malakor_y: 'MALAKOR (2190)', fenrir: 'FENRIR' });
/* soundtrack per page */
Object.keys(CUT_MOOD).forEach(k => delete CUT_MOOD[k]);
/* (music is set on every page above) */

/* ---------- loading on demand ---------- */
const COMIC_LIST = new Set([].concat(Array.from({ length: 81 }, (_, i) => 'cs' + String(i + 1).padStart(2, '0')),
  ['vespera', 'triton', 'malakor', 'echo', 'brann'].flatMap(p => ['m1', 'm2', 'm3', 'm4', 'm5'].map(m => 'duo_' + p + '_' + m)),
  ['vespera', 'triton', 'malakor', 'echo', 'brann'].map(p => 'super_' + p)));
COMIC.load = function () { COMIC.started = true; };
COMIC.has = k => COMIC_LIST.has(k);
COMIC.need = function (list, done) {
  let left = 0; const fin = () => { if (--left <= 0 && done) { const d = done; done = null; d(); } };
  for (const k of list) { if (!COMIC_LIST.has(k)) continue; let im = COMIC.img[k]; if (im && (im.ok || im.bad)) continue; left++;
    if (im) { im.addEventListener('load', fin); im.addEventListener('error', fin); continue; }
    im = new Image(); im.onload = () => { im.ok = true; fin(); }; im.onerror = () => { im.bad = true; fin(); }; im.src = 'assets/comic/' + k + '.webp'; COMIC.img[k] = im; }
  if (!left && done) done();
};
COMIC.free = function (keep) { const K = new Set(keep || []); for (const k in COMIC.img) { if (K.has(k) || k === '@duo') continue; const im = COMIC.img[k]; im.src = ''; delete COMIC.img[k]; } };
COMIC.pages = function (id) {
  const ally = (SAVE.ally && PARTNERS.includes(SAVE.ally)) ? SAVE.ally : null; const out = [];
  for (const pg of (CUTS[id] || [])) {
    if (pg.duo) { const d = ally ? duoPage(id, ally) : null; if (d) out.push(d); continue; }
    const p2 = pg.filter(p => COMIC.has(p.img) && !(p.trueEnd && archCount() < ARCH_N));
    if (p2.length) out.push(p2.map(p => Object.assign({}, p, { beats: p.beats.filter(b => !b.choice || b.choice === (SAVE.nereus || 'spare')) })));
  }
  return out;
};
COMIC.exists = id => COMIC.pages(id).length > 0;
