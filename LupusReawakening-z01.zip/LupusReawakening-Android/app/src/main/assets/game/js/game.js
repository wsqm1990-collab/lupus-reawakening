'use strict';
/* =====================================================================
   GAME: entities, physics, combat, AI, bosses, projectiles, particles
   World units = low-res pixels. Lane depth y in [LANE_T, LANE_B].
   ===================================================================== */
const GRAV = 820;
let G = null;
/* a delayed action that belongs to this run only: it is dropped if the player left the stage meanwhile */
function later(fn, ms) { const g0 = G; return setTimeout(() => { if (G && G === g0) fn(); }, ms); }

function newE(o) {
  return Object.assign({ x: 0, y: 230, z: 0, vx: 0, vy: 0, vz: 0, face: 1, hp: 100, maxhp: 100, st: 'idle', t: 0, ct: 0, inv: 0, flash: 0, dead: false, deadT: 0, poise: 0, team: 'e', shieldHP: 0, shieldT: 0, bleedT: 0, bleedD: 0, cd: 0.5, jug: 0, hr: 11 }, o);
}
const upMul = () => 1 + 0.15 * SAVE.up.dmg;
/* difficulty: enemy health, enemy damage, enemy attack cooldowns, simultaneous attackers, score bonus, partner regen */
/* each level changes behaviour, not only numbers: windups, simultaneous attackers, enemy combos and blocks, extra enemies, boss move sets, healing */
const DIFF = {
  easy: { hp: 0.7, dmg: 0.55, cd: 1.4, tok: -1, score: 0.75, regen: 1.6, wind: 1.35, combo: 0, eblock: 0, extra: 0, elite: 0, bossExtra: false, drops: 1.3, heroRegen: 1.2 },
  normal: { hp: 1, dmg: 1, cd: 1, tok: 0, score: 1, regen: 1, wind: 1, combo: 0.15, eblock: 0, extra: 0, elite: 0, bossExtra: false, drops: 1, heroRegen: 1 },
  hard: { hp: 1.35, dmg: 1.45, cd: 0.75, tok: 1, score: 1.3, regen: 0.6, wind: 0.8, combo: 0.45, eblock: 0.12, extra: 1, elite: 0.08, bossExtra: true, drops: 0.7, heroRegen: 0.6, armor: 0.75, vial: 0.18 },
  nightmare: { hp: 1.75, dmg: 2, cd: 0.55, tok: 2, score: 1.7, regen: 0.25, wind: 0.62, combo: 0.75, eblock: 0.28, extra: 2, elite: 0.18, bossExtra: true, drops: 0.45, heroRegen: 0.2, armor: 0.5, vial: 0.12 }
};
const DIFFS = ['easy', 'normal', 'hard', 'nightmare'];
const DF = () => DIFF[SAVE.diff] || DIFF.normal;
function setSt(e, st, t) { if (e.st !== st) e.ct = 0; e.st = st; if (t != null) e.t = t; }

function makeHero(id, isPlayer, x, y) {
  const d = HERO[id], maxhp = Math.round(d.hp * (1 + 0.2 * SAVE.up.hp) * (1 + 0.04 * (heroLv(id) - 1)) * (1 + 0.07 * skl(id).def));
  return newE({ kind: 'hero', id, team: 'p', isPlayer, x, y, hp: maxhp, maxhp, fury: 0, form: 'h', spCd: 0, dashCd: 0, chainT: 0, idx: 0, atkT: 0, atkDur: 0.25, hitDone: false, queued: false, air: false, aiT: 0, lastHurt: 9, hr: 10 });
}
function hs(h) {
  const K = skl(h.id), m = upMul() * (1 + 0.03 * (heroLv(h.id) - 1)) * (1 + 0.06 * K.atk), cdm = Math.max(0.35, (1 - 0.12 * SAVE.up.cd) * (1 - 0.07 * K.spc)), ka = K.def >= 2 ? 0.06 : 0;
  if (h.id === 'lupus') { const f = FORM[h.form]; return { dmg: f.dmg * m, reach: f.reach, dur: f.dur, armor: Math.min(0.8, f.armor * (DF().armor || 1) + ka), regen: f.regen, spd: f.spd, cd: f.cd * cdm }; }
  const d = HERO[h.id]; return { dmg: d.dmg * m, reach: d.reach, dur: d.dur, armor: Math.min(0.8, (d.armor || 0) * (DF().armor || 1) + ka), regen: 0, spd: d.spd, cd: d.cd * cdm };
}
const heroKey = h => { if (h.id === 'lupus') { const p44 = G && G.st && G.st.l44 && !G.mode; if (h.form === 'h' && (p44 || skinOn('lupus'))) return 'lupus44'; if (h.form === 'f' && p44 && window.ATLAS.lupus44_f) return 'lupus44_f'; return FORM[h.form].key; } return skinOn(h.id) ? SKINS[h.id].key : HERO[h.id].key; };

/* ---------- world ---------- */
function newGame(si, opt) {
  opt = opt || {}; const st = STAGES[si]; WORLD_W = st.w || 1620;
  G = {
    stage: si, st, heroes: [], enemies: [], props: [], proj: [], parts: [], slashes: [], rings: [], texts: [], drops: [], lines: [], flashes: [],
    camX: 0, locked: false, waveIdx: 0, spawnQ: [], score: 0, combo: 0, comboT: 0, maxCombo: 0, time: 0, shake: 0, hitstop: 0, flashScr: 0,
    tok: 0, banner: null, title: 2.8, say: null, sayT: 0, bossSpawned: false, bossPending: false, boss: null, over: 0, clearT: 0, slow: 1, goT: 0, hintT: si === 0 ? 11 : 0, kills: 0, lastE: null, lastET: 0,
    leaving: [], tagCd: 0, assistCd: 0, autoTag: 0, lastHitT: -9, hz: [], hzOn: null, hzT: 2, syn: 0, superFx: null, shards: 0, hurtCount: 0, koCount: 0, xforms: 0, tags: 0, elites: 0, ck: 0
  };
  const solo = !opt.mode && (st.solo || !partnerOk(SAVE.ally, st.id)) && !(opt.mode === 'tutorial');
  const p = makeHero(SAVE.hero, true, 70, 232), a = solo ? null : makeHero(SAVE.ally, false, 40, 250);
  /* tag team: only the active hero is on the field; the partner waits off-screen (G.ally) */
  G.player = p; G.ally = a; G.team = a ? [p, a] : [p]; G.heroes = [p]; if (a) a.bench = true; G.objs = []; G.talkQ = []; G.mech = opt.mode ? null : st.mech;
  for (const x of st.props || []) G.props.push(newE({ kind: 'prop', team: 'n', key: Math.random() < 0.5 ? 'crate' : 'barrel', x, y: rnd(LANE_T + 6, LANE_B - 6), hp: 60, maxhp: 60, hr: 10 }));
  G.mode = opt.mode || null;
  if (G.mode === 'rush') { G.rushIdx = opt.rushIdx || 0; G.rushTime = opt.time || 0; G.waveIdx = st.waves.length; G.title = 1.2; G.hintT = 0; p.x = WORLD_W - VW * 0.6; a.x = p.x - 30; G.camX = WORLD_W - VW; G.props = []; if (opt.hp) { p.hp = Math.max(1, p.maxhp * opt.hp[0]); a.hp = a.maxhp * opt.hp[1]; if (opt.hp[1] <= 0) { a.dead = true; a.hp = 0; } } G.shards = opt.shards || 0; }
  if (G.mode === 'tutorial') { WORLD_W = 1620; G.camX = (WORLD_W - VW) / 2; p.x = G.camX + 110; a.x = p.x; G.locked = true; G.waveIdx = st.waves.length; G.title = 0; G.hintT = 0; G.props = []; G.tutNext = opt.next || 'stages';
    const d = spawnEnemy('Z', 1); d.arrive = false; d.x = G.camX + VW / 2 + 30; d.y = 232; d.face = -1; d.dummy = true; d.hp = d.maxhp = 99999; d.def = Object.assign({}, d.def, { name: T('dummy') });
    G.tut = { i: 0, moved: 0, lastX: p.x, t: 0, steps: ['move', 'attack', 'jump', 'dash', 'block', 'spec', 'tag', 'assist'].concat(SAVE.hero === 'lupus' || SAVE.ally === 'lupus' ? ['form'] : []).concat(['super', 'done']) }; }
  if (G.mode === 'endless') { WORLD_W = 1620; G.camX = (WORLD_W - VW) / 2; p.x = G.camX + 120; a.x = p.x; G.locked = true; G.ew = 0; G.ewActive = false; G.ewDelay = 2.5; G.title = 0; G.hintT = 0; G.props = G.props.filter(q => q.x > G.camX + 40 && q.x < G.camX + VW - 120); }
  if (st.say && !opt.fromWave && !G.mode) { G.sayQ = st.say; G.sayDelay = 2.8; }
  /* checkpoint: restart at the first wave not yet cleared */
  if (typeof mechInit === 'function') mechInit(G, opt);
  if (opt.fromWave) { const w = st.waves[opt.fromWave]; G.waveIdx = opt.fromWave; G.ck = opt.fromWave; G.title = 0; G.hintT = 0; if (w) { p.x = w.x - 140; a.x = p.x; G.camX = clamp(p.x - VW * 0.36, 0, WORLD_W - VW); G.props = G.props.filter(q => q.x > p.x); } }
  return G;
}
const aliveHeroes = () => G.heroes.filter(h => !h.dead);
function nearestHero(e) { if (e.objT && e.objT.hp > 0 && !e.objT.dead) return e.objT; let b = null, bd = 1e9; for (const h of G.heroes) { if (h.dead || h.st === 'down') continue; let d = dist(e, h); if (h.isPlayer) d *= 0.8; if (d < bd) { bd = d; b = h; } } return b || G.player; }
function nearestEnemy(a, maxd) { let b = null, bd = maxd || 1e9; for (const e of G.enemies) { if (e.dead) continue; const d = dist(a, e); if (d < bd) { bd = d; b = e; } } return b; }
const enemiesAlive = () => G.enemies.filter(e => !e.dead).length;

function spawnEnemy(type, side, elite) {
  if (!elite && !G.mode && Math.random() < (DF().elite || 0) + (SAVE.ngp ? 0.12 : 0)) elite = true;
  let def = ENEMY[type]; const sc = (1 + (0.12 * Math.min(G.stage, 5) + 0.05 * Math.max(0, G.stage - 5)) * (G.mode === 'endless' ? 0 : 1) + (G.endlessLv || 0) * 0.12) * (SAVE.ngp && !G.mode ? 1.35 : 1);
  if (elite) def = Object.assign({}, def, { name: T('elite') + ' ' + def.name, hp: def.hp * 2.6, pts: def.pts * 4, heavy: true, wind: (def.wind || 0.35) * 0.8, spd: def.spd * 1.15 });
  const x = side < 0 ? G.camX - 30 : G.camX + VW + 30, y = rnd(LANE_T + 4, LANE_B - 2);
  const e = newE({ kind: 'enemy', type, def, key: def.key, ai0: def.ai, x, y, face: side < 0 ? 1 : -1, hp: def.hp * sc * DF().hp, maxhp: def.hp * sc * DF().hp, ai: 'move', aiT: rnd(0, 0.5), cd: rnd(0.3, 1.4) * DF().cd, hr: def.hr, poiseMax: def.heavy ? def.hp * 0.4 : 1, blocking: false, arrive: true, dm: sc * DF().dmg });
  if (elite) { e.elite = true; e.dm *= 1.3; e.poiseMax = def.hp * 0.5; }
  G.enemies.push(e); return e;
}
function spawnBoss(id) {
  const def = BOSS[id];
  const bhp = def.hp * (0.5 + 0.5 * DF().hp) * (SAVE.ngp && !G.mode ? 1.3 : 1); const e = newE({ kind: 'boss', type: id, def, key: def.key, x: G.camX + VW + 70, y: 232, face: -1, hp: bhp, maxhp: bhp, pat: null, pi: 0, cd: 1.2, hr: def.hr, poiseMax: def.hp * 0.12, p2: false, frame: 'idle', dm: (1 + 0.09 * G.stage) * DF().dmg * (SAVE.ngp && !G.mode ? 1.2 : 1), bossIn: 1.6, fade: 1 });
  G.enemies.push(e); G.boss = e; G.bossSpawned = true; if (typeof voice === 'function') later(() => voice((def.vox || id) + '_intro'), 700); if (typeof bossSpawned === 'function') bossSpawned(e); return e;
}

/* ---------- fx ---------- */
function blood(x, y, z, n, col) { for (let i = 0; i < n; i++) G.parts.push({ x, y, z, vx: rnd(-90, 90), vy: rnd(-12, 12), vz: rnd(40, 170), life: rnd(0.4, 0.9), t: 0, col: col || (Math.random() < 0.7 ? '#b0001c' : '#ff2a44'), size: Math.random() < 0.3 ? 2 : 1, grav: 520, stick: true }); }
function sparks(x, y, z, n, col) { for (let i = 0; i < n; i++) { const a = rnd(0, 6.28), s = rnd(60, 190); G.parts.push({ x, y, z, vx: Math.cos(a) * s, vy: 0, vz: Math.sin(a) * s * 0.7 + 30, life: rnd(0.12, 0.3), t: 0, col: col || '#fff', size: 1, grav: 160 }); } }
function dust(x, y, n, col) { for (let i = 0; i < n; i++) G.parts.push({ x: x + rnd(-6, 6), y: y + rnd(-2, 2), z: 1, vx: rnd(-40, 40), vy: 0, vz: rnd(10, 40), life: rnd(0.25, 0.5), t: 0, col: col || '#8a8098', size: Math.random() < 0.4 ? 2 : 1, grav: 60, dust: true }); }
function debris(x, y, tag, n) { const pcs = Object.keys(window.ITEMS).filter(k => k.startsWith(tag)); for (let i = 0; i < n; i++) G.parts.push({ x, y, z: rnd(4, 20), vx: rnd(-110, 110), vy: rnd(-20, 20), vz: rnd(80, 220), life: rnd(1.6, 2.4), t: 0, img: pcs[i % pcs.length], rot: rnd(0, 6), vr: rnd(-12, 12), col: '#000', size: 1, grav: 620, bounce: 0.4 }); }
function slashFx(x, y, z, face, col, size, ang, dur) { G.slashes.push({ x, y, z, face, col: col || '#ff2a40', size: size || 30, ang: ang || 0, t: 0, dur: dur || 0.18 }); }
function ringFx(x, y, z, rmax, col, dur) { G.rings.push({ x, y, z: z || 0, rmax, col: col || '#ff2a40', t: 0, dur: dur || 0.4 }); }
function hitFlash(x, y, z, big, col) { G.flashes.push({ x, y, z, t: 0, dur: big ? 0.16 : 0.1, big, col: col || '#ffffff' }); }
function textFx(x, y, s, col, size) { G.texts.push({ x, y, s, col: col || '#fff', size: size || 1, t: 0, vy: -26 }); }
const shake = v => { G.shake = Math.max(G.shake, v); };
const freeze = t => { G.hitstop = Math.max(G.hitstop, t); };

/* ---------- damage ---------- */
const facingTo = (tg, att) => (att.x - tg.x) * tg.face >= 0;
function hurt(att, tg, dmg, o) {
  o = o || {};
  if (tg.dead) return false;
  if (tg.kind === 'obj') return objHurt(att, tg, dmg, o);
  if (tg.kind === 'prop') { tg.hp -= dmg; tg.flash = 1; tg.vx += (att.x < tg.x ? 1 : -1) * 30; sparks(tg.x, tg.y, 12, 5, '#d8b070'); sfx('hit'); shake(2); if (tg.hp <= 0) breakProp(tg); return true; }
  if (tg.inv > 0 && !o.ignoreInv) {
    if (tg.isPlayer && tg.st === 'dash' && tg.id === 'lupus' && !tg.cDone) { tg.cDone = true; tg.fury = Math.min(300, tg.fury + 22); textFx(tg.x, tg.y - 80, T('counter'), '#3af0ff', 1); sfx('pick'); }
    return false;
  }
  if (tg.team === 'e') {
    if (tg.kind === 'boss' && tg.bossIn > 0) return false;
    if (tg.st === 'down' && !o.ground) return false;
    let guarding = (tg.def.shield && tg.blocking) || tg.guard;
    if (!guarding && tg.kind === 'enemy' && !tg.dummy && tg.ai === 'move' && tg.st !== 'hurt' && DF().eblock && Math.random() < DF().eblock) { guarding = true; tg.ai = 'rec'; tg.t = 0.25; }
    if (guarding && !o.brk && facingTo(tg, att)) {
      dmg *= 0.12; sparks(tg.x + tg.face * 14, tg.y, 30, 8, '#9cf'); sfx('hit'); tg.flash = 0.4; tg.guardHit = (tg.guardHit || 0) + 1;
      if (!tg.blkT || G.time - tg.blkT > 0.6) { tg.blkT = G.time; textFx(tg.x, tg.y - 70, T('block'), '#9ca0b0', 1); } if (att.team === 'p' && att.st === 'atk') att.vx = -att.face * 70;
    }
  }
  if (tg.kind === 'hero' && tg.st === 'guard' && !o.unblock && (att.x - tg.x) * tg.face >= -4) {
    const parry = G.time - (tg.guardT0 || -9) < 0.18 + (skl(tg.id).def >= 3 ? 0.06 : 0);
    if (parry) {
      sparks(tg.x + tg.face * 14, tg.y, 34, 14, '#ffffff'); ringFx(tg.x + tg.face * 12, tg.y, 30, 34, '#9ab4ff', 0.3); freeze(0.1); shake(4); sfx('ok'); vibe(35, 200);
      textFx(tg.x, tg.y - 86, T('parry'), '#9ab4ff', 2); if (tg.id === 'lupus') tg.fury = Math.min(300, tg.fury + 25);
      if (att.kind === 'enemy' && !att.dead) { setSt(att, 'hurt', 0.9); att.vx = tg.face * 90; att.pat = null; }
      if (att.kind === 'boss' && !att.dead) { att.poise = (att.poise || 0) + att.poiseMax * 0.35; }
      tg.guardT0 = G.time; return false;
    }
    dmg *= 0.15; tg.vx = -tg.face * 40; sparks(tg.x + tg.face * 12, tg.y, 32, 6, '#9ab4ff'); sfx('hit'); tg.guardHitT = G.time;
    if (!o.launch || Math.random() < 0.6) { const dd = Math.max(1, Math.round(dmg)); tg.hp -= dd; textFx(tg.x, tg.y - 74, '' + dd, '#9ab4ff', 1); if (tg.hp <= 0) { kill(tg, att.x <= tg.x ? 1 : -1, att); } return true; }
  }
  let d = dmg * (o.mult || 1);
  if (tg.team === 'e' && att.team === 'p') d *= dmgBonus(att, tg, o);
  if (tg.team === 'e' && tg.def && tg.def.guardian && !(att.z > 2 || att.air || o.launch || o.brk) && facingTo(tg, att)) { d *= 0.1; if (!tg.gT || G.time - tg.gT > 0.8) { tg.gT = G.time; textFx(tg.x, tg.y - 70, T('fromAbove'), '#c8d8ff', 1); } sparks(tg.x + tg.face * 12, tg.y, 30, 6, '#c8d8ff'); }
  if (tg.giant && !tg.vuln) { sparks(att.x, att.y, 40, 4, '#9cf4ff'); return false; }
  if (tg.team === 'p') { d *= (1 - (tg.kind === 'hero' ? hs(tg).armor : 0)); if (tg.shieldHP > 0) { const ab = Math.min(tg.shieldHP, d); tg.shieldHP -= ab; d -= ab; sparks(tg.x, tg.y, 36, 6, '#a7ff1a'); } }
  d = Math.max(1, Math.round(d));
  tg.hp -= d; tg.flash = 1;
  const big = d > 60 || o.launch;
  sfx(big ? 'hit2' : 'hit');
  const hz = 28 + tg.z;
  blood(tg.x + (att.x < tg.x ? -3 : 3), tg.y, hz, big ? 10 : 5);
  hitFlash(tg.x + (att.x < tg.x ? -5 : 5), tg.y, hz, big, tg.team === 'e' ? '#ffffff' : '#ff6070');
  if (att.team === 'p' && tg.team === 'e') {
    G.combo++; G.comboT = 2.4; G.lastHitT = G.time; if (!G.superFx) G.syn = Math.min(100, G.syn + (0.9 + d * 0.012 + (att.assist ? 1.5 : 0)) * (skl(G.player.id).spc >= 3 ? 1.25 : 1)); G.maxCombo = Math.max(G.maxCombo, G.combo); G.lastE = tg; G.lastET = 2.5;
    textFx(tg.x + rnd(-5, 5), tg.y - (tg.kind === 'boss' ? 110 : 76), '' + d, big ? '#ffd23a' : '#ffffff', big ? 2 : 1);
    if (att.id === 'lupus' && att.form !== 'a') att.fury = Math.min(300, att.fury + d * 0.13 * (1 + 0.25 * SAVE.up.fury));
    if (att.id === 'vespera') att.hp = Math.min(att.maxhp, att.hp + d * 0.08);
    G.score += Math.round(d * 0.5);
    if (o.bleed) { tg.bleedT = 3; tg.bleedD = Math.max(tg.bleedD, 16 * upMul()); }
    freeze(big ? 0.08 : 0.045); shake(big ? 4 : 1.5);
  } else if (tg.team === 'p') {
    textFx(tg.x, tg.y - 74, '' + d, '#ff4060', 1);
    if (tg.id === 'lupus') tg.fury = Math.min(300, tg.fury + d * 0.1 * (1 + 0.25 * SAVE.up.fury));
    tg.lastHurt = 0; if (tg.kind === 'hero') { G.hurtCount++; if (tg.isPlayer && d >= 12) vibe(big ? 80 : 45, big ? 220 : 140); } sfx('hurt'); shake(big ? 5 : 2); G.flashScr = Math.max(G.flashScr, big ? 0.3 : 0.12);
  }
  const dir = att.x <= tg.x ? 1 : -1;
  if (tg.hp <= 0) { kill(tg, dir, att); return true; }
  if (tg.team === 'e') {
    if (tg.hasTok) { G.tok--; tg.hasTok = false; }
    const heavy = tg.def.heavy || tg.kind === 'boss';
    if (heavy) tg.poise += d;
    const airborne = tg.st === 'knock' && tg.z > 0;
    if (airborne && tg.kind !== 'boss') { /* juggle */ tg.jug++; tg.vz = Math.max(tg.vz, 150 * Math.pow(0.78, tg.jug)); tg.vx = dir * (o.kx || 60) * 0.6; tg.t = 0.6; }
    else if (o.launch && tg.kind !== 'boss') { if (heavy && tg.poise < tg.poiseMax) tg.vx += dir * 40; else { launch(tg, dir, o.kx || 120, o.kz || 210); tg.poise = 0; } }
    else if (!heavy || tg.poise >= tg.poiseMax || o.stun) {
      if (tg.kind === 'boss') { if (tg.poise >= tg.poiseMax) { tg.poise = 0; if (tg.pat && tg.pat.n !== 'charge') { setSt(tg, 'hurt', 0.3); tg.pat = null; tg.cd = 0.5; tg.vx = dir * 50; } } }
      else { setSt(tg, 'hurt', o.stun || 0.32); tg.vx = dir * (o.kx || 50); tg.ai = 'move'; tg.aiT = 0.3; if (tg.def.ai === 'lunge') tg.vz = 0; }
    } else tg.vx += dir * 12;
  } else if (tg.kind === 'hero') {
    if (o.launch) launch(tg, dir, o.kx || 120, o.kz || 210);
    else if (!(tg.form === 'a') && !(tg.form === 'f' && d < 30) && !(tg.id === 'brann' && d < 45)) { if (tg.st !== 'down' && tg.st !== 'knock') { setSt(tg, 'hurt', 0.28); tg.vx = dir * 50; } }
    tg.inv = Math.max(tg.inv, o.launch ? 1.0 : 0.55);
  }
  return true;
}
function launch(f, dir, kx, kz) { setSt(f, 'knock', 0.6); f.vx = dir * kx; f.vz = kz; f.z = Math.max(f.z, 1); f.jug = 0; f.ai = 'move'; if (f.hasTok) { G.tok--; f.hasTok = false; } if (f.kind === 'hero') { f.inv = 1.0; f.cDone = false; } }
function kill(f, dir, att) {
  if (typeof killHook === 'function' && killHook(f, dir, att)) return;
  f.dead = true; f.hp = 0; setSt(f, 'dead'); f.deadT = 0; f.vx = dir * 110; f.vz = 200; f.z = Math.max(f.z, 1);
  if (f.hasTok) { G.tok--; f.hasTok = false; }
  sfx('die'); blood(f.x, f.y, 30, 18);
  if (f.team === 'e') {
    { const h = G.player; if (h && !h.dead) { const before = heroLv(h.id); SAVE.xp = SAVE.xp || {}; SAVE.xp[h.id] = (SAVE.xp[h.id] || 0) + Math.round((f.def.pts || 100) / 6 * (f.kind === 'boss' ? 1.5 : 1)); G.xpGain = (G.xpGain || 0) + Math.round((f.def.pts || 100) / 6); const after = heroLv(h.id); if (after > before) { textFx(h.x, h.y - 110, T('levelUp') + ' ' + T('lv') + ' ' + after, '#7dff9a', 2); sfx('pick'); ringFx(h.x, h.y, 10, 70, '#7dff9a', 0.5); } } }
    G.kills++; G.score += (f.def.pts || 100) * (1 + Math.min(G.combo, 50) * 0.02) * DF().score | 0;
    if (f.kind === 'boss' && G.mode === 'endless') { shake(12); G.slow = 0.4; ringFx(f.x, f.y, 30, 200, '#ffffff', 0.9); sfx('boom'); for (let i = 0; i < 5; i++) G.drops.push({ x: f.x + (i - 2) * 14, y: f.y + 6, type: 'coin', t: 0, z: 30, vz: 140 + i * 15 }); G.boss = null; }
    else if (f.kind === 'boss' && (f.mini || (G.bosses && G.bosses.some(b => b !== f && !b.dead)))) { vibe(160, 200); shake(10); ringFx(f.x, f.y, 30, 160, '#ffffff', 0.7); sfx('boom'); G.drops.push({ x: f.x, y: f.y, type: 'vial', t: 0, z: 30, vz: 120 }); if (G.boss === f) G.boss = G.bosses.find(b => b !== f && !b.dead) || f; }
    else if (f.kind === 'boss') { vibe(260, 255); shake(14); G.slow = 0.3; G.clearT = 0.001; ringFx(f.x, f.y, 30, 200, '#ffffff', 0.9); ringFx(f.x, f.y, 30, 150, '#ff2a40', 1.2); sfx('boom'); G.drops.push({ x: f.x, y: f.y, type: 'vial', t: 0, z: 30, vz: 120 }); for (let i = 0; i < 5; i++) G.drops.push({ x: f.x + (i - 2) * 14, y: f.y + 6, type: 'coin', t: 0, z: 30, vz: 140 + i * 15 }); musicStop(); }
    else if (f.elite) { G.elites++; for (let i = 0; i < 3; i++) G.drops.push({ x: f.x + (i - 1) * 12, y: f.y, type: 'coin', t: 0, z: 10, vz: 100 + i * 20 }); G.drops.push({ x: f.x, y: f.y + 4, type: 'vial', t: 0, z: 10, vz: 90 }); }
    else { const r = Math.random() / DF().drops; if (r < 0.13) G.drops.push({ x: f.x, y: f.y, type: 'vial', t: 0, z: 10, vz: 90 }); else if (r < 0.26) G.drops.push({ x: f.x, y: f.y, type: 'fury', t: 0, z: 10, vz: 90 }); else if (r < 0.42) G.drops.push({ x: f.x, y: f.y, type: 'coin', t: 0, z: 10, vz: 90 }); }
  } else if (f.isPlayer) { G.koCount++; if (G.ally && !G.ally.dead) { G.autoTag = 1.1; textFx(f.x, f.y - 70, T('ko'), '#ff2a40', 2); } else { G.over = 0.001; musicStop(); } }
  else { textFx(f.x, f.y - 70, T('down'), '#ff2a40', 1); }
}
function breakProp(p) {
  if (p.key === 'barrel') { /* explosive barrel: blast hurts enemies around it */
    ringFx(p.x, p.y, 6, 80, '#ffb02a', 0.45); ringFx(p.x, p.y, 6, 50, '#ffffff', 0.3); hitFlash(p.x, p.y, 20, true, '#ffb02a'); shake(8); G.flashScr = Math.max(G.flashScr, 0.2);
    for (let i = 0; i < 16; i++) { const a = rnd(0, 6.28), sp = rnd(60, 200); G.parts.push({ x: p.x, y: p.y, z: 14, vx: Math.cos(a) * sp, vy: rnd(-15, 15), vz: rnd(60, 220), life: rnd(0.4, 0.8), t: 0, col: i % 2 ? '#ffb02a' : '#ff5020', size: 2, grav: 300, glowP: true }); }
    for (const e of G.enemies) if (!e.dead && Math.hypot(e.x - p.x, (e.y - p.y) * 1.6) < 80) hurt({ x: p.x, y: p.y, team: 'p', id: 'barrel' }, e, 110 * upMul(), { launch: e.kind !== 'boss', kx: 160, kz: 230, brk: true });
    for (const q of G.props) if (!q.dead && q !== p && Math.hypot(q.x - p.x, q.y - p.y) < 60) later(() => { if (!q.dead) breakProp(q); }, 120);
  }
  p.dead = true; sfx('boom'); shake(4); debris(p.x, p.y, p.key === 'crate' ? 'dc' : 'db', 9); dust(p.x, p.y, 8);
  const r = Math.random(); G.drops.push({ x: p.x, y: p.y, type: r < 0.45 ? 'vial' : r < 0.8 ? 'fury' : 'coin', t: 0, z: 14, vz: 120 });
}

/* ---------- projectiles ---------- */
function shoot(o) { const p = Object.assign({ x: 0, y: 230, z: 26, vx: 0, vy: 0, dmg: 20, team: 'e', r: 7, life: 2, type: 'bolt', pierce: false, hit: new Set(), col: '#ff2a40', launch: false, kx: 70, low: false, t: 0, brk: false }, o); G.proj.push(p); return p; }
function updProj(p, dt) {
  p.t += dt; p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt;
  if (p.type === 'orb' && p.wob) p.z = 30 + Math.sin(p.t * 9) * 6;
  const targets = p.team === 'p' ? foes() : G.heroes.concat(objsP());
  for (const f of targets) {
    if (f.dead || p.hit.has(f)) continue;
    if (Math.abs(p.y - f.y) > 12 + (p.type === 'wave' ? 6 : 0)) continue;
    if (Math.abs(p.x - f.x) > p.r + (f.hr || 10)) continue;
    if (p.low) { if (f.z > 16) continue; } else if (Math.abs(p.z - (f.z + 22)) > 34) continue;
    p.hit.add(f);
    hurt({ x: p.x - Math.sign(p.vx || 1) * 10, y: p.y, team: p.team, id: p.owner || '' }, f, p.dmg, { launch: p.launch, kx: p.kx, brk: p.brk, bleed: p.bleed });
    if (!p.pierce) { p.life = 0; sparks(p.x, p.y, p.z, 6, p.col); }
  }
  if (p.life <= 0 && (p.type === 'bolt' || p.type === 'orb')) sparks(p.x, p.y, p.z, 4, p.col);
}

/* ---------- physics ---------- */
function phys(f, dt) {
  if (f.z > 0 || f.vz !== 0) {
    f.vz -= GRAV * dt * (f.glide ? 0.35 : 1); if (f.glide && f.vz < -50) f.vz = -50;
    f.z += f.vz * dt;
    if (f.z <= 0) {
      f.z = 0;
      if (f.st === 'knock' || f.st === 'dead') {
        if (f.vz < -150) { f.vz = -f.vz * 0.33; f.z = 0.5; dust(f.x, f.y, 6); shake(2); sfx('land'); f.vx *= 0.6; return; }
        if (f.st === 'knock') { setSt(f, 'down', f.kind === 'hero' ? 0.5 : 0.7); dust(f.x, f.y, 4); }
      } else if (f.vz < -180) { sfx('land'); dust(f.x, f.y, 4); f.landT = 0.08; }
      f.vz = 0;
    }
  }
  f.glide = false;
}
function friction(f, dt, k) { f.vx *= Math.exp(-(k || 8) * dt); }
function bounds(f) {
  const lo = f.team === 'p' ? G.camX + 12 : 0, hi = f.team === 'p' ? (G.locked ? G.camX + VW - 96 : WORLD_W - 14) : WORLD_W;
  if (f.team === 'e' && f.kind === 'enemy' && !f.arrive && !f.dead) {
    const L = G.camX + 14, R = G.camX + VW - 135;
    if ((f.x < L || f.x > R) && f.st === 'knock' && Math.abs(f.vx) > 80) { f.vx = -f.vx * 0.45; sparks(f.x, f.y, 20, 8, '#fff'); shake(3); f.hp -= 8; dust(f.x, f.y, 5); }
    f.x = clamp(f.x, L, R);
  }
  if (f.kind === 'boss' && f.bossIn <= 0 && !f.fleeing && !f.giant) f.x = clamp(f.x, G.camX + 40 + (f.def.wide ? 50 : 0), G.camX + VW - 150 - (f.def.wide ? 50 : 0));
  if (f.team === 'p') f.x = clamp(f.x, lo, hi);
  f.y = clamp(f.y, LANE_T, LANE_B);
}
/* soft body separation (bodies push each other, props block) */
function separate(dt) {
  const bodies = G.enemies.filter(e => !e.dead && e.z < 20 && !e.arrive);
  for (let i = 0; i < bodies.length; i++) for (let j = i + 1; j < bodies.length; j++) {
    const a = bodies[i], b = bodies[j]; const dx = b.x - a.x, dy = (b.y - a.y) * 2; const d = Math.hypot(dx, dy) || 0.01; const m = (a.hr + b.hr) * 0.9;
    if (d < m) { const push = (m - d) * 0.5 * Math.min(1, dt * 12); const ux = dx / d, uy = dy / d; if (a.kind !== 'boss') { a.x -= ux * push; a.y -= uy * push * 0.5; } if (b.kind !== 'boss') { b.x += ux * push; b.y += uy * push * 0.5; } }
  }
  for (const pr of G.props) {
    if (pr.dead) continue;
    for (const f of G.heroes.concat(bodies)) { if (f.dead || f.z > 18) continue; const dx = f.x - pr.x, dy = (f.y - pr.y) * 2; const d = Math.hypot(dx, dy) || 0.01, m = pr.hr + f.hr * 0.7; if (d < m) { f.x += dx / d * (m - d); f.y += dy / d * (m - d) * 0.4; } }
  }
}

/* ---------- hero logic ---------- */
function setForm(h, f, silent) {
  if (h.form === f) return; h.form = f; h.inv = Math.max(h.inv, 0.9); setSt(h, 'idle');
  if (!silent) { sfx('transform'); shake(7); freeze(0.14); ringFx(h.x, h.y, 26, 120, f === 'a' ? '#ff1a3a' : '#ff8a30', 0.6); ringFx(h.x, h.y, 26, 80, '#ffffff', 0.35); G.flashScr = 0.5; blood(h.x, h.y, 30, 16); if (!G.cine) textFx(h.x, h.y - 96, T(FORM[f].label) + '!', f === 'a' ? '#ff2a40' : '#ff9a40', 2); }
  if (f !== 'h') h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.08);
}
function startXform(h, to) {
  if (h.dead || h.st === 'xform' || h.form === to) return;
  const up = to === 'a' || (to === 'f' && h.form === 'h'); if (up && h.isPlayer) vibe(90, 180);
  setSt(h, 'xform'); h.xt = 0; h.xto = to; h.xup = up; h.xdur = up ? 1.35 : 0.6; h.xswap = false; h.vx = h.vy = 0; h.inv = Math.max(h.inv, h.xdur + 0.3);
  if (up) sfx('howl');
  if (h.isPlayer && up) G.cine = { h, t: 0, dur: h.xdur };
}
function updXform(h, dt) {
  h.xt += dt; phys(h, dt); const mid = h.xdur * (h.xup ? 0.52 : 0.4), to = h.xto;
  if (!h.xswap) {
    const col = to === 'a' ? '#ff1030' : to === 'f' ? '#ffb040' : '#9ab4ff';
    if (h.xup) for (let i = 0; i < 2; i++) { const a = rnd(0, 6.28), r = rnd(45, 80); G.parts.push({ x: h.x + Math.cos(a) * r, y: h.y + rnd(-6, 6), z: 45 + Math.sin(a) * r * 0.7, vx: -Math.cos(a) * r * 2.4, vy: 0, vz: -Math.sin(a) * r * 1.7, life: 0.4, t: 0, col, size: 2, grav: 0, glowP: true }); }
    shake(0.5 + h.xt * (h.xup ? 3 : 1));
    if (h.xt >= mid) {
      h.xswap = true; setForm(h, to, !h.xup); setSt(h, 'xform'); h.xsw = h.xt;
      if (h.xup) {
        freeze(0.06); shake(12); G.flashScr = 0.7; ringFx(h.x, h.y, 10, 150, col, 0.7); ringFx(h.x, h.y, 10, 100, '#ffffff', 0.45);
        for (let i = 0; i < 26; i++) { const a = rnd(0, 6.28), s = rnd(120, 300); G.parts.push({ x: h.x, y: h.y, z: 50, vx: Math.cos(a) * s, vy: rnd(-20, 20), vz: Math.sin(a) * s * 0.6 + 80, life: rnd(0.5, 1), t: 0, col: i % 3 ? '#4a3020' : (to === 'a' ? '#e8e4dc' : '#b0001c'), size: rndi(2, 3), grav: 500, bounce: 0.3 }); }
        for (const e of G.enemies) { if (e.dead || dist(e, h) > 120) continue; hurt(h, e, 25 * upMul(), { launch: e.kind !== 'boss', kx: 200, kz: 220, brk: true, ignoreInv: true }); }
      } else { ringFx(h.x, h.y, 10, 60, col, 0.4); sfx('transform'); }
    }
  }
  if (h.xt >= h.xdur) { setSt(h, 'idle'); }
  bounds(h);
}
function tryTransform(h) {
  if (h.id !== 'lupus' || h.dead) return;
  if (h.st === 'xform') return;
  if (h.form === 'x') return;
  /* tap = go UP a form (never down); hold FORM = back to human (see fix81.js) */
  const tx = clamp(h.x, G.camX + 130, G.camX + VW - 130), hint = (k, col) => { textFx(tx, h.y - 104, k, col || '#ffb02a', 1); sfx('ui'); if (h.isPlayer && h.form !== 'h' && (G.holdHintN = (G.holdHintN || 0) + 1) <= 3) textFx(tx, h.y - 93, T('holdHuman'), '#c8c0d8', 1); };
  if (h.form === 'h') { if (h.fury >= 100) { startXform(h, 'f'); return true; } textFx(h.x, h.y - 96, T('fury') + ' 1/3', '#ffb02a', 1); sfx('ui'); return false; }
  if (h.form === 'f') {
    if (G.st.l44 && !G.mode) { hint(T('form3No'), '#ff6a40'); return false; }
    if (h.fury >= 200) { startXform(h, 'a'); return true; }
    hint(T('fury') + ' 2/3'); return false;
  }
  hint(T('ascended')); return false;
}
function startDash(h, mx, my) {
  let dx = mx, dy = my; if (!dx && !dy) dx = h.face; const l = Math.hypot(dx, dy) || 1;
  setSt(h, 'dash', 0.2); h.vx = dx / l * 250; h.vy = dy / l * 120; if (dx) h.face = dx > 0 ? 1 : -1; h.inv = Math.max(h.inv, 0.3); h.dashCd = 0.7; h.cDone = false; sfx('dash'); dust(h.x, h.y, 5);
}
function startAtk(h) {
  const s = hs(h); h.hitDone = false; h.queued = false; h.air = h.z > 0;
  h.idx = h.air ? 1 : (h.chainT > 0 ? (h.idx % 3) + 1 : 1);
  h.atkDur = s.dur * (h.idx === 3 ? 1.4 : 1); h.atkT = h.atkDur; h.vx = 0; setSt(h, 'atk'); h.ct = 0; sfx('slash');
}
function heroHit(h) {
  const s = hs(h); const idx = h.idx, last = idx === 3 && !h.air;
  if (h.id === 'malakor') { shoot({ x: h.x + h.face * 22, y: h.y, z: 30 + h.z, vx: h.face * 230, dmg: s.dmg * (last ? 1.6 : 1), team: 'p', owner: 'malakor', r: 7, life: 1.3, type: 'orb', col: '#a7ff1a', pierce: last, launch: last, kx: 90 }); sfx('shot'); sparks(h.x + h.face * 22, h.y, 30 + h.z, 6, '#a7ff1a'); return; }
  if (h.id === 'echo' && (idx === 1 || h.air)) { shoot({ x: h.x + h.face * 24, y: h.y, z: 32 + h.z, vx: h.face * 400, dmg: s.dmg * 0.95, team: 'p', owner: 'echo', r: 6, life: 0.8, type: 'orb', col: '#3ae6ff', kx: 60 }); sfx('shot'); sparks(h.x + h.face * 24, h.y, 32 + h.z, 6, '#3ae6ff'); return; }
  const mult = last ? 1.55 : 1, reach = s.reach * (last ? 1.15 : 1);
  const col = h.id === 'lupus' ? (h.form === 'h' ? '#ff3a4a' : h.form === 'f' ? '#ff6a30' : '#ff1030') : HERO[h.id].color;
  slashFx(h.x + h.face * reach * 0.5, h.y, 30 + h.z, h.face, col, reach * 0.8, idx === 1 ? -0.4 : idx === 2 ? 0.45 : -1.1, 0.18);
  for (const e of foes()) {
    if (e.dead) continue; const dx = (e.x - h.x) * h.face;
    if (dx < -8 || dx > reach + (e.hr || 10)) continue; if (Math.abs(e.y - h.y) > 13) continue; if (Math.abs(e.z - h.z) > 36) continue;
    const brk = h.id === 'triton' || h.id === 'brann' || h.form === 'f' || h.form === 'a' || last;
    hurt(h, e, s.dmg * mult, { launch: last || (h.air && e.z > 0), kx: last ? 140 : 45, kz: 220, brk: brk && !(e.type === 'K' && !last), bleed: h.form === 'a' });
  }
}
function startSpec(h) {
  const s = hs(h); setSt(h, 'spec'); h.hitDone = false; h.spCd = s.cd; h.t = 0; h.vx = 0;
  h.specDur = h.id === 'lupus' ? (h.form === 'f' ? 0.8 : h.form === 'a' ? 0.7 : 0.55) : h.id === 'malakor' ? 0.6 : h.id === 'echo' ? 0.75 : h.id === 'brann' ? 0.8 : 0.55; h.specAt = h.specDur * 0.45;
  sfx(h.id === 'lupus' && h.form === 'f' ? 'howl' : 'special'); h.inv = Math.max(h.inv, 0.25);
}
function heroSpecFire(h) {
  const s = hs(h), dm = s.dmg;
  if (h.id === 'lupus') {
    if (h.form === 'h') {
      const len = 140; G.lines.push({ x: h.x, y: h.y, z: 30, len, face: h.face, t: 0, dur: 0.32 });
      slashFx(h.x + h.face * len * 0.85, h.y, 34, h.face, '#ff1a40', 40, -0.4, 0.3);
      for (const e of foes()) { if (e.dead) continue; const dx = (e.x - h.x) * h.face; if (dx < -6 || dx > len || Math.abs(e.y - h.y) > 15) continue; hurt(h, e, dm * 2.2, { launch: true, kx: 170, kz: 230, brk: true }); }
      shake(5);
    } else if (h.form === 'f') {
      ringFx(h.x, h.y, 4, 120, '#ff2a40', 0.6); ringFx(h.x, h.y, 4, 80, '#ffffff', 0.35); shake(10); freeze(0.12); G.flashScr = 0.3;
      for (const e of foes()) { if (e.dead) continue; if (dist(e, h) > 120) continue; hurt(h, e, dm * 1.2, { stun: 1.5, kx: 140, brk: true, launch: e.kind === 'prop' ? false : !(e.def && e.def.heavy) && e.kind !== 'boss', kz: 170 }); }
    } else {
      ringFx(h.x, h.y, 4, 90, '#ff0033', 0.5); shake(12); freeze(0.12); G.flashScr = 0.35;
      for (let i = 0; i < 12; i++) { const dx = i % 2 ? 1 : -1; shoot({ x: h.x + dx * 14, y: clamp(h.y + rnd(-30, 30), LANE_T, LANE_B), z: rnd(10, 56), vx: dx * rnd(260, 340), dmg: dm * 1.5, team: 'p', owner: 'lupus', r: 9, life: 0.9, type: 'spike', col: '#ffffff', pierce: true, bleed: true, kx: 70 }); }
      for (const e of foes()) { if (e.dead) continue; if (dist(e, h) > 90) continue; hurt(h, e, dm * 1.3, { launch: true, kx: 140, kz: 230, brk: true, bleed: true }); }
    }
  } else if (h.id === 'vespera') { shoot({ x: h.x + h.face * 20, y: h.y, z: 36 + h.z, vx: h.face * 180, dmg: dm * 2.6, team: 'p', owner: 'vespera', r: 22, life: 1.5, type: 'orb', col: '#ff3ad0', pierce: true, launch: true, kx: 120, wob: true, brk: true, big: true }); ringFx(h.x, h.y, 30, 50, '#ff3ad0', 0.3); }
  else if (h.id === 'triton') { shoot({ x: h.x + h.face * 20, y: h.y, z: 8, vx: h.face * 200, dmg: dm * 1.7, team: 'p', owner: 'triton', r: 30, life: 1.15, type: 'wave', col: '#3af0ff', pierce: true, launch: true, kx: 150, brk: true }); h.shieldHP = Math.max(h.shieldHP, 180); h.shieldT = 4; ringFx(h.x, h.y, 20, 55, '#3af0ff', 0.4); shake(4); }
  else if (h.id === 'echo') { /* RAILGUN: a long piercing beam down the lane */
    const len = 300; G.lines.push({ x: h.x, y: h.y, z: 32, len, face: h.face, t: 0, dur: 0.4, col: '#3ae6ff', w: 5 }); shake(7); freeze(0.06); sfx('shot'); sfx('special');
    ringFx(h.x + h.face * 24, h.y, 32, 30, '#3ae6ff', 0.3);
    for (const e of foes()) { if (e.dead) continue; const dx = (e.x - h.x) * h.face; if (dx < -6 || dx > len || Math.abs(e.y - h.y) > 16) continue; hurt(h, e, dm * 2.4, { launch: true, kx: 190, kz: 200, brk: true }); sparks(e.x, e.y, 34, 8, '#3ae6ff'); }
  }
  else if (h.id === 'brann') { /* STONE QUAKE: a ground slam, ring of shards */
    ringFx(h.x, h.y, 4, 130, '#ff5a3a', 0.6); ringFx(h.x, h.y, 4, 90, '#d8d0c8', 0.4); shake(12); freeze(0.1); G.flashScr = 0.25; sfx('boom'); dust(h.x, h.y, 22, '#9a9088');
    for (const sd of [-1, 1]) shoot({ x: h.x, y: h.y, z: 0, vx: sd * 230, dmg: dm * 1.2, team: 'p', owner: 'brann', r: 18, life: 0.7, type: 'shock', col: '#ff5a3a', pierce: true, low: true, kx: 120, launch: true });
    for (const e of foes()) { if (e.dead || dist(e, h) > 120) continue; hurt(h, e, dm * 1.7, { launch: e.kind !== 'boss', kx: 130, kz: 260, brk: true, stun: 1.2 }); }
    h.shieldHP = Math.max(h.shieldHP, 120); h.shieldT = 3;
  }
  else if (h.id === 'malakor') {
    sfx('heal'); ringFx(h.x, h.y, 4, 100, '#a7ff1a', 0.6);
    { const b = G.ally; if (b && b.bench && b !== h) { if (b.dead) { b.dead = false; b.hp = b.maxhp * 0.35; setSt(b, 'idle'); textFx(h.x, h.y - 100, T('partner') + ' ^', '#a7ff1a', 1); } else b.hp = Math.min(b.maxhp, b.hp + b.maxhp * 0.22); } }
    for (const a of G.heroes) { if (a.dead) continue; a.hp = Math.min(a.maxhp, a.hp + a.maxhp * 0.22); a.shieldHP = Math.max(a.shieldHP, 200); a.shieldT = 6; textFx(a.x, a.y - 80, '+' + T('heal'), '#a7ff1a', 1); ringFx(a.x, a.y, 10, 36, '#a7ff1a', 0.4); }
    for (const e of G.enemies) { if (e.dead || dist(e, h) > 100) continue; hurt(h, e, dm * 1.6, { kx: 120, launch: true, kz: 150 }); }
  }
}
function updHero(h, dt, c) {
  h.ct += dt; h.inv = Math.max(0, h.inv - dt); h.flash = Math.max(0, h.flash - dt * 5); h.spCd = Math.max(0, h.spCd - dt); h.dashCd = Math.max(0, h.dashCd - dt); h.chainT = Math.max(0, h.chainT - dt); h.lastHurt += dt; if (h.landT) h.landT -= dt;
  if (h.shieldT > 0) { h.shieldT -= dt; if (h.shieldT <= 0) h.shieldHP = 0; }
  if (h.dead) { h.deadT += dt; h.x += h.vx * dt; friction(h, dt, 4); phys(h, dt); return; }
  const s = hs(h);
  if (s.regen && !(SAVE.diff === 'nightmare' && h.form !== 'f')) h.hp = Math.min(h.maxhp, h.hp + s.regen * DF().heroRegen * dt);
  if (heroTick(h, dt, c)) return;
  if (h.st === 'xform') { updXform(h, dt); return; }
  if (h.id === 'lupus' && h.form !== 'x') { if (h.form === 'f') h.fury -= 3.2 * dt; else if (h.form === 'a') h.fury -= 27 * dt; if (h.fury <= 0) { h.fury = 0; if (h.form !== 'h') startXform(h, 'h'); } else if (h.form === 'a' && h.fury < 70) startXform(h, 'f'); }
  if (c.form) h.formPress = { t: G.time, acted: tryTransform(h) };
  else if (c.formHeld && h.formPress && !h.formPress.acted && (h.form === 'f' || h.form === 'a') && G.time - h.formPress.t > 0.55) { h.formPress.acted = true; startXform(h, 'h'); }
  if (h.st === 'xform') return;
  const grounded = h.z <= 0 && h.vz === 0;
  switch (h.st) {
    case 'hurt': h.t -= dt; h.x += h.vx * dt; friction(h, dt); phys(h, dt); if (h.t <= 0) setSt(h, h.z > 0 ? 'air' : 'idle'); break;
    case 'knock': h.x += h.vx * dt; friction(h, dt, 1.5); phys(h, dt); break;
    case 'down': h.t -= dt; h.x += h.vx * dt; friction(h, dt, 10); if (h.t <= 0) { setSt(h, 'getup', 0.3); } break;
    case 'getup': h.t -= dt; if (h.t <= 0) { setSt(h, 'idle'); h.inv = Math.max(h.inv, 0.6); } break;
    case 'dash': h.t -= dt; h.x += h.vx * dt; h.y += h.vy * dt; phys(h, dt); if (Math.random() < 0.5) dust(h.x - h.face * 6, h.y, 1); if (c.atk && h.t < 0.12) { setSt(h, 'idle'); startAtk(h); } else if (h.t <= 0) { setSt(h, h.z > 0 ? 'air' : 'idle'); h.vx = 0; h.vy = 0; } break;
    case 'atk': {
      h.atkT -= dt; const p = 1 - h.atkT / h.atkDur; phys(h, dt);
      if (!h.hitDone && p >= 0.4) { h.hitDone = true; heroHit(h); }
      if (!h.air && p < 0.45) h.x += h.face * 50 * dt;
      if (c.atk || (c.atkHeld && p > 0.5)) h.queued = true;
      if (c.spec && h.spCd <= 0) { startSpec(h); break; }
      if (c.dash && h.dashCd <= 0 && p > 0.45) { startDash(h, c.mx, c.my); break; }
      if (h.atkT <= 0) { h.chainT = 0.5; setSt(h, h.z > 0 ? 'air' : 'idle'); if (h.queued) startAtk(h); }
      break;
    }
    case 'tagin': h.x += h.vx * dt; friction(h, dt, 2); phys(h, dt); if (h.z <= 0) { h.z = 0; h.vz = 0; shake(5); dust(h.x, h.y, 10); sfx('land'); ringFx(h.x, h.y, 4, 70, HERO[h.id].color, 0.4); for (const e of G.enemies) if (!e.dead && dist(e, h) < 70) hurt(h, e, hs(h).dmg * 1.2, { launch: e.kind !== 'boss', kx: 150, kz: 200, brk: true }); setSt(h, 'idle'); } break;
    case 'spec': h.t += dt; phys(h, dt); if (!h.hitDone && h.t >= h.specAt) { h.hitDone = true; heroSpecFire(h); } if (h.t >= h.specDur) setSt(h, h.z > 0 ? 'air' : 'idle'); break;
    case 'guard':
      phys(h, dt); h.vx *= 0.8; h.vy *= 0.8; h.x += h.vx * dt; h.y += h.vy * dt;
      if (!c.block) { setSt(h, 'idle'); break; }
      if (c.dash && h.dashCd <= 0) { startDash(h, c.mx, c.my); break; }
      if (c.atk) { setSt(h, 'idle'); startAtk(h); break; }
      if (c.mx) h.face = c.mx > 0 ? 1 : -1; break;
    default: {
      if (c.block && grounded && h.isPlayer) { setSt(h, 'guard'); h.guardT0 = G.time; h.vx *= 0.3; h.vy *= 0.3; break; }
      if (c.dash && h.dashCd <= 0 && (grounded || airDashOk())) { startDash(h, c.mx, c.my); break; }
      if (c.spec && h.spCd <= 0 && grounded) { startSpec(h); break; }
      if (c.atk && h.isPlayer && grounded && tryThrow(h)) break;
      if (c.atk || (c.atkHeld && h.chainT > 0.2)) { startAtk(h); break; }
      if (c.jump && grounded) { h.vz = HERO[h.id].jump; h.z = 1; setSt(h, 'air'); sfx('jump'); dust(h.x, h.y, 4); }
      /* momentum: accelerate toward target velocity */
      const tvx = c.mx * s.spd, tvy = c.my * s.spd * 0.6, acc = grounded ? 14 : 5;
      h.vx += (tvx - h.vx) * Math.min(1, acc * dt); h.vy += (tvy - h.vy) * Math.min(1, acc * dt);
      h.x += h.vx * dt; h.y += h.vy * dt;
      if (c.mx) h.face = c.mx > 0 ? 1 : -1;
      if (h.id === 'vespera' && h.z > 0 && c.jumpHeld && h.vz < 0) h.glide = true;
      const was = h.z > 0; phys(h, dt);
      if (h.z > 0) setSt(h, 'air'); else setSt(h, (Math.abs(h.vx) > 12 || Math.abs(h.vy) > 8) ? 'walk' : 'idle');
      if (h.st === 'walk') h.wph = (h.wph || 0) + dt * 12 * Math.max(0.55, Math.min(1.35, Math.hypot(h.vx, h.vy / 0.6) / s.spd));
    }
  }
  bounds(h);
}

/* ---------- tag team (Marvel vs Capcom / Cosmic Invasion style) ---------- */
const TAG_CD = 1.6, ASSIST_CD = 8;
function canTag() {
  const p = G.player, a = G.ally; if (!a || p.form === 'x' || G.panel) return false;
  return G.tagCd <= 0 && a && !a.dead && !a.assist && !G.cine && G.over <= 0 && !G.clearT && !p.dead && ['idle', 'walk', 'air', 'atk', 'spec', 'dash', 'hurt'].includes(p.st);
}
function canAssist() { const p = G.player, a = G.ally; if (!a || p.form === 'x' || G.panel) return false; return G.assistCd <= 0 && a && !a.dead && !a.assist && !G.cine && G.over <= 0 && !G.clearT && !p.dead && p.st !== 'xform'; }
function jumpOut(h) { /* hero leaps off the screen */ G.heroes = G.heroes.filter(x => x !== h); h.leaveT = 0; if (!h.dead) { setSt(h, 'air'); h.vx = -h.face * 170; h.vz = 320; h.z = Math.max(h.z, 1); } G.leaving.push(h); }
function tagSwap(forced) {
  const out = G.player, inn = G.ally;
  const combo = !forced && G.time - G.lastHitT < 0.8 && G.lastE && !G.lastE.dead;
  out.isPlayer = false; out.shieldHP = 0; jumpOut(out);
  inn.bench = false; inn.assist = false; inn.isPlayer = true; inn.hitDone = false; inn.queued = false; inn.chainT = 0; inn.vy = 0; inn.flash = 0; inn._trail = [];
  inn.face = out.face; inn.y = clamp(out.y, LANE_T, LANE_B);
  if (combo) {
    const e = G.lastE; inn.face = e.x >= out.x ? 1 : -1; inn.x = clamp(e.x - inn.face * 34, G.camX + 20, G.camX + VW - 100); inn.y = clamp(e.y, LANE_T, LANE_B); inn.z = 30; inn.vz = 0; inn.vx = 0;
    inn.spCd = 0; startSpec(inn); inn.specAt *= 0.5; G.comboT = 2.6; G.syn = Math.min(100, G.syn + 8); freeze(0.08); G.flashScr = 0.25;
    textFx(inn.x, inn.y - 108, T('tagCombo'), '#ffd23a', 2); ringFx(inn.x, inn.y, 20, 80, HERO[inn.id].color, 0.4);
  } else { inn.x = clamp(out.x - out.face * 46, G.camX + 16, G.camX + VW - 100); inn.z = 160; inn.vz = -30; inn.vx = out.face * 80; setSt(inn, 'tagin'); }
  inn.inv = Math.max(inn.inv, 0.9); G.heroes.push(inn); G.player = inn; G.ally = out; out.bench = true;
  G.tagCd = forced ? 0.6 : TAG_CD; if (!forced) G.tags++; sfx('dash'); sfx('special');
}
function callAssist() {
  const p = G.player, a = G.ally;
  a.assist = true; a.bench = false; a.isPlayer = false; a.astPh = 'in'; a.face = p.face; a.hitDone = false; a._trail = [];
  a.y = clamp(p.y + (p.y < (LANE_T + LANE_B) / 2 ? 12 : -12), LANE_T, LANE_B); a.x = clamp(p.x - p.face * 36, G.camX + 14, G.camX + VW - 100); a.z = 130; a.vz = -60; a.vx = p.face * 60; setSt(a, 'tagin'); a.inv = 99;
  G.heroes.push(a); G.assistCd = ASSIST_CD; sfx('dash'); textFx(a.x, a.y - 112, T('assist') + '!', HERO[a.id].color, 1);
}
function updAssist(a, dt) {
  if (a.astPh === 'in') { updHero(a, dt, {}); if (a.st !== 'tagin') { const en = nearestEnemy(a, 420); if (en) a.face = en.x >= a.x ? 1 : -1; a.spCd = 0; startSpec(a); a.astPh = 'spec'; } }
  else if (a.astPh === 'spec') { updHero(a, dt, {}); if (a.st !== 'spec') { a.astPh = 'out'; a.inv = 0; jumpOut(a); } }
}
function updBench(b, dt) { b.spCd = Math.max(0, b.spCd - dt); b.shieldHP = 0; b.inv = 0; b.flash = 0; if (!b.dead) b.hp = Math.min(b.maxhp, b.hp + b.maxhp * 0.025 * DF().regen * dt); }
function updLeaving(dt) {
  for (const h of G.leaving) { h.leaveT += dt; h.x += h.vx * dt; if (!h.dead) { h.vz -= GRAV * dt * 0.7; h.z = Math.max(0, h.z + h.vz * dt); } h.fade = 1 - h.leaveT / 0.55; }
  G.leaving = G.leaving.filter(h => { if (h.leaveT < 0.55) return true; h.fade = null; h.z = 0; h.vz = 0; h.vx = 0; setSt(h, h.dead ? 'dead' : 'idle'); if (h.assist) { h.assist = false; h.bench = true; } return false; });
}
function tagStep(dt, pc) {
  G.tagCd = Math.max(0, G.tagCd - dt); G.assistCd = Math.max(0, G.assistCd - dt);
  const a = G.ally; if (!a) { updLeaving(dt); return; }
  if (a.assist && G.heroes.includes(a)) updAssist(a, dt); else if (a.bench && !a.assist) updBench(a, dt);
  updLeaving(dt);
  if (G.autoTag > 0) { G.autoTag -= dt; if (G.autoTag <= 0) { if (a.assist) G.autoTag = 0.1; else if (!a.dead) tagSwap(true); } return; }
  if (pc.tag && canTag()) tagSwap(false);
  else if (pc.assist && canAssist()) callAssist();
}

/* ---------- ally AI ---------- */
function allyCtl(a, dt) {
  const c = { mx: 0, my: 0, atk: false, atkHeld: false, jump: false, spec: false, dash: false, form: false, jumpHeld: false };
  const p = G.player; a.aiT -= dt; const en = nearestEnemy(a, 360); const s = hs(a); const ranged = a.id === 'malakor' || a.id === 'echo';
  let tx, ty;
  if (en) { const side = Math.sign(a.x - en.x) || 1; tx = ranged ? en.x + side * 130 : en.x + side * Math.max(16, s.reach * 0.7); ty = en.y; if (Math.abs(tx - p.x) > 260) tx = p.x + (tx > p.x ? 260 : -260); }
  else { tx = p.x - p.face * 46; ty = p.y + 16; }
  const dx = tx - a.x, dy = ty - a.y;
  if (Math.abs(dx) > 7) c.mx = Math.sign(dx); if (Math.abs(dy) > 5) c.my = Math.sign(dy);
  if (en) {
    const fx = en.x - a.x, need = ranged ? 260 : s.reach + (en.hr || 10);
    if (Math.abs(en.y - a.y) < (ranged ? 10 : 8) && Math.abs(fx) < need && a.aiT <= 0) { if ((fx > 0) === (a.face > 0) || !c.mx) { c.atk = true; c.mx = 0; } a.face = fx >= 0 ? 1 : -1; if (Math.random() < 0.02) a.aiT = rnd(0.2, 0.6); }
    let near = 0; for (const e of G.enemies) if (!e.dead && dist(e, a) < 115) near++;
    if (a.spCd <= 0) { if (a.id === 'malakor') { if (G.heroes.some(h => !h.dead && h.hp < h.maxhp * 0.6) || G.heroes.some(h => h.dead)) c.spec = true; } else if (near >= 2 || (G.boss && !G.boss.dead && dist(G.boss, a) < 160)) { if (!(a.id === 'lupus' && a.form === 'h') || Math.abs(en.y - a.y) < 12) c.spec = true; } }
    if (a.id === 'lupus' && a.form === 'h' && a.fury >= 120) c.form = true;
    for (const e of G.enemies) if (!e.dead && (e.ai === 'wind' || (e.pat && e.pat.ps === 1)) && dist(e, a) < 55 && a.dashCd <= 0 && Math.random() < 0.04) c.dash = true;
  }
  return c;
}

/* ---------- enemy logic ---------- */
function eHit(e, reach, dmg, o) {
  o = o || {}; const dm = dmg * e.dm;
  for (const h of G.heroes.concat(objsP())) {
    if (h.dead) continue; const dx = (h.x - e.x) * e.face;
    if (o.rad) { if (dist(e, h) > o.rad || h.z > 22) continue; } else { if (dx < -6 || dx > reach + 10) continue; if (Math.abs(h.y - e.y) > 13 || h.z > 30) continue; }
    hurt(e, h, dm, o);
  }
}
function moveTo(e, tx, ty, spd, dt) { const dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy); if (d < 2) return 0; const m = Math.min(d, spd * dt); e.x += dx / d * m; e.y += dy / d * m * 0.8; e.moving = true; return d; }
function getTok(e, max) { if (e.hasTok) return true; max = Math.max(1, max + DF().tok); if (G.tok < max) { G.tok++; e.hasTok = true; return true; } return false; }
function relTok(e) { if (e.hasTok) { G.tok--; e.hasTok = false; } }

function updEnemy(e, dt) {
  e.ct += dt; e.flash = Math.max(0, e.flash - dt * 5); e.inv = Math.max(0, e.inv - dt); e.cd -= dt; e.moving = false;
  if (e.dead) { e.deadT += dt; e.x += e.vx * dt; friction(e, dt, 3); phys(e, dt); return; }
  if (e.bleedT > 0) { e.bleedT -= dt; e.hp -= e.bleedD * dt; if (Math.random() < dt * 8) blood(e.x, e.y, 30, 1); if (e.hp <= 0) { kill(e, 1, G.player); return; } }
  if (e.kind === 'boss') { updBoss(e, dt); bounds(e); return; }
  const def = e.def;
  if (e.arrive) { const inX = clamp(e.x, G.camX + 50, G.camX + VW - 140); e.face = inX >= e.x ? 1 : -1; e.x += e.face * Math.max(def.spd, 60) * dt; e.moving = true; if (Math.abs(inX - e.x) < 4 || (e.x > G.camX + 30 && e.x < G.camX + VW - 125)) e.arrive = false; phys(e, dt); return; }
  if (e.st === 'hurt') { e.t -= dt; e.x += e.vx * dt; friction(e, dt); if (e.t <= 0) setSt(e, 'idle'); bounds(e); return; }
  if (e.st === 'knock') { e.x += e.vx * dt; friction(e, dt, 1.2); phys(e, dt); bounds(e); return; }
  if (e.st === 'down') { e.t -= dt; e.x += e.vx * dt; friction(e, dt, 10); if (e.t <= 0) setSt(e, 'getup', 0.35); bounds(e); return; }
  if (e.st === 'getup') { e.t -= dt; if (e.t <= 0) { setSt(e, 'idle'); e.inv = 0.35; e.ai = 'move'; } return; }
  if (e.dummy) { phys(e, dt); e.hp = e.maxhp; const t0 = nearestHero(e); e.face = t0.x >= e.x ? 1 : -1; e.x += (G.camX + VW / 2 + 30 - e.x) * Math.min(1, dt * 0.8); bounds(e); return; }
  const tg = nearestHero(e); const dx = tg.x - e.x, dy = tg.y - e.y; const reach = def.reach || 32; e.blocking = false; phys(e, dt);
  const ai = def.ai;
  if (ai === 'bomber' || ai === 'sniper' || ai === 'capture') { aiExtra(e, tg, dt); bounds(e); return; }
  if (e.ai === 'move') {
    e.face = dx >= 0 ? 1 : -1;
    if (ai === 'melee' || ai === 'brute') {
      const maxTok = 2; if (def.shield) e.blocking = true;
      if (!e.hasTok) { const side = Math.sign(e.x - tg.x) || 1; moveTo(e, tg.x + side * (85 + (e.ct * 7 % 30)), tg.y + Math.sin(e.ct * 0.8 + e.x) * 15, def.spd * 0.8, dt); if (Math.hypot(dx, dy) < 170 && e.cd <= 0) getTok(e, maxTok); }
      else { moveTo(e, tg.x - e.face * reach * 0.75, tg.y, def.spd, dt); if (Math.abs(dx) < reach + 4 && Math.abs(dy) < 7 && e.cd <= 0) { e.ai = 'wind'; e.t = (def.wind || 0.35) * DF().wind; e.blocking = false; sfx('alarm'); } }
    } else if (ai === 'ranged') {
      const adx = Math.abs(dx); const want = adx < 115 ? -1 : adx > 200 ? 1 : 0; e.x += e.face * want * def.spd * dt; if (want) e.moving = true; moveTo(e, e.x, tg.y, def.spd * 0.8, dt);
      if (adx < 40 && e.cd <= 0) { e.ai = 'wind'; e.t = 0.3; e.melee = true; } else if (Math.abs(dy) < 11 && e.cd <= 0 && adx < 280) { e.ai = 'wind'; e.t = 0.5; e.melee = false; }
    } else if (ai === 'lunge') {
      const adx = Math.abs(dx);
      if (!e.hasTok) { const side = Math.sign(e.x - tg.x) || 1; moveTo(e, tg.x + side * 110, tg.y + Math.sin(e.ct * 1.5 + e.x) * 20, def.spd * 0.9, dt); if (e.cd <= 0) getTok(e, 3); }
      else { moveTo(e, tg.x - e.face * 75, tg.y, def.spd, dt); if (adx < 115 && adx > 45 && Math.abs(dy) < 9 && e.cd <= 0) { e.ai = 'wind'; e.t = 0.38; } }
    } else if (ai === 'beam') {
      const adx = Math.abs(dx); const want = adx < 130 ? -1 : adx > 210 ? 1 : 0; e.x += e.face * want * def.spd * dt; if (want) e.moving = true; moveTo(e, e.x, tg.y, def.spd * 0.9, dt);
      if (adx < 35 && e.cd <= 0) { e.ai = 'wind'; e.t = 0.25; e.melee = true; } else if (Math.abs(dy) < 8 && e.cd <= 0 && adx < 320) { e.ai = 'wind'; e.t = 0.75; e.melee = false; }
    }
  } else if (e.ai === 'wind') {
    e.t -= dt; if (ai === 'ranged' || ai === 'beam') e.face = dx >= 0 ? 1 : -1;
    if (e.t <= 0) { e.ai = 'hit'; e.t = 0.24; e.hitDone = false; e.ct = 0; }
  } else if (e.ai === 'hit') {
    e.t -= dt;
    if (!e.hitDone) {
      e.hitDone = true;
      if (ai === 'ranged') { if (e.melee) { eHit(e, 30, 16, { kx: 80 }); slashFx(e.x + e.face * 15, e.y, 30, e.face, '#ff2a40', 22, 0, 0.15); sfx('slash'); } else { shoot({ x: e.x + e.face * 28, y: e.y, z: 32, vx: e.face * 230, dmg: def.dmg * e.dm, team: 'e', r: 6, life: 2, type: 'bolt', col: '#ff3050' }); sfx('shot'); hitFlash(e.x + e.face * 30, e.y, 32, false, '#ff5060'); } }
      else if (ai === 'beam') { if (e.melee) { eHit(e, 35, 24, { kx: 110 }); slashFx(e.x + e.face * 15, e.y, 30, e.face, '#ff2a40', 26, 0, 0.15); sfx('slash'); } else { shoot({ x: e.x + e.face * 28, y: e.y, z: 30, vx: e.face * 400, dmg: def.dmg * e.dm, team: 'e', r: 20, life: 1.3, type: 'beam', col: '#ff2040', pierce: true }); sfx('shot'); } }
      else if (ai === 'lunge') { e.vx = e.face * 250; e.vz = 150; e.z = 1; e.lunged = true; e.t = 0.6; }
      else if (ai === 'brute') { eHit(e, 0, def.dmg, { rad: 64, launch: true, kx: 140, kz: 220 }); ringFx(e.x + e.face * 26, e.y, 0, 70, '#9aff6a', 0.4); dust(e.x + e.face * 26, e.y, 12); shake(7); sfx('boom'); }
      else { eHit(e, reach, def.dmg, { kx: 90, launch: (e.hitCount || 0) % 3 === 2 }); slashFx(e.x + e.face * reach * 0.5, e.y, 30, e.face, '#ff3040', reach * 0.8, -0.3, 0.18); sfx('slash'); e.hitCount = (e.hitCount || 0) + 1; }
    }
    if (ai === 'lunge' && e.lunged) {
      e.x += e.vx * dt; e.vx *= 0.985;
      for (const h of G.heroes) if (!h.dead && !e.lungeHit && Math.abs(h.x - e.x) < 17 && Math.abs(h.y - e.y) < 12 && h.z < 26) { e.lungeHit = true; hurt(e, h, def.dmg * e.dm, { kx: 90 }); }
      if (e.z <= 0 && e.t < 0.45) { e.lunged = false; e.lungeHit = false; e.ai = 'rec'; e.t = 0.7; e.vx = 0; relTok(e); dust(e.x, e.y, 3); }
    } else if (e.t <= 0) { if (ai === 'melee' && (e.chain || 0) < 2 && Math.random() < DF().combo) { e.chain = (e.chain || 0) + 1; e.ai = 'wind'; e.t = 0.16; const t1 = nearestHero(e); e.face = t1.x >= e.x ? 1 : -1; e.x += e.face * 8; } else { e.chain = 0; e.ai = 'rec'; e.t = ai === 'brute' ? 0.9 : rnd(0.35, 0.8); } }
  } else if (e.ai === 'rec') { e.t -= dt; if (def.shield) e.blocking = true; if (e.t <= 0) { e.ai = 'move'; e.cd = (ai === 'ranged' || ai === 'beam' ? rnd(1.4, 2.6) : rnd(0.5, 1.4)) * DF().cd; relTok(e); } }
  bounds(e);
}

/* ---------- bosses ---------- */
function startPat(e, n) { e.pat = { n, t: 0, ps: 0, hits: 0 }; e.guard = false; e.guardHit = 0; e.ct = 0; }
function endPat(e, cd) { e.fade = 1; e.pat = null; e.cd = (cd != null ? cd : rnd(0.7, 1.4)) * (e.p2 ? 0.65 : 1) * DF().cd; e.frame = 'idle'; e.guard = false; e.vx = 0; e.charging = false; e.windup = false; }
const bossFace = (e, tg) => { e.face = tg.x >= e.x ? 1 : -1; };
function updBoss(e, dt) {
  if (e.giant) { updGiant(e, dt); return; }
  if (bossScript(e, dt)) return;
  const def = e.def, tg = nearestHero(e);
  if (e.bossIn > 0) { e.bossIn -= dt; e.y = 232; if (e.x > G.camX + VW - 200) { e.x -= 160 * dt; e.moving = true; } return; }
  if (e.morph > 0) { /* phase-2 transformation: the boss is untouchable while it changes */
    const before = e.morph; e.morph -= dt; e.frame = 'spec'; e.windup = true; shake(2);
    if (Math.random() < dt * 25) sparks(e.x + rnd(-30, 30), e.y, rnd(20, 90), 2, e.type === 'nacht' ? '#a7ff1a' : (def.col || '#ff2040'));
    if (e.type === 'nacht' && before > e.morphDur / 2 && e.morph <= e.morphDur / 2) { e.key = def.big; e.hr = 26; e.def = Object.assign({}, e.def, { reach: 64 }); ringFx(e.x, e.y, 30, 140, '#a7ff1a', 0.9); ringFx(e.x, e.y, 30, 90, '#ffffff', 0.5); sfx('roar'); shake(12); G.flashScr = 0.5; blood(e.x, e.y, 60, 30, '#7aff3a'); }
    if (e.morph <= 0) { e.windup = false; e.frame = 'idle'; e.cd = 0.5; sfx('roar'); ringFx(e.x, e.y, 30, 120, def.col || '#ff2040', 0.6); }
    return; }
  if (e.st === 'hurt') { e.t -= dt; e.x += e.vx * dt; friction(e, dt); if (e.t <= 0) setSt(e, 'idle'); return; }
  const spd = def.spd * (e.p2 ? 1.25 : 1);
  if (!e.p2 && !e.mini && !def.phases && e.hp < e.maxhp * 0.5) {
    e.p2 = true; e.pat = null; shake(10); ringFx(e.x, e.y, 30, 160, '#ff0033', 0.8); sfx('roar'); textFx(e.x, e.y - 120, T('p2'), '#ff3050', 2); e.cd = 0.8;
    if (e.type === 'voss') { spawnEnemy('ZS', -1); spawnEnemy('ZS', 1); }
    if (def.pats2) e.def = Object.assign({}, def, { pats: def.pats2 }); e.pi = 0;
    e.morph = e.type === 'nacht' ? 1.9 : 1.0; e.morphDur = e.morph; e.inv = e.morph; e.vx = 0; sfx('transform'); G.flashScr = 0.25;
    if (e.type === 'beast') for (let i = 0; i < 3; i++) spawnEnemy('H', i % 2 ? 1 : -1);
    if (e.type === 'warden') { spawnEnemy('Z', 1); spawnEnemy('ZS', -1); }
    if (e.type === 'prime') { spawnEnemy('M', 1); spawnEnemy('M', -1); }
    if (def.minions && !['voss', 'beast', 'warden', 'prime'].includes(e.type)) { spawnEnemy(def.minions[0], 1); spawnEnemy(def.minions[def.minions.length - 1], -1); }
  }
  if (e.fade != null && e.fade < 1 && (!e.pat || e.pat.n !== 'blink')) e.fade = Math.min(1, e.fade + dt * 4);
  if (!e.pat) {
    bossFace(e, tg); e.frame = 'idle'; const dx = tg.x - e.x, dy = tg.y - e.y; e.cd -= dt;
    if (Math.abs(dx) > 100 || Math.abs(dy) > 10) { moveTo(e, tg.x - e.face * 75, tg.y, spd * 0.7, dt); e.frame = 'walk'; }
    if (e.cd <= 0) { const pats = e.def.pats.concat(DF().bossExtra && e.def.extra ? e.def.extra : []); let n = pats[e.pi++ % pats.length], tries = 0;
      while (tries++ < 4 && (n === e.lastPat || (n === 'blink' && e.lastBlink != null && e.pi - e.lastBlink < 3))) n = pats[e.pi++ % pats.length];
      if (n === 'blink') e.lastBlink = e.pi; e.lastPat = n; startPat(e, n); }
    return;
  }
  const P = e.pat; P.t += dt; const dx = tg.x - e.x, dy = tg.y - e.y; const dm = e.dm * (e.p2 ? 1.15 : 1); const reach = e.def.reach || 56;
  switch (P.n) {
    case 'slash': {
      if (P.ps === 0) { bossFace(e, tg); e.frame = 'walk'; moveTo(e, tg.x - e.face * reach * 0.8, tg.y, spd * 1.2, dt); if ((Math.abs(dx) < reach + 12 && Math.abs(dy) < 7) || P.t > 3) { P.ps = 1; P.t = 0; e.ct = 0; } }
      else if (P.ps === 1) { e.frame = 'wind'; e.windup = true; if (P.t > (e.p2 ? 0.3 : 0.42) * DF().wind) { P.ps = 2; P.t = 0; e.ct = 0; } }
      else if (P.ps === 2) { e.windup = false; e.frame = 'atk'; P.hits++; eHit(e, reach, def.wide ? 62 : 40, { kx: 130, launch: P.hits >= 3, kz: 220 }); slashFx(e.x + e.face * reach * 0.5, e.y, 40, e.face, e.type === 'voss' ? '#ff2040' : (def.col || '#ff5030'), reach * 0.9, P.hits === 2 ? 0.5 : -0.4, 0.22); sfx('slash'); shake(4); e.x += e.face * 14; P.ps = 3; P.t = 0; }
      else if (P.ps === 3) { e.frame = 'atk'; if (P.t > 0.28) { if (P.hits < 3) { bossFace(e, tg); P.ps = 1; P.t = 0; e.ct = 0; } else endPat(e); } }
      break;
    }
    case 'charge': {
      if (P.ps === 0) { bossFace(e, tg); e.frame = 'wind'; e.windup = true; if (Math.abs(dy) > 4) e.y += Math.sign(dy) * 60 * dt; if (P.t > 0.85) { P.ps = 1; P.t = 0; e.windup = false; sfx('roar'); e.hitSet = new Set(); } }
      else if (P.ps === 1) {
        e.charging = true; e.frame = 'run'; e.x += e.face * 360 * dt; e.moving = true; if (Math.random() < 0.6) dust(e.x - e.face * 20, e.y, 1);
        for (const h of G.heroes) { if (h.dead || e.hitSet.has(h)) continue; if (Math.abs(h.x - e.x) < (def.wide ? 60 : 30) && Math.abs(h.y - e.y) < 15 && h.z < 30) { e.hitSet.add(h); hurt(e, h, 62 * dm, { launch: true, kx: 220, kz: 230 }); shake(8); } }
        const wall = e.x < G.camX + 50 + (def.wide ? 50 : 0) || e.x > G.camX + VW - 155 - (def.wide ? 50 : 0);
        if (P.t > 1.4 || wall) { e.charging = false; P.ps = 2; P.t = 0; shake(7); sparks(e.x + e.face * 20, e.y, 20, 14); dust(e.x, e.y, 10); sfx('boom'); }
      } else if (P.ps === 2) { e.frame = 'idle'; e.dazed = true; if (P.t > 1.1) { e.dazed = false; endPat(e, 0.6); } }
      break;
    }
    case 'guard': bossFace(e, tg); e.frame = 'block'; e.guard = true; if (P.t > 2.2 || e.guardHit >= 4) { e.guard = false; P.n = 'slash'; P.ps = 1; P.t = 0; P.hits = 1; } break;
    case 'wave': {
      bossFace(e, tg);
      if (P.ps === 0) { e.frame = 'wind'; e.windup = true; if (P.t > 0.55) { P.ps = 1; P.t = 0; e.ct = 0; } }
      else if (P.ps === 1) { e.windup = false; e.frame = 'spec'; shoot({ x: e.x + e.face * 30, y: e.y, z: 26, vx: e.face * 280, dmg: 52 * dm, team: 'e', r: 18, life: 1.5, type: 'wave', col: def.col || '#ff1a40', pierce: true, kx: 90 }); slashFx(e.x + e.face * 30, e.y, 40, e.face, '#ff1a40', 50, -0.2, 0.25); sfx('special'); P.hits++; P.ps = 2; P.t = 0; }
      else if (P.ps === 2 && P.t > 0.35) { if (P.hits < (e.p2 ? 3 : 2)) { P.ps = 0; P.t = 0; e.y += clamp(dy, -30, 30) * 0.6; } else endPat(e); }
      break;
    }
    case 'slam': {
      bossFace(e, tg);
      if (P.ps === 0) { e.frame = 'wind'; e.windup = true; if (P.t < 0.4) moveTo(e, tg.x - e.face * 60, tg.y, spd, dt); if (P.t > 0.85 * DF().wind) { P.ps = 1; P.t = 0; e.ct = 0; } }
      else if (P.ps === 1) { e.windup = false; e.frame = 'atk'; shake(12); sfx('boom'); ringFx(e.x + e.face * 30, e.y, 0, 110, '#ffb060', 0.5); dust(e.x + e.face * 30, e.y, 16); eHit(e, 0, 58, { rad: 88, launch: true, kx: 150, kz: 260 }); for (const s of [-1, 1]) shoot({ x: e.x, y: e.y, z: 0, vx: s * 220, dmg: 40 * dm, team: 'e', r: 18, life: 0.9, type: 'shock', col: '#ffb060', pierce: true, low: true, kx: 90 }); P.ps = 2; P.t = 0; }
      else if (P.ps === 2) { e.frame = 'atk'; if (P.t > 0.9) endPat(e); }
      break;
    }
    case 'roar': {
      bossFace(e, tg); e.frame = 'spec'; if (P.ps === 0 && P.t > 0.2) { P.ps = 1; sfx('roar'); shake(12); ringFx(e.x, e.y, 30, 170, '#ff2030', 0.8); for (const h of G.heroes) if (!h.dead && dist(h, e) < 170) { setSt(h, 'hurt', 0.7); h.vx = Math.sign(h.x - e.x) * 90; h.inv = 0.3; } if (enemiesAlive() < 4) { const mn = def.minions || ['H']; spawnEnemy(pick(mn), -1); spawnEnemy(pick(mn), 1); if (e.p2) spawnEnemy(def.minions ? pick(mn) : 'S', 1); } }
      if (P.t > 1.2) endPat(e); break;
    }
    case 'shoot': {
      bossFace(e, tg); const adx = Math.abs(dx);
      if (P.ps === 0) { e.frame = 'walk'; if (adx < 140) { e.x -= e.face * 80 * dt; e.moving = true; } else if (adx > 220) { e.x += e.face * 80 * dt; e.moving = true; } moveTo(e, e.x, tg.y, 50, dt); if (P.t > 0.7) { P.ps = 1; P.t = 0; e.ct = 0; } }
      else if (P.ps === 1) { e.frame = 'atk'; e.windup = true; if (P.t > 0.45) { const mz = def.muzzle || [26, 36], sy0 = e.y, ay = clamp((tg.y - sy0) / Math.max(40, Math.abs(tg.x - e.x)) * 260, -60, 60); for (let i = -1; i <= 1; i++) shoot({ x: e.x + e.face * mz[0], y: clamp(sy0 + i * 6, LANE_T, LANE_B), z: mz[1], vx: e.face * 260, vy: ay + i * 10, dmg: 30 * dm, team: 'e', r: 8, life: 2.2, type: 'orb', col: def.shot || def.col || '#a7ff1a' }); sfx('shot'); P.hits++; P.ps = 2; P.t = 0; e.windup = false; } }
      else if (P.ps === 2 && P.t > 0.35) { if (P.hits < (e.p2 ? 4 : 3)) { P.ps = 1; P.t = 0; } else endPat(e); }
      break;
    }
    case 'summon': { bossFace(e, tg); e.frame = 'spec'; if (P.ps === 0 && P.t > 0.5) { P.ps = 1; sfx('special'); ringFx(e.x, e.y, 10, 70, '#a7ff1a', 0.6); if (enemiesAlive() < 5) { const ty = def.minions || (e.p2 ? ['S', 'M', 'H'] : ['H', 'S']); spawnEnemy(pick(ty), -1); spawnEnemy(pick(ty), 1); if (e.p2) spawnEnemy(def.minions ? pick(def.minions) : 'M', 1); } } if (P.t > 1.3) endPat(e); break; }
    case 'blink': {
      if (P.ps === 0) { e.fade = Math.max(0, 1 - P.t / 0.3); e.frame = 'spec'; if (P.t > 0.3) { P.ps = 1; P.t = 0; const side = tg.x > G.camX + VW / 2 ? -1 : 1; e.x = clamp(tg.x + side * 95, G.camX + 40, G.camX + VW - 100); e.y = clamp(tg.y + rnd(-10, 10), LANE_T, LANE_B); ringFx(e.x, e.y, 10, 50, '#a7ff1a', 0.4); } }
      else if (P.ps === 1) { e.fade = Math.min(1, P.t / 0.25); bossFace(e, tg); e.frame = 'wind'; if (P.t > 0.5) { P.ps = 2; P.t = 0; e.ct = 0; e.frame = 'atk'; eHit(e, 70, 36, { kx: 120, launch: true }); slashFx(e.x + e.face * 34, e.y, 40, e.face, '#a7ff1a', 56, 0, 0.22); sfx('slash'); } }
      else if (P.ps === 2 && P.t > 0.4) endPat(e);
      break;
    }
    case 'rain': { /* telegraphed zones rain down around the heroes */
      bossFace(e, tg); e.frame = 'spec';
      if (P.ps === 0) { e.windup = true; if (P.t > 0.6) { P.ps = 1; P.t = 0; e.windup = false; sfx('special'); ringFx(e.x, e.y, 30, 90, '#ff5a2a', 0.5); const n = e.p2 ? 5 : 3, kind = def.rain || 'debris'; for (const h of G.heroes) { if (h.dead) continue; for (let i = 0; i < n; i++) G.hz.push({ kind: kind === 'spike' ? 'debris' : kind, spike: kind === 'spike', boss: true, x: clamp(h.x + (i - (n - 1) / 2) * 34 + rnd(-6, 6), G.camX + 20, G.camX + VW - 100), y: clamp(h.y + rnd(-12, 12), LANE_T + 4, LANE_B - 4), r: kind === 'gas' ? 26 : 22, t: -i * 0.12, warn: 0.9, live: kind === 'gas' ? 1.8 : 0.25, dmg: (kind === 'gas' ? 30 : 48) * dm }); } } }
      else if (P.t > 1.1) endPat(e, 0.5);
      break;
    }
    case 'cross': { /* two waves on the lanes above and below the hero */
      bossFace(e, tg);
      if (P.ps === 0) { e.frame = 'wind'; e.windup = true; if (P.t > 0.5) { P.ps = 1; P.t = 0; e.windup = false; e.frame = 'spec'; for (const oy of [-20, 20]) shoot({ x: e.x + e.face * 30, y: clamp(tg.y + oy, LANE_T, LANE_B), z: 26, vx: e.face * 300, dmg: 46 * dm, team: 'e', r: 18, life: 1.5, type: 'wave', col: def.col || '#ff1a40', pierce: true, kx: 90 }); shoot({ x: e.x + e.face * 30, y: tg.y, z: 26, vx: e.face * 170, dmg: 46 * dm, team: 'e', r: 16, life: 2, type: 'wave', col: '#ff8a2a', pierce: true, kx: 90 }); sfx('special'); } }
      else if (P.t > 0.8) endPat(e);
      break;
    }
    case 'combo': { /* three lunging strikes that track the hero */
      if (P.ps === 0) { bossFace(e, tg); e.frame = 'wind'; e.windup = true; if (P.t > 0.35 * DF().wind) { P.ps = 1; P.t = 0; e.windup = false; } }
      else if (P.ps === 1) { e.frame = 'atk'; e.x += e.face * 260 * dt; e.moving = true; if (Math.abs(dy) > 3) e.y += Math.sign(dy) * 70 * dt; if (P.t > 0.16) { P.hits++; eHit(e, reach * 0.9, def.wide ? 50 : 34, { kx: 90, launch: P.hits >= 3, kz: 200 }); slashFx(e.x + e.face * reach * 0.5, e.y, 40, e.face, def.col || '#ff5030', reach * 0.8, P.hits % 2 ? -0.5 : 0.5, 0.18); sfx('slash'); P.ps = 2; P.t = 0; } }
      else if (P.ps === 2 && P.t > 0.14) { if (P.hits < 3) { bossFace(e, tg); P.ps = 1; P.t = 0; e.ct = 0; } else endPat(e, 0.9); }
      break;
    }
    case 'leap': { /* jumps and lands where the hero stood: a shadow marks the spot */
      if (P.ps === 0) { bossFace(e, tg); e.frame = 'wind'; e.windup = true; if (P.t > 0.4 * DF().wind) { P.ps = 1; P.t = 0; P.tx = clamp(tg.x, G.camX + 50, G.camX + VW - 120); P.ty = tg.y; P.sx = e.x; P.sy = e.y; e.windup = false; sfx('jump'); G.hz.push({ kind: 'debris', boss: true, x: P.tx, y: P.ty, r: def.wide ? 54 : 40, t: 0, warn: 0.75, live: 0.2, dmg: 64 * dm, quiet: true }); } }
      else if (P.ps === 1) { const k = Math.min(1, P.t / 0.75); e.frame = 'run'; e.x = lerp(P.sx, P.tx, k); e.y = lerp(P.sy, P.ty, k); e.z = Math.sin(k * Math.PI) * 120; if (k >= 1) { e.z = 0; P.ps = 2; P.t = 0; shake(10); sfx('boom'); dust(e.x, e.y, 18); ringFx(e.x, e.y, 0, 90, def.col || '#ffb060', 0.45); vibe(40, 160); } }
      else if (P.ps === 2) { e.frame = 'atk'; if (P.t > 0.7) endPat(e, 0.7); }
      break;
    }
    case 'volley': { /* a fan of aimed shots */
      bossFace(e, tg);
      if (P.ps === 0) { e.frame = 'wind'; e.windup = true; if (P.t > 0.5 * DF().wind) { P.ps = 1; P.t = 0; e.windup = false; } }
      else if (P.ps === 1) { e.frame = 'spec'; const mz = def.muzzle || [30, 34]; const n = e.p2 ? 7 : 5; for (let i = 0; i < n; i++) { const a = (i - (n - 1) / 2) * 0.16; shoot({ x: e.x + e.face * mz[0], y: e.y, z: mz[1], vx: e.face * 230 * Math.cos(a), vy: 230 * Math.sin(a) * 0.45, dmg: 28 * dm, team: 'e', r: 7, life: 2.2, type: 'orb', col: def.shot || def.col || '#ff3050' }); } sfx('shot'); P.ps = 2; P.t = 0; }
      else if (P.ps === 2 && P.t > 0.7) endPat(e);
      break;
    }
    case 'sweep': { /* a low shockwave along the floor: jump over it */
      bossFace(e, tg);
      if (P.ps === 0) { e.frame = 'wind'; e.windup = true; if (P.t > 0.55 * DF().wind) { P.ps = 1; P.t = 0; e.windup = false; } }
      else if (P.ps === 1) { e.frame = 'atk'; for (const oy of [-14, 0, 14]) shoot({ x: e.x + e.face * 20, y: clamp(e.y + oy, LANE_T, LANE_B), z: 0, vx: e.face * 250, dmg: 40 * dm, team: 'e', r: 16, life: 1.6, type: 'shock', col: def.col || '#ffb060', pierce: true, low: true, kx: 100, launch: true }); sfx('boom'); shake(6); P.ps = 2; P.t = 0; }
      else if (P.ps === 2 && P.t > 0.6) endPat(e);
      break;
    }
    case 'grab': { /* unblockable lunge: dodge it */
      if (P.ps === 0) { bossFace(e, tg); e.frame = 'wind'; e.windup = true; e.grabFx = true; if (P.t > 0.7 * DF().wind) { P.ps = 1; P.t = 0; e.windup = false; e.hitSet = new Set(); sfx('roar'); } }
      else if (P.ps === 1) { e.frame = 'run'; e.x += e.face * 330 * dt; e.moving = true; for (const h of G.heroes) { if (h.dead || e.hitSet.has(h)) continue; if (Math.abs(h.x - e.x) < (def.wide ? 60 : 32) && Math.abs(h.y - e.y) < 14 && h.z < 30) { e.hitSet.add(h); hurt(e, h, 78 * dm, { launch: true, kx: 200, kz: 260, unblock: true }); shake(9); vibe(80, 230); } } if (P.t > 0.55) { e.grabFx = false; endPat(e, 0.8); } }
      break;
    }
    default: endPat(e);
  }
}

/* ---------- stage hazards (telegraphed: everyone in the zone gets hit, enemies too) ---------- */
function spawnHazard(kind) {
  const p = G.player; if (!p) return;
  if (kind === 'debris') { const x = clamp(p.x + rnd(-90, 120), G.camX + 30, G.camX + VW - 110), y = clamp(p.y + rnd(-18, 18), LANE_T + 6, LANE_B - 4); G.hz.push({ kind, x, y, r: 28, t: 0, warn: 1.1, live: 0.25, dmg: 70 }); }
  else if (kind === 'gas') { const x = clamp(p.x + rnd(-70, 110), G.camX + 30, G.camX + VW - 110), y = clamp(p.y + rnd(-14, 14), LANE_T + 8, LANE_B - 6); G.hz.push({ kind, x, y, r: 36, t: 0, warn: 1.0, live: 3.2, dmg: 34 }); }
  else if (kind === 'shock') { const x = clamp(p.x + rnd(-80, 110), G.camX + 40, G.camX + VW - 110), y = clamp(p.y + rnd(-14, 14), LANE_T + 8, LANE_B - 6); G.hz.push({ kind, x, y, r: 40, t: 0, warn: 1.2, live: 1.5, dmg: 44 }); sfx('alarm'); }
  else if (kind === 'train') { const y = clamp(p.y + rnd(-10, 10), LANE_T + 14, LANE_B - 12); G.hz.push({ kind, x: G.camX, y, r: 15, t: 0, warn: 1.5, live: 0.7, dmg: 130 }); sfx('alarm'); }
}
function inHazard(h, e) { if (h.kind === 'train') return Math.abs(e.y - h.y) < h.r && e.z < 40; return Math.hypot(e.x - h.x, (e.y - h.y) * 1.8) < h.r && e.z < 30; }
function updHazards(dt) {
  for (const h of G.hz) {
    const was = h.t; h.t += dt;
    if (was < h.warn && h.t >= h.warn) {
      if (h.kind === 'debris' && !h.quiet) { sfx('boom'); shake(5); debris(h.x, h.y, 'db', 6); dust(h.x, h.y, 10); }
      if (h.kind === 'train') { sfx('roar'); shake(9); }
      if (h.kind === 'gas') sfx('special');
      if (h.kind === 'shock') { sfx('shot'); shake(3); }
      h.hitSet = new Set();
    }
    if (h.t >= h.warn && h.t < h.warn + h.live) {
      for (const e of G.heroes.concat(G.enemies)) {
        if (e.dead || !inHazard(h, e) || (h.boss && e.team !== 'p')) continue;
        if (h.kind === 'shock') { if (Math.floor(h.t * 3) !== Math.floor((h.t - dt) * 3)) { hurt({ x: h.x, y: h.y, team: e.team === 'p' ? 'e' : 'n' }, e, h.dmg * (e.team === 'p' ? DF().dmg : 1.4) * 0.5, { ignoreInv: false, stun: 0.35 }); sparks(e.x, e.y, 20, 6, '#9cf4ff'); } }
        else if (h.kind === 'gas') { if (Math.floor(h.t * 4) !== Math.floor((h.t - dt) * 4)) hurt({ x: h.x, y: h.y, team: e.team === 'p' ? 'e' : 'n' }, e, h.dmg * (e.team === 'p' ? DF().dmg : 1.4) * 0.25, { ignoreInv: false }); }
        else if (!h.hitSet.has(e)) { h.hitSet.add(e); hurt({ x: h.kind === 'train' ? e.x + 30 : h.x, y: h.y, team: e.team === 'p' ? 'e' : 'n' }, e, h.dmg * (e.team === 'p' ? DF().dmg : 1.6), { launch: e.kind !== 'boss', kx: h.kind === 'train' ? 240 : 120, kz: 230, ignoreInv: false, brk: true }); }
      }
      if (h.kind === 'shock' && Math.random() < dt * 30) sparks(h.x + rnd(-h.r, h.r), h.y + rnd(-8, 8), 2, 2, Math.random() < 0.5 ? '#ffffff' : '#5ae6ff');
      if (h.kind === 'gas' && Math.random() < dt * 20) G.parts.push({ x: h.x + rnd(-h.r, h.r), y: h.y + rnd(-6, 6), z: rnd(2, 20), vx: rnd(-10, 10), vy: 0, vz: rnd(10, 30), life: 0.8, t: 0, col: '#9aff4a', size: 2, grav: 0, dust: true });
    }
  }
  G.hz = G.hz.filter(h => h.t < h.warn + h.live);
}

/* ---------- TEAM SUPER: both heroes strike the whole screen together ---------- */
function canSuper() { const p = G.player, a = G.ally; if (!a || p.form === 'x' || G.panel) return false; return G.syn >= 100 && !G.superFx && !G.cine && G.over <= 0 && !G.clearT && !p.dead && a && !a.dead && !a.assist && p.st !== 'xform' && G.autoTag <= 0; }
function startSuper() {
  const p = G.player, a = G.ally; G.syn = 0; vibe(140, 220);
  a.bench = false; a.assist = true; a.astPh = 'super'; a.isPlayer = false; a.face = p.face; a.x = clamp(p.x - p.face * 40, G.camX + 20, G.camX + VW - 110); a.y = clamp(p.y + 10, LANE_T, LANE_B); a.z = 0; a.vz = 0; a._trail = []; G.heroes.push(a);
  for (const h of [p, a]) { h.inv = 3; h.spCd = 0; startSpec(h); h.specDur = 1.2; h.specAt = 99; h.vx = 0; }
  G.superFx = { t: 0, p, a, hit: false }; sfx('howl'); sfx('special'); shake(6); freeze(0.05);
}
function updSuper(dt) {
  const S = G.superFx; S.t += dt;
  for (const h of [S.p, S.a]) { h.t += dt; phys(h, dt); h.flash = 0; }
  if (S.t < 0.75 && Math.random() < 0.8) for (const h of [S.p, S.a]) { const an = rnd(0, 6.28), r = rnd(40, 70); G.parts.push({ x: h.x + Math.cos(an) * r, y: h.y, z: 45 + Math.sin(an) * r * 0.7, vx: -Math.cos(an) * r * 2.5, vy: 0, vz: -Math.sin(an) * r * 1.8, life: 0.4, t: 0, col: h.id === 'lupus' ? '#ff2a40' : HERO[h.id].color, size: 2, grav: 0, glowP: true }); }
  if (!S.hit && S.t >= 0.8) {
    S.hit = true; shake(16); freeze(0.1); G.flashScr = 0.9; G.slow = 0.35; sfx('boom'); sfx('roar');
    for (const h of [S.p, S.a]) { ringFx(h.x, h.y, 20, 260, h.id === 'lupus' ? '#ff2a40' : HERO[h.id].color, 0.9); }
    const dm = (S.p.id === 'lupus' ? FORM[S.p.form].dmg : HERO[S.p.id].dmg) + (S.a.id === 'lupus' ? FORM[S.a.form].dmg : HERO[S.a.id].dmg);
    for (const e of G.enemies) { if (e.dead || e.x < G.camX - 20 || e.x > G.camX + VW + 20) continue; hurt(S.p, e, dm * 6 * upMul() * (e.kind === 'boss' ? 0.55 : 1), { launch: e.kind !== 'boss', kx: 220, kz: 300, brk: true, ignoreInv: true, bleed: true }); }
    for (const q of G.props) if (!q.dead && q.x > G.camX && q.x < G.camX + VW) breakProp(q);
  }
  if (S.t >= 1.6) { const a = S.a; G.superFx = null; for (const h of [S.p, a]) { setSt(h, 'idle'); h.inv = 0.6; } a.astPh = 'out'; jumpOut(a); }
}

/* ---------- ENDLESS NIGHT: waves forever, harder each time ---------- */
const EW_POOL = [['S', 'Z', 'H'], ['S', 'Z', 'H', 'ZS', 'M', 'V'], ['S', 'Z', 'H', 'ZS', 'M', 'V', 'K', 'A']];
function endlessStep(dt) {
  if (!G.ewActive) { G.ewDelay -= dt; if (G.ewDelay <= 0) {
    G.ew++; G.endlessLv = G.ew - 1; G.ewActive = true; const pool = EW_POOL[Math.min(2, Math.floor((G.ew - 1) / 4))], n = Math.min(3 + Math.floor(G.ew * 0.6), 9);
    G.spawnQ = []; for (let i = 0; i < n; i++) G.spawnQ.push({ t: 0.3 + i * 0.45, type: pick(pool), elite: false, side: i % 2 ? -1 : 1 });
    if (G.ew % 5 === 0) G.spawnQ.push({ t: 0.3 + n * 0.45, type: pick(['K', 'A', 'V']), elite: true, side: 1 });
    if (G.ew % 10 === 0) { G.bossPending = true; G.bossT = 2.5; const ids = Object.keys(BOSS); G.ewBoss = ids[Math.floor(G.ew / 10 - 1) % ids.length]; G.banner = { t: 0, boss: BOSS[G.ewBoss] }; }
    G.banner2 = { t: 0, txt: T('wave') + ' ' + G.ew }; sfx('alarm');
  } return; }
  for (const s of G.spawnQ) s.t -= dt; const due = G.spawnQ.filter(s => s.t <= 0); G.spawnQ = G.spawnQ.filter(s => s.t > 0);
  due.forEach(s => { const e = spawnEnemy(s.type, s.side, s.elite); if (s.elite) { G.banner2 = { t: 0, txt: e.def.name }; sfx('roar'); } });
  if (G.bossPending) { G.bossT -= dt; if (G.bossT <= 0) { G.bossPending = false; const b = spawnBoss(G.ewBoss); b.x = G.camX + VW - 60; b.maxhp = b.hp = b.hp * (0.6 + 0.08 * G.ew / 10); sfx('roar'); shake(8); } }
  if (!G.spawnQ.length && !G.bossPending && enemiesAlive() === 0) { G.ewActive = false; G.ewDelay = 2.6; sfx('ok'); for (const h of G.team) if (!h.dead) h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.1); G.score += 200 * G.ew; }
}

/* ---------- TRAINING: one step at a time ---------- */
function tutStep(dt) {
  const T0 = G.tut, p = G.player, step = T0.steps[T0.i]; T0.t += dt; if (T0.flash > 0) T0.flash -= dt;
  let ok = false;
  if (step === 'move') { T0.moved += Math.abs(p.x - T0.lastX) + Math.abs(p.y - (T0.lastY || p.y)); T0.lastX = p.x; T0.lastY = p.y; ok = T0.moved > 140; }
  else if (step === 'attack') ok = G.combo >= 5;
  else if (step === 'jump') ok = p.z > 18;
  else if (step === 'dash') ok = p.st === 'dash';
  else if (step === 'block') ok = p.st === 'guard' && G.time - (p.guardT0 || 0) > 0.4;
  else if (step === 'spec') ok = p.st === 'spec';
  else if (step === 'tag') ok = G.tags >= 1;
  else if (step === 'assist') ok = G.ally.assist === true;
  else if (step === 'form') { if (p.id !== 'lupus' && G.ally.id === 'lupus' && canTag()) { G.tagCd = 0; tagSwap(true); } if (G.player.id === 'lupus' && G.player.form === 'h') G.player.fury = Math.max(G.player.fury, 120); ok = G.player.id === 'lupus' && G.player.form !== 'h'; }
  else if (step === 'super') { if (!G.superFx) G.syn = 100; ok = !!G.superFx; }
  else if (step === 'done') { if (T0.t > 3 && !T0.left) { T0.left = true; SAVE.tutDone = true; saveGame(); Scene.go(G.tutNext); } return; }
  if (ok && T0.t > 0.4) { T0.i++; T0.t = 0; T0.flash = 0.8; sfx('pick'); textFx(p.x, p.y - 100, 'OK!', '#7dff9a', 2); if (T0.steps[T0.i] === 'done') { sfx('ok'); SAVE.tutDone = true; saveGame(); } }
}
