'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { createRuntime } = require('./runtime.cjs');

/* 8.5: open combat space, with wave/event progression still enforced.
 * Damage uses hurt(); waves, queued hatching and release use the real engine.
 * Fixtures position the hero or select a checkpoint; none bypass a live lock.
 */
async function main() {
  const r = createRuntime({ seed: 8500 }); await r.settle();
  const pristine = r.run('JSON.stringify(SAVE)');
  const tests = [], results = [];
  const test = (name, fn) => tests.push({ name, fn });
  async function enter(stage, args = {}) {
    r.run(`SAVE=${pristine};SAVE.music=false;SAVE.sfx=false;SAVE.diff='normal';Inp.reset();window.__err=[]`);
    await r.play(stage, args);
    r.run('G.title=0;G.player.inv=10000');
  }
  function damageEnemies() {
    r.run('for(const e of G.enemies.slice()) if(!e.dead) hurt(G.player,e,e.maxhp*3,{ignoreInv:true,brk:true,ground:true})');
  }
  function waveSteps(frames) { r.run(`for(let i=0;i<${frames};i++) Scenes.play.waves(1/60)`); }
  function goDrawn() {
    return r.run(`(() => {
      const original=PIX.text, texts=[];
      PIX.text=function(g,text,...args){texts.push(String(text));return original.call(this,g,text,...args)};
      const time=G.time; G.time=0;
      try { drawOverlays(bg); } finally { PIX.text=original;G.time=time; }
      return texts.includes(T('go')+' >');
    })()`);
  }
  function positionAtNextWave() {
    r.run('G.player.x=G.st.waves[G.waveIdx].x+1;G.player.vx=G.player.vy=0;G.camX=clamp(G.player.x-VW*.36,0,WORLD_W-VW)');
  }

  test('the prologue has no artificial doors and retains its alarm and props', async () => {
    await enter(0);
    assert.equal(r.run('typeof MECH.escape.drawBack'), 'undefined');
    assert.equal(r.run("Object.prototype.hasOwnProperty.call(G,'doors')"), false);
    assert.equal(r.run('typeof MECH.escape.drawOver'), 'function');
    assert.equal(r.run('G.props.length'), r.run('G.st.props.length'));
    const source = fs.readFileSync(path.join(r.root, 'js/game8.js'), 'utf8');
    assert(!source.includes('G.doors'));
    positionAtNextWave(); r.tick(1, true);
    assert(r.run('G.locked && G.spawnQ.length>0'));
    assert.deepEqual(r.json('window.__err||[]'), []);
  });

  test('a normal wave waits for scheduled and living enemies, then releases exactly once', async () => {
    await enter(0); positionAtNextWave(); r.tick();
    const checkpoint = r.run('G.ck'), camera = r.run('G.camX');
    assert(r.run('G.locked && G.spawnQ.length>0')); assert(!goDrawn());
    r.run('Inp.keys.r=true;Inp.held.r=true'); r.tick(120);
    assert.equal(r.run('G.locked'), true); assert.equal(r.run('G.waveIdx'), 0);
    assert.equal(r.run('G.camX'), camera); assert.equal(r.run('G.ck'), checkpoint);
    assert(r.run('enemiesAlive()>0')); assert(!goDrawn());
    r.run('Inp.reset()'); damageEnemies(); r.tick(30);
    assert.equal(r.run('G.locked'), false); assert.equal(r.run('G.waveIdx'), 1);
    assert.equal(r.run('G.ck'), 1); assert(goDrawn());
    r.tick(30); assert.equal(r.run('G.waveIdx'), 1);
  });

  test('starting the next wave cancels a previous GO immediately', async () => {
    await enter(0); r.run('G.goT=3'); positionAtNextWave(); r.tick();
    assert.equal(r.run('G.goT'), 0); assert(r.run('G.locked && G.spawnQ.length>0'));
    assert(!goDrawn());
  });

  test('GO rendering rejects a stale timer during combat, queues, events or failure', async () => {
    await enter(0); r.run('G.goT=3'); assert(goDrawn());
    const conditions = [
      ['G.locked=true', 'G.locked=false'],
      ["G.spawnQ=[{t:9,type:'T',side:1}]", 'G.spawnQ=[]'],
      ["G.testEnemy=spawnEnemy('T',1)", 'G.enemies=[]'],
      ['G.duelHold=true', 'G.duelHold=false'],
      ['G.bossPending=true', 'G.bossPending=false'],
      ['G.bossSpawned=true', 'G.bossSpawned=false'],
      ['G.arena=true', 'G.arena=false'],
      ['G.over=.001', 'G.over=0']
    ];
    for (const [set, reset] of conditions) {
      r.run(set); assert(!goDrawn(), `GO leaked while ${set}`); r.run(reset);
    }
    assert(goDrawn());
  });

  test('GO stays hidden behind story and combat events and returns after they finish', async () => {
    await enter(0); r.run('G.goT=3'); assert(goDrawn());
    for (const key of ['panel', 'choice', 'cine', 'superFx']) {
      r.run(`G.${key}={}`); assert(!goDrawn(), `GO leaked during ${key}`);
      r.run(`G.${key}=null`); assert(goDrawn(), `GO did not return after ${key}`);
    }
  });

  test('incubator hatching keeps an active wave locked before and after all delayed spawns', async () => {
    await enter(5, { fromWave: 1 }); positionAtNextWave(); r.tick();
    const waveCount = r.run('G.spawnQ.length');
    r.run('hurt(G.player,G.incubs[0],G.incubs[0].maxhp*3,{brk:true})');
    assert.equal(r.run('G.spawnQ.length'), waveCount + 3);
    assert.equal(r.run('G.goT'), 0); assert.equal(r.run('G.sideEncounter'), false);
    // Kill every appearance promptly: a gap between appearances must not clear.
    for (let i = 0; i < 600 && r.run('G.locked'); i++) {
      if (r.run('G.spawnQ.length>0')) { assert(r.run('G.locked')); assert(!goDrawn()); }
      r.tick(); damageEnemies();
    }
    r.tick();
    assert.equal(r.run('G.spawnQ.length'), 0); assert.equal(r.run('enemiesAlive()'), 0);
    assert.equal(r.run('G.locked'), false); assert.equal(r.run('G.waveIdx'), 2);
    assert.equal(r.run('G.ck'), 2); assert(goDrawn());
    assert.equal(r.run('G.incDown'), 1);
    assert.equal(r.run('G.incubs.filter(o=>!o.dead).length'), 2);
  });

  test('an incubator between waves creates an encounter without consuming a wave or checkpoint', async () => {
    await enter(5, { fromWave: 2 });
    r.run('G.player.x=920;G.player.y=G.incubs[0].y;G.camX=G.player.x-VW*.36;G.player.hp=G.player.maxhp*.5;G.goT=3;G.testHP=G.player.hp;hurt(G.player,G.incubs[0],G.incubs[0].maxhp*3,{brk:true})');
    assert(r.run('G.locked && G.sideEncounter')); assert.equal(r.run('G.spawnQ.length'), 3);
    assert.deepEqual(r.json('G.spawnQ.map(s=>({t:s.t,type:s.type,x:s.x,y:s.y,arrive:s.arrive}))'), [
      { t: .3, type: 'M', x: 924, y: r.run('clamp(G.incubs[0].y+18,LANE_T,LANE_B)'), arrive: false },
      { t: .5, type: 'M', x: 940, y: r.run('clamp(G.incubs[0].y+18,LANE_T,LANE_B)'), arrive: false },
      { t: .7, type: 'X', x: 956, y: r.run('clamp(G.incubs[0].y+18,LANE_T,LANE_B)'), arrive: false }
    ]);
    waveSteps(10); assert.equal(r.run('enemiesAlive()'), 0); assert(r.run('G.locked')); assert(!goDrawn());
    waveSteps(40); assert.equal(r.run('enemiesAlive()'), 3); assert(r.run('G.locked')); assert(!goDrawn());
    assert.deepEqual(r.json('G.enemies.filter(e=>!e.dead).map(e=>e.type)'), ['M', 'M', 'X']);
    damageEnemies(); waveSteps(1);
    assert.equal(r.run('G.locked'), false); assert.equal(r.run('G.sideEncounter'), false);
    assert.equal(r.run('G.waveIdx'), 2); assert.equal(r.run('G.ck'), 2);
    assert.equal(r.run('G.player.hp'), r.run('G.testHP'), 'side encounter granted the regular wave heal');
    assert(goDrawn());
    r.tick(20); positionAtNextWave(); r.tick();
    assert(r.run('G.locked && !G.sideEncounter && G.spawnQ.length>0'));
    assert.equal(r.run('G.waveIdx'), 2); assert.equal(r.run('G.goT'), 0);
  });

  test('pausing does not hatch queued mutants or release the encounter', async () => {
    await enter(5, { fromWave: 2 });
    r.run('hurt(G.player,G.incubs[0],G.incubs[0].maxhp*3,{brk:true});Scenes.play.menu=true');
    const before = r.json('G.spawnQ.map(s=>s.t)'); r.tick(120);
    assert.deepEqual(r.json('G.spawnQ.map(s=>s.t)'), before);
    assert.equal(r.run('enemiesAlive()'), 0); assert(r.run('G.locked')); assert(!goDrawn());
    r.run('Scenes.play.menu=false'); r.tick(50);
    assert.equal(r.run('G.spawnQ.length'), 0); assert.equal(r.run('enemiesAlive()'), 3);
  });

  for (const stage of [1, 5, 13, 14]) test(`stage ${stage + 1} preserves its global objective gate without blocking earlier waves`, async () => {
    await enter(stage); assert(r.run('!!MECH[G.mech].gate()'));
    r.run('G.goT=3'); assert(goDrawn(), 'a future objective hid the release of an earlier block');
    const array = r.run("G.clues?'clues':G.incubs?'incubs':G.towers?'towers':'reacts'");
    assert.equal(r.run(`G.${array}.length`), 3);
    // A checkpoint after every normal wave still needs all stage objectives.
    await enter(stage, { fromWave: r.run('G.st.waves.length') });
    r.run('G.goT=3'); assert(!goDrawn());
    r.run('G.player.x=WORLD_W-VW*.62+8;Scenes.play.waves(0)');
    assert.equal(r.run('G.bossPending'), false); assert.equal(r.run('G.locked'), false);
    assert(r.run('G.player.x<WORLD_W-VW*.62 && MECH[G.mech].backtrack()'));
    r.run('G.goT=0');
    if (stage === 1) r.run('for(const clue of G.clues){G.player.x=clue.x;G.player.y=clue.y;G.sensing=true;MECH.investigate.update(1/60)}');
    else {
      // Each incubator uses its real hatching encounter before the exit opens.
      for (let i = 0; i < 3; i++) {
        r.run(`G.player.x=G.${array}[${i}].x-20;hurt(G.player,G.${array}[${i}],G.${array}[${i}].maxhp*3,{brk:true})`);
        if (stage === 5) { waveSteps(50); damageEnemies(); waveSteps(1); }
      }
    }
    r.run('Scenes.play.waves(0)'); assert.equal(r.run('MECH[G.mech].gate()'), null);
    assert.equal(r.run('G.locked'), false); assert(goDrawn());
    r.run('G.player.x=WORLD_W-VW*.62+8;Scenes.play.waves(0)');
    assert(r.run('G.locked && G.bossPending')); assert.equal(r.run('G.goT'), 0); assert(!goDrawn());
  });

  test('existing local ritual and duel holds still reject early release', async () => {
    await enter(7, { fromWave: 2 }); positionAtNextWave(); r.tick();
    assert(r.run('G.locked && G.duelHold && !!G.statue'));
    r.run('G.goT=3'); waveSteps(120);
    assert.equal(r.run('G.waveIdx'), 2); assert(r.run('G.locked')); assert(!goDrawn());
    assert.equal(r.run('G.statue.dead'), false);
    await enter(1, { fromWave: 3 }); positionAtNextWave(); r.tick();
    assert(r.run('G.locked && G.duelHold && !!G.panel'));
    waveSteps(120); assert.equal(r.run('G.waveIdx'), 3); assert(r.run('G.locked')); assert(!goDrawn());
  });

  console.log('TAP version 13');
  for (const { name, fn } of tests) {
    try { await fn(); assert.deepEqual(r.json('window.__err||[]'), []); results.push(true); console.log(`ok ${results.length} - ${name}`); }
    catch (e) { results.push(false); console.log(`not ok ${results.length} - ${name}\n  ---\n  message: ${JSON.stringify(e.message)}\n  ...`); }
  }
  console.log(`1..${results.length}\n# ${results.filter(Boolean).length} passed, ${results.filter(v=>!v).length} failed`);
  if (results.some(v=>!v)) process.exitCode = 1;
}
main().catch(e => { console.error(e.stack); process.exitCode = 1; });
