'use strict';
/* =====================================================================
   ART — asset loading, sprite atlases, per-stage colour grading,
   dynamic rim lights, shadows, reflections, layered scenery, atmosphere.
   World space = 270 units tall; the frame buffer is 2x (540 px), so
   1 atlas pixel = 0.5 world unit (atlases were baked at that scale).
   ===================================================================== */
const VIEW_H = 270, LANE_T = 196, LANE_B = 262, WALL_Y = 176, TILE_W = 810;
const ART = { img: {}, loaded: 0, total: 0, graded: {}, sil: new Map(), stage: 0 };

/* ---------- loading ---------- */
ART.list = function () {
  const L = [];
  for (const k in window.ATLAS) L.push(['c_' + k, 'assets/chars/' + k + '.webp']);
  for (let s = 1; s <= 5; s++) for (let l = 1; l <= 4; l++) L.push(['s' + s + '_l' + l, 'assets/bg/s' + s + '_l' + l + '.webp']);
  L.push(['items', 'assets/ui/items.webp']);
  return L;
};
ART.load = function (done) {
  const L = ART.list(); ART.total = L.length;
  L.forEach(([k, src]) => { const im = new Image(); im.onload = im.onerror = () => { ART.loaded++; if (ART.loaded >= ART.total) done(); }; im.src = src; ART.img[k] = im; });
};

/* ---------- stage look ---------- */
const LOOK = {
  1: { amb: '#b4bce0', tint: '#2a3cff', tintA: 0.05, refl: 0.30, fog: 'rgba(30,40,90,0.10)', rim: '#47e6ff', rimA: 0.55,
       lights: [[201, 120, '#ff1a3a', 120], [395, 110, '#20e6ff', 120], [477, 100, '#ff1a3a', 110], [597, 120, '#20e6ff', 120], [768, 110, '#ff1a3a', 110]], fx: 'rain' },
  2: { amb: '#b0b8dc', tint: '#3050ff', tintA: 0.05, refl: 0.22, fog: 'rgba(40,50,110,0.10)', rim: '#9cc4ff', rimA: 0.5,
       lights: [[75, 142, '#ff8a30', 120], [183, 142, '#ff8a30', 120], [418, 142, '#ff8a30', 120], [698, 142, '#ff8a30', 120], [477, 60, '#ff1a3a', 160]], fx: 'embers' },
  3: { amb: '#e2c6a4', tint: '#ff7a20', tintA: 0.06, refl: 0, fog: 'rgba(90,50,20,0.08)', rim: '#ffb060', rimA: 0.5,
       lights: [[149, 171, '#ff8a30', 130], [578, 171, '#ff8a30', 130], [380, 120, '#ffc070', 200]], fx: 'dust' },
  4: { amb: '#a6c4c0', tint: '#10a080', tintA: 0.06, refl: 0.36, water: true, fog: 'rgba(20,90,80,0.10)', rim: '#40ffe0', rimA: 0.5,
       lights: [[67, 57, '#ff2a3a', 140], [246, 57, '#ff2a3a', 140], [496, 57, '#ff2a3a', 140], [675, 57, '#ff2a3a', 140], [157, 40, '#30e8ff', 130], [366, 40, '#30e8ff', 130], [582, 40, '#30e8ff', 130]], fx: 'drips' },
  5: { amb: '#bcccb4', tint: '#40ff40', tintA: 0.05, refl: 0.26, fog: 'rgba(40,90,20,0.09)', rim: '#9aff40', rimA: 0.5,
       lights: [[60, 100, '#8aff2a', 110], [180, 100, '#8aff2a', 110], [300, 100, '#8aff2a', 110], [403, 61, '#ff1a2a', 170], [520, 100, '#8aff2a', 110], [640, 100, '#8aff2a', 110], [760, 100, '#8aff2a', 110]], fx: 'spores' }
};
const MENU_LOOK = { amb: '#c8cce4', tint: '#3040ff', tintA: 0.03, refl: 0.25, rim: '#47e6ff', rimA: 0.45, lights: [] };

/* graded atlas copy: multiply by ambient + colour cast (keeps alpha) */
ART.grade = function (key, look) {
  const id = key + '|' + look.amb + look.tint;
  if (ART.graded[id]) return ART.graded[id];
  const src = ART.img['c_' + key]; if (!src || !src.width) return src;
  const c = document.createElement('canvas'); c.width = src.width; c.height = src.height; const g = c.getContext('2d');
  g.drawImage(src, 0, 0);
  g.globalCompositeOperation = 'multiply'; g.fillStyle = look.amb; g.fillRect(0, 0, c.width, c.height);
  g.globalCompositeOperation = 'source-over'; g.globalAlpha = look.tintA || 0; g.fillStyle = look.tint; g.fillRect(0, 0, c.width, c.height);
  g.globalAlpha = 1; g.globalCompositeOperation = 'destination-in'; g.drawImage(src, 0, 0);
  return ART.graded[id] = c;
};
ART.useLook = function (look) { ART.look = look; ART.sil.clear(); };
ART.useLook(MENU_LOOK);

/* ---------- frames ---------- */
ART.anim = function (key, an) { const A = window.ATLAS[key]; return A && (A.a[an] || A.a.idle); };
ART.frameCount = (key, an) => { const a = ART.anim(key, an); return a ? a.length : 1; };
ART.frame = function (key, an, i, loop) {
  const A = window.ATLAS[key]; if (!A) return null; const ids = A.a[an] || A.a.idle; const n = ids.length;
  const k = loop === false ? Math.max(0, Math.min(n - 1, i)) : ((i % n) + n) % n;
  const f = A.f[ids[k]]; return { key, id: ids[k], sx: f[0], sy: f[1], w: f[2], h: f[3], ax: f[4], ay: f[5] };
};
/* silhouette of a frame in a solid colour (cached) */
ART.silhouette = function (fr, col) {
  const id = fr.key + ':' + fr.id + col; let c = ART.sil.get(id); if (c) return c;
  c = document.createElement('canvas'); c.width = fr.w; c.height = fr.h; const g = c.getContext('2d');
  g.drawImage(ART.img['c_' + fr.key], fr.sx, fr.sy, fr.w, fr.h, 0, 0, fr.w, fr.h);
  g.globalCompositeOperation = 'source-in'; g.fillStyle = col; g.fillRect(0, 0, fr.w, fr.h);
  if (ART.sil.size > 900) ART.sil.clear();
  ART.sil.set(id, c); return c;
};
const half = v => Math.round(v * 2) / 2;
/* draw frame with feet at (x,y) world coords. o: {face, alpha, sc, flash, tint, tintA, rim:[col,dx,dy,a], ghost} */
ART.draw = function (g, fr, x, y, o) {
  if (!fr) return; o = o || {};
  const look = ART.look; const src = o.raw ? ART.img['c_' + fr.key] : ART.grade(fr.key, look);
  const sc = (o.sc || 1) * 0.5, face = o.face || 1;
  g.save(); g.translate(half(x), half(y)); if (face < 0) g.scale(-1, 1); g.scale(sc * (o.sx || 1), sc * (o.sy || 1));
  if (o.alpha != null) g.globalAlpha = o.alpha;
  const dx = -fr.ax, dy = -fr.ay;
  if (o.rims) for (const r of o.rims) { g.save(); g.globalAlpha = (o.alpha != null ? o.alpha : 1) * r[3]; g.drawImage(ART.silhouette(fr, r[0]), dx + r[1] * face, dy + r[2]); g.restore(); }
  g.drawImage(src, fr.sx, fr.sy, fr.w, fr.h, dx, dy, fr.w, fr.h);
  if (o.flash > 0) { g.globalAlpha = Math.min(1, o.flash) * (o.alpha != null ? o.alpha : 1); g.drawImage(ART.silhouette(fr, o.flashCol || '#ffffff'), dx, dy); }
  if (o.tint) { g.globalAlpha = (o.tintA || 0.4) * (o.alpha != null ? o.alpha : 1); g.drawImage(ART.silhouette(fr, o.tint), dx, dy); }
  g.restore();
};
/* environment light reaching a world point: returns rim list [[col,dx,dy,a]] */
ART.rimsAt = function (wx, wy, h, t) {
  const L = ART.look; const out = [];
  /* constant cool/ambient rim from behind-top (sells the "inside the scene" feeling) */
  out.push([L.rim, -1.6, -1.2, L.rimA * 0.55]);
  if (!L.lights || !L.lights.length) return out;
  let best = null, bd = 1e9;
  const tx = ((wx % TILE_W) + TILE_W) % TILE_W, tile = Math.floor(wx / TILE_W), mir = tile % 2 === 1;
  for (const l of L.lights) {
    const lx = mir ? TILE_W - l[0] : l[0]; const lwx = tile * TILE_W + lx;
    const d = Math.hypot(lwx - wx, (l[1] - (wy - h * 0.6)) * 0.6);
    if (d < l[3] && d < bd) { bd = d; best = [l, lwx]; }
  }
  if (best) {
    const [l, lwx] = best; const k = 1 - bd / l[3]; const side = Math.sign(lwx - wx) || 1;
    const flick = l[2] === '#ff8a30' ? 0.85 + 0.15 * Math.sin(t * 17 + lwx) : 0.92 + 0.08 * Math.sin(t * 3 + lwx);
    out.push([l[2], 2 * side, -1, Math.min(0.9, k * 1.4) * flick, side]);
  }
  return out;
};

/* ---------- shadows & reflections ---------- */
ART.shadow = function (g, x, y, rx, a) {
  rx = Math.max(4, rx); const ry = rx * 0.28;
  g.save(); g.globalAlpha = a == null ? 0.55 : a; g.translate(x, y); g.scale(1, ry / rx);
  const gr = g.createRadialGradient(0, 0, 0, 0, 0, rx); gr.addColorStop(0, 'rgba(0,0,0,0.9)'); gr.addColorStop(0.55, 'rgba(0,0,0,0.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = gr; g.beginPath(); g.arc(0, 0, rx, 0, 6.283); g.fill(); g.restore();
};
ART.reflect = function (g, fr, x, y, z, face, a, t, water, sc) {
  if (!fr || !a) return; const src = ART.grade(fr.key, ART.look); sc = (sc || 1) * 0.5;
  const fade = Math.max(0, 1 - z / 70); if (fade <= 0) return;
  g.save(); g.globalAlpha = a * fade;
  const H = fr.ay; // only the part above the feet
  if (!water) {
    g.translate(half(x), half(y + z * 0.9)); if (face < 0) g.scale(-1, 1); g.scale(sc, -sc * 0.62);
    g.drawImage(src, fr.sx, fr.sy, fr.w, Math.min(fr.h, H), -fr.ax, -fr.ay, fr.w, Math.min(fr.h, H));
  } else {
    /* sliced reflection with ripple distortion */
    const step = 4; for (let s = 0; s < H; s += step) {
      const sy = fr.ay - s - step; if (sy < 0) break;
      const off = Math.sin(t * 5 + s * 0.22 + x * 0.05) * (1 + s * 0.025);
      const yy = y + z * 0.9 + s * sc * 0.62;
      g.save(); g.translate(half(x + off), yy); if (face < 0) g.scale(-1, 1); g.scale(sc, -sc * 0.62);
      g.globalAlpha = a * fade * Math.max(0, 1 - s / H * 0.9);
      g.drawImage(src, fr.sx, fr.sy + sy, fr.w, step, -fr.ax, -step, fr.w, step);
      g.restore();
    }
  }
  g.restore();
};

/* ---------- scenery ---------- */
const BG = { n: 1, t: 0, drops: [], motes: [] };
BG.set = function (n) { BG.n = n; ART.useLook(LOOK[n]); BG.motes = []; };
function drawTiled(g, im, camX, f, y, w, h, alpha, every) {
  if (!im || !im.width) return;
  const off = camX * f; const i0 = Math.floor(off / w);
  g.save(); if (alpha != null) g.globalAlpha = alpha;
  for (let i = i0; i <= i0 + Math.ceil(VW / w) + 1; i++) {
    const x = i * w - off; if (every && ((i % every) + every) % every) continue;
    if (i % 2 === 0) g.drawImage(im, x, y, w, h);
    else { g.save(); g.translate(x + w, y); g.scale(-1, 1); g.drawImage(im, 0, 0, w, h); g.restore(); }
  }
  g.restore();
}
BG.back = function (g, camX, dt) {
  BG.t += dt || 0; const n = BG.n;
  drawTiled(g, ART.img['s' + n + '_l3'], camX, 1, 0, TILE_W, VIEW_H);
  /* light pulses over the scenery (neon / fire / tubes) */
  const L = LOOK[n]; g.save(); g.globalCompositeOperation = 'lighter';
  const i0 = Math.floor(camX / TILE_W);
  for (let i = i0; i <= i0 + 1; i++) for (const l of L.lights) {
    const lx = (i % 2 ? TILE_W - l[0] : l[0]) + i * TILE_W - camX; if (lx < -80 || lx > VW + 80) continue;
    const fl = l[2] === '#ff8a30' ? 0.5 + 0.5 * Math.sin(BG.t * 13 + lx) * Math.sin(BG.t * 7.3 + i) : 0.5 + 0.5 * Math.sin(BG.t * 2.1 + l[0]);
    const r = 26 + fl * 6; const gr = g.createRadialGradient(lx, l[1], 0, lx, l[1], r); gr.addColorStop(0, l[2]); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.globalAlpha = 0.08 + fl * 0.1; g.fillStyle = gr; g.fillRect(lx - r, l[1] - r, r * 2, r * 2);
    /* light pool on the floor */
    if (l[1] > 90) { g.globalAlpha = 0.07 + fl * 0.05; g.save(); g.translate(lx, WALL_Y + 14); g.scale(1, 0.25); const gp = g.createRadialGradient(0, 0, 0, 0, 0, 70); gp.addColorStop(0, l[2]); gp.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gp; g.fillRect(-70, -70, 140, 140); g.restore(); }
  }
  g.restore();
};
BG.frontC = {};
BG.front = function (g, camX) {
  const n = BG.n; let c = BG.frontC[n];
  if (!c) { const im = ART.img['s' + n + '_l4']; c = document.createElement('canvas'); c.width = im.width; c.height = im.height; const x = c.getContext('2d'); x.drawImage(im, 0, 0);
    x.globalCompositeOperation = 'destination-out'; const gr = x.createLinearGradient(0, im.height * 0.8, 0, im.height); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,1)'); x.fillStyle = gr; x.fillRect(0, im.height * 0.8, im.width, im.height * 0.2);
    x.globalCompositeOperation = 'source-atop'; x.fillStyle = 'rgba(4,2,10,0.55)'; x.fillRect(0, 0, im.width, im.height); BG.frontC[n] = c; }
  drawTiled(g, c, camX, 1.35, 0, TILE_W, VIEW_H, 0.9, 2);
};
BG.menu = function (g, n, t, pan) {
  pan = pan || 0;
  drawTiled(g, ART.img['s' + n + '_l1'], pan, 0.15, 0, TILE_W, VIEW_H);
  drawTiled(g, ART.img['s' + n + '_l2'], pan, 0.4, 0, TILE_W, VIEW_H);
};
BG.atmos = function (g, t, dt) {
  const fx = LOOK[BG.n].fx;
  if (fx === 'rain') {
    g.fillStyle = 'rgba(170,200,255,0.35)';
    for (let i = 0; i < 110; i++) { const x = ((i * 53.7 + t * 50) % (VW + 40)) - 20, y = ((i * 31.3 + t * 460) % (VIEW_H + 30)) - 20; g.fillRect(x, y, 0.5, 5); }
    g.fillStyle = 'rgba(190,210,255,0.5)';
    for (let i = 0; i < 18; i++) { const ph = (t * 3 + i * 0.37) % 1; if (ph > 0.25) continue; const x = (i * 97.1 + Math.floor(t * 3 + i * 0.37) * 41) % VW, y = LANE_T - 8 + ((i * 37) % (LANE_B - LANE_T + 8)); const r = 1 + ph * 10; g.fillRect(x - r, y, 1, 0.5); g.fillRect(x + r, y, 1, 0.5); }
  } else if (fx === 'embers' || fx === 'dust' || fx === 'spores') {
    const col = fx === 'embers' ? '#ffa040' : fx === 'dust' ? 'rgba(255,220,170,0.6)' : '#b8ff60';
    g.fillStyle = col;
    for (let i = 0; i < 40; i++) { const sp = fx === 'embers' ? 1 : -0.3; const x = (i * 71.3 + Math.sin(t * 0.7 + i) * 20 + t * 8) % VW, y = (VIEW_H - ((i * 43.7 + t * 18 * sp * (0.5 + (i % 5) / 5)) % VIEW_H) + VIEW_H) % VIEW_H; g.globalAlpha = 0.35 + 0.35 * Math.sin(t * 3 + i); g.fillRect(x, y, i % 3 ? 0.5 : 1, i % 3 ? 0.5 : 1); }
    g.globalAlpha = 1;
  } else if (fx === 'drips') {
    g.fillStyle = 'rgba(160,255,230,0.6)';
    for (let i = 0; i < 12; i++) { const ph = (t * 0.6 + i * 0.41) % 1; const x = (i * 131.7) % VW; g.fillRect(x, ph * 200, 0.5, 3); if (ph > 0.95) { g.fillRect(x - 3, 200, 6, 0.5); } }
  }
  /* low ground mist */
  const L = LOOK[BG.n]; g.save(); const gr = g.createLinearGradient(0, WALL_Y - 10, 0, VIEW_H); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.35, L.fog); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, WALL_Y - 10, VW, VIEW_H - WALL_Y + 10); g.restore();
  /* vignette */
  const v = g.createRadialGradient(VW / 2, VIEW_H / 2, VIEW_H * 0.35, VW / 2, VIEW_H / 2, VIEW_H * 0.95); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.45)'); g.fillStyle = v; g.fillRect(0, 0, VW, VIEW_H);
};
ART.item = function (g, name, x, y, o) {
  const m = window.ITEMS[name]; if (!m) return; o = o || {}; const s = (o.sc || 1) * 0.5;
  g.save(); g.translate(half(x), half(y)); if (o.rot) g.rotate(o.rot); if (o.alpha != null) g.globalAlpha = o.alpha; if (o.face < 0) g.scale(-1, 1);
  const ax = o.center ? m[2] / 2 : m[2] / 2, ay = o.center ? m[3] / 2 : m[3];
  g.drawImage(ART.img.items, m[0], m[1], m[2], m[3], -ax * s, -ay * s, m[2] * s, m[3] * s); g.restore();
};
