'use strict';
/* ===== MAIN LOOP: update scene -> draw on pixel buffer -> nearest-neighbour upscale -> HD overlays ===== */
let lastT = 0;
function frame(t) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (t - lastT) / 1000 || 0.016); lastT = t;
  bg.setTransform(2, 0, 0, 2, 0, 0); bg.imageSmoothingEnabled = false; bg.globalAlpha = 1; bg.globalCompositeOperation = 'source-over';
  bg.save(); bg.beginPath(); bg.rect(0, 0, VW, VH); bg.clip();
  const s = Scene.cur;
  window.__inFrameDraw = true;
  if (s) { try { s.update && s.update(dt); s.draw && s.draw(bg); } catch (e) { console.error(e); window.__err = (window.__err || []).slice(-19).concat(String(e && e.stack || e)); } }
  window.__inFrameDraw = false;
  if (Scene.fade > 0) { bg.fillStyle = 'rgba(0,0,0,' + Scene.fade + ')'; bg.fillRect(0, 0, VW, VH); Scene.fade = Math.max(0, Scene.fade - dt * 4); }
  bg.restore();
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.imageSmoothingEnabled = false; ctx.fillStyle = '#000'; ctx.fillRect(0, 0, cv.width, cv.height);
  ctx.imageSmoothingEnabled = false; ctx.drawImage(BUF, 0, 0, VW * 2, VH * 2, OX, OY, Math.round(VW * SCALE), Math.round(VH * SCALE));
  /* Native Full-HD UI overlays (Touch Controls, Pause Menu, Tutorial & K.O. Banner) */
  try {
    if (window.ControlsUI && ControlsUI.drawHD) ControlsUI.drawHD(ctx);
    if (window.PauseUI && PauseUI.drawOverlaysHD) PauseUI.drawOverlaysHD(ctx);
    if (Scene.name === 'play' && Scenes.play && Scenes.play.menu && window.PauseUI && PauseUI.drawHD) PauseUI.drawHD(ctx);
  } catch (e) { console.error(e); }
}
window.androidBack = function () {
  const n = Scene.name;
  if (n === 'controls' && window.ControlsUI) { ControlsUI.close(false); return 'ok'; }
  if (n === 'confirmReset') { Scene.go('title'); return 'ok'; }
  if (n === 'play') { if (G && (G.over > 0 || G.clearT > 0)) return 'ok'; Scenes.play.onKey('pause'); return 'ok'; }
  if (n === 'title') { if (Scenes.title.opts) { Scenes.title.opts = false; return 'ok'; } return 'exit'; }
  if (n === 'stages') { Scene.go('title'); return 'ok'; }
  if (n === 'select') { Scene.go(Scenes.select.o && Scenes.select.o.mode ? 'lair' : 'stages'); return 'ok'; }
  if (n === 'prep') return 'ok';
  if (n === 'clear' || n === 'load') return 'ok';
  Scene.go('title'); return 'ok';
};
window.addEventListener('error', e => { window.__err = (window.__err || []).slice(-19).concat(e.message); });
/* English is the main language. The 8.2 build briefly defaulted to Portuguese;
   migrate that unchosen default once, preserving explicit language selections. */
/* v8: Lupus is always the playable lead; the old choice becomes the partner */
if (SAVE.hero !== 'lupus') { if (SAVE.ally === 'lupus' || !SAVE.ally) SAVE.ally = SAVE.hero; SAVE.hero = 'lupus'; } if (SAVE.ally === 'lupus' || !HERO[SAVE.ally]) SAVE.ally = 'vespera'; if (SAVE.vib == null) SAVE.vib = true;
if (!SAVE.langV9) {
  if (SAVE.langSet !== true && (!SAVE.lang || SAVE.lang === 'pt')) SAVE.lang = 'en';
  SAVE.langV5 = true; SAVE.langV9 = true; saveGame();
}
if (!I18N[SAVE.lang]) { SAVE.lang = 'en'; saveGame(); }
applyLang();
document.documentElement.lang = SAVE.lang === 'pt' ? 'pt-BR' : SAVE.lang;
const startGame = () => { Scene.go('load'); requestAnimationFrame(frame); ART.load(() => { Scenes.load.ready = true; COMIC.load(); }); };
if (document.fonts && document.fonts.ready) document.fonts.ready.then(startGame); else startGame();
