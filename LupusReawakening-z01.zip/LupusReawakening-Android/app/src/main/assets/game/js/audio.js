'use strict';
/* =====================================================================
   AUDIO v7 — real soundtrack (assets/music/*.ogg) and character voices
   (assets/voice/*.ogg). If a track cannot play, the procedural composer
   in core.js takes over, so the game is never silent.
   ===================================================================== */
const MUSIC_BY_IDX = ['stage1', 'stage2', 'stage3', 'stage4', 'stage5', 'title'];
const MUS = { cur: null, base: null, el: {}, failed: {}, pend: null, fading: [] };
const _procStart = window.musicStart, _procStop = window.musicStop;
const musVol = () => SAVE.music ? 0.6 * (MUS.dyn || 1) : 0;
const musName = i => typeof i === 'number' ? (MUSIC_BY_IDX[i] || 'title') : (i || 'title');
const procIdx = n => { const m = /^stage(\d+)$/.exec(n); return m ? (+m[1] - 1) % 5 : n === 'title' ? 5 : 4; };
var musEl = function (n) {
  let a = MUS.el[n]; if (a) return a;
  a = new Audio('assets/music/' + n + '.ogg'); a.preload = 'auto'; a.loop = !/^(victory|gameover)$/.test(n);
  a.addEventListener('error', () => { MUS.failed[n] = true; if (MUS.cur === n) { MUS.cur = null; _procStart(procIdx(n)); } });
  MUS.el[n] = a; return a;
};
function musPlay(n) {
  const a = musEl(n);
  for (const k in MUS.el) if (k !== n && !MUS.el[k].paused) fadeOut(MUS.el[k]);
  MUS.fading = MUS.fading.filter(x => x !== a);
  try { a.currentTime = 0; } catch (e) { }
  a.volume = 0; const p = a.play(); MUS.cur = n;
  if (p && p.catch) p.catch(() => { MUS.pend = n; });
  fadeIn(a);
}
function fadeIn(a) { const tgt = musVol(); let v = 0; const id = setInterval(() => { v = Math.min(tgt, v + 0.06); try { a.volume = v; } catch (e) { } if (v >= tgt || MUS.fading.includes(a)) clearInterval(id); }, 50); }
function fadeOut(a) { MUS.fading.push(a); const id = setInterval(() => { const v = Math.max(0, a.volume - 0.08); try { a.volume = v; } catch (e) { } if (v <= 0) { clearInterval(id); a.pause(); MUS.fading = MUS.fading.filter(x => x !== a); } }, 50); }
window.musicStart = function (i) {
  const n = musName(i); AU.wantMusic = i; MUS.base = n;
  if (MUS.failed[n]) { MUS.cur = null; for (const k in MUS.el) MUS.el[k].pause(); _procStart(procIdx(n)); return; }
  _procStop(); AU.wantMusic = i;
  if (MUS.cur === n && !musEl(n).paused) return;
  musPlay(n);
};
window.musicStop = function () { _procStop(); MUS.base = null; MUS.cur = null; for (const k in MUS.el) if (!MUS.el[k].paused) fadeOut(MUS.el[k]); };
const _setOpts = window.setAudioOpts;
window.setAudioOpts = function () { _setOpts(); for (const k in MUS.el) { const a = MUS.el[k]; if (!a.paused && !MUS.fading.includes(a)) a.volume = musVol(); } };
/* autoplay may be blocked until the first touch (browsers); the APK allows it */
const resumeMus = () => { if (MUS.pend) { const n = MUS.pend; MUS.pend = null; if (MUS.base === n || MUS.cur === n) musPlay(n); } };
['pointerdown', 'keydown'].forEach(ev => document.addEventListener(ev, resumeMus, true));
document.addEventListener('visibilitychange', () => { const a = MUS.cur && MUS.el[MUS.cur]; if (!a) return; if (document.hidden) a.pause(); else if (MUS.base) { const p = a.play(); if (p && p.catch) p.catch(() => { MUS.pend = MUS.cur; }); } });
/* in-game: boss / endless / rush tracks take over automatically */
setInterval(() => {
  if (!MUS.base || Scene.name !== 'play' || typeof G === 'undefined' || !G) return;
  let want = MUS.base;
  if (G.mode === 'endless') want = G.boss && !G.boss.dead ? 'boss' : 'endless';
  else if (G.mode === 'rush') want = 'boss';
  else if (MUS.lock) want = MUS.lock;
  else if (G.boss && !G.boss.dead && G.boss.bossIn < 1.5 && !G.boss.fleeing) want = G.boss.def.music || 'boss';
  if (want !== MUS.cur && !MUS.failed[want] && G.over <= 0 && !G.clearT) musPlay(want);
}, 300);

/* ---------- music that follows the story ----------
   comic pages carry a mood; each mood has its own cue (assets/music/cue_*.ogg, Audio Pack 4).
   Until a cue exists, the closest track already in the game plays instead. */
const MOOD_FALLBACK = { cue_1944: 'stage5', cue_tension: 'boss', cue_villain: 'finalboss', cue_sorrow: 'title', cue_heroic: 'stage1', cue_mystery: 'stage6', cue_dawn: 'title', cue_betrayal: 'boss' };
function musicMood(m) { if (!m) return; const n = MUS.failed[m] ? MOOD_FALLBACK[m] || 'title' : m; musicStart(n); }
const _musEl0 = musEl;
musEl = function (n) { const fresh = !MUS.el[n]; const a = _musEl0(n); if (fresh && MOOD_FALLBACK[n]) a.addEventListener('error', () => { if (MUS.base === n) musicStart(MOOD_FALLBACK[n]); }); return a; };
/* duck the music while a line of dialogue appears */
function musDuck(k, t) { MUS.duck = k; MUS.duckT = t || 1.2; }
setInterval(() => {
  let dyn = 1;
  if (MUS.duckT > 0) { MUS.duckT -= 0.1; dyn = MUS.duck; }
  if (Scene.name === 'play' && typeof G !== 'undefined' && G && !G.mode) dyn *= (G.locked || (G.boss && !G.boss.dead)) ? 1 : 0.62;
  MUS.dyn = MUS.dyn == null ? dyn : MUS.dyn + (dyn - MUS.dyn) * 0.25;
  const a = MUS.cur && MUS.el[MUS.cur]; if (a && !a.paused && !MUS.fading.includes(a)) try { a.volume = Math.max(0, Math.min(1, musVol())); } catch (e) { }
}, 100);
/* in-game cues: a stinger when a fight starts and when a boss appears, a heartbeat when the hero is about to fall */
const GAMECUE = { locked: false, boss: null, hb: 0 };
setInterval(() => {
  if (Scene.name !== 'play' || typeof G === 'undefined' || !G) { GAMECUE.locked = false; GAMECUE.boss = null; return; }
  if (G.locked && !GAMECUE.locked && !G.bossPending && !G.boss) sfx('sting');
  if (G.boss && GAMECUE.boss !== G.boss) sfx('stingBoss');
  GAMECUE.locked = G.locked; GAMECUE.boss = G.boss;
  const p = G.player; GAMECUE.hb -= 0.2; if (p && !p.dead && p.hp < p.maxhp * 0.25 && GAMECUE.hb <= 0) { sfx('heart'); GAMECUE.hb = 0.9; }
}, 200);

/* ---------- voices ---------- */
const VOX = { pool: {}, last: {}, ok: {} };
function voice(n, gap) {
  if (!SAVE.sfx || VOX.ok[n] === false) return;
  const now = performance.now(), who = n.split('_')[0];
  if (now - (VOX.last[who] || -1e9) < (gap || 900)) return; VOX.last[who] = now;
  let a = VOX.pool[n];
  if (!a) { a = new Audio('assets/voice/' + n + '.ogg'); a.addEventListener('error', () => { VOX.ok[n] = false; }); VOX.pool[n] = a; }
  try { a.currentTime = 0; a.volume = 0.9; const p = a.play(); if (p && p.catch) p.catch(() => { }); } catch (e) { }
}
const VOX_HEROES = ['lupus', 'vespera', 'triton', 'malakor', 'echo', 'brann'];
/* the voice set a hero uses right now: Lupus 1944 in the prologue, Fenrir in the last fight */
const vid = h => h.id !== 'lupus' ? h.id : h.form === 'x' ? 'fenrir' : (h.form === 'h' && G && G.st && G.st.l44 && !G.mode) ? 'lupus44' : 'lupus';
const vline = (h, line) => { const v = vid(h); if (v === 'fenrir') line = ({ atk1: 'atk', atk2: 'atk', tagin: 'transform', assist: 'atk', ko: 'hurt' })[line] || line; return v + '_' + line; };
const BOSS_DEFEAT = { construct: 'construct_ko', levgiant: 'leviathan_defeat', voss_r: 'voss_defeat', kane2: 'kane_defeat', kreutzw: 'kreutz_defeat', pack: 'beast_defeat', finalwolf: 'firstwolf_defeat', kreutz44: '' };
const wrap = (name, after) => { const f = window[name]; if (typeof f !== 'function') return; window[name] = function () { const r = f.apply(this, arguments); try { after.apply(this, [r].concat([].slice.call(arguments))); } catch (e) { } return r; }; };
wrap('startAtk', (r, h) => { if (h && h.kind === 'hero' && h.idx === 3 && Math.random() < 0.55) voice(vline(h, 'atk' + (Math.random() < 0.5 ? 1 : 2)), 1400); else if (h && h.kind === 'hero' && h.idx === 1 && Math.random() < 0.12) voice(vline(h, 'atk1'), 2200); });
wrap('startSpec', (r, h) => { if (h && h.kind === 'hero' && !h.assist && !(G && G.superFx)) voice(vline(h, 'special'), 300); });
wrap('startXform', (r, h, to) => { if (h && to !== 'h' && to !== 'x') { voice('lupus_transform', 300); if (h.isPlayer && typeof playSting === 'function') playSting('sting_transform'); } });
wrap('tagSwap', () => { const p = G && G.player; if (p) voice(vline(p, 'tagin'), 300); });
wrap('callAssist', () => { const a = G && G.heroes.find(h => h.assist); if (a) voice(a.id + '_assist', 300); });
wrap('startSuper', () => { if (G && G.team && G.team.some(h => h.id === 'lupus')) setTimeout(() => voice('lupus_super', 0), 900); });
wrap('hurt', (r, att, tg, dmg) => { if (r && tg && tg.kind === 'hero' && !tg.dead && dmg > 30) voice(vline(tg, 'hurt'), 2500); });
wrap('kill', (r, f) => { if (!f || !f.dead) return; if (f.kind === 'hero') voice(vline(f, 'ko'), 200); else if (f.kind === 'boss' && !f.mini && G.mode !== 'endless') { const n = BOSS_DEFEAT[f.type] != null ? BOSS_DEFEAT[f.type] : f.type + '_defeat'; if (n) { VOX.last[n.split('_')[0]] = 0; voice(n, 0); } } });
