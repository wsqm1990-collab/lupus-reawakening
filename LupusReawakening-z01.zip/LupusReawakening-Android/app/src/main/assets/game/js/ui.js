'use strict';
/* =====================================================================
   UI + SCENES + ENTITY RENDERING (world space 270 tall, buffer 2x)
   ===================================================================== */
const COLR = { red: '#ff2a40', cyan: '#3af0ff', lime: '#a7ff1a', gold: '#ffb02a', pink: '#ff3ad0', white: '#f2eef8', gray: '#9a94ac', dark: '#0a0612' };
function btn(id, x, y, w, h, label, col) { return { id, x: Math.round(x), y: Math.round(y), w, h, label, col: col || COLR.red }; }
function drawBtn(g, b, hot) { PIX.panel(g, b.x, b.y, b.w, b.h, { edge: b.col, bg: hot ? 'rgba(40,10,24,0.92)' : 'rgba(10,6,18,0.86)' }); PIX.text(g, b.label, b.x + b.w / 2, b.y + Math.round(b.h / 2) - 3, { col: COLR.white, align: 'c', s: b.s || 1 }); }
const hitB = (list, x, y) => list.find(b => x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h);
function dim(g, a) { g.fillStyle = 'rgba(6,3,12,' + a + ')'; g.fillRect(0, 0, VW, VH); }
function pixCircle(g, cx, cy, r) { for (let yy = -r; yy <= r; yy++) { const w = Math.floor(Math.sqrt(r * r - yy * yy)); g.fillRect(cx - w, cy + yy, w * 2 + 1, 1); } }
const ROSTER = ['lupus', 'vespera', 'triton', 'malakor', 'echo', 'brann'];
const ROSTER_KEY = { lupus: 'lupus_h', vespera: 'vespera', triton: 'triton', malakor: 'malakor', echo: 'echo', brann: 'brann' };
const heroOpen = id => !HERO[id].act || SAVE.unlocked > ACT2;
const FACE_ALIAS = { levgiant: 'leviathan', kane2: 'kane', voss_r: 'voss', kreutzw: 'kreutz', pack: 'beast', finalwolf: 'firstwolf' };
function faceOf(key) { key = FACE_ALIAS[key] || key; return 'face_' + (window.ITEMS['face_' + key] ? key : 'lupus_h'); }
function drawFace(g, key, x, y, size) { const m = window.ITEMS[faceOf(key)]; g.save(); g.imageSmoothingEnabled = true; g.drawImage(ART.img.items, m[0], m[1], m[2], m[3], x, y, size, size); g.restore(); }

/* ---------------- animation selection ---------------- */
const IMPACT = { atk1: 2, atk2: 2, atk3: 3, air: 1, spec: 3 };
/* 9.4: new attack sheets name their own striking frame */
function impactOf(key, an) { const k2 = ART.extKey(key, an), B = k2 && window.ATLAS[k2]; return B && B.imp && B.imp[an] != null ? B.imp[an] : IMPACT[an]; }
function phased(n, p, hitP, imp) { return p < hitP ? Math.min(imp - 1, Math.floor(p / hitP * imp)) : Math.min(n - 1, imp + Math.floor((p - hitP) / (1 - hitP) * (n - imp))); }
function track(e, tag) { if (e._tag !== tag) { e._tag = tag; e._t0 = G ? G.time : 0; } return (G ? G.time : 0) - e._t0; }
function entFrame(e) {
  if (e.kind === 'prop') return null;
  const key = e.kind === 'hero' ? heroKey(e) : e.key;
  const n = an => ART.frameCount(key, an); const T = G.time;
  if (e.kind === 'hero') {
    switch (e.st) {
      case 'walk': return ['walk', Math.floor(e.wph || 0)];
      case 'tagin': return ['fall', 1];
      case 'xform': return e.xswap ? ['win', Math.floor((e.xt - e.xsw) * 9), false] : ['hurt', 1, false];
      case 'air': return [e.vz > 0 ? 'rise' : 'fall', e.vz > 0 ? (e.vz > 150 ? 0 : 1) : (e.vz > -150 ? 0 : 1)];
      case 'atk': { const an = e.air ? 'air' : 'atk' + e.idx; const p = 1 - e.atkT / e.atkDur; return [an, phased(n(an), p, 0.4, impactOf(key, an)), false]; }
      case 'spec': return ['spec', phased(n('spec'), e.t / e.specDur, 0.45, IMPACT.spec), false];
      case 'dash': return ['run', Math.floor(e.ct * 16)];
      case 'guard': return ['guard', 0, false];
      case 'hurt': return ['hurt', Math.min(1, Math.floor(e.ct * 12)), false];
      case 'knock': return ['knock', 0];
      case 'down': return ['down', 0];
      case 'getup': return ['getup', Math.floor(e.ct * 7), false];
      case 'dead': return [e.z > 1 ? 'knock' : 'down', 0];
      default: if (e.landT > 0) return ['getup', 1, false]; if (e.taunt) return ['win', Math.floor(T * 7)]; return ['idle', Math.floor(T * 7 + e.x * 0.01)];
    }
  }
  if (e.kind === 'boss') {
    if (e.dead) return ['dead', Math.floor(track(e, 'dead') * 6), false];
    if (e.st === 'hurt') return ['hurt', Math.floor(track(e, 'hurt') * 10), false];
    if (e.bossIn > 0) return ['walk', Math.floor(T * 9)];
    const P = e.pat, f = e.frame; const el = track(e, f + (P ? P.n + P.ps + P.hits : ''));
    const atkAn = !P ? 'atk1' : ({ slash: 'atk1', charge: 'atk2', guard: 'atk2', wave: 'spec', slam: (e.key === 'nacht_big' ? 'atk1' : e.key === 'prime' ? 'spec' : 'atk2'), roar: 'spec', shoot: (e.def.shootAn || 'atk1'), summon: 'spec', blink: 'atk2', combo: 'atk1', leap: 'atk2', volley: (e.def.shootAn || 'spec'), sweep: 'atk2', grab: 'atk2' })[P.n] || 'atk1';
    if (f === 'run') return ['run', Math.floor(T * 12)];
    if (f === 'walk') return ['walk', Math.floor(T * 9)];
    if (f === 'wind') return [atkAn, Math.min(2, Math.floor(el * 7)), false];
    if (f === 'atk') return [atkAn, Math.min(5, 3 + Math.floor(el * 10)), false];
    if (f === 'spec') return [atkAn === 'atk1' && P && P.n !== 'shoot' && P.n !== 'combo' ? 'spec' : atkAn, Math.min(5, Math.floor(el * 8)), false];
    if (f === 'block') return ['atk2', 1, false];
    return ['idle', Math.floor(T * 7)];
  }
  /* regular enemy */
  if (e.dead) return [e.z > 1 ? 'knock' : 'down', 0];
  if (e.arrive) return ['walk', Math.floor(T * 10 + e.x * 0.05)];
  switch (e.st) { case 'hurt': return ['hurt', Math.min(1, Math.floor(e.ct * 12)), false]; case 'knock': return ['knock', 0]; case 'down': return ['down', 0]; case 'getup': return ['getup', Math.floor(e.ct * 7), false]; }
  const el = track(e, 'ai' + e.ai);
  if (e.ai === 'wind') { const dur = e.def.wind || (e.def.ai === 'ranged' ? 0.5 : e.def.ai === 'beam' ? 0.75 : 0.35); return ['atk', Math.min(1, Math.floor(el / dur * 2)), false]; }
  if (e.ai === 'hit') return ['atk', Math.min(4, 2 + Math.floor(el * 9)), false];
  if (e.ai === 'rec' && el < 0.12) return ['atk', 4, false];
  return [e.moving ? 'walk' : 'idle', Math.floor(T * (e.moving ? 10 : 6) + e.x * 0.05)];
}
function depthScale(y) { return 0.93 + 0.11 * (y - LANE_T) / (LANE_B - LANE_T); }
function entHeight(e) { const k = e.kind === 'hero' ? heroKey(e) : e.key; return (window.ATLAS[k] || { h: 70 }).h; }
function frameOf(e) {
  const r = entFrame(e); if (!r) return null; e._an = r[0];
  const key = e.kind === 'hero' ? heroKey(e) : e.key;
  return ART.frame(key, r[0], r[1], r[2]);
}
/* draw an entity with lights, crossfade and afterimages */
function drawEnt(g, e, cam) {
  if (window.Super90 && Super90.drawActor && Super90.drawActor(g, e, cam)) return null;
  if (e.kind === 'obj') { drawObj(g, e, cam); return null; }
  if (e.giant) { drawGiant(g, e, cam); return null; }
  if (e.kind === 'prop') { const o = { sc: 1, alpha: 1 }; if (e.flash > 0) o.alpha = 0.75 + 0.25 * Math.cos(e.flash * 30); ART.item(g, e.key, e.x - cam, e.y + 1, o); return null; }
  const fr = frameOf(e); if (!fr) return null;
  const hov = e.def && e.def.fly && !e.dead && e.st !== 'down' ? e.def.fly + Math.sin(G.time * 6 + e.x) * 2 : 0;
  const x = e.x - cam, y = e.y - e.z - hov, sc = depthScale(e.y);
  let alpha = null;
  /* 9.4: heroes stay solid while invulnerable (no see-through blinking) */
  if (e.dead) alpha = bossKoActive() && G.koCine.boss === e ? 1 : e.kind === 'boss' ? Math.max(0, 1 - Math.max(0, e.deadT - 2)) : (e.deadT > 0.8 ? (Math.floor(e.deadT * 16) % 2 ? 0.25 : 0.9) : 1);
  if (e.fade != null && e.fade < 1) alpha = Math.max(0.05, e.fade);
  { const M = G.mech && MECH[G.mech]; const ma = M && M.entAlpha ? M.entAlpha(e) : null; if (ma != null) alpha = alpha == null ? ma : Math.min(alpha, ma); }
  let tint = null, tintA = 0.4;
  if (e.def && e.def.tint) { tint = e.def.tint; tintA = e.def.tintA || 0.3; } if (e.tintTwin) { tint = '#5a7aff'; tintA = 0.22; } if (e.packWolf) { tint = '#ffb020'; tintA = 0.3; }
  /* 9.4: a wind-up flashes once (plus the warning icon above the head) instead of strobing red */
  const warnArt = !!(window.FX94 && FX94.ready);   /* with the warning-icon art the body keeps its colours */
  if (!warnArt && e.kind === 'enemy' && e.ai === 'wind' && e._tag === 'aiwind') { const el = G.time - e._t0; if (el < 0.14) { tint = '#ff1a30'; tintA = 0.4 * (1 - el / 0.14); } }
  if (e.kind === 'boss' && e.windup) { tint = '#ff1a30'; tintA = warnArt ? 0.06 : 0.1 + 0.06 * Math.sin(G.time * 9); }
  let mxsc = 1; if (e.kind === 'boss' && e.morph > 0) { const k = 1 - e.morph / e.morphDur; tint = e.type === 'nacht' ? '#a7ff1a' : e.def.phases ? '#ffb020' : '#ff2040'; tintA = 0.25 + 0.3 * Math.abs(Math.sin(G.time * 18)); mxsc = 1 + 0.08 * Math.sin(k * Math.PI) + (Math.random() - 0.5) * 0.02; RD.glow(g, x, y - 50, 60 + 50 * k, tint, 0.35); }
  if (e.kind === 'boss' && e.guard) { tint = '#6aa0ff'; tintA = 0.3; }
  if (e.kind === 'boss' && e.p2 && !tint) { tint = '#ff0030'; tintA = 0.1 + 0.05 * Math.sin(G.time * 6); }
  if (e.kind === 'hero' && e.st === 'spec') { tint = '#ffffff'; tintA = 0.12 * Math.max(0, Math.sin(e.t / e.specDur * Math.PI)); }
  let xsc = mxsc * (e.big || 1), jit = 0;
  if (e.elite && !e.dead) { xsc = 1.14; RD.glow(g, x, y - 40, 46, '#ffc030', 0.08 + 0.04 * Math.sin(G.time * 4)); if (!tint) { tint = '#ffc030'; tintA = 0.1 + 0.04 * Math.sin(G.time * 4); } }
  if (e.kind === 'hero' && e.st === 'xform') {
    const xc = e.xto === 'a' ? '#ff1030' : e.xto === 'f' ? '#ff9a30' : '#9ab4ff';
    if (!e.xswap) { const k = e.xt / (e.xdur * 0.5); tint = xc; tintA = 0.15 + 0.35 * k * (0.5 + 0.5 * Math.sin(G.time * 45)); jit = (Math.random() - 0.5) * 2 * k; xsc = 1 + 0.04 * k; RD.glow(g, x, y - 45, 40 + 40 * k, xc, 0.25 + 0.35 * k); }
    else { const k = Math.min(1, (e.xt - e.xsw) / 0.3); xsc = 1.18 - 0.18 * k; if (k < 1) { tint = '#ffffff'; tintA = 0.4 * (1 - k); } RD.glow(g, x, y - 50, 70 * (1 - k * 0.5), xc, 0.5 * (1 - k * 0.6)); }
  }
  /* afterimages */
  /* 9.4: afterimages only for real bursts of speed (dash, tag-in, Ascended/Fenrir strikes, boss charges) */
  const trailOn = (e.kind === 'hero' && (e.st === 'dash' || e.st === 'tagin' || (e.id === 'lupus' && (e.form === 'a' || e.form === 'x') && e.st === 'atk'))) || (e.kind === 'boss' && e.charging);
  e._trail = e._trail || [];
  if (trailOn && (!e._trailT || G.time - e._trailT > 0.035)) { e._trailT = G.time; e._trail.push({ fr, x: e.x, y, face: e.face, t: G.time }); }
  e._trail = e._trail.filter(q => G.time - q.t < 0.22);
  const tcol = e.kind !== 'hero' ? '#ff2040' : e.id === 'lupus' ? (e.form === 'a' ? '#ff1030' : e.form === 'x' ? '#ffe080' : '#ff6040') : HERO[e.id].color;
  for (const q of e._trail) { const a = 0.26 * (1 - (G.time - q.t) / 0.22); g.save(); g.globalAlpha = a; g.globalCompositeOperation = 'lighter'; ART.draw(g, q.fr, q.x - cam, q.y, { face: q.face, sc, tint: tcol, tintA: 1, alpha: a }); g.restore(); }
  /* 9.4: pixel frames switch cleanly, with no dissolve (it doubled every pose) */
  e._lastAn = e._an; e._lastFr = fr;
  const smooth = Math.abs(sc - 1) > 0.01; g.imageSmoothingEnabled = smooth;
  const rims = ART.rimsAt(e.x, e.y, entHeight(e), G.time);
  /* 9.4: impact squash and a shudder while the hit-pause holds (9.5: no code-made tumble);
     the hit flash is a crisp, nearly solid blink (3 frames) instead of a pale see-through fade */
  const hitAge = e._hitT != null ? G.time - e._hitT : 9, squash = hitAge < 0.09 ? 1 - hitAge / 0.09 : 0;
  if (G.hitstop > 0 && hitAge < 0.02) jit += (Math.random() - 0.5) * 3.2;
  ART.draw(g, fr, x + jit, y, { pal: e.kind === 'hero' ? ((SAVE.pal || {})[e.id] || 0) : 0, face: e.face, sc: sc * xsc, alpha, flash: e.flash > 0.75 ? 0.85 : 0, flashCol: e.team === 'p' ? '#ff8090' : '#ffffff', tint, tintA, rims, sx: (e.landT > 0 ? 1.04 : 1) * (1 + 0.07 * squash), sy: (e.landT > 0 ? 0.95 : 1) * (1 - 0.07 * squash) });
  g.imageSmoothingEnabled = false;
  if (e.kind === 'hero' && e.id === 'lupus' && e.form === 'a' && !e.dead) RD.glow(g, x, y - 46, 46, '#ff0a2a', 0.12 + 0.06 * Math.sin(G.time * 9));
  if (e.kind === 'hero' && e.id === 'lupus' && e.form === 'x' && !e.dead) RD.glow(g, x, y - 60, 70, '#ffd060', 0.22 + 0.1 * Math.sin(G.time * 7));
  if (e.shieldHP > 0 && window.drawShield92) drawShield92(g, e, x, y);
  return fr;
}

/* =========================== LOADING =========================== */
Scenes.load = {
  t: 0, ready: false,
  enter() { this.t = 0; },
  update(dt) { this.t += dt; if (this.ready && this.t > 0.4 && !this.went) { this.went = true; BG.set(1); Scene.go('studio'); } },
  draw(g) {
    g.fillStyle = '#07040d'; g.fillRect(0, 0, VW, VH);
    PIX.text(g, 'LUPUS', VW / 2, 92, { s: 5, align: 'c', grad: ['#ffffff', '#b8bccb', '#6a6e80', '#d8dce8'] });
    PIX.text(g, T('loading'), VW / 2, 160, { align: 'c', col: COLR.red });
    PIX.bar(g, VW / 2 - 70, 176, 140, 5, ART.total ? ART.loaded / ART.total : 0, COLR.red);
  }
};

/* =========================== STUDIO SPLASH (Neon Howl Games) =========================== */
const STUDIO_L = ['emblem', 'word', 'games'].reduce((o, k) => { const im = new Image(); im.src = 'assets/ui/studio_' + k + '.webp'; o[k] = im; return o; }, {});
const STUDIO_EMB = Array.from({ length: 40 }, (_, i) => [(i * 0.618034) % 1, (i * 0.7548777) % 1, 0.5 + (i % 4) / 4, i]);
/* animated Neon Howl Games ident: neon emblem ignites from the wolf's eye, the howl ripples out, the chrome wordmark slams in, GAMES types on, a light sweep, then fade */
Scenes.studio = {
  t: 0, END: 4.4,
  enter() { this.t = 0; this.done = false; this.howled = false; this.slam = false; },
  update(dt) {
    this.t += dt;
    if (!this.howled && this.t > 0.95) { this.howled = true; audioInit(); sfx('howl'); }
    if (!this.slam && this.t > 1.45) { this.slam = true; sfx('boom'); }
    if (this.t > this.END && !this.done) this.finish();
  },
  finish() { this.done = true; playCut('intro', () => Scene.go('title'), 5); },
  draw(g) {
    const t = this.t, L = STUDIO_L, ok = im => im.complete && im.width;
    g.fillStyle = '#000'; g.fillRect(0, 0, VW, VH);
    const fade = t > this.END - 0.6 ? Math.max(0, (this.END - t) / 0.6) : 1;
    const sz = Math.min(VH * 0.94, VW * 0.62), k = sz / 627, x0 = VW / 2 - sz / 2, y0 = (VH - sz) / 2 - 2;
    const P = (px, py) => [x0 + px * k, y0 + py * k];
    const [ex, ey] = P(322, 156), [mx, my] = P(440, 172);
    /* impact shake */
    const st = t - 1.45, shake = st > 0 && st < 0.3 ? (1 - st / 0.3) * 3 : 0;
    g.save(); g.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake); g.globalAlpha = fade; g.imageSmoothingEnabled = true;
    /* backdrop glow that breathes once lit */
    const lit = Math.min(1, Math.max(0, (t - 0.4) / 0.6));
    RD.glow(g, VW / 2, y0 + sz * 0.32, sz * 0.6, '#ff2a9d', 0.16 * lit * (0.85 + 0.15 * Math.sin(t * 3)));
    RD.glow(g, VW / 2 + sz * 0.12, y0 + sz * 0.3, sz * 0.35, '#3af0ff', 0.10 * lit);
    /* spark in the eye before ignition */
    if (t < 1.1) { const sp = Math.min(1, t / 0.35); RD.glow(g, ex, ey, 10 + 20 * sp, '#ff4ad0', 0.6 * sp); g.fillStyle = '#fff'; g.globalAlpha = fade * sp; g.fillRect(ex - 1, ey - 1, 2, 2); g.globalAlpha = fade; }
    /* emblem: radial ignition from the eye + neon flicker */
    if (ok(L.emblem) && t > 0.35) {
      const r = Math.min(1, (t - 0.35) / 0.7), fl = [0.42, 0.5, 0.56, 0.66, 0.72, 0.84];
      let on = fl.findIndex(x => x > t); on = t > 0.9 ? 1 : (on % 2 === 1 ? 0.25 : 1);
      if (t > 2 && Math.sin(t * 13) * Math.sin(t * 3.1) > 0.97) on = 0.55; /* occasional neon stutter */
      const br = 1 + 0.008 * Math.sin(t * 2.4);
      g.save(); g.beginPath(); g.arc(ex, ey, 6 + r * r * sz * 1.1, 0, 7); g.clip(); g.globalAlpha = fade * on;
      const w = 627 * k * br, h = 418 * k * br; g.drawImage(L.emblem, VW / 2 - w / 2, y0 + 418 * k / 2 - h / 2, w, h); g.restore();
      /* hot rim of the ignition front */
      if (r < 1) { g.save(); g.globalCompositeOperation = 'lighter'; g.strokeStyle = 'rgba(255,120,230,' + (0.7 * (1 - r)).toFixed(2) + ')'; g.lineWidth = 2; g.beginPath(); g.arc(ex, ey, 6 + r * r * sz * 1.1, 0, 7); g.stroke(); g.restore(); }
    }
    /* the howl: sound rings from the muzzle + eye flash */
    const ht = t - 0.95;
    if (ht > 0 && ht < 1.3) {
      g.save(); g.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 3; i++) { const q = ht - i * 0.18; if (q < 0 || q > 0.9) continue; const rr = 8 + q * 120, al = (1 - q / 0.9) * 0.55; g.strokeStyle = (i % 2 ? 'rgba(255,60,200,' : 'rgba(80,230,255,') + al.toFixed(2) + ')'; g.lineWidth = 2 - q; g.beginPath(); g.arc(mx, my, rr, -Math.PI * 0.62, Math.PI * 0.12); g.stroke(); }
      g.restore(); RD.glow(g, ex, ey, 26, '#ff3ad0', Math.max(0, 0.7 - ht));
    }
    /* wordmark slam */
    if (ok(L.word) && t > 1.25) {
      const q = Math.min(1, (t - 1.25) / 0.2), sc = 1 + (1 - q) * (1 - q) * 1.4, w = 627 * k * sc, h = 102 * k * sc, cy = y0 + (418 + 51) * k;
      g.globalAlpha = fade * q; g.drawImage(L.word, VW / 2 - w / 2, cy - h / 2, w, h); g.globalAlpha = fade;
      /* chromatic split right after impact */
      if (st > 0 && st < 0.4) { const d = (1 - st / 0.4) * 5; g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = fade * (1 - st / 0.4) * 0.6; g.drawImage(L.word, VW / 2 - w / 2 - d, cy - h / 2, w, h); g.drawImage(L.word, VW / 2 - w / 2 + d, cy - h / 2 + 1, w, h); g.restore(); }
      /* chrome light sweep (adds light only where the letters are) */
      const sw = (t - 2.25) / 0.55;
      if (sw > 0 && sw < 1) { g.save(); const sx = VW / 2 - w / 2 + sw * (w + 60) - 30; g.beginPath(); g.moveTo(sx, cy - h); g.lineTo(sx + 14, cy - h); g.lineTo(sx - 6, cy + h); g.lineTo(sx - 20, cy + h); g.clip(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = fade * 0.9; g.drawImage(L.word, VW / 2 - w / 2, cy - h / 2, w, h); g.drawImage(L.word, VW / 2 - w / 2, cy - h / 2, w, h); g.restore(); }
    }
    /* GAMES types on */
    if (ok(L.games) && t > 1.7) {
      const q = Math.min(1, (t - 1.7) / 0.45), w = 627 * k, h = 35 * k, gy = y0 + 520 * k;
      g.save(); g.beginPath(); g.rect(x0, gy - 4, w * (0.25 + 0.55 * q), h + 8); g.clip(); g.drawImage(L.games, x0, gy, w, h); g.restore();
      if (q < 1) { RD.glow(g, x0 + w * (0.25 + 0.55 * q), gy + h / 2, 8, '#3af0ff', 0.8); }
    }
    /* impact flash */
    if (st > 0 && st < 0.15) { g.fillStyle = 'rgba(255,255,255,' + (0.5 * (1 - st / 0.15)).toFixed(2) + ')'; g.fillRect(-10, -10, VW + 20, VH + 20); }
    /* neon embers drifting up */
    if (t > 1) for (const [x, o, sp, i] of STUDIO_EMB) { const q = (t * 0.12 * sp + o) % 1, a = Math.min(1, (t - 1) * 2) * (1 - q) * 0.8; g.fillStyle = (i % 2 ? 'rgba(255,70,210,' : 'rgba(90,235,255,') + a.toFixed(2) + ')'; g.fillRect(Math.round(VW / 2 + (x - 0.5) * sz * 1.4 + Math.sin(t + i) * 3), Math.round(VH - q * VH * 0.9), 1, 1); }
    g.restore(); g.imageSmoothingEnabled = false;
    if (!ok(L.emblem)) PIX.text(g, 'NEON HOWL GAMES', VW / 2, VH / 2, { s: 2, align: 'c', col: '#ff2a6d' });
    if (t > 2.4) { g.save(); g.globalAlpha = Math.min(1, (t - 2.4) * 2) * fade * 0.7; PIX.text(g, 'PRESENTS', VW / 2, VH - 13, { align: 'c', col: '#9a94ac', out: null }); g.restore(); }
  },
  onDown() { if (this.t > 0.4 && !this.done) this.finish(); },
  onKey(k) { if (k === 'ok' && !this.done) this.finish(); }
};

/* =========================== TITLE =========================== */
function drawLogo(g, cx, y, s) {
  s = s || 6;
  PIX.text(g, 'LUPUS', cx + 2, y + 3, { s, align: 'c', col: '#7a0012', out: '#0a0612' });
  PIX.text(g, 'LUPUS', cx, y, { s, align: 'c', grad: ['#ffffff', '#d4d8e4', '#8a8ea0', '#5a5e70', '#e8ecf4'], out: '#0a0612' });
  g.fillStyle = '#c8001e'; const w = PIX.textW('LUPUS', s); const x0 = cx - w / 2;
  for (let i = 0; i < 7; i++) { const dx = x0 + 6 + i * (w / 7) + (i * 13 % 7), len = 3 + (i * 7 % 9) + Math.sin(Date.now() / 600 + i) * 1.5; g.fillRect(Math.round(dx), y + 7 * s - 2, 2, len); }
  PIX.text(g, 'REAWAKENING', cx, y + 7 * s + 8, { s: 2, align: 'c', col: '#ff2a40', out: '#2a0008' });
}
/* small "stage" for menus: floor of a stage + characters with reflections */
function menuCast(g, cast, t, n, cam) {
  const look = LOOK[n]; ART.useLook(look);
  const list = cast.map(c => Object.assign({}, c)).sort((a, b) => a.y - b.y);
  for (const c of list) { const fr = ART.frame(c.k, c.an || 'idle', Math.floor(t * 7 + (c.o || 0)), c.loop); c.fr = fr; if (look.refl) ART.reflect(g, fr, c.x, c.y, 0, c.f, look.refl, t, look.water, depthScale(c.y)); }
  for (const c of list) ART.shadow(g, c.x, c.y + 1, 16 * (window.ATLAS[c.k].h / 80), 0.6);
  g.imageSmoothingEnabled = true;
  for (const c of list) ART.draw(g, c.fr, c.x, c.y, { face: c.f, sc: depthScale(c.y), rims: ART.rimsAt(c.x + cam, c.y, window.ATLAS[c.k].h, t) });
  g.imageSmoothingEnabled = false;
}
const TITLE_CAST = [['vespera', -96, 228, 1, 0], ['lupus_h', -16, 250, 1, 2], ['triton', 74, 238, -1, 1], ['malakor', 150, 226, -1, 3]];
/* title key art (Cosmic-Invasion poster style): Primordial Beast looming over a cracked lava planet, Outcasts left, the three Lupus forms right */
const TITLE_IMG = ['bg', 'left', 'right'].reduce((o, k) => { const im = new Image(); im.src = 'assets/ui/title_' + k + '.webp'; o[k] = im; return o; }, {});
const TITLE_STARS = Array.from({ length: 70 }, (_, i) => [(i * 0.618034) % 1, ((i * 0.7548777) % 1) * 0.7, 0.3 + (i * 7 % 10) / 14, i]);
const TITLE_EMB = Array.from({ length: 46 }, (_, i) => [(i * 0.618034) % 1, (i * 0.3819660 * 3) % 1, 0.6 + (i % 5) / 6, i]);
function drawTitleScene(g, t) {
  const cx = VW / 2, ok = im => im.complete && im.width, ia = Math.min(1, t / 1.1), ez = 1 - Math.pow(1 - ia, 3);
  g.fillStyle = '#16061e'; g.fillRect(0, 0, VW, VH);
  g.imageSmoothingEnabled = true;
  /* background plate: slow breathing zoom toward the Beast */
  if (ok(TITLE_IMG.bg)) { const z = 1.02 + 0.012 * Math.sin(t * 0.5), w = 624 * z, h = 270 * z; g.drawImage(TITLE_IMG.bg, cx - w / 2, (270 - h) * 0.3, w, h); }
  /* twinkling sparkles */
  for (const [x, y, b, i] of TITLE_STARS) { const tw = Math.max(0, Math.sin(t * (0.8 + i % 4 * 0.5) + i * 1.7)); if (tw < 0.2) continue; const px = Math.round(x * VW), py = Math.round(y * 190), a = (b * tw).toFixed(2); g.fillStyle = 'rgba(255,240,250,' + a + ')'; g.fillRect(px, py, 1, 1); if (i % 6 === 0) { const L = Math.round(2 + tw * 4); g.fillRect(px - L, py, L * 2 + 1, 1); g.fillRect(px, py - L, 1, L * 2 + 1); } }
  /* Beast aura pulse + glowing eyes */
  const hb = 0.5 + 0.5 * Math.sin(t * 2.2);
  RD.glow(g, cx, 92, 130, '#ff1040', 0.06 + 0.07 * hb);
  RD.glow(g, cx + 28, 34, 16, '#ff2a2a', 0.3 + 0.4 * hb);
  /* planet rim + lava heat */
  const PR = 750, pcy = 201 + PR;
  g.save(); g.globalCompositeOperation = 'lighter'; g.strokeStyle = 'rgba(255,150,190,' + (0.18 + 0.14 * Math.sin(t * 1.6)).toFixed(2) + ')'; g.lineWidth = 2; g.beginPath(); g.arc(cx, pcy, PR, Math.PI * 1.3, Math.PI * 1.7); g.stroke(); g.restore();
  for (const [dx, ph] of [[-230, 0], [-150, 2], [150, 1], [235, 3]]) RD.glow(g, cx + dx, 252, 40, '#ff6a10', 0.08 + 0.07 * Math.sin(t * 2.4 + ph));
  /* rising embers */
  for (const [x, o, sp, i] of TITLE_EMB) { const k = (t * 0.09 * sp + o) % 1, py = 268 - k * 150, px = Math.round(x * VW + Math.sin(t * 1.5 + i) * 4); g.fillStyle = i % 3 ? 'rgba(255,140,40,' + (1 - k).toFixed(2) + ')' : 'rgba(255,230,140,' + (1 - k).toFixed(2) + ')'; g.fillRect(px, Math.round(py), 1, i % 4 ? 1 : 2); }
  /* hero groups anchored to the screen edges, sliding in and floating */
  const gs = Math.min(1, VW / 600), gw = 210 * gs, gh = 270 * gs;
  if (ok(TITLE_IMG.left)) g.drawImage(TITLE_IMG.left, -gw * (1 - ez) * 1.1, VH - gh + Math.sin(t * 1.3) * 1.5, gw, gh);
  if (ok(TITLE_IMG.right)) g.drawImage(TITLE_IMG.right, VW - gw + gw * (1 - ez) * 1.1, VH - gh + Math.sin(t * 1.3 + 1.6) * 1.5, gw, gh);
  g.imageSmoothingEnabled = false;
  /* soft dark pool behind the menu for legibility */
  const my = (window.V95 && V95.titleLayout ? V95.titleLayout().menuY : 184) + 38, mg = g.createRadialGradient(cx, my, 10, cx, my, 130); mg.addColorStop(0, 'rgba(8,2,12,0.55)'); mg.addColorStop(1, 'rgba(8,2,12,0)'); g.fillStyle = mg; g.fillRect(cx - 140, my - 62, 280, VH - my + 62);
}
function drawTitleLogo(g, cx, y, t) {
  const s = 6, w = PIX.textW('LUPUS', s);
  RD.glow(g, cx, y + 22, w * 0.7, '#ff1030', 0.28);
  PIX.text(g, 'LUPUS', cx + 3, y + 4, { s, align: 'c', col: '#5a000e', out: '#000' });
  PIX.text(g, 'LUPUS', cx, y, { s, align: 'c', grad: ['#ffffff', '#e4e8f0', '#9aa0b4', '#5a5e70', '#f0f2f8'], out: '#0a0612' });
  /* three claw marks ripped through the logo */
  g.save(); g.globalCompositeOperation = 'source-over';
  for (let i = 0; i < 3; i++) { const x0 = cx + w * 0.30 + i * 8, y0 = y - 3; g.strokeStyle = '#0a0612'; g.lineWidth = 3.5; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x0 - 16, y0 + 48); g.stroke(); g.strokeStyle = '#ff2a40'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x0 - 16, y0 + 48); g.stroke(); g.strokeStyle = '#ffd0d6'; g.lineWidth = 0.6; g.beginPath(); g.moveTo(x0 - 3, y0 + 9); g.lineTo(x0 - 12, y0 + 36); g.stroke(); }
  const gl = (t * 0.6) % 3; if (gl < 1) { g.globalCompositeOperation = 'lighter'; g.globalAlpha = Math.sin(gl * Math.PI) * 0.6; g.fillStyle = '#ffffff'; g.beginPath(); const gx = cx - w / 2 + gl * w; g.moveTo(gx, y); g.lineTo(gx + 8, y); g.lineTo(gx - 6, y + 7 * s); g.lineTo(gx - 14, y + 7 * s); g.fill(); }
  g.restore();
  /* red slanted banner */
  const bw = PIX.textW('REAWAKENING', 2) + 26, by = y + 7 * s + 6;
  g.fillStyle = '#000'; g.beginPath(); g.moveTo(cx - bw / 2 + 4, by - 1); g.lineTo(cx + bw / 2 + 9, by - 1); g.lineTo(cx + bw / 2 - 4, by + 18); g.lineTo(cx - bw / 2 - 9, by + 18); g.fill();
  g.fillStyle = '#c4001e'; g.beginPath(); g.moveTo(cx - bw / 2 + 6, by + 1); g.lineTo(cx + bw / 2 + 6, by + 1); g.lineTo(cx + bw / 2 - 6, by + 16); g.lineTo(cx - bw / 2 - 6, by + 16); g.fill();
  g.fillStyle = '#ff4a60'; g.fillRect(cx - bw / 2 + 6, by + 1, bw, 1);
  PIX.text(g, 'REAWAKENING', cx, by + 3, { s: 2, align: 'c', col: '#ffffff', out: '#3a0008' });
}
Scenes.title = {
  t: 0, opts: false, btns: [], sel: 0, items: [],
  enter() { this.t = 0; this.opts = false; this.langPick = false; this.sel = 0; BG.set(1); musicStart(5); },
  layout() {
    this.btns = [];
    this.items = [['start', T('menuStart')], ['lair', T('lair')], ['diff', T('difficulty') + ':  < ' + T('d_' + (SAVE.diff || 'normal')) + ' >'], ['story', T('menuStory')], ['opt', T('options')]].map((it, i) => ({ id: it[0], label: it[1], x: VW / 2 - 110, y: (window.V95 && V95.titleLayout ? V95.titleLayout().menuY : 184) + i * 13, w: 220, h: 12 }));
    if (!this.opts) return;
    if (this.langPick) { const cols = 3, bw = 120, bh = 20, x0 = VW / 2 - (cols * bw + (cols - 1) * 8) / 2; LANGS.forEach((c, i) => { const b = btn('L_' + c, x0 + (i % cols) * (bw + 8), 52 + Math.floor(i / cols) * 28, bw, bh, I18N[c].native, c === SAVE.lang ? COLR.red : COLR.cyan); this.btns.push(b); }); this.btns.push(btn('closeL', VW / 2 - 60, 52 + 4 * 28 + 6, 120, 18, T('back'), COLR.gray)); }
    else { const L = [['lang', T('lang') + ': ' + I18N[SAVE.lang].native], ['music', T('music') + ': ' + (SAVE.music ? T('on') : T('off'))], ['sfx', T('sfx') + ': ' + (SAVE.sfx ? T('on') : T('off'))], ['vib', T('vibration') + ': ' + (SAVE.vib !== false ? T('on') : T('off'))], ['cauto', T('comicAuto') + ': ' + (SAVE.comicAuto ? T('on') : T('off'))], ['reset', T('newGame')], ['close', T('back')]]; L.forEach((l, i) => this.btns.push(btn(l[0], VW / 2 - 90, 64 + i * 22, 180, 18, l[1], l[0] === 'reset' ? COLR.gold : COLR.cyan))); }
  },
  update(dt) {
    this.t += dt; this.layout();
    if (!this.opts) { if (Inp.edge.u) { this.sel = (this.sel + this.items.length - 1) % this.items.length; sfx('ui'); } if (Inp.edge.d) { this.sel = (this.sel + 1) % this.items.length; sfx('ui'); } if (Inp.edge.atk) this.activate(this.items[this.sel].id); }
    Inp.edge = {};
  },
  draw(g) {
    const t = this.t; drawTitleScene(g, t);
    const ia = Math.min(1, t / 0.8); g.save(); g.globalAlpha = ia;
    if (window.V95 && V95.titleLayout) { const L = V95.titleLayout().logo; drawTitleLogo(g, VW / 2, L.y + 6, t, L.w); }   /* 9.5.1: fades in where it stays, clear of the heroes */
    else drawTitleLogo(g, VW / 2, 98 + (1 - ia) * 14, t);
    g.restore();
    if (!this.opts) {
      this.items.forEach((it, i) => {
        const on = i === this.sel, cy = it.y + it.h / 2, tw = PIX.textW(it.label, 1) * 1 + 34;
        if (on) {
          const w = Math.max(tw, 120) + Math.sin(t * 6) * 2, x0 = VW / 2 - w / 2;
          g.fillStyle = '#000'; g.beginPath(); g.moveTo(x0 + 6, it.y - 1); g.lineTo(x0 + w + 8, it.y - 1); g.lineTo(x0 + w - 4, it.y + it.h + 1); g.lineTo(x0 - 8, it.y + it.h + 1); g.fill();
          const gr = g.createLinearGradient(x0, 0, x0 + w, 0); gr.addColorStop(0, '#8a0016'); gr.addColorStop(0.5, '#e0102c'); gr.addColorStop(1, '#8a0016');
          g.fillStyle = gr; g.beginPath(); g.moveTo(x0 + 8, it.y + 1); g.lineTo(x0 + w + 4, it.y + 1); g.lineTo(x0 + w - 6, it.y + it.h - 1); g.lineTo(x0 - 4, it.y + it.h - 1); g.fill();
          g.fillStyle = '#ff7080'; g.fillRect(x0 + 8, it.y + 1, w - 4, 1);
          /* claw cursor */
          const ax = x0 - 14 + Math.sin(t * 8) * 2; for (let k = 0; k < 3; k++) { g.fillStyle = '#000'; g.fillRect(ax - 1 + k * 3, cy - 5, 3, 10); } for (let k = 0; k < 3; k++) for (let s2 = 0; s2 < 8; s2++) { g.fillStyle = '#f2eef8'; g.fillRect(ax + k * 3 + Math.round(s2 * 0.3), cy - 4 + s2, 1, 1); }
        }
        const dcol = it.id === 'diff' ? ({ easy: '#7dff9a', normal: '#ffcf3a', hard: '#ff8a3a', nightmare: '#ff3a50' })[SAVE.diff || 'normal'] : null;
        PIX.text(g, it.label, VW / 2, it.y + 3, { align: 'c', col: on ? '#ffe680' : (dcol || '#ffcf3a'), out: '#1a0008', shadow: '#000' });
      });
      PIX.text(g, '(C) 2026 NEON HOWL GAMES', VW - 6, VH - 10, { align: 'r', col: '#6a6080', out: '#000' });
      PIX.text(g, 'V9.5.1', 6, VH - 10, { col: '#6a6080', out: '#000' });
    } else { dim(g, 0.82); PIX.text(g, this.langPick ? T('lang') : T('options'), VW / 2, this.langPick ? 26 : 38, { s: 2, align: 'c', col: COLR.cyan }); for (const b of this.btns) drawBtn(g, b); }
  },
  activate(id) {
    sfx('ok');
    if (id === 'start') this.start();
    else if (id === 'story') playCut('intro', () => Scene.go('title'), 5);
    else if (id === 'diff') { const i = DIFFS.indexOf(SAVE.diff || 'normal'); SAVE.diff = DIFFS[(i + 1) % DIFFS.length]; saveGame(); }
    else if (id === 'opt') this.opts = true;
    else if (id === 'lair') Scene.go('lair');
  },
  onDown(id, x, y) {
    if (!this.opts) { const i = this.items.findIndex(it => x >= it.x - 20 && x <= it.x + it.w + 20 && y >= it.y - 2 && y <= it.y + it.h + 2); if (i >= 0) { this.sel = i; this.activate(this.items[i].id); } return; }
    const b = hitB(this.btns, x, y); if (!b) return;
    sfx('ok');
    if (b.id === 'close') this.opts = false;
    else if (b.id === 'lang') this.langPick = true; else if (b.id === 'closeL') this.langPick = false;
    else if (b.id.startsWith('L_')) { setLang(b.id.slice(2)); this.langPick = false; }
    else if (b.id === 'music') { SAVE.music = !SAVE.music; setAudioOpts(); saveGame(); }
    else if (b.id === 'sfx') { SAVE.sfx = !SAVE.sfx; setAudioOpts(); saveGame(); }
    else if (b.id === 'vib') { SAVE.vib = SAVE.vib === false; saveGame(); vibe(60, 200); }
    else if (b.id === 'cauto') { SAVE.comicAuto = !SAVE.comicAuto; saveGame(); }
    else if (b.id === 'reset') { SAVE.unlocked = 1; SAVE.up = { dmg: 0, hp: 0, fury: 0, cd: 0 }; SAVE.best = {}; saveGame(); this.opts = false; }
  },
  start() { SAVE.pendingMode = null; Scene.go('select'); },
  onKey(k) { if (k === 'ok') { if (this.opts) this.opts = false; else this.activate(this.items[this.sel].id); } }
};

/* =========================== INTRO STORY =========================== */
Scenes.intro = {
  i: 0, t: 0,
  enter() { this.i = -1; SAVE.seenIntro = true; saveGame(); this.next(); musicStart(5); },
  next() { this.i++; this.t = 0; if (this.i >= STORY.length) { Scene.go('select'); return; } BG.set(STORY[this.i].stage); sfx('ui'); },
  update(dt) { this.t += dt; if (this.t > 6.5) this.next(); },
  draw(g) {
    const s = STORY[this.i]; if (!s) return; const t = this.t, cx = VW / 2, cam = 300 + t * 10;
    BG.back(g, cam, 1 / 60);
    let cast = [];
    if (s.cast === 'lab') cast = [{ k: 'nacht', x: cx + 70, y: 214, f: -1 }, { k: 'zealot', x: cx - 96, y: 224, f: 1 }, { k: 'lupus_h', an: 'down', x: cx - 6, y: 244, f: 1 }, { k: 'zealot', x: cx + 130, y: 240, f: -1, o: 2 }];
    else if (s.cast === 'rage') { RD.glow(g, cx, 190, 150, '#ff1030', 0.25 + 0.1 * Math.sin(t * 8)); cast = [{ k: 'lupus_a', an: 'spec', x: cx, y: 244, f: 1, loop: false, o: -t * 7 + Math.min(5, t * 3) }, { k: 'zealot', an: 'down', x: cx - 110, y: 250, f: 1 }, { k: 'bulwark', an: 'knock', x: cx + 110, y: 228, f: -1 }]; }
    else if (s.cast === 'city') cast = [{ k: 'lupus_h', an: 'walk', x: cx - 80 + t * 22, y: 238, f: 1, o: t * 4 }];
    else if (s.cast === 'sigil') { const sx = cx + 90, sy = 110; g.save(); g.strokeStyle = '#c8001e'; g.lineWidth = 3; g.globalAlpha = 0.85; g.beginPath(); g.arc(sx, sy, 26, 0, 7); g.stroke(); g.fillStyle = '#c8001e'; g.fillRect(sx - 1.5, sy - 40, 3, 80); g.fillRect(sx - 18, sy - 1.5, 36, 3); g.restore(); cast = [{ k: 'hunter', an: 'down', x: cx + 60, y: 248, f: 1 }, { k: 'lupus_h', x: cx - 60, y: 238, f: 1 }]; }
    else if (s.cast === 'team') cast = TITLE_CAST.map(([k, dx, y, f, o]) => ({ k, an: t > 2.2 ? 'win' : 'idle', x: cx + dx, y, f, o }));
    for (const c of cast) c.y -= 46;
    g.save(); g.translate(0, -18); BG.back(g, cam, 0); menuCast(g, cast.map(c => Object.assign(c, { y: c.y + 18 })), t, s.stage, cam); g.restore();
    BG.atmos(g, t);
    g.fillStyle = '#05030a'; g.fillRect(0, 0, VW, 22); g.fillRect(0, VH - 64, VW, 64);
    const lines = s[SAVE.lang]; const shown = Math.floor(t * 34); let used = 0;
    lines.forEach((l, n) => { const vis = Math.max(0, Math.min(l.length, shown - used)); used += l.length + 4; PIX.text(g, l.slice(0, vis), 22, VH - 56 + n * 14, { col: n === 0 ? COLR.red : COLR.white }); });
    PIX.text(g, T('skip'), VW - 8, 8, { align: 'r', col: COLR.gray });
    PIX.text(g, (this.i + 1) + '/' + STORY.length, 8, 8, { col: '#5a5470' });
    if (t > 2.2 && Math.sin(t * 5) > 0) PIX.text(g, T('tapNext'), VW - 10, VH - 12, { align: 'r', col: '#6a6480', out: null });
  },
  onDown(id, x, y) { if (x > VW - 70 && y < 24) { sfx('ok'); Scene.go('select'); return; } this.next(); },
  onKey(k) { if (k === 'ok') this.next(); }
};

/* =========================== SELECT =========================== */
Scenes.select = {
  step: 0, sel: null, hero: null, t: 0, back: null, cards: [],
  enter() { this.step = 1; this.sel = null; this.hero = 'lupus'; this.t = 0; BG.set(3); musicStart(5); },
  update(dt) {
    this.t += dt; this.back = btn('back', 6, 6, 62, 16, T('back'), COLR.gray);
    const n = ROSTER.length - 1, gap = 6, cw = Math.floor((VW - 16 - gap * (n - 1)) / n), x0 = Math.round((VW - (cw * n + gap * (n - 1))) / 2);
    this.cards = ROSTER.filter(id => id !== 'lupus').map((id, i) => ({ id, x: x0 + i * (cw + gap), y: 30, w: cw, h: 212 }));
  },
  draw(g) {
    BG.menu(g, 3, this.t, this.t * 10); dim(g, 0.45);
    PIX.text(g, 'THORNE  +  ' + T('selectAlly'), VW / 2, 12, { align: 'c', col: COLR.white });
    for (const c of this.cards) {
      const H = HERO[c.id], sel = this.sel === c.id, dis = this.step === 1 && c.id === this.hero;
      PIX.panel(g, c.x, c.y, c.w, c.h, { edge: sel ? H.color : PIX.shade(H.color, 0.55), bg: sel ? 'rgba(30,10,30,0.88)' : 'rgba(10,6,18,0.78)' });
      if (sel) { g.fillStyle = H.color; g.globalAlpha = 0.1 + 0.07 * Math.sin(this.t * 6); g.fillRect(c.x + 1, c.y + 1, c.w - 2, c.h - 2); g.globalAlpha = 1; }
      PIX.text(g, H.name, c.x + c.w / 2, c.y + 6, { align: 'c', col: H.color });
      const key = ROSTER_KEY[c.id]; const fr = ART.frame(key, sel ? 'win' : 'idle', Math.floor(this.t * 7));
      g.save(); g.beginPath(); g.rect(c.x + 2, c.y + 16, c.w - 4, 104); g.clip();
      RD.glow(g, c.x + c.w / 2, c.y + 80, 46, H.color, 0.28); ART.shadow(g, c.x + c.w / 2, c.y + 116, 18, 0.7);
      ART.useLook(MENU_LOOK); g.imageSmoothingEnabled = true; const s = Math.min(1, 96 / window.ATLAS[key].h);
      ART.draw(g, fr, c.x + c.w / 2, c.y + 116, { face: 1, sc: s, rims: [[H.color, -2, -1, 0.7]] }); g.imageSmoothingEnabled = false; g.restore();
      PIX.wrap(H.role, c.w - 8, 1).slice(0, 2).forEach((l, n) => PIX.text(g, l, c.x + c.w / 2, c.y + 124 + n * 9, { align: 'c', col: COLR.gray, out: null }));
      T('stats').forEach((lab, n) => { const yy = c.y + 146 + n * 12; PIX.text(g, lab.slice(0, c.w < 80 ? 3 : 5), c.x + 4, yy, { col: '#c8c0d8', out: null }); PIX.bar(g, c.x + (c.w < 80 ? 24 : 40), yy, c.w - (c.w < 80 ? 28 : 46), 6, H.stats[n] / 5, H.color, '#1a0f22', 5); });
      if (dis) { g.fillStyle = 'rgba(0,0,0,0.62)'; g.fillRect(c.x, c.y, c.w, c.h); PIX.text(g, 'P1', c.x + c.w / 2, c.y + c.h / 2, { s: 2, align: 'c', col: COLR.white }); }
      if (!heroOpen(c.id)) { g.fillStyle = 'rgba(4,2,10,0.78)'; g.fillRect(c.x, c.y + 14, c.w, c.h - 14); PIX.text(g, T('locked'), c.x + c.w / 2, c.y + 60, { align: 'c', col: '#8a84a0' }); PIX.wrap(T('act2Lock'), c.w - 8, 1).forEach((l, n) => PIX.text(g, l, c.x + c.w / 2, c.y + 74 + n * 9, { align: 'c', col: '#6a6480', out: null })); }
    }
    if (this.sel && Math.sin(this.t * 6) > -0.4) PIX.text(g, T('tapAgain'), VW / 2, VH - 20, { align: 'c', col: COLR.white });
    drawBtn(g, this.back);
  },
  onDown(id, x, y) {
    if (hitB([this.back], x, y)) { sfx('ui'); Scene.go('title'); return; }
    for (const c of this.cards) {
      if (x < c.x || x > c.x + c.w || y < c.y || y > c.y + c.h) continue;
      if (this.step === 1 && c.id === this.hero) return;
      if (!heroOpen(c.id)) { sfx('ui'); return; }
      if (this.sel === c.id) { sfx('ok'); { SAVE.hero = 'lupus'; SAVE.ally = c.id; saveGame(); if (SAVE.pendingMode) startMode(SAVE.pendingMode); else if (!SAVE.tutDone) Scene.go('play', { stage: 0, mode: 'tutorial', next: 'stages' }); else Scene.go('stages'); } }
      else { this.sel = c.id; sfx('ui'); }
      return;
    }
  }
};

/* =========================== STAGE MAP =========================== */
Scenes.stages = {
  t: 0, back: null, cards: [],
  enter(o) { this.t = 0; musicStart(5); this.act = (o && o.act) || (SAVE.unlocked > ACT2 ? 2 : 1); this.newAct = !!(o && o.act === 2); },
  update(dt) {
    this.t += dt; this.back = btn('back', 6, 6, 62, 16, T('back'), COLR.gray);
    const tw = 70; this.tabs = [1, 2].map(a => btn('act' + a, VW / 2 - tw - 3 + (a - 1) * (tw + 6), 30, tw, 14, T('act' + a), a === this.act ? COLR.red : '#5a5470'));
    const gap = 6, cw = Math.floor((VW - 16 - gap * 4) / 5), x0 = Math.round((VW - (cw * 5 + gap * 4)) / 2), off = this.act === 2 ? ACT2 : 0;
    this.cards = STAGES.slice(off, off + 5).map((s, j) => ({ i: off + j, x: x0 + j * (cw + gap), y: 50, w: cw, h: 178 }));
  },
  draw(g) {
    BG.menu(g, 2, this.t, this.t * 8); dim(g, 0.6);
    PIX.text(g, T('stages'), VW / 2, 12, { s: 2, align: 'c', col: COLR.red });
    { const dk = SAVE.diff || 'normal'; PIX.text(g, T('difficulty') + ': ' + T('d_' + dk), VW - 8, 12, { align: 'r', col: ({ easy: '#7dff9a', normal: '#ffcf3a', hard: '#ff8a3a', nightmare: '#ff3a50' })[dk], out: '#0a0612' }); }
    PIX.text(g, HERO[SAVE.hero].name + '  +  ' + HERO[SAVE.ally].name, 8, VH - 12, { col: '#c8c0d8', out: '#0a0612' });
    for (const b of this.tabs) drawBtn(g, b);
    if (this.newAct && this.t < 4 && Math.sin(this.t * 6) > -0.5) PIX.text(g, T('newHeroes'), VW - 8, VH - 12, { align: 'r', col: COLR.gold, out: '#0a0612' });
    for (const k of this.cards) {
      const s = STAGES[k.i], lock = k.i + 1 > SAVE.unlocked, im = ART.img['s' + s.id + '_l3'];
      g.save(); g.imageSmoothingEnabled = true; const tw = k.w - 2, th = 110; const sw = th / VIEW_H * im.height * 0.0 + 0; // crop
      const srcH = im.height * 0.78, srcW = srcH * tw / th, srcX = (im.width - srcW) * (0.25 + 0.12 * (k.i % 5));
      g.drawImage(im, srcX, im.height * 0.12, srcW, srcH, k.x + 1, k.y + 1, tw, th); g.restore();
      if (lock) { g.fillStyle = 'rgba(0,0,0,0.75)'; g.fillRect(k.x + 1, k.y + 1, k.w - 2, 110); }
      PIX.panel(g, k.x, k.y + 108, k.w, 70, { edge: lock ? '#3a3448' : COLR.red });
      g.fillStyle = lock ? '#3a3448' : COLR.red; g.fillRect(k.x, k.y, k.w, 1); g.fillRect(k.x, k.y, 1, 110); g.fillRect(k.x + k.w - 1, k.y, 1, 110);
      PIX.text(g, String(s.id).padStart(2, '0'), k.x + 5, k.y + 6, { s: 2, col: lock ? '#5a5470' : COLR.red });
      PIX.wrap(s.name[SAVE.lang], k.w - 8, 1).forEach((l, n) => PIX.text(g, l, k.x + 4, k.y + 114 + n * 9, { col: lock ? '#6a6480' : COLR.white, out: null }));
      const bk = BOSS[s.boss].key; if (!lock) drawFace(g, bk, k.x + k.w - 26, k.y + 146, 22);
      if (!lock) { const m = (SAVE.stars || {})[s.id] || 0; for (let n = 0; n < 3; n++) drawStar(g, k.x + 10 + n * 14, k.y + 140, 5.5, !!(m & (1 << n))); }
      if (lock) { PIX.text(g, T('locked'), k.x + k.w / 2, k.y + 46, { align: 'c', col: '#8a84a0' }); if (k.i >= ACT2 && SAVE.unlocked <= ACT2) PIX.wrap(T('act2Lock'), k.w - 8, 1).forEach((l, n) => PIX.text(g, l, k.x + k.w / 2, k.y + 60 + n * 9, { align: 'c', col: '#6a6480', out: null })); }
      else if (SAVE.best[s.id]) { PIX.text(g, T('best'), k.x + 4, k.y + 154, { col: COLR.gold, out: null }); PIX.text(g, '' + SAVE.best[s.id], k.x + 4, k.y + 164, { col: COLR.gold, out: null }); }
    }
    drawBtn(g, this.back);
  },
  onDown(id, x, y) {
    if (hitB([this.back], x, y)) { sfx('ui'); Scene.go('select'); return; }
    { const b = hitB(this.tabs, x, y); if (b) { sfx('ui'); this.act = b.id === 'act2' ? 2 : 1; this.newAct = false; return; } }
    for (const k of this.cards) if (x >= k.x && x <= k.x + k.w && y >= k.y && y <= k.y + k.h) { if (k.i + 1 > SAVE.unlocked) { sfx('ui'); return; } sfx('ok'); playCut('s' + STAGES[k.i].id + 'pre', () => Scene.go('play', k.i), STAGES[k.i].music); return; }
  }
};

/* =========================== PLAY =========================== */
function fxStep(dt) {
    for (const q of G.parts) { q.t += dt; q.x += q.vx * dt; q.y += (q.vy || 0) * dt; q.vz -= q.grav * dt; q.z += q.vz * dt; if (q.vr) q.rot += q.vr * dt; if (q.z < 0) { q.z = 0; if (q.bounce) { q.vz = -q.vz * q.bounce; q.vx *= 0.6; if (q.vr) q.vr *= 0.5; } else { q.vz = 0; q.vx *= 0.3; q.grav = 0; } } if (q.dust) q.vx *= 0.92; }
    G.parts = G.parts.filter(q => q.t < q.life); if (G.parts.length > 500) G.parts.splice(0, G.parts.length - 500);
    for (const arr of [G.slashes, G.rings, G.lines, G.flashes]) for (const q of arr) q.t += dt;
    G.slashes = G.slashes.filter(q => q.t < q.dur); G.rings = G.rings.filter(q => q.t < q.dur); G.lines = G.lines.filter(q => q.t < q.dur); G.flashes = G.flashes.filter(q => q.t < q.dur);
    if (window.FX94) FX94.step(dt);
    for (const q of G.texts) { q.t += dt; q.y += q.vy * dt; q.vy *= 0.94; } G.texts = G.texts.filter(q => q.t < 0.9);
}

const BTN = () => window.ControlsUI ? window.ControlsUI.buttons() : ({ sense: { x: VW - 204, y: 216, r: 13 }, atk: { x: VW - 50, y: 222, r: 24 }, jump: { x: VW - 104, y: 246, r: 17 }, dash: { x: VW - 112, y: 202, r: 15 }, spec: { x: VW - 56, y: 170, r: 18 }, form: { x: VW - 158, y: 236, r: 15 }, tag: { x: VW - 104, y: 156, r: 15 }, assist: { x: VW - 156, y: 188, r: 13 }, super: { x: VW - 50, y: 122, r: 15 }, block: { x: VW - 160, y: 146, r: 14 } });
const JOY = { r: 30 };
function playerCtl() {
  const k = Inp.keys; let mx = 0, my = 0;
  if (k.l) mx -= 1; if (k.r) mx += 1; if (k.u) my -= 1; if (k.d) my += 1;
  if (Inp.joy.id != null) { const ax = Inp.joy.ax, ay = Inp.joy.ay, m = Math.hypot(ax, ay); if (m > 0.1) { const f = Math.min(1, (m - 0.1) / 0.65); mx = ax / m * f; my = ay / m * f; if (Math.abs(my) < 0.12) my = 0; } }
  const c = { mx, my, atk: !!Inp.edge.atk, atkHeld: !!Inp.held.atk, jump: !!Inp.edge.jump, jumpHeld: !!Inp.held.jump, spec: !!Inp.edge.spec, dash: !!Inp.edge.dash, form: !!Inp.edge.form, formHeld: !!Inp.held.form, block: !!Inp.held.block, sense: !!Inp.held.sense, tag: !!Inp.edge.tag, assist: !!Inp.edge.assist, super: !!Inp.edge.super };
  Inp.edge = {}; return c;
}
Scenes.play = {
  menu: false, btns: [],
  enter(arg) { const o = typeof arg === 'object' ? arg : { stage: arg }; const st = STAGES[o.stage]; BG.set(o.mode === 'endless' && o.bg ? o.bg : (st.bg || st.id)); newGame(o.stage, o); this.menu = false; this.arg = o; MUS.lock = null; musicStart(G.st.music); },
  pauseMenu() { const L = [['resume', T('resume')], ['restart', T('restart')], ['music', T('music') + ': ' + (SAVE.music ? T('on') : T('off'))], ['sfx', T('sfx') + ': ' + (SAVE.sfx ? T('on') : T('off'))], ['vib', T('vibration') + ': ' + (SAVE.vib !== false ? T('on') : T('off'))], ['lang', T('lang') + ': ' + I18N[SAVE.lang].native], ['quit', T('quit')]]; this.btns = L.map((l, i) => btn(l[0], VW / 2 - 80, 62 + i * 24, 160, 18, l[1], l[0] === 'resume' ? COLR.red : l[0] === 'quit' ? COLR.gold : COLR.cyan)); },
  update(dt) {
    if (PORTRAIT) return;
    if (this.menu) { this.pauseMenu(); return; }
    const raw = dt; G.time += dt;
    if (G.choice) { G.choice.t += raw; Inp.edge = {}; return; }
    if (G.panel) { panelStep(raw); Inp.edge = {}; return; }
    talkStep(raw);
    if (G.hitstop > 0) { G.hitstop -= raw; G.shake *= 0.9; return; }
    if (G.superFx) { G.time += 0; Inp.edge = {}; updSuper(raw); fxStep(raw); updLeaving(raw); G.flashScr = Math.max(0, G.flashScr - raw * 1.2); G.shake *= Math.exp(-5 * raw); return; }
    if (G.cine) { G.cine.t += raw; Inp.edge = {}; updHero(G.player, raw, { mx: 0, my: 0 }); fxStep(raw); G.flashScr = Math.max(0, G.flashScr - raw * 1.6); G.shake *= Math.exp(-6 * raw); if (G.cine.t >= G.cine.dur) G.cine = null; return; }
    const ko = bossKoActive();
    const koSlowActive = ko ? G.clearT < 1.3 : G.clearT > 0 && G.clearT < 1.85 && G.boss && G.boss.dead && !G.boss.fleeing;
    if (koSlowActive) G.slow = ko ? (G.clearT < 0.45 ? 0.25 : lerp(0.25, 1, (G.clearT - 0.45) / 0.85))
      : (G.clearT < 1.35 ? 0.16 : lerp(0.16, 0.45, (G.clearT - 1.35) / 0.5));
    dt *= G.slow; if (!koSlowActive && G.slow < 1) G.slow = Math.min(1, G.slow + raw * (G.clearT >= 1.85 ? 0.9 : 0.2));
    G.title = Math.max(0, G.title - raw); G.flashScr = Math.max(0, G.flashScr - raw * 1.6); G.shake *= Math.exp(-10 * raw); G.hintT -= raw;
    if (G.comboT > 0) { G.comboT -= dt; if (G.comboT <= 0) G.combo = 0; }
    if (G.lastET > 0) G.lastET -= raw;
    const pc = playerCtl(); if (window.Traversal90 && Traversal90.consumeInput) Traversal90.consumeInput(pc); let p = G.player; senseStep(raw, pc); archStep(); thrownStep();
    { const M = G.mech && MECH[G.mech]; if (M && M.update && G.over <= 0) M.update(dt); }
    if (G.guest) { const b = G.guest; if (b.dead) { b.revT = (b.revT || 8) - dt; if (b.revT <= 0) { b.dead = false; b.hp = b.maxhp * 0.5; b.revT = 8; setSt(b, 'idle'); b.inv = 1.5; G.heroes = G.heroes.filter(h => h !== b).concat([b]); } } else updHero(b, dt, allyCtl(b, dt)); }
    if (G.over > 0) { G.over += raw; updHero(p, dt, { mx: 0, my: 0 }); if (G.over > 2.2) { if (G.mode) this.modeEnd(false); else Scene.go('over'); return; } } else updHero(p, dt, G.autoTag > 0 ? { mx: 0, my: 0 } : pc);
    tagStep(dt, pc); p = G.player; if (pc.super && canSuper()) startSuper();
    for (const e of G.enemies) updEnemy(e, dt);
    separate(dt);
    G.enemies = G.enemies.filter(e => !(e.dead && e.deadT > (e.kind === 'boss' ? 99 : 1.4)));
    for (const pr of G.props) { if (pr.dead) continue; pr.flash = Math.max(0, pr.flash - dt * 5); pr.x += pr.vx * dt; friction(pr, dt, 10); }
    G.props = G.props.filter(pr => !pr.dead);
    for (const q of G.proj) updProj(q, dt); G.proj = G.proj.filter(q => q.life > 0 && q.x > G.camX - 160 && q.x < G.camX + VW + 160);
    fxStep(dt);
    for (const d of G.drops) {
      d.t += dt; if (d.z > 0 || d.vz) { d.vz -= GRAV * dt; d.z += d.vz * dt; if (d.z <= 0) { d.z = 0; d.vz = d.vz < -60 ? -d.vz * 0.4 : 0; } }
      for (const h of G.heroes) { if (h.dead || d.got) continue; if (Math.abs(h.x - d.x) < 16 && Math.abs(h.y - d.y) < 12) { d.got = true; sfx('pick'); if (d.type === 'vial') { h.hp = Math.min(h.maxhp, h.hp + h.maxhp * (DF().vial || 0.25)); textFx(h.x, h.y - 90, '+HP', '#ff4060', 1); } else if (d.type === 'fury') { if (h.id === 'lupus') h.fury = Math.min(300, h.fury + 45); else h.spCd = Math.max(0, h.spCd - 3); textFx(h.x, h.y - 90, '+' + T('fury'), COLR.gold, 1); } else { G.score += 100; G.shards++; SAVE.shards = (SAVE.shards || 0) + 1; textFx(h.x, h.y - 90, '+1', '#b8e8ff', 1); } } }
    }
    G.drops = G.drops.filter(d => !d.got && d.t < 25);
    if (G.hzOn) { G.hzT -= dt; if (G.hzT <= 0) { spawnHazard(G.hzOn); G.hzT = G.hzOn === 'train' ? rnd(4.5, 6) : G.hzOn === 'shock' ? rnd(3, 4.4) : rnd(2.2, 3.4); } }
    updHazards(dt); if (G.banner2) { G.banner2.t += raw; if (G.banner2.t > 2) G.banner2 = null; }
    // Some traversal mechanics need to frame the moving hero before a wave
    // freezes the camera, rather than correct an already off-screen arena.
    { const M = G.mech && MECH[G.mech]; if (M && M.camera) M.camera(dt); }
    this.waves(dt);
    /* camera: smooth follow with a small look-ahead in the facing direction */
    const end = WORLD_W - VW; const goal = G.locked ? (G.bossPending || G.bossSpawned ? end : G.camX) : end;
    G.look = lerp(G.look || 0, p.face * 18 * (Math.abs(p.vx) > 20 ? 1 : 0.4), Math.min(1, dt * 2.5));
    /* stages with things to find (clues) let the camera scroll back while no fight is on */
    const back = !G.locked && G.mech && MECH[G.mech] && MECH[G.mech].backtrack && MECH[G.mech].backtrack();
    const tgt = clamp(p.x - VW * 0.36 + G.look, back ? 0 : G.camX, goal);
    if (!(G.locked && !(G.bossPending || G.bossSpawned)) && G.mode !== 'endless' && !G.arena && !(G.auto && !G.bossPending && !G.bossSpawned)) G.camX = lerp(G.camX, tgt, Math.min(1, dt * 5));
    G.camX = Math.min(G.camX, end);
    if (G.sayQ) { G.sayDelay -= raw; if (G.sayDelay <= 0) { G.say = G.sayQ; G.sayT = 3.6; G.sayQ = null; } }
    if (G.sayT > 0) { G.sayT -= raw; if (G.sayT <= 0) G.say = null; }
    if (G.banner) { G.banner.t += raw; if (G.banner.t > 2.6) G.banner = null; }
    if (G.goT > 0) G.goT -= raw;
    if (G.boss && G.boss.dead && G.clearT > 0) {
      G.clearT += raw;
      for (const e of G.enemies) if (!e.dead && e.kind !== 'boss') kill(e, 1, p);
      const k = bossKoActive();
      // A malformed/removed body cannot hold progression forever. This guard
      // is run on the clear clock even if the enemy list no longer contains it.
      if (k && k.settledAt == null && G.clearT >= BOSS_KO.maxAir) settleBossKo(k);
      if (k ? k.settledAt != null : G.clearT > 1.6) G.player.taunt = true;
      const done = k ? k.settledAt != null && G.clearT >= k.settledAt + BOSS_KO.hold + BOSS_KO.fade : G.clearT > 3.6;
      /* 9.5: the line being spoken over the K.O. ends before the comic cuts in */
      if (done && !G.finishing && !(window.V95 && V95.holdFinish(raw))) { G.finishing = true; this.finish(); }
    }
  },
  waves(dt) {
    if (G.mode === 'endless') { endlessStep(dt); return; }
    if (G.mode === 'tutorial') { tutStep(dt); return; }
    const st = G.st, p = G.player, M = G.mech && MECH[G.mech];
    if (!G.locked && !G.bossSpawned && !G.arena) {
      const w = st.waves[G.waveIdx];
      if (w && p.x > w.x) startWave(w);
      else if (!w) { const gk = M && M.gate ? M.gate() : null;
        if (G.exitGateBlocked && !gk) G.goT = 4;
        G.exitGateBlocked = !!gk;
        if (p.x > WORLD_W - VW * 0.62) {
          if (gk) { p.x = Math.min(p.x, WORLD_W - VW * 0.62 - 2); p.vx = Math.min(p.vx, 0); if (!G.gateT || G.time - G.gateT > 2.4) { G.gateT = G.time; G.banner2 = { t: 0, txt: T(gk) }; sfx('ui'); } }
          else { G.locked = true; G.goT = 0; G.bossPending = true; G.bossT = 1.8; G.banner = { t: 0, boss: BOSS[st.boss] }; sfx('alarm'); }
        }
      }
    }
    if (G.locked) {
      for (const s of G.spawnQ) s.t -= dt; const due = G.spawnQ.filter(s => s.t <= 0); G.spawnQ = G.spawnQ.filter(s => s.t > 0);
      due.forEach(s => {
        const e = spawnEnemy(s.type, s.side, s.elite);
        if (s.x != null) { e.x = s.x; e.y = s.y; e.arrive = s.arrive; }
        if (M && M.spawned) M.spawned(e);
        if (s.elite) { G.banner2 = { t: 0, txt: e.def.name }; sfx('roar'); }
      });
      if (G.bossPending) { G.bossT -= dt; if (G.bossT <= 0) { G.bossPending = false; spawnBoss(st.boss); sfx('roar'); shake(8); playSting('sting_boss'); } }
      else if (G.arena) { }
      else if (G.spawnQ.length === 0 && !G.bossSpawned && !G.duelHold && enemiesAlive() === 0) {
        G.locked = false; G.goT = 4; sfx('ok'); playSting('sting_clear'); G.hzOn = null;
        if (!G.sideEncounter) {
          G.waveIdx++; G.ck = G.waveIdx; G.objTarget = null; waveCleared();
          for (const h of G.team) if (!h.dead) h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.12);
        }
        G.sideEncounter = false;
      }
    }
  },
  modeEnd(win) {
    const r = { mode: G.mode, win, score: Math.round(G.score), wave: G.ew || 0, time: (G.rushTime || 0) + G.time, bosses: (G.rushIdx || 0) + (win ? 1 : 0), shards: G.shards };
    if (G.mode === 'rush' && win && G.rushIdx < RUSH_N() - 1) { const p = G.player, a = G.ally; const hp = [p.hp / p.maxhp, a.dead ? 0 : a.hp / a.maxhp]; if (p !== G.team[0]) { hp.reverse(); } Scene.go('play', { stage: G.rushIdx + 1, mode: 'rush', rushIdx: G.rushIdx + 1, time: r.time, hp: [G.team[0].hp / G.team[0].maxhp, G.team[1].dead ? 0 : G.team[1].hp / G.team[1].maxhp], shards: G.shards }); return; }
    if (r.mode === 'endless') r.bonus = Math.floor(r.wave * 1.5); else r.bonus = win ? 60 : r.bosses * 6;
    SAVE.shards = (SAVE.shards || 0) + r.bonus; SAVE.best = SAVE.best || {};
    if (r.mode === 'endless') { r.record = !(SAVE.best.endless >= r.wave); if (r.record) SAVE.best.endless = r.wave; }
    else { r.record = win && !(SAVE.best.rush <= r.time); if (r.record) SAVE.best.rush = r.time; }
    saveGame(); Scene.go('modeEnd', r);
  },
  finish() { const st = G.st; const res = { score: Math.round(G.score), time: G.time, combo: G.maxCombo, stage: G.stage, shards: G.shards, xp: G.xpGain || 0 };
    if (G.mode) { this.modeEnd(true); return; }
    { const list = CHAL[st.id] || [], prev = (SAVE.stars || {})[st.id] || 0; let mask = prev, fresh = 0; res.chal = list.map((c, i) => { const ok = chalDone(c, G, true); if (ok && !(prev & (1 << i))) fresh++; if (ok) mask |= 1 << i; return { c, ok, was: !!(prev & (1 << i)) }; }); SAVE.stars = SAVE.stars || {}; SAVE.stars[st.id] = mask; res.fresh = fresh; res.bonus = fresh * 10; SAVE.shards = (SAVE.shards || 0) + res.bonus; } if (!SAVE.best[st.id] || SAVE.best[st.id] < res.score) SAVE.best[st.id] = res.score; if (G.stage + 2 > SAVE.unlocked && G.stage < STAGES.length - 1) SAVE.unlocked = G.stage + 2; if (G.stage === STAGES.length - 1) SAVE.unlocked = Math.max(SAVE.unlocked, STAGES.length + 1); saveGame(); playCut('s' + st.id + 'post', () => Scene.go('clear', res)); },
  onKey(k) { if (k === 'pause' || k === 'hide') { if (G.over > 0 || (G.clearT > 0 && !G.fleeWait90)) return; this.menu = k === 'hide' ? true : !this.menu; } },
  onDown(id, x, y) {
    if (this.menu) {
      const b = hitB(this.btns, x, y); if (!b) return; sfx('ok');
      if (b.id === 'resume') this.menu = false; else if (b.id === 'restart') Scene.go('play', Object.assign({}, this.arg, { fromWave: 0 })); else if (b.id === 'quit') { if (G.mode === 'tutorial') { SAVE.tutDone = true; saveGame(); Scene.go(G.tutNext); } else Scene.go(G.mode ? 'lair' : 'stages'); }
      else if (b.id === 'music') { SAVE.music = !SAVE.music; setAudioOpts(); saveGame(); } else if (b.id === 'sfx') { SAVE.sfx = !SAVE.sfx; setAudioOpts(); saveGame(); } else if (b.id === 'vib') { SAVE.vib = SAVE.vib === false; saveGame(); vibe(60, 200); } else if (b.id === 'lang') { setLang(LANGS[(LANGS.indexOf(SAVE.lang) + 1) % LANGS.length]); }
      return;
    }
    if (Math.hypot(x - (VW - 14), y - 14) < 14) { this.menu = true; sfx('ui'); return; }
    const B = BTN();
    if (G.choice) { choiceTap(x, y); return; } if (G.panel) { if (!window.V95 || V95.panelTapOk()) panelAdvance(); return; }
    for (const n in B) { if (n === 'form' && G.player.id !== 'lupus') continue; if (n === 'sense' && !senseOk()) continue; if ((n === 'tag' || n === 'assist') && (!G.ally || G.ally.dead)) continue; if (n === 'super' && !canSuper()) continue; const b = B[n]; if (Math.hypot(x - b.x, y - b.y) < b.r + 7) { Inp.btnIds[id] = n; Inp.held[n] = true; Inp.edge[n] = true; return; } }
    if (x < VW * 0.5 && Inp.joy.id == null) { const j = Inp.joy; j.id = id; j.ox = x; j.oy = y; j.x = x; j.y = y; j.ax = j.ay = 0; }
  },
  onMove(id, x, y) { const j = Inp.joy; if (j.id === id) { let dx = x - j.ox, dy = y - j.oy; const d = Math.hypot(dx, dy); if (d > JOY.r) { j.ox += dx / d * (d - JOY.r); j.oy += dy / d * (d - JOY.r); dx = x - j.ox; dy = y - j.oy; } j.x = x; j.y = y; j.ax = dx / JOY.r; j.ay = dy / JOY.r; } },
  onUp(id) { if (Inp.joy.id === id) { Inp.joy.id = null; Inp.joy.ax = Inp.joy.ay = 0; } const n = Inp.btnIds[id]; if (n) { Inp.held[n] = false; delete Inp.btnIds[id]; } },
  draw(g) {
    if (PORTRAIT) { g.fillStyle = '#07040d'; g.fillRect(0, 0, VW, VH); PIX.text(g, T('rotate'), VW / 2, VH / 2, { align: 'c', s: 2, col: COLR.white }); return; }
    if (this.menu && window.PauseUI) { PauseUI.draw(g); return; }
    const sx = G.shake > 0.3 ? rnd(-G.shake, G.shake) : 0, sy = G.shake > 0.3 ? rnd(-G.shake, G.shake) * 0.6 : 0;
    g.save(); g.translate(half(sx), half(sy));
    const cam = half(G.camX), look = ART.look;
    let ck = 0; if (G.cine) { const t = G.cine.t, d = G.cine.dur; ck = Math.min(1, t / 0.25, (d - t) / 0.25 + 0.0001); ck = ck * ck * (3 - 2 * ck); const h = G.cine.h, fx = h.x - cam, fy = h.y - 55; const z = 1 + 0.32 * ck; g.translate(VW / 2, VH * 0.5); g.scale(z, z); g.translate(-lerp(VW / 2, fx, ck), -lerp(VH * 0.5, fy, ck)); }
    else if (G.superFx && G.superFx.v90 && window.Super90 && Super90.camera) Super90.camera(g, cam);
    else if (bossKoActive()) {
      const k = bossKoActive();
      let kz = Math.max(0, Math.min(1, G.clearT / 0.22, k.settledAt == null ? 1 : 1 - (G.clearT - k.settledAt) / 0.4));
      kz = kz * kz * (3 - 2 * kz);
      const b = G.boss, fr = frameOf(b), sc = depthScale(b.y) * (b.big || 1) * 0.5;
      const bx = clamp(b.x - cam + (fr ? (fr.w / 2 - fr.ax) * b.face * sc : 0), 80, VW - 80);
      const by = clamp(b.y - (b.z || 0) + (fr ? (fr.h / 2 - fr.ay) * sc : -38), 70, VH - 60);
      const z = 1 + 0.16 * kz;
      g.translate(VW / 2, VH * 0.5); g.scale(z, z); g.translate(-lerp(VW / 2, bx, kz * 0.65), -lerp(VH * 0.5, by, kz * 0.65));
    }
    const M = G.mech && MECH[G.mech];
    if (M && M.bg) M.bg(g, cam); else BG.back(g, cam, G.hitstop > 0 ? 0 : 1 / 60);
    if (M && M.drawBack) M.drawBack(g, cam);
    drawArchives(g, cam);
    const ents = [...G.props, ...(G.objs || []), ...G.heroes, ...G.enemies.filter(e => !(e.hid95 > 0)), ...G.leaving].sort((a, b) => (a.y + (a === G.player ? 3 : 0)) - (b.y + (b === G.player ? 3 : 0)));
    /* reflections (wet floors / water) */
    if (look.refl) { g.save(); g.beginPath(); g.rect(0, WALL_Y + 4, VW, VIEW_H); g.clip(); g.imageSmoothingEnabled = true; for (const e of ents) { if (e.kind === 'prop' || e.kind === 'obj' || e.giant || (window.Super90 && Super90.handles && Super90.handles(e))) continue; const fr = frameOf(e); ART.reflect(g, fr, e.x - cam, e.y, e.z, e.face, look.refl * (e.dead ? 0.5 : 1), G.time, look.water, depthScale(e.y)); } g.restore(); g.imageSmoothingEnabled = false; }
    /* hazard telegraphs on the floor */
    for (const h of G.hz) {
      if (window.Flood90 && Flood90.drawHazard && Flood90.drawHazard(g, h, cam)) continue;
      if (window.V95 && V95.drawHazard(g, h, cam)) continue;   /* 9.5: drawn gas vents */
      if (h.t < 0) continue;
      const k = Math.min(1, h.t / h.warn), live = h.t >= h.warn, x = h.x - cam;
      if (h.kind === 'bolt') { g.save(); if (!live) { g.globalAlpha = 0.3 + 0.4 * k; g.strokeStyle = '#9cd8ff'; g.lineWidth = 1; g.beginPath(); g.ellipse(x, h.y, h.r * k, h.r * 0.5 * k, 0, 0, 7); g.stroke(); g.fillStyle = 'rgba(160,210,255,0.15)'; g.beginPath(); g.ellipse(x, h.y, h.r, h.r * 0.5, 0, 0, 7); g.fill(); } else { g.globalCompositeOperation = 'lighter'; g.strokeStyle = '#e8f4ff'; g.lineWidth = 2.5; g.beginPath(); let px = x + rnd(-6, 6), py = -10; g.moveTo(px, py); while (py < h.y) { py += rnd(12, 26); px += rnd(-10, 10); g.lineTo(px, Math.min(py, h.y)); } g.stroke(); RD.glow(g, x, h.y - 10, 50, '#9cd8ff', 0.7); } g.restore(); continue; }
      if (h.kind === 'beam') { g.save(); if (!live) { g.globalAlpha = 0.15 + 0.25 * (Math.floor(h.t * 8) % 2); g.fillStyle = '#3af0ff'; g.fillRect(0, h.y - h.r, VW, h.r * 2); } else { g.globalCompositeOperation = 'lighter'; g.fillStyle = '#3af0ff'; g.globalAlpha = 0.8; g.fillRect(0, h.y - 34 - h.r * 0.6, VW, h.r * 1.2); g.fillStyle = '#ffffff'; g.fillRect(0, h.y - 34 - h.r * 0.25, VW, h.r * 0.5); } g.restore(); continue; }
      if (h.kind === 'train') { if (!live) { g.save(); g.globalAlpha = 0.18 + 0.22 * (Math.floor(h.t * 8) % 2); g.fillStyle = '#ffd23a'; g.fillRect(0, h.y - h.r, VW, h.r * 2); g.globalAlpha = 0.8; g.fillStyle = '#000'; for (let xx = -((h.t * 120) % 24); xx < VW; xx += 24) { g.beginPath(); g.moveTo(xx, h.y - h.r); g.lineTo(xx + 8, h.y - h.r); g.lineTo(xx + 20, h.y + h.r); g.lineTo(xx + 12, h.y + h.r); g.fill(); } g.restore(); } continue; }
      if (h.kind === 'shock') { g.save(); g.strokeStyle = '#1a1622'; g.lineWidth = 2; g.beginPath(); g.moveTo(x - 30, 0); g.quadraticCurveTo(x - 20, h.y - 70, x + Math.sin(G.time * 9) * 3, h.y - 4); g.stroke(); g.fillStyle = live ? '#ffffff' : '#5ae6ff'; g.fillRect(x - 2 + Math.sin(G.time * 9) * 3, h.y - 6, 4, 4); g.restore(); }
      g.save(); g.globalAlpha = live ? (h.kind === 'gas' ? 0.35 : 0.6) : 0.25 + 0.35 * k; g.strokeStyle = h.kind === 'gas' ? '#9aff4a' : h.kind === 'shock' ? '#5ae6ff' : '#ff5a2a'; g.fillStyle = h.kind === 'gas' ? 'rgba(120,255,60,0.25)' : h.kind === 'shock' ? (live && Math.floor(G.time * 20) % 2 ? 'rgba(200,250,255,0.35)' : 'rgba(60,200,255,0.2)') : 'rgba(255,60,30,0.18)'; g.lineWidth = 1.5;
      g.beginPath(); g.ellipse(x, h.y, h.r, h.r * 0.55, 0, 0, 7); g.fill(); g.stroke(); if (live && h.kind === 'shock') { g.strokeStyle = '#ffffff'; g.lineWidth = 1; g.beginPath(); let px = x - h.r * 0.8, py = h.y; g.moveTo(px, py); for (let i = 0; i < 7; i++) { px += h.r * 0.23; py = h.y + (Math.random() - 0.5) * h.r * 0.5; g.lineTo(px, py); } g.stroke(); } if (!live) { g.beginPath(); g.ellipse(x, h.y, h.r * k, h.r * 0.55 * k, 0, 0, 7); g.stroke(); } g.restore();
      if (h.spike && live) { g.fillStyle = '#d8d0e0'; for (let i = -2; i <= 2; i++) { g.beginPath(); g.moveTo(x + i * 7 - 3, h.y); g.lineTo(x + i * 7, h.y - 26 + Math.abs(i) * 5); g.lineTo(x + i * 7 + 3, h.y); g.fill(); } }
      else if (h.kind === 'debris' && !live && !h.quiet) { const fy = h.y - 200 * (1 - k * k); g.fillStyle = '#3a3048'; g.fillRect(x - 6, fy - 8, 12, 10); g.fillStyle = '#6a5a78'; g.fillRect(x - 6, fy - 8, 12, 2); }
      if (h.kind === 'gas' && live) RD.glow(g, x, h.y - 10, h.r * 1.4, '#7aff3a', 0.25);
    }
    if (G.superFx && G.superFx.v90 && window.Super90 && Super90.drawUnder) Super90.drawUnder(g, cam);
    /* contact shadows */
    for (const e of ents) { if (e.giant || e.kind === 'obj' && e.sub === 'statue') continue; const big = e.kind === 'boss' ? (e.def.wide ? 2.6 : 1.5) : e.def && e.def.heavy ? 1.3 : 1; ART.shadow(g, e.x - cam, e.y + 1, (e.kind === 'prop' ? 13 : 17) * big * depthScale(e.y) * (1 - Math.min(0.55, e.z / 150)), (e.dead ? 0.3 : 0.62) * (1 - Math.min(0.5, e.z / 200))); }
    for (const d of G.drops) { ART.shadow(g, d.x - cam, d.y, 6, 0.5); ART.item(g, d.type === 'fury' ? 'orb' : d.type, d.x - cam, d.y - d.z - 1 - Math.abs(Math.sin(d.t * 4)) * 2, { sc: 1 }); RD.glow(g, d.x - cam, d.y - d.z - 6, 12, d.type === 'vial' ? '#ff2040' : COLR.gold, 0.3); }
    if (M && M.drawEnts) M.drawEnts(g, cam);
    /* 9.5: gas clouds and feather bursts take their place in the depth order */
    if (window.V95) { V95.beginEnts(); V95.drawShut(g, cam); }
    for (const e of ents) { if (window.V95) V95.cloudsUpTo(g, cam, e.y); drawEnt(g, e, cam); }
    if (window.V95) V95.cloudsUpTo(g, cam, 1e9);
    if (G.superFx && G.superFx.v90 && window.Super90 && Super90.drawWorld) Super90.drawWorld(g, cam);
    /* x-ray: when a body in front covers the active hero, redraw him as a glowing outline + ghost so he never vanishes */
    { const pl = G.player, fr = pl && pl._lastFr; if (fr && !pl.dead && !G.cine && !G.superFx) {
      const H = entHeight(pl), occ = G.enemies.filter(e => !e.dead && e.y > pl.y + 3 && e.y - pl.y < 60 && Math.abs(e.x - pl.x) < (e.kind === 'boss' ? (e.def.wide ? 95 : 55) : 26) + 10);
      if (occ.length) {
        const x = pl.x - cam, y = pl.y - pl.z, sc = depthScale(pl.y), col = pl.id === 'lupus' ? (pl.form === 'a' ? '#ff2a40' : '#ffb02a') : HERO[pl.id].color;
        g.imageSmoothingEnabled = true;
        for (const [dx, dy] of [[-1.5, 0], [1.5, 0], [0, -1.5], [0, 1.5]]) ART.draw(g, fr, x + dx, y + dy, { face: pl.face, sc, tint: col, tintA: 1, alpha: 0.9 });
        ART.draw(g, fr, x, y, { face: pl.face, sc, alpha: 0.9, rims: ART.rimsAt(pl.x, pl.y, H, G.time) }); g.imageSmoothingEnabled = false;
        const ay = y - H * sc - 8 + Math.sin(G.time * 8) * 1.5; g.fillStyle = '#000'; g.beginPath(); g.moveTo(x - 5, ay - 1); g.lineTo(x + 5, ay - 1); g.lineTo(x, ay + 6); g.fill(); g.fillStyle = col; g.beginPath(); g.moveTo(x - 3.5, ay); g.lineTo(x + 3.5, ay); g.lineTo(x, ay + 4.5); g.fill();
      }
    } }
    if (G.superFx && !G.superFx.v90) { const S = G.superFx, k = Math.min(1, S.t / 0.2, (1.6 - S.t) / 0.2 + 0.0001); g.fillStyle = 'rgba(4,0,10,' + 0.7 * k + ')'; g.fillRect(-VW, -VH, VW * 3, VH * 3); for (const h of [S.p, S.a]) { const col = h.id === 'lupus' ? '#ff2a40' : HERO[h.id].color; RD.glow(g, h.x - cam, h.y - 50, 90, col, 0.45 * k); drawEnt(g, h, cam); } if (S.t > 0.7 && S.t < 1.1) { const q = (S.t - 0.7) / 0.4; g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = 1 - q; [S.p, S.a].forEach((h, i) => { g.fillStyle = h.id === 'lupus' ? '#ff2a40' : HERO[h.id].color; g.fillRect(0, h.y - 60 + i * 30 - 6 * (1 - q), VW, 8 + 20 * (1 - q)); }); g.restore(); } }
    if (ck > 0) { const h = G.cine.h, hx = h.x - cam, hy = h.y - 50; const gr = g.createRadialGradient(hx, hy, 30, hx, hy, 260); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(4,0,8,' + 0.78 * ck + ')'); g.fillStyle = gr; g.fillRect(cam - VW, -VH, VW * 3, VH * 3); g.fillStyle = gr; g.fillRect(-VW, -VH, VW * 3, VH * 3); drawEnt(g, h, cam); }
    for (const h of G.hz) if (h.kind === 'train' && h.t >= h.warn) { const k = (h.t - h.warn) / h.live, x = VW + 40 - k * (VW * 2.6); g.save(); g.fillStyle = '#0c0a14'; g.fillRect(x, h.y - 46, VW * 1.4, 52); g.fillStyle = '#3a3448'; g.fillRect(x, h.y - 46, VW * 1.4, 3); for (let i = 0; i < 14; i++) { g.fillStyle = i % 2 ? '#ffe9a0' : '#7af0ff'; g.fillRect(x + 20 + i * 60, h.y - 36, 26, 10); } g.fillStyle = '#ff2a40'; g.fillRect(x, h.y - 20, 6, 10); RD.glow(g, x + 4, h.y - 16, 40, '#fff2c0', 0.5); g.restore(); }
    for (const l of G.lines) { if (l.col) { const k = l.t / l.dur, x0 = l.x - cam + l.face * 20, len = l.len * Math.min(1, k * 5), y = l.y - l.z, w = (l.w || 4) * (1 - k * 0.7); g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = 1 - k * k; g.fillStyle = l.col; g.fillRect(Math.min(x0, x0 + l.face * len), y - w, len, w * 2); g.fillStyle = '#ffffff'; g.fillRect(Math.min(x0, x0 + l.face * len), y - w * 0.35, len, w * 0.7); RD.glow(g, x0, y, 18 * (1 - k), l.col, 0.6); g.restore(); continue; } const k = l.t / l.dur, x0 = l.x - cam + l.face * 14, len = l.len * Math.min(1, k * 3); g.save(); g.globalAlpha = 1 - k; g.strokeStyle = '#c8ccd8'; g.lineWidth = 2; g.setLineDash([3, 2]); g.beginPath(); g.moveTo(x0, l.y - l.z); g.lineTo(x0 + l.face * len, l.y - l.z + Math.sin(l.t * 40) * 2); g.stroke(); g.restore(); }
    for (const p of G.proj) drawProj(g, p, cam);
    for (const s of G.slashes) drawSlash(g, s, cam);
    for (const r of G.rings) { const k = r.t / r.dur; g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = 1 - k; g.strokeStyle = r.col; g.lineWidth = 3 * (1 - k) + 0.5; g.beginPath(); g.ellipse(r.x - cam, r.y - r.z, lerp(8, r.rmax, k), lerp(8, r.rmax, k) * 0.32, 0, 0, 7); g.stroke(); g.restore(); }
    for (const f of G.flashes) drawImpact(g, f, cam);
    if (window.FX94) FX94.draw(g, cam);
    for (const q of G.parts) {
      if (q.img) { ART.item(g, q.img, q.x - cam, q.y - q.z, { rot: q.rot, alpha: Math.min(1, 3 * (1 - q.t / q.life)), center: true }); continue; }
      if (q.glowP) { RD.glow(g, q.x - cam, q.y - q.z, 5, q.col, 0.8 * (1 - q.t / q.life)); }
      g.globalAlpha = q.dust ? 0.55 * (1 - q.t / q.life) : Math.min(1, 2 * (1 - q.t / q.life)); g.fillStyle = q.col; const s = q.size * (q.dust ? 1.5 : 0.75); g.fillRect(q.x - cam - s / 2, q.y - q.z - s / 2, s, s);
    }
    g.globalAlpha = 1;
    BG.front(g, cam);
    if (M && M.drawOver) M.drawOver(g, cam);
    drawSenses(g, cam);
    for (const q of G.texts) PIX.text(g, q.s, q.x - cam, q.y, { align: 'c', s: q.size, col: q.col });
    g.restore();
    BG.atmos(g, G.time);
    if (G.flashScr > 0) { g.fillStyle = 'rgba(255,40,70,' + G.flashScr * 0.28 + ')'; g.fillRect(0, 0, VW, VH); }
    if (G.superFx && G.superFx.v90) { if (window.Super90 && Super90.drawHUD) Super90.drawHUD(g); return; }
    if (G.superFx && G.superFx.t < 1.05) { drawSuperSplash(g); return; }
    const pl = G.player; if (pl.hp < pl.maxhp * 0.25 && !pl.dead) { const v = g.createRadialGradient(VW / 2, VH / 2, VH * 0.4, VW / 2, VH / 2, VH); v.addColorStop(0, 'rgba(160,0,20,0)'); v.addColorStop(1, 'rgba(160,0,20,' + (0.25 + 0.12 * Math.sin(G.time * 6)) + ')'); g.fillStyle = v; g.fillRect(0, 0, VW, VH); }
    if (G.superFx) { const S = G.superFx, bh = 30; g.fillStyle = '#000'; g.fillRect(0, 0, VW, bh); g.fillRect(0, VH - bh, VW, bh); PIX.text(g, S.duo && DUO[S.duo] ? T(DUO[S.duo].name) : T('super'), VW / 2, 9, { s: 2, align: 'c', grad: ['#ffffff', '#ffe08a', '#ff8a2a'] }); PIX.text(g, HERO[S.p.id].name + ' + ' + HERO[S.a.id].name, VW / 2, VH - 20, { align: 'c', col: COLR.white }); return; }
    if (G.cine || (G.cineBar || 0) > 0) { G.cineBar = G.cine ? Math.min(1, (G.cineBar || 0) + 0.08) : Math.max(0, G.cineBar - 0.08); }
    if (!(G.cineBar > 0.5)) { drawHUD(g); if (M && M.hud) M.hud(g); drawOverlays(g); drawTalk(g); drawControls(g); }
    if (G.panel) { drawPanel(g); return; }
    if (G.choice) { drawChoice(g); return; }
    if (G.cineBar > 0) { const bh = 26 * G.cineBar; g.fillStyle = '#000'; g.fillRect(0, 0, VW, bh); g.fillRect(0, VH - bh, VW, bh); if (G.cine && G.cine.h.xswap) { const f = G.cine.h.form; PIX.text(g, T(FORM[f].label) + '!', VW / 2, VH - bh / 2 - 7, { s: 2, align: 'c', col: f === 'a' ? '#ff2a40' : '#ffb02a' }); } }
    if (this.menu) { dim(g, 0.8); PIX.text(g, T('paused'), VW / 2, 30, { s: 3, align: 'c', col: COLR.red }); for (const b of this.btns) drawBtn(g, b); if (!G.mode) (CHAL[G.st.id] || []).forEach((c, i) => { const y = 214 + i * 12, ok = c.k === 'clear' ? false : c.k === 'combo' ? G.maxCombo >= c.n : c.k === 'tags' ? G.tags >= c.n : c.k === 'nohit' ? G.hurtCount <= c.n : c.k === 'noko' ? G.koCount === 0 : c.k === 'time' ? G.time <= c.n : false; drawStar(g, VW / 2 - 96, y + 3, 5, ok); PIX.text(g, chalText(c), VW / 2 - 86, y, { col: ok ? COLR.white : '#8a84a0', out: null }); }); }
  }
};
function drawSlash(g, s, cam) {
  const k = s.t / s.dur, x = s.x - cam, y = s.y - s.z; const R = s.size * (0.8 + 0.35 * k);
  g.save(); g.translate(x, y); if (s.face < 0) g.scale(-1, 1); g.rotate(s.ang); g.globalCompositeOperation = 'lighter';
  const a0 = -1.2 + k * 0.5, a1 = 1.15, th = Math.max(0.5, (1 - k) * R * 0.32);
  g.globalAlpha = (1 - k) * 0.9; g.fillStyle = s.col;
  g.beginPath(); g.arc(0, 0, R, a0, a1); g.arc(-th * 0.6, 0, R - th, a1, a0, true); g.closePath(); g.fill();
  g.globalAlpha = (1 - k); g.fillStyle = '#ffffff'; g.beginPath(); g.arc(0, 0, R, a0 + 0.2, a1 - 0.1); g.arc(-th * 0.15, 0, R - th * 0.3, a1 - 0.1, a0 + 0.2, true); g.closePath(); g.fill();
  g.restore();
}
function drawImpact(g, f, cam) {
  const k = f.t / f.dur, x = f.x - cam, y = f.y - f.z, R = (f.big ? 18 : 11) * (0.6 + k * 0.7);
  g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = 1 - k; g.strokeStyle = f.col; g.lineWidth = f.big ? 1.5 : 1;
  g.beginPath(); for (let i = 0; i < 8; i++) { const a = i / 8 * 6.28 + 0.3; const l0 = R * 0.3, l1 = i % 2 ? R * 0.6 : R; g.moveTo(x + Math.cos(a) * l0, y + Math.sin(a) * l0 * 0.8); g.lineTo(x + Math.cos(a) * l1, y + Math.sin(a) * l1 * 0.8); } g.stroke();
  g.restore(); RD.glow(g, x, y, R * 1.6, f.col === '#ffffff' ? '#ffe0c0' : f.col, 0.4 * (1 - k));
}
function drawProj(g, p, cam) {
  const x = p.x - cam, y = p.y - p.z, s = Math.sign(p.vx) || 1;
  RD.glow(g, x, y, p.r * 2 + 8, p.col, 0.4);
  g.save(); g.globalCompositeOperation = 'lighter';
  if (p.type === 'bolt') { g.fillStyle = p.col; g.fillRect(Math.min(x, x - s * 12), y - 1, 12, 2); g.fillStyle = '#fff'; g.fillRect(x - (s > 0 ? 4 : 0), y - 0.5, 4, 1); }
  else if (p.type === 'beam') { g.fillStyle = p.col; g.fillRect(Math.min(x, x - s * 70), y - 1.5, 70, 3); g.fillStyle = '#fff'; g.fillRect(Math.min(x, x - s * 66), y - 0.5, 66, 1); }
  else if (p.type === 'orb') { const r = p.r * (0.75 + 0.15 * Math.sin(p.t * 20)); const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.4, p.col); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); if (p.big) { g.strokeStyle = p.col; g.lineWidth = 1.5; g.beginPath(); g.arc(x, y, r * 1.1, p.t * 8, p.t * 8 + 4); g.stroke(); } }
  else if (p.type === 'wave') { g.translate(x, y); g.scale(s, 1); g.fillStyle = p.col; g.globalAlpha = 0.85; g.beginPath(); g.moveTo(-6, -30); g.quadraticCurveTo(22, -12, 4, 14); g.quadraticCurveTo(12, -12, -6, -30); g.fill(); g.fillStyle = '#ffffff'; g.globalAlpha = 0.7; g.beginPath(); g.moveTo(-2, -26); g.quadraticCurveTo(18, -10, 4, 10); g.quadraticCurveTo(10, -10, -2, -26); g.fill(); }
  else if (p.type === 'spike') { g.fillStyle = '#f2ece0'; g.beginPath(); g.moveTo(x + s * 9, y); g.lineTo(x - s * 6, y - 1.5); g.lineTo(x - s * 6, y + 1.5); g.fill(); g.fillStyle = '#ff1a3a'; g.fillRect(x + (s > 0 ? 5 : -7), y - 0.75, 2, 1.5); }
  else if (p.type === 'shock') { g.fillStyle = p.col; for (let i = -10; i <= 10; i++) g.fillRect(x + i * 2, p.y - Math.abs(Math.sin(p.t * 20 + i)) * 8, 1.5, 2); }
  g.restore();
}

/* ---------- HUD ---------- */
function drawHUD(g) {
  const p = G.player, a = G.ally, H = HERO[p.id];
  PIX.panel(g, 4, 4, 140, 38, { edge: H.color });
  drawFace(g, heroKey(p), 7, 7, 32);
  PIX.text(g, H.name, 42, 8, { col: COLR.white });
  if (p.id === 'lupus' && p.form === 'h') PIX.text(g, heroSpecLabel(p), 140, 8, { align: 'r', col: COLR.gold, out: '#000' });
  PIX.bar(g, 42, 18, 98, 7, p.hp / p.maxhp, '#ff2a40', '#2a0810');
  if (p.shieldHP > 0) { g.fillStyle = COLR.lime; g.fillRect(43, 18, Math.min(96, 96 * p.shieldHP / p.maxhp), 1); }
  if (p.id === 'lupus') { PIX.text(g, T('fury'), 42, 30, { col: COLR.gold, out: null }); const full = p.fury >= (p.form === 'h' ? 100 : 200); PIX.bar(g, 76, 30, 64, 6, p.form === 'x' ? p.hp / p.maxhp : p.fury / 300, full && Math.sin(G.time * 10) > 0 ? '#ffe05a' : COLR.gold, '#2a1a08', 3); }
  else { PIX.text(g, T('sp_' + p.id), 42, 30, { col: H.color, out: null }); PIX.bar(g, 94, 30, 46, 6, 1 - p.spCd / Math.max(0.1, hs(p).cd), H.color, '#1a1020'); }
  if (p.id === 'lupus') { const FL = G.fenrirT ? ['h', 'f', 'a', 'x'] : ['h', 'f', 'a']; FL.forEach((f, i) => { const cur = p.form === f; const x = VW / 2 - FL.length * 16 + 2 + i * 32;
    /* 9.4: the next form's picture lights up and pulses when the fury allows it — tap it to transform */
    const up = !cur && ((f === 'f' && p.form === 'h' && p.fury >= 100) || (f === 'a' && p.form !== 'a' && p.fury >= 200 && !(G.st && G.st.l44 && !G.mode))), pulse = 0.5 + 0.5 * Math.sin(G.time * 7);
    const fc = f === 'a' ? '#ff1a3a' : f === 'f' ? '#ff8a30' : '#e8e8f0';
    PIX.panel(g, x, 5, 28, 28, { edge: cur ? fc : up && pulse > 0.35 ? fc : '#3a3448', cut: 3, bg: 'rgba(10,6,18,0.8)' }); g.save(); if (!cur) g.globalAlpha = up ? 0.7 + 0.3 * pulse : f === 'h' ? 0.6 : 0.35; drawFace(g, f === 'x' ? 'fenrir' : f === 'h' && G.st.l44 && !G.mode ? 'lupus44' : 'lupus_' + f, x + 2, 7, 24); g.restore(); }); PIX.text(g, T(FORM[p.form].label), VW / 2, 37, { align: 'c', col: p.form === 'a' ? COLR.red : p.form === 'x' ? '#ffe080' : p.form === 'f' ? '#ff8a30' : '#c8c0d8' }); }
  if (a) {
    const ready = canTag(); g.save(); if (a.dead) g.globalAlpha = 0.5; PIX.panel(g, 4, 44, 108, 26, { edge: ready ? HERO[a.id].color : '#3a3448', cut: 3, bg: 'rgba(10,6,18,0.78)' }); drawFace(g, heroKey(a), 6, 46, 22); g.restore();
    PIX.text(g, HERO[a.id].name, 31, 48, { col: a.dead ? '#6a6480' : COLR.white, out: '#0c0710' }); PIX.bar(g, 31, 58, 76, 5, a.dead ? 0 : a.hp / a.maxhp, HERO[a.id].color, '#1a1020');
    if (a.dead) PIX.text(g, T('ko'), 108 - PIX.textW(T('ko'), 1), 48, { col: COLR.red }); else if (ready && Math.sin(G.time * 5) > 0) PIX.text(g, T('tag'), 108 - PIX.textW(T('tag'), 1), 48, { col: COLR.gold, out: '#0c0710' });
    if (!a.dead && G.assistCd > 0) { g.fillStyle = '#ffd23a'; g.fillRect(31, 65, Math.round(76 * (1 - G.assistCd / ASSIST_CD)), 1); }
    { const full = G.syn >= 100; PIX.text(g, full ? T('super') + '!' : T('synergy'), 6, 74, { col: full && Math.sin(G.time * 10) > 0 ? '#ffffff' : '#ffb02a', out: '#0c0710' }); PIX.bar(g, 6, 84, 106, 4, G.syn / 100, full ? '#ffe08a' : '#ff8a2a', '#2a1a08'); }
  }
  PIX.text(g, String(Math.round(G.score)).padStart(7, '0'), VW - 30, 8, { align: 'r', col: COLR.gold });
  { const sx = VW - 30 - PIX.textW('0000000', 1) - 14; g.fillStyle = '#b8e8ff'; g.beginPath(); g.arc(sx, 11, 4, 0, 7); g.fill(); g.fillStyle = '#0a0612'; g.beginPath(); g.arc(sx + 2, 10, 3.4, 0, 7); g.fill(); PIX.text(g, '' + G.shards, sx - 7, 8, { align: 'r', col: '#b8e8ff' }); }
  g.fillStyle = 'rgba(10,6,18,0.8)'; pixCircle(g, VW - 14, 14, 9); g.fillStyle = '#9a94ac'; g.fillRect(VW - 17, 10, 2, 8); g.fillRect(VW - 13, 10, 2, 8);
  { const status = G.mode === 'tutorial' ? T('training') : G.mode === 'endless' ? T('mode_endless') + ' - ' + T('wave') + ' ' + G.ew : G.mode === 'rush' ? T('mode_rush') + ' ' + (G.rushIdx + 1) + '/' + RUSH_N() : T('stage') + ' ' + G.st.id + ': ' + (G.st.name[SAVE.lang] || G.st.name.en);
    const left = p.id === 'lupus' ? VW / 2 + (G.fenrirT ? 4 : 3) * 16 + 8 : 154, width = Math.max(32, VW - 30 - left);
    let label = status; if (PIX.textW(label, 1) > width) { while (label.length > 1 && PIX.textW(label + '...', 1) > width) label = label.slice(0, -1); label += '...'; }
    PIX.text(g, label, VW - 30, 20, { align: 'r', col: '#c8c0d8', out: '#0c0710' }); }
  if (G.combo >= 3) { const rank = G.combo >= 40 ? 4 : G.combo >= 20 ? 3 : G.combo >= 10 ? 2 : G.combo >= 5 ? 1 : 0; const bump = G.comboT > 2.2 ? 1 : 0; /* 9.4: compact counter under the team cards, like the HUD combo of modern brawlers */ const nTxt = 'x' + G.combo; PIX.text(g, nTxt, 6, 97 - bump, { s: 2, col: '#ffb02a', out: '#0c0710' }); PIX.text(g, T('hits'), 9 + PIX.textW(nTxt, 2), 103, { col: COLR.white, out: '#0c0710' }); if (rank) PIX.text(g, T('combo')[rank], 6, 114, { col: COLR.red, out: '#0c0710' }); }
  const b = G.boss && !G.boss.dead ? G.boss : G.mini;
  const duelHUD90 = !!(window.Duel90 && Duel90.drawHUD && Duel90.drawHUD(g, b));
  if (!duelHUD90 && G.bosses) { const o = G.bosses.find(q => q !== b && !q.dead); if (o) { const w = Math.min(230, VW - 230), x = Math.round(VW / 2 - w / 2) + 12; PIX.bar(g, x, 69, w, 3, o.hp / o.maxhp, '#5a7aff', '#2a0810'); } }
  if (!duelHUD90 && b && !b.dead && b.bossIn <= 0) { const w = Math.min(230, VW - 230), x = Math.round(VW / 2 - w / 2) + 12; drawFace(g, b.key === 'nacht_big' ? 'nacht' : b.key, x - 26, 48, 22); PIX.text(g, b.def.name, VW / 2 + 12, 50, { align: 'c', col: COLR.white }); PIX.bar(g, x, 60, w, 7, b.hp / b.maxhp, '#c4001f', '#2a0810'); g.fillStyle = '#ffffff'; g.fillRect(x + Math.round(w / 2), 60, 1, 7); }
  else if (!duelHUD90 && G.lastE && G.lastET > 0 && !G.lastE.dead && G.lastE.kind === 'enemy') { const e = G.lastE; PIX.text(g, e.def.name, VW - 8, 34, { align: 'r', col: '#c8c0d8' }); PIX.bar(g, VW - 88, 44, 80, 5, e.hp / e.maxhp, '#ff2a40', '#2a0810'); }
}
function drawOverlays(g) {
  if (G.title > 0) {
    const k = G.title / 2.8, a = k > 0.85 ? (1 - k) / 0.15 : k < 0.2 ? k / 0.2 : 1;
    g.save(); g.globalAlpha = a; g.fillStyle = 'rgba(6,3,12,0.72)'; g.fillRect(0, VH / 2 - 44, VW, 88);
    PIX.text(g, T('stage') + ' 0' + G.st.id, VW / 2, VH / 2 - 36, { align: 'c', col: COLR.red });
    PIX.text(g, G.st.name[SAVE.lang], VW / 2, VH / 2 - 22, { align: 'c', s: 2, grad: ['#ffffff', '#c8ccd8', '#8a8ea0'] });
    PIX.text(g, G.st.sub[SAVE.lang], VW / 2, VH / 2 + 4, { align: 'c', col: '#b8b0c8' });
    PIX.text(g, T('objective') + ': ' + G.st.obj[SAVE.lang], VW / 2, VH / 2 + 20, { align: 'c', col: COLR.cyan }); g.restore();
  }
  if (G.banner) {
    const b = G.banner, k = b.t / 2.6, a = k < 0.1 ? k / 0.1 : k > 0.85 ? (1 - k) / 0.15 : 1;
    g.save(); g.globalAlpha = a; g.fillStyle = 'rgba(70,0,10,0.8)'; g.fillRect(0, 66, VW, 72); g.fillStyle = COLR.red; g.fillRect(0, 66, VW, 1); g.fillRect(0, 137, VW, 1);
    drawFace(g, b.boss.key, VW / 2 - 140, 70, 64);
    if (Math.sin(b.t * 14) > 0) PIX.text(g, '! ' + T('bossWarn') + ' !', VW / 2 + 30, 74, { align: 'c', col: '#ff5060' });
    PIX.text(g, b.boss.name, VW / 2 + 30, 92, { align: 'c', s: 2, col: COLR.white }); PIX.text(g, b.boss.sub, VW / 2 + 30, 118, { align: 'c', col: COLR.red }); g.restore();
  }
  if (G.mode === 'tutorial' && G.tut) { const T0 = G.tut, step = T0.steps[T0.i], n = T0.steps.length - 1; const w = Math.min(VW - 160, 330), x = VW / 2 - w / 2; PIX.panel(g, x, 96, w, 34, { edge: T0.flash > 0 ? '#7dff9a' : COLR.cyan }); PIX.text(g, T('training') + '  ' + Math.min(T0.i + 1, n) + '/' + n, VW / 2, 101, { align: 'c', col: COLR.cyan, out: null }); PIX.text(g, T(tutKey94(step)) + (step === 'spec' && G.player.form !== 'x' ? ': ' + heroSpecLabel(G.player) : ''), VW / 2, 115, { align: 'c', col: COLR.white });
    const map = { attack: 'atk', jump: 'jump', dash: 'dash', block: 'block', spec: 'spec', tag: 'tag', assist: 'assist', form: 'form', super: 'super' }, bn = map[step]; if (bn) { const b = BTN()[bn], ay = b.y - b.r - 14 + Math.sin(G.time * 8) * 3; g.fillStyle = '#000'; g.beginPath(); g.moveTo(b.x - 7, ay - 2); g.lineTo(b.x + 7, ay - 2); g.lineTo(b.x, ay + 8); g.fill(); g.fillStyle = '#7dff9a'; g.beginPath(); g.moveTo(b.x - 5, ay - 1); g.lineTo(b.x + 5, ay - 1); g.lineTo(b.x, ay + 6); g.fill(); }
    if (step === 'move') { const jx = Inp.joy.id != null ? Inp.joy.ox : 50, jy = Inp.joy.id != null ? Inp.joy.oy : 214, ay = jy - 46 + Math.sin(G.time * 8) * 3; g.fillStyle = '#7dff9a'; g.beginPath(); g.moveTo(jx - 5, ay - 1); g.lineTo(jx + 5, ay - 1); g.lineTo(jx, ay + 6); g.fill(); } }
  if (G.banner2) { const b = G.banner2, a = Math.min(1, b.t * 4, (2 - b.t) * 3); g.save(); g.globalAlpha = Math.max(0, a); g.fillStyle = 'rgba(80,40,0,0.7)'; g.fillRect(0, 100, VW, 22); PIX.text(g, '! ' + b.txt + ' !', VW / 2, 107, { align: 'c', col: '#ffc030' }); g.restore(); }
  const goMech = G.mech && MECH[G.mech], exitBlocked = !G.st.waves[G.waveIdx] && goMech && goMech.gate && goMech.gate();
  if (G.goT > 0 && !G.locked && !G.bossPending && !G.bossSpawned && !G.arena && !G.duelHold && !G.panel && !G.choice && !G.cine && !G.superFx && !G.over && !G.spawnQ.length && !enemiesAlive() && !exitBlocked && Math.sin(G.time * 8) > -0.2) PIX.text(g, T('go') + ' >', VW - 60, 120, { s: 2, col: COLR.gold });
  if (G.say) { const s = G.say; g.save(); g.globalAlpha = Math.min(1, G.sayT * 2); PIX.panel(g, VW / 2 - 130, VH - 54, 260, 34, { edge: HERO[s.w].color }); drawFace(g, ROSTER_KEY[s.w], VW / 2 - 127, VH - 51, 28); PIX.text(g, HERO[s.w].name, VW / 2 - 94, VH - 48, { col: HERO[s.w].color }); PIX.text(g, s[SAVE.lang], VW / 2 - 94, VH - 36, { col: COLR.white }); g.restore(); }
  if (G.hintT >= 5 && G.hintT < 10 && G.stage === 0 && G.ally) PIX.text(g, T('hintTag'), VW / 2, 70, { align: 'c', col: COLR.gold });
  if (G.hintT > 0 && G.hintT < 5 && G.stage === 0) PIX.text(g, G.player.id === 'lupus' && G.hintT < 2.5 ? T('hint2') : T('hint1'), VW / 2, 70, { align: 'c', col: '#c8c0d8' });
  { const fade = bossClearFade(); if (fade > 0) { g.fillStyle = 'rgba(0,0,0,' + fade + ')'; g.fillRect(0, 0, VW, VH); } }
  if (G.over > 0) { g.fillStyle = 'rgba(0,0,0,' + Math.min(0.9, G.over / 2) + ')'; g.fillRect(0, 0, VW, VH); }
}

/* ---------- touch controls ---------- */
const ctrlCache = {};
function ctrlDisc(r, col, held) {
  const k = r + col + held; if (ctrlCache[k]) return ctrlCache[k];
  const [c, g] = PIX.canvas(r * 2 + 4, r * 2 + 4); const o = r + 2;
  g.fillStyle = '#0a0612'; pixCircle(g, o, o, r + 1); g.fillStyle = col; pixCircle(g, o, o, r); g.fillStyle = held ? PIX.shade(col, 0.55) : 'rgba(12,8,22,1)'; pixCircle(g, o, o, r - 2);
  g.fillStyle = 'rgba(255,255,255,0.12)'; for (let yy = -r + 3; yy < -r / 3; yy++) { const w = Math.floor(Math.sqrt((r - 3) * (r - 3) - yy * yy)); g.fillRect(o - w, o + yy, w * 2, 1); }
  return ctrlCache[k] = c;
}
function icon(g, name, x, y, col) {
  g.fillStyle = col;
  if (name === 'atk') { for (let i = 0; i < 3; i++) for (let s = 0; s < 10; s++) g.fillRect(x - 6 + i * 4 + Math.round(s * 0.5), y - 5 + s, 2, 1); }
  else if (name === 'block') { g.fillRect(x - 5, y - 6, 10, 2); g.fillRect(x - 5, y - 6, 2, 7); g.fillRect(x + 3, y - 6, 2, 7); for (let s = 0; s < 5; s++) g.fillRect(x - 4 + s, y + 1 + s, 9 - s * 2, 1); }
  else if (name === 'jump') { for (let s = 0; s < 6; s++) g.fillRect(x - s, y - 4 + s, s * 2 + 1, 1); g.fillRect(x - 1, y + 2, 3, 4); }
  else if (name === 'dash') { for (const o of [-4, 1]) for (let s = 0; s < 5; s++) { g.fillRect(x + o + s, y - 5 + s, 2, 1); g.fillRect(x + o + s, y + 5 - s, 2, 1); } }
  else if (name === 'sense') { g.fillRect(x - 6, y - 1, 12, 2); g.fillRect(x - 4, y - 3, 8, 6); g.fillStyle = '#000'; g.fillRect(x - 1, y - 2, 2, 4); }
  else if (name === 'spec') { for (let i = 0; i < 8; i++) { const a = i / 8 * 6.28; for (let s = 2; s < (i % 2 ? 5 : 8); s++) g.fillRect(Math.round(x + Math.cos(a) * s), Math.round(y + Math.sin(a) * s), 1, 1); } g.fillRect(x - 1, y - 1, 3, 3); }
}
function drawControls(g) {
  if (G.over > 0 || Scenes.play.menu) return; const B = BTN(); const p = G.player;
  const j = Inp.joy; const jx = j.id != null ? Math.round(j.ox) : 50, jy = j.id != null ? Math.round(j.oy) : 214;
  g.save(); g.globalAlpha = j.id != null ? 0.75 : 0.4; g.drawImage(ctrlDisc(JOY.r, '#6a6480', false), jx - JOY.r - 2, jy - JOY.r - 2);
  const kx = j.id != null ? j.x : jx, ky = j.id != null ? j.y : jy; const dx = kx - jx, dy = ky - jy, dd = Math.hypot(dx, dy) || 1, m = Math.min(dd, JOY.r);
  g.globalAlpha = j.id != null ? 0.9 : 0.5; g.drawImage(ctrlDisc(13, '#c8c0d8', true), Math.round(jx + dx / dd * m) - 15, Math.round(jy + dy / dd * m) - 15); g.restore();
  const s = hs(p);
  const one = (n, col, ic, extra) => { const b = B[n], held = Inp.held[n]; g.save(); g.globalAlpha = held ? 0.9 : (G.boss && !G.boss.dead || G.mini ? 0.34 : 0.42); g.drawImage(ctrlDisc(b.r, col, held), b.x - b.r - 2, b.y - b.r - 2); if (ic) icon(g, ic, b.x, b.y, held ? '#ffffff' : col); if (extra) extra(b); g.restore(); };
  one('atk', '#ff2a40', 'atk'); one('jump', '#3af0ff', 'jump'); one('dash', '#c8c0d8', 'dash'); one('block', '#9ab4ff', 'block');
  if (senseOk()) one('sense', '#ff5070', 'sense', b => { const r = (G.sense == null ? 100 : G.sense) / 100; g.strokeStyle = G.sensing ? '#ffffff' : '#ff5070'; g.lineWidth = 2; g.beginPath(); g.arc(b.x, b.y, b.r + 3, -Math.PI / 2, -Math.PI / 2 + 6.283 * r); g.stroke(); if (G.mech === 'investigate' && !G.sensing && Math.sin(G.time * 6) > 0 && (G.clueN || 0) < 3) PIX.text(g, T('senseTxt'), b.x, b.y - b.r - 11, { align: 'c', col: '#ff5070', out: '#000' }); });
  one('spec', COLR.gold, 'spec', b => { const r = p.spCd / s.cd; if (r > 0) { g.fillStyle = 'rgba(0,0,0,0.6)'; g.beginPath(); g.moveTo(b.x, b.y); g.arc(b.x, b.y, b.r - 2, -Math.PI / 2, -Math.PI / 2 + 6.283 * r); g.closePath(); g.fill(); } });
  { const a = G.ally; if (a && !a.dead) {
      const face = (n, ok, cdk, col) => one(n, ok ? col : '#5a5470', null, b => { g.save(); g.beginPath(); g.arc(b.x, b.y, b.r - 3, 0, 7); g.clip(); if (!ok) g.globalAlpha = 0.45; drawFace(g, heroKey(a), b.x - b.r + 3, b.y - b.r + 3, (b.r - 3) * 2); g.restore(); if (cdk > 0) { g.fillStyle = 'rgba(0,0,0,0.6)'; g.beginPath(); g.moveTo(b.x, b.y); g.arc(b.x, b.y, b.r - 2, -Math.PI / 2, -Math.PI / 2 + 6.283 * cdk); g.closePath(); g.fill(); } const L = T(n); PIX.text(g, L, b.x, b.y + b.r + 1, { align: 'c', col: ok ? col : '#8a84a0', out: '#000' }); });
      face('tag', canTag(), G.tagCd / TAG_CD, HERO[a.id].color); face('assist', canAssist(), G.assistCd / ASSIST_CD, COLR.gold);
  } }
  if (canSuper()) one('super', '#ffe08a', 'spec', b => { g.strokeStyle = '#ffe08a'; g.lineWidth = 1; g.beginPath(); g.arc(b.x, b.y, b.r + 2 + Math.sin(G.time * 10) * 2, 0, 7); g.stroke(); PIX.text(g, T('super'), b.x, b.y + b.r + 1, { align: 'c', col: '#ffe08a', out: '#000' }); });
  if (p.id === 'lupus') { const p44 = G.st && G.st.l44 && !G.mode; const ready = p.form === 'h' ? p.fury >= 100 : p.form === 'f' ? (p.fury >= 200 && !p44) : false; one('form', ready ? '#ffd23a' : '#7a6a40', null, b => { const nf = p.form === 'h' ? 'lupus_f' : 'lupus_a'; g.save(); g.beginPath(); g.arc(b.x, b.y, b.r - 3, 0, 7); g.clip(); if (!ready) g.globalAlpha *= 0.45; drawFace(g, nf, b.x - b.r + 3, b.y - b.r + 3, (b.r - 3) * 2); g.restore(); if (ready && Math.sin(G.time * 10) > 0) { g.strokeStyle = '#ffd23a'; g.lineWidth = 1; g.beginPath(); g.arc(b.x, b.y, b.r + 3, 0, 7); g.stroke(); } }); }
}

/* =========================== GAME OVER =========================== */
Scenes.over = {
  t: 0, btns: [],
  enter() { this.t = 0; sfx('die'); musicStart('gameover'); },
  update(dt) { this.t += dt; const ck = G && G.mode !== 'endless' && G.mode !== 'rush' && G.ck > 0; this.btns = (ck ? [btn('ck', VW / 2 - 80, 146, 160, 18, T('checkpoint'), COLR.gold)] : []).concat([btn('retry', VW / 2 - 80, 170, 160, 18, T('retry'), COLR.red), btn('menu', VW / 2 - 80, 194, 160, 18, T('menu'), COLR.gray)]); },
  draw(g) { BG.back(g, G ? G.camX : 0, 0); dim(g, 0.78); ART.draw(g, ART.frame(heroKey(G.player), 'down', 0), VW / 2, 148, { face: 1 }); PIX.text(g, T('gameOver'), VW / 2, 44, { s: 4, align: 'c', col: COLR.red }); PIX.text(g, T('goLine'), VW / 2, 86, { align: 'c', col: '#b8b0c8' }); for (const b of this.btns) drawBtn(g, b); },
  onDown(id, x, y) { const b = hitB(this.btns, x, y); if (!b) return; sfx('ok'); if (b.id === 'ck') Scene.go('play', { stage: G.stage, fromWave: G.ck }); else if (b.id === 'retry') Scene.go('play', Object.assign({}, Scenes.play.arg, { fromWave: 0 })); else Scene.go(G.mode ? 'lair' : 'stages'); }
};

/* =========================== CLEAR: results, challenges, upgrade =========================== */
function drawStar(g, x, y, r, on) { g.save(); g.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r; g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } g.closePath(); g.fillStyle = on ? '#ffd23a' : 'rgba(60,50,80,0.9)'; g.fill(); g.strokeStyle = '#0a0612'; g.lineWidth = 1; g.stroke(); g.restore(); }
function drawShard(g, x, y) { g.fillStyle = '#b8e8ff'; g.beginPath(); g.arc(x, y, 4, 0, 7); g.fill(); g.fillStyle = '#0a0612'; g.beginPath(); g.arc(x + 2, y - 1, 3.4, 0, 7); g.fill(); }
const UP_MAX = 5;
Scenes.clear = {
  t: 0, res: null, step: 0, cards: [], btn: null, opts: [],
  enter(res) { this.res = res; this.t = 0; this.step = 0; sfx('ok'); musicStart('victory'); if (typeof voice === 'function' && G && G.player) voice(G.player.id + '_victory', 0); this.opts = ['dmg', 'hp', 'fury', 'cd'].filter(k => (SAVE.up[k] || 0) < UP_MAX).sort(() => Math.random() - 0.5).slice(0, 3); musicStart(5); saveGame(); },
  update(dt) {
    this.t += dt; const cw = 110, gap = 10, x0 = Math.round((VW - (cw * 3 + gap * 2)) / 2) + 30; this.cards = this.opts.map((o, i) => ({ id: o, x: x0 + i * (cw + gap), y: 96, w: cw, h: 100 }));
    const last = this.res.stage >= 4; this.btn = btn('go', VW / 2 - 40, 226, 150, 18, this.step === 0 ? T('next') + ' >' : last ? T('theEnd') + ' >' : T('stages') + ' >', COLR.red);
  },
  draw(g) {
    BG.back(g, WORLD_W - VW, 1 / 60); dim(g, 0.62);
    const hk = heroKey(G.player); g.imageSmoothingEnabled = true; ART.draw(g, ART.frame(hk, 'win', Math.floor(this.t * 7)), 58, 252, { face: 1, rims: ART.rimsAt(WORLD_W - VW + 58, 252, 80, this.t) }); g.imageSmoothingEnabled = false;
    PIX.text(g, T('clear'), VW / 2, 14, { s: 3, align: 'c', grad: ['#ffffff', '#ff8090', '#ff2a40'] });
    const R = this.res;
    PIX.text(g, T('score') + ' ' + R.score + '   ' + T('time') + ' ' + fmtTime(R.time) + '   ' + T('maxCombo') + ' ' + R.combo, VW / 2, 46, { align: 'c', col: COLR.white });
    if (this.step === 0) {
      PIX.panel(g, VW / 2 - 150, 62, 300, 92, { edge: COLR.gold }); PIX.text(g, T('challenges'), VW / 2, 68, { align: 'c', col: COLR.gold });
      (R.chal || []).forEach((r, i) => { const y = 86 + i * 20, k = Math.min(1, Math.max(0, (this.t - 0.4 - i * 0.35) * 4)); drawStar(g, VW / 2 - 132, y + 3, 7 * (r.ok ? 0.6 + 0.4 * k : 1), r.ok && k > 0); PIX.text(g, chalText(r.c), VW / 2 - 118, y, { col: r.ok ? COLR.white : '#7a7490', out: null }); if (r.ok && !r.was && k >= 1) PIX.text(g, T('newTag'), VW / 2 + 140, y, { align: 'r', col: '#7dff9a', out: null }); });
      PIX.panel(g, VW / 2 - 150, 160, 300, 56, { edge: '#5a5470' });
      drawShard(g, VW / 2 - 132, 172); PIX.text(g, T('shards') + ': +' + (R.shards + (R.bonus || 0)) + (R.bonus ? '  (' + T('challenges') + ' +' + R.bonus + ')' : ''), VW / 2 - 120, 169, { col: '#b8e8ff', out: null });
      [SAVE.hero, SAVE.ally].forEach((id, i) => { const lv = heroLv(id), xp = (SAVE.xp || {})[id] || 0, a = xpFor(lv), b = xpFor(Math.min(LV_MAX, lv + 1)); const y = 184 + i * 14; PIX.text(g, HERO[id].name + ' ' + T('lv') + ' ' + lv, VW / 2 - 132, y, { col: HERO[id].color, out: null }); PIX.bar(g, VW / 2 - 30, y, 170, 5, lv >= LV_MAX ? 1 : (xp - a) / Math.max(1, b - a), HERO[id].color, '#1a1020'); });
      drawBtn(g, this.btn, Math.sin(this.t * 5) > 0);
    } else if (this.step === 1) {
      PIX.text(g, T('pickUp'), VW / 2 + 30, 78, { align: 'c', col: COLR.gold });
      for (const k of this.cards) { PIX.panel(g, k.x, k.y, k.w, k.h, { edge: COLR.red }); const ic = { dmg: 'atk', hp: 'vial', fury: 'orb', cd: 'spec' }[k.id]; if (ic === 'atk' || ic === 'spec') { g.fillStyle = 'rgba(255,40,64,0.15)'; pixCircle(g, k.x + k.w / 2, k.y + 26, 15); icon(g, ic, k.x + k.w / 2, k.y + 26, COLR.red); } else ART.item(g, ic, k.x + k.w / 2, k.y + 34, { sc: 1.6 }); PIX.wrap(T('up_' + k.id), k.w - 8, 1).forEach((l, n) => PIX.text(g, l, k.x + k.w / 2, k.y + 52 + n * 9, { align: 'c', col: COLR.white, out: null })); PIX.text(g, T('up_' + k.id + '_d'), k.x + k.w / 2, k.y + 76, { align: 'c', col: COLR.gold, out: null }); for (let n = 0; n < UP_MAX; n++) { g.fillStyle = n < (SAVE.up[k.id] || 0) ? COLR.gold : '#3a3448'; g.fillRect(k.x + k.w / 2 - 24 + n * 10, k.y + 88, 8, 4); } }
    } else drawBtn(g, this.btn, Math.sin(this.t * 5) > 0);
  },
  onDown(id, x, y) {
    if (!this.btn) return;
    if (this.step === 0) { if (hitB([this.btn], x, y) || this.t > 0.6) { sfx('ok'); this.step = this.opts.length ? 1 : 2; } return; }
    if (this.step === 1) { for (const k of this.cards) if (x >= k.x && x <= k.x + k.w && y >= k.y && y <= k.y + k.h) { SAVE.up[k.id] = (SAVE.up[k.id] || 0) + 1; saveGame(); sfx('ok'); this.step = 2; return; } return; }
    if (hitB([this.btn], x, y)) { sfx('ok'); if (this.res.stage === ACT2 - 1) playCut('ending', () => playCut('act2', () => Scene.go('stages', { act: 2 }))); else if (this.res.stage >= STAGES.length - 1) playCut('finale', () => Scene.go('end', { final: true })); else Scene.go('stages'); }
  },
  onKey(k) { if (k === 'ok') this.onDown(0, this.btn.x + 2, this.btn.y + 2); }
};

/* =========================== THE LAIR (spend Moon Shards) =========================== */
let RUSH_N = () => SAVE.unlocked > ACT2 ? STAGES.length : ACT2;
const LAIR_UP_MAX = 8, PAL_COST = 40, MODE_COST = { endless: 40, rush: 60 };
const upCost = k => 25 + 15 * (SAVE.up[k] || 0);
function startMode(m) { SAVE.pendingMode = null; saveGame(); if (m === 'rush') Scene.go('play', { stage: 0, mode: 'rush', rushIdx: 0 }); else Scene.go('play', { stage: Math.floor(Math.random() * (SAVE.unlocked > ACT2 ? STAGES.length : 5)), mode: 'endless' }); }
function galleryPages() {
  const out = [], st = SAVE.stars || {};
  const ok = id => { let m; if (id === 'intro') return true; if ((m = /^s(\d+)pre$/.exec(id))) return SAVE.unlocked >= +m[1]; if ((m = /^s(\d+)post$/.exec(id))) return !!st[+m[1]]; if (id === 'ending' || id === 'act2') return !!st[5]; if (id === 'finale') return !!st[10]; return false; };
  for (const id in CUTS) if (ok(id)) for (const pg of CUTS[id]) for (const p of pg) if (COMIC.has(p.img) && !out.includes(p.img)) out.push(p.img);
  return out;
}
Scenes.lair = {
  t: 0, tab: 0, msg: null, view: -1,
  enter() { this.t = 0; this.view = -1; COMIC.load(); BG.set(3); musicStart(5); },
  update(dt) { this.t += dt; if (this.msg) { this.msg.t -= dt; if (this.msg.t <= 0) this.msg = null; } this.layout(); },
  say(txt, col) { this.msg = { txt, col: col || COLR.gold, t: 1.6 }; },
  buy(cost) { if ((SAVE.shards || 0) < cost) { sfx('ui'); this.say(T('noShards'), COLR.red); return false; } SAVE.shards -= cost; saveGame(); sfx('pick'); return true; },
  layout() {
    const B = this.btns = [btn('back', 6, 6, 62, 16, T('back'), COLR.gray)];
    const tabs = [T('upgrades'), T('colors'), T('gallery'), T('modes')], tw = Math.min(118, (VW - 40) / 4);
    tabs.forEach((l, i) => B.push(Object.assign(btn('tab' + i, VW / 2 - tw * 2 + i * tw + 2, 28, tw - 4, 16, l, i === this.tab ? COLR.red : '#5a5470'))));
    this.items = [];
    if (this.tab === 0) ['dmg', 'hp', 'fury', 'cd'].forEach((k, i) => { const lv = SAVE.up[k] || 0, y = 54 + i * 52; this.items.push({ kind: 'up', k, x: 24, y, w: VW - 48, h: 46, lv, b: lv < LAIR_UP_MAX ? btn('u_' + k, VW - 140, y + 15, 104, 16, upCost(k) + '', (SAVE.shards || 0) >= upCost(k) ? COLR.gold : '#5a5470') : null }); });
    else if (this.tab === 1) ROSTER.filter(heroOpen).forEach((id, i, a) => { const cw = (VW - 24) / a.length; this.items.push({ kind: 'pal', id, x: 12 + i * cw, y: 52, w: cw - 4, h: 208 }); });
    else if (this.tab === 2) { const pages = this.pages = galleryPages(); const cols = 6, cw = (VW - 40) / cols; pages.forEach((img, i) => this.items.push({ kind: 'gal', img, i, x: 20 + (i % cols) * cw, y: 52 + Math.floor(i / cols) * 54 - (this.scroll || 0), w: cw - 6, h: 48 })); }
    else { this.items.push({ kind: 'tut', b: btn('m_tut', VW / 2 - 70, 240, 140, 18, T('training'), COLR.cyan) }); }
    if (this.tab === 3) ['endless', 'rush'].forEach((m, i) => { const cw = (VW - 60) / 2, x = 20 + i * (cw + 20), own = !!(SAVE.owned || {})[m]; this.items.push({ kind: 'mode', m, x, y: 54, w: cw, h: 176, own, b: btn('m_' + m, x + cw / 2 - 60, 204, 120, 18, own ? T('play') : MODE_COST[m] + '', own ? COLR.red : (SAVE.shards || 0) >= MODE_COST[m] ? COLR.gold : '#5a5470') }); });
  },
  draw(g) {
    BG.menu(g, 3, this.t, this.t * 8); dim(g, 0.72);
    PIX.text(g, T('lair'), VW / 2, 8, { s: 2, align: 'c', col: COLR.red });
    drawShard(g, VW - 70, 13); PIX.text(g, '' + (SAVE.shards || 0), VW - 60, 10, { col: '#b8e8ff' });
    for (const b of this.btns) drawBtn(g, b);
    for (const it of this.items) {
      if (it.kind === 'up') { PIX.panel(g, it.x, it.y, it.w, it.h, { edge: '#5a5470' }); PIX.text(g, T('up_' + it.k), it.x + 10, it.y + 8, { col: COLR.white }); PIX.text(g, T('up_' + it.k + '_d'), it.x + 10, it.y + 20, { col: COLR.gold, out: null }); for (let n = 0; n < LAIR_UP_MAX; n++) { g.fillStyle = n < it.lv ? COLR.gold : '#3a3448'; g.fillRect(it.x + 10 + n * 14, it.y + 33, 11, 5); } if (it.b) { drawBtn(g, it.b); drawShard(g, it.b.x + 14, it.b.y + 8); } else PIX.text(g, 'MAX', VW - 88, it.y + 19, { align: 'c', col: COLR.gold }); }
      else if (it.kind === 'pal') { const H = HERO[it.id], cur = (SAVE.pal || {})[it.id] || 0; PIX.panel(g, it.x, it.y, it.w, it.h, { edge: H.color }); PIX.text(g, H.name, it.x + it.w / 2, it.y + 6, { align: 'c', col: H.color });
        const key = ROSTER_KEY[it.id], fr = ART.frame(key, 'idle', Math.floor(this.t * 7)); ART.useLook(MENU_LOOK); g.imageSmoothingEnabled = true; ART.draw(g, fr, it.x + it.w / 2, it.y + 122, { face: 1, sc: Math.min(1, 100 / window.ATLAS[key].h), pal: cur }); g.imageSmoothingEnabled = false;
        it.sw = []; for (let n = 0; n < 4; n++) { const own = n === 0 || !!(SAVE.owned || {})['pal_' + it.id + '_' + n], sx = it.x + 8 + n * ((it.w - 16) / 4), sw = (it.w - 16) / 4 - 4, sy = it.y + 134; it.sw.push({ n, x: sx, y: sy, w: sw, h: 44, own }); PIX.panel(g, sx, sy, sw, 44, { edge: n === cur ? '#ffffff' : own ? H.color : '#3a3448', cut: 2 }); g.save(); g.beginPath(); g.rect(sx + 2, sy + 2, sw - 4, 40); g.clip(); g.imageSmoothingEnabled = true; ART.draw(g, ART.frame(key, 'idle', 0), sx + sw / 2, sy + 62, { face: 1, sc: 0.62, pal: n }); g.restore(); g.imageSmoothingEnabled = false; if (!own) { g.fillStyle = 'rgba(0,0,0,0.55)'; g.fillRect(sx + 1, sy + 1, sw - 2, 42); drawShard(g, sx + sw / 2 - 8, sy + 22); PIX.text(g, '' + PAL_COST, sx + sw / 2 - 2, sy + 19, { col: '#b8e8ff', out: null }); } }
        PIX.text(g, T('pal' + cur), it.x + it.w / 2, it.y + 186, { align: 'c', col: '#c8c0d8', out: null }); }
      else if (it.kind === 'gal') { if (it.y < 48 || it.y > VH - 20) continue; const im = COMIC.img[it.img]; g.fillStyle = '#000'; g.fillRect(it.x - 1, it.y - 1, it.w + 2, it.h + 2); const sc = Math.max(it.w / im.width, it.h / im.height); g.save(); g.beginPath(); g.rect(it.x, it.y, it.w, it.h); g.clip(); g.imageSmoothingEnabled = true; g.drawImage(im, it.x + (it.w - im.width * sc) / 2, it.y + (it.h - im.height * sc) / 2, im.width * sc, im.height * sc); g.restore(); g.imageSmoothingEnabled = false; }
      else if (it.kind === 'tut') drawBtn(g, it.b);
      else if (it.kind === 'mode') { PIX.panel(g, it.x, it.y, it.w, it.h, { edge: it.m === 'rush' ? COLR.red : COLR.cyan }); PIX.text(g, T('mode_' + it.m), it.x + it.w / 2, it.y + 10, { s: 2, align: 'c', col: it.m === 'rush' ? COLR.red : COLR.cyan }); PIX.wrap(T('mode_' + it.m + '_d'), it.w - 20, 1).forEach((l, n) => PIX.text(g, l, it.x + it.w / 2, it.y + 40 + n * 10, { align: 'c', col: COLR.white, out: null }));
        if (it.m === 'rush') ['warden', 'voss', 'prime', 'nacht', 'beast'].forEach((k, n) => drawFace(g, k, it.x + it.w / 2 - 82 + n * 34, it.y + 92, 30)); else ['zealot', 'knight', 'zealot'].forEach((k, n) => { g.save(); g.globalAlpha = n === 1 ? 1 : 0.6; drawFace(g, k, it.x + it.w / 2 - 54 + n * 38, it.y + (n === 1 ? 86 : 94), n === 1 ? 36 : 28); g.restore(); });
        const best = (SAVE.best || {})[it.m]; if (best != null) PIX.text(g, T('best') + ': ' + (it.m === 'rush' ? fmtTime(best) : T('wave') + ' ' + best), it.x + it.w / 2, it.y + 134, { align: 'c', col: COLR.gold }); drawBtn(g, it.b); if (!it.own) drawShard(g, it.b.x + 14, it.b.y + 9); }
    }
    if (this.tab === 2 && !this.items.length) PIX.text(g, T('locked'), VW / 2, 140, { align: 'c', col: COLR.gray });
    if (this.view >= 0) { const im = COMIC.img[this.pages[this.view]]; g.fillStyle = 'rgba(0,0,0,0.95)'; g.fillRect(0, 0, VW, VH); const sc = Math.min((VW - 20) / im.width, (VH - 20) / im.height); g.imageSmoothingEnabled = true; g.drawImage(im, (VW - im.width * sc) / 2, (VH - im.height * sc) / 2, im.width * sc, im.height * sc); g.imageSmoothingEnabled = false; PIX.text(g, (this.view + 1) + '/' + this.pages.length, VW / 2, VH - 9, { align: 'c', col: COLR.gray }); PIX.text(g, '<', 8, VH / 2, { s: 2, col: COLR.white }); PIX.text(g, '>', VW - 18, VH / 2, { s: 2, col: COLR.white }); }
    if (this.msg) PIX.text(g, this.msg.txt, VW / 2, VH - 12, { align: 'c', col: this.msg.col });
  },
  onDown(id, x, y) {
    if (this.view >= 0) { if (x < VW * 0.25) this.view = Math.max(0, this.view - 1); else if (x > VW * 0.75) this.view = Math.min(this.pages.length - 1, this.view + 1); else this.view = -1; sfx('ui'); return; }
    const b = hitB(this.btns, x, y);
    if (b) { sfx('ui'); if (b.id === 'back') Scene.go('title'); else { this.tab = +b.id.slice(3); this.scroll = 0; } return; }
    for (const it of this.items) {
      if (it.kind === 'up' && it.b && hitB([it.b], x, y)) { if (this.buy(upCost(it.k))) { SAVE.up[it.k] = (SAVE.up[it.k] || 0) + 1; saveGame(); this.say(T('up_' + it.k) + ' +1'); } return; }
      if (it.kind === 'pal' && it.sw) for (const sw of it.sw) if (x >= sw.x && x <= sw.x + sw.w && y >= sw.y && y <= sw.y + sw.h) { if (!sw.own) { if (!this.buy(PAL_COST)) return; SAVE.owned = SAVE.owned || {}; SAVE.owned['pal_' + it.id + '_' + sw.n] = true; } SAVE.pal = SAVE.pal || {}; SAVE.pal[it.id] = sw.n; saveGame(); sfx('ok'); return; }
      if (it.kind === 'gal' && x >= it.x && x <= it.x + it.w && y >= it.y && y <= it.y + it.h) { this.view = it.i; sfx('ok'); return; }
      if (it.kind === 'tut' && hitB([it.b], x, y)) { sfx('ok'); Scene.go('play', { stage: 0, mode: 'tutorial', next: 'lair' }); return; }
      if (it.kind === 'mode' && hitB([it.b], x, y)) { if (!it.own) { if (this.buy(MODE_COST[it.m])) { SAVE.owned = SAVE.owned || {}; SAVE.owned[it.m] = true; saveGame(); this.say(T('unlocked')); } return; } sfx('ok'); SAVE.pendingMode = it.m; Scene.go('select'); return; }
    }
  },
  onMove(id, x, y) { },
  onKey(k) { if (k === 'ok' && this.view >= 0) this.view = -1; }
};
Scenes.modeEnd = {
  t: 0, r: null, btns: [],
  enter(r) { this.r = r; this.t = 0; musicStart(5); sfx(r.win ? 'ok' : 'die'); },
  update(dt) { this.t += dt; this.btns = [btn('again', VW / 2 - 80, 196, 160, 18, T('retry'), COLR.red), btn('lair', VW / 2 - 80, 220, 160, 18, T('lair'), COLR.gray)]; },
  draw(g) {
    BG.back(g, G ? G.camX : 0, 0); dim(g, 0.8); const r = this.r;
    PIX.text(g, T('mode_' + r.mode), VW / 2, 26, { s: 3, align: 'c', col: r.mode === 'rush' ? COLR.red : COLR.cyan });
    PIX.text(g, r.mode === 'rush' ? (r.win ? T('rushDone') : T('gameOver')) : T('nightFell'), VW / 2, 62, { s: 2, align: 'c', col: COLR.white });
    const lines = r.mode === 'endless' ? [T('wave') + ': ' + r.wave, T('score') + ': ' + r.score] : [T('bossesDown') + ': ' + r.bosses + '/5', T('time') + ': ' + fmtTime(r.time), T('score') + ': ' + r.score];
    lines.forEach((l, i) => PIX.text(g, l, VW / 2, 96 + i * 14, { align: 'c', col: '#c8c0d8' }));
    if (r.record) PIX.text(g, T('newRecord'), VW / 2, 96 + lines.length * 14 + 4, { align: 'c', col: COLR.gold });
    drawShard(g, VW / 2 - 50, 172); PIX.text(g, T('shards') + ' +' + (r.shards + r.bonus), VW / 2 - 40, 169, { col: '#b8e8ff' });
    for (const b of this.btns) drawBtn(g, b);
  },
  onDown(id, x, y) { const b = hitB(this.btns, x, y); if (!b) return; sfx('ok'); if (b.id === 'again') startMode(this.r.mode); else Scene.go('lair'); }
};

/* =========================== ENDING =========================== */
Scenes.end = {
  t: 0,
  enter(o) { this.t = 0; this.mus = false; this.fin = !!(o && o.final); BG.set(this.fin ? 7 : 1); musicStart(this.fin ? 'victory' : 5); },
  update(dt) { this.t += dt; if (this.fin && this.t > 7.5 && !this.mus) { this.mus = true; musicStart(5); } },
  draw(g) {
    const cam = 200 + this.t * 6; BG.back(g, cam, 1 / 60);
    menuCast(g, (this.fin ? TITLE_CAST.concat([['echo', -186, 238, 1, 4], ['brann', 196, 246, -1, 5]]) : TITLE_CAST).map(([k, dx, y, f, o]) => ({ k, an: 'win', x: VW / 2 + dx, y, f, o })), this.t, 1, cam);
    BG.front(g, cam); BG.atmos(g, this.t);
    const gr = g.createLinearGradient(0, 0, 0, 140); gr.addColorStop(0, 'rgba(6,3,12,0.85)'); gr.addColorStop(1, 'rgba(6,3,12,0)'); g.fillStyle = gr; g.fillRect(0, 0, VW, 140);
    PIX.text(g, T('theEnd'), VW / 2, 14, { s: 4, align: 'c', col: COLR.red });
    PIX.text(g, T(this.fin ? 'end1b' : 'end1'), VW / 2, 56, { align: 'c', col: COLR.white }); PIX.wrap(T(this.fin ? 'end2b' : 'end2'), VW - 40, 1).forEach((l, i) => PIX.text(g, l, VW / 2, 70 + i * 11, { align: 'c', col: '#c8c0d8' }));
    PIX.text(g, T('thanks'), VW / 2, 104, { align: 'c', col: COLR.gold });
    if (this.t > 3 && Math.sin(this.t * 4) > 0) PIX.text(g, T('tapNext'), VW / 2, VH - 12, { align: 'c', col: '#c8c0d8' });
  },
  onDown() { if (this.t > 2) { sfx('ok'); Scene.go('title'); } }
};

function setLang(c) {
  if (!I18N[c]) return false;
  const previous = SAVE.lang; SAVE.lang = c; SAVE.langSet = true; SAVE.langV9 = true;
  applyLang(); document.documentElement.lang = c === 'pt' ? 'pt-BR' : c; saveGame();
  if (window.Dialogue9) Dialogue9.languageChanged(previous);
  return true;
}
