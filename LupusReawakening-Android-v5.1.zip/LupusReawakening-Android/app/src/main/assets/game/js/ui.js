'use strict';
/* =====================================================================
   UI + SCENES + ENTITY RENDERING (world space 270 tall, buffer 2x)
   ===================================================================== */
const COLR = { red: '#ff2a40', cyan: '#3af0ff', lime: '#a7ff1a', gold: '#ffb02a', pink: '#ff3ad0', white: '#f2eef8', gray: '#9a94ac', dark: '#0a0612' };
function btn(id, x, y, w, h, label, col) { return { id, x: Math.round(x), y: Math.round(y), w, h, label, col: col || COLR.red }; }
function drawBtn(g, b, hot) { PIX.panel(g, b.x, b.y, b.w, b.h, { edge: b.col, bg: hot ? 'rgba(40,10,24,0.92)' : 'rgba(10,6,18,0.86)' }); PIX.text(g, b.label, b.x + b.w / 2, b.y + Math.round(b.h / 2) - 3, { col: COLR.white, align: 'c', s: b.s || 1 }); }
const hitB = (list, x, y) => list.find(b => x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h);
function dim(g, a) { g.fillStyle = 'rgba(6,3,12,' + a + ')'; g.fillRect(0, 0, VW, VH); }
function pixCircle(g, cx, cy, r) { for (let yy = -r; yy <= r; yy++) { const w = Math.floor(Math.sqrt(r * r - yy * yy)); g.fillRect(cx - w, cy + yy, w * 2 + 1, 1); } }
const ROSTER = ['lupus', 'vespera', 'triton', 'malakor'];
const ROSTER_KEY = { lupus: 'lupus_h', vespera: 'vespera', triton: 'triton', malakor: 'malakor' };
function faceOf(key) { return 'face_' + (window.ITEMS['face_' + key] ? key : 'lupus_h'); }
function drawFace(g, key, x, y, size) { const m = window.ITEMS[faceOf(key)]; g.save(); g.imageSmoothingEnabled = true; g.drawImage(ART.img.items, m[0], m[1], m[2], m[3], x, y, size, size); g.restore(); }

/* ---------------- animation selection ---------------- */
const IMPACT = { atk1: 2, atk2: 2, atk3: 3, air: 1, spec: 3 };
function phased(n, p, hitP, imp) { return p < hitP ? Math.min(imp - 1, Math.floor(p / hitP * imp)) : Math.min(n - 1, imp + Math.floor((p - hitP) / (1 - hitP) * (n - imp))); }
function track(e, tag) { if (e._tag !== tag) { e._tag = tag; e._t0 = G ? G.time : 0; } return (G ? G.time : 0) - e._t0; }
function entFrame(e) {
  if (e.kind === 'prop') return null;
  const key = e.kind === 'hero' ? heroKey(e) : e.key;
  const n = an => ART.frameCount(key, an); const T = G.time;
  if (e.kind === 'hero') {
    switch (e.st) {
      case 'walk': return ['walk', Math.floor(e.wph || 0)];
      case 'tagin': return ['fall', 1];
      case 'xform': return e.xswap ? ['win', Math.floor((e.xt - e.xsw) * 9), false] : ['hurt', 1, false];
      case 'air': return [e.vz > 0 ? 'rise' : 'fall', e.vz > 0 ? (e.vz > 150 ? 0 : 1) : (e.vz > -150 ? 0 : 1)];
      case 'atk': { const an = e.air ? 'air' : 'atk' + e.idx; const p = 1 - e.atkT / e.atkDur; return [an, phased(n(an), p, 0.4, IMPACT[an]), false]; }
      case 'spec': return ['spec', phased(n('spec'), e.t / e.specDur, 0.45, IMPACT.spec), false];
      case 'dash': return ['run', Math.floor(e.ct * 16)];
      case 'hurt': return ['hurt', Math.min(1, Math.floor(e.ct * 12)), false];
      case 'knock': return ['knock', 0];
      case 'down': return ['down', 0];
      case 'getup': return ['getup', Math.floor(e.ct * 7), false];
      case 'dead': return [e.z > 1 ? 'knock' : 'down', 0];
      default: if (e.landT > 0) return ['getup', 1, false]; if (e.taunt) return ['win', Math.floor(T * 7)]; return ['idle', Math.floor(T * 7 + e.x * 0.01)];
    }
  }
  if (e.kind === 'boss') {
    if (e.dead) return ['dead', Math.floor(track(e, 'dead') * 6), false];
    if (e.st === 'hurt') return ['hurt', Math.floor(track(e, 'hurt') * 10), false];
    if (e.bossIn > 0) return ['walk', Math.floor(T * 9)];
    const P = e.pat, f = e.frame; const el = track(e, f + (P ? P.n + P.ps + P.hits : ''));
    const atkAn = !P ? 'atk1' : ({ slash: 'atk1', charge: 'atk2', guard: 'atk2', wave: 'spec', slam: (e.key === 'nacht_big' ? 'atk1' : e.key === 'prime' ? 'spec' : 'atk2'), roar: 'spec', shoot: 'atk1', summon: 'spec', blink: 'atk2' })[P.n] || 'atk1';
    if (f === 'run') return ['run', Math.floor(T * 12)];
    if (f === 'walk') return ['walk', Math.floor(T * 9)];
    if (f === 'wind') return [atkAn, Math.min(2, Math.floor(el * 7)), false];
    if (f === 'atk') return [atkAn, Math.min(5, 3 + Math.floor(el * 10)), false];
    if (f === 'spec') return [atkAn === 'atk1' && P && P.n !== 'shoot' ? 'spec' : atkAn, Math.min(5, Math.floor(el * 8)), false];
    if (f === 'block') return ['atk2', 1, false];
    return ['idle', Math.floor(T * 7)];
  }
  /* regular enemy */
  if (e.dead) return [e.z > 1 ? 'knock' : 'down', 0];
  if (e.arrive) return ['walk', Math.floor(T * 10 + e.x * 0.05)];
  switch (e.st) { case 'hurt': return ['hurt', Math.min(1, Math.floor(e.ct * 12)), false]; case 'knock': return ['knock', 0]; case 'down': return ['down', 0]; case 'getup': return ['getup', Math.floor(e.ct * 7), false]; }
  const el = track(e, 'ai' + e.ai);
  if (e.ai === 'wind') { const dur = e.def.wind || (e.def.ai === 'ranged' ? 0.5 : e.def.ai === 'beam' ? 0.75 : 0.35); return ['atk', Math.min(1, Math.floor(el / dur * 2)), false]; }
  if (e.ai === 'hit') return ['atk', Math.min(4, 2 + Math.floor(el * 9)), false];
  if (e.ai === 'rec' && el < 0.12) return ['atk', 4, false];
  return [e.moving ? 'walk' : 'idle', Math.floor(T * (e.moving ? 10 : 6) + e.x * 0.05)];
}
function depthScale(y) { return 0.93 + 0.11 * (y - LANE_T) / (LANE_B - LANE_T); }
function entHeight(e) { const k = e.kind === 'hero' ? heroKey(e) : e.key; return (window.ATLAS[k] || { h: 70 }).h; }
function frameOf(e) {
  const r = entFrame(e); if (!r) return null; e._an = r[0];
  const key = e.kind === 'hero' ? heroKey(e) : e.key;
  return ART.frame(key, r[0], r[1], r[2]);
}
/* draw an entity with lights, crossfade and afterimages */
function drawEnt(g, e, cam) {
  if (e.kind === 'prop') { const o = { sc: 1, alpha: 1 }; if (e.flash > 0) o.alpha = 0.75 + 0.25 * Math.cos(e.flash * 30); ART.item(g, e.key, e.x - cam, e.y + 1, o); return null; }
  const fr = frameOf(e); if (!fr) return null;
  const x = e.x - cam, y = e.y - e.z, sc = depthScale(e.y);
  let alpha = null;
  if (e.inv > 0 && !e.dead && e.st !== 'dash' && e.kind === 'hero' && Math.floor(e.inv * 18) % 2 === 0) alpha = 0.55;
  if (e.dead) alpha = e.kind === 'boss' ? Math.max(0, 1 - Math.max(0, e.deadT - 2)) : (e.deadT > 0.8 ? (Math.floor(e.deadT * 16) % 2 ? 0.25 : 0.9) : 1);
  if (e.fade != null && e.fade < 1) alpha = Math.max(0.05, e.fade);
  let tint = null, tintA = 0.4;
  if (e.kind === 'enemy' && e.ai === 'wind' && Math.floor(G.time * 14) % 2 === 0) { tint = '#ff1a30'; tintA = 0.22; }
  if (e.kind === 'boss' && e.windup) { tint = '#ff1a30'; tintA = 0.1 + 0.1 * Math.sin(G.time * 30); }
  if (e.kind === 'boss' && e.guard) { tint = '#6aa0ff'; tintA = 0.3; }
  if (e.kind === 'boss' && e.p2 && !tint) { tint = '#ff0030'; tintA = 0.1 + 0.05 * Math.sin(G.time * 6); }
  if (e.kind === 'hero' && e.st === 'spec') { tint = '#ffffff'; tintA = 0.12 * Math.max(0, Math.sin(e.t / e.specDur * Math.PI)); }
  let xsc = 1, jit = 0;
  if (e.kind === 'hero' && e.st === 'xform') {
    const xc = e.xto === 'a' ? '#ff1030' : e.xto === 'f' ? '#ff9a30' : '#9ab4ff';
    if (!e.xswap) { const k = e.xt / (e.xdur * 0.5); tint = xc; tintA = 0.15 + 0.35 * k * (0.5 + 0.5 * Math.sin(G.time * 45)); jit = (Math.random() - 0.5) * 2 * k; xsc = 1 + 0.04 * k; RD.glow(g, x, y - 45, 40 + 40 * k, xc, 0.25 + 0.35 * k); }
    else { const k = Math.min(1, (e.xt - e.xsw) / 0.3); xsc = 1.18 - 0.18 * k; if (k < 1) { tint = '#ffffff'; tintA = 0.4 * (1 - k); } RD.glow(g, x, y - 50, 70 * (1 - k * 0.5), xc, 0.5 * (1 - k * 0.6)); }
  }
  /* afterimages */
  const trailOn = (e.kind === 'hero' && (e.st === 'dash' || e.st === 'tagin' || (e.id === 'lupus' && e.form === 'a' && (e.st === 'atk' || e.st === 'walk')))) || (e.kind === 'boss' && e.charging);
  e._trail = e._trail || [];
  if (trailOn && (!e._trailT || G.time - e._trailT > 0.035)) { e._trailT = G.time; e._trail.push({ fr, x: e.x, y, face: e.face, t: G.time }); }
  e._trail = e._trail.filter(q => G.time - q.t < 0.22);
  const tcol = e.kind !== 'hero' ? '#ff2040' : e.id === 'lupus' ? (e.form === 'a' ? '#ff1030' : '#ff6040') : HERO[e.id].color;
  for (const q of e._trail) { const a = 0.35 * (1 - (G.time - q.t) / 0.22); g.save(); g.globalAlpha = a; g.globalCompositeOperation = 'lighter'; ART.draw(g, q.fr, q.x - cam, q.y, { face: q.face, sc, tint: tcol, tintA: 1, alpha: a }); g.restore(); }
  /* crossfade from the previous animation */
  const tag = fr.key + fr.id;
  if (e._lastFr && e._lastFr.key === fr.key && e._lastAn !== e._an && e._lastFr.id !== fr.id && e.st !== 'walk') { e._xf = { fr: e._lastFr, t: 0.07 }; }
  e._lastAn = e._an; e._lastFr = fr;
  const smooth = Math.abs(sc - 1) > 0.01; g.imageSmoothingEnabled = smooth;
  if (e._xf && e._xf.t > 0) { ART.draw(g, e._xf.fr, x, y, { face: e.face, sc, alpha: (alpha == null ? 1 : alpha) * (e._xf.t / 0.07) * 0.6 }); e._xf.t -= 1 / 60; }
  const rims = ART.rimsAt(e.x, e.y, entHeight(e), G.time);
  ART.draw(g, fr, x + jit, y, { face: e.face, sc: sc * xsc, alpha, flash: Math.min(0.42, e.flash * 0.6), flashCol: e.team === 'p' ? '#ff8090' : '#ffffff', tint, tintA, rims, sx: e.landT > 0 ? 1.04 : 1, sy: e.landT > 0 ? 0.95 : 1 });
  g.imageSmoothingEnabled = false;
  if (e.kind === 'hero' && e.id === 'lupus' && e.form === 'a' && !e.dead) RD.glow(g, x, y - 46, 46, '#ff0a2a', 0.12 + 0.06 * Math.sin(G.time * 9));
  if (e.shieldHP > 0) { g.save(); g.globalAlpha = 0.4 + 0.2 * Math.sin(G.time * 10); g.strokeStyle = e.id === 'triton' ? COLR.cyan : COLR.lime; g.lineWidth = 1; g.beginPath(); g.ellipse(x, y - entHeight(e) * 0.48, 26, entHeight(e) * 0.56, 0, 0, 7); g.stroke(); g.restore(); }
  return fr;
}

/* =========================== LOADING =========================== */
Scenes.load = {
  t: 0, ready: false,
  enter() { this.t = 0; },
  update(dt) { this.t += dt; if (this.ready && this.t > 0.4 && !this.went) { this.went = true; BG.set(1); playCut('intro', () => Scene.go('title'), 5); } },
  draw(g) {
    g.fillStyle = '#07040d'; g.fillRect(0, 0, VW, VH);
    PIX.text(g, 'LUPUS', VW / 2, 92, { s: 5, align: 'c', grad: ['#ffffff', '#b8bccb', '#6a6e80', '#d8dce8'] });
    PIX.text(g, T('loading'), VW / 2, 160, { align: 'c', col: COLR.red });
    PIX.bar(g, VW / 2 - 70, 176, 140, 5, ART.total ? ART.loaded / ART.total : 0, COLR.red);
  }
};

/* =========================== TITLE =========================== */
function drawLogo(g, cx, y, s) {
  s = s || 6;
  PIX.text(g, 'LUPUS', cx + 2, y + 3, { s, align: 'c', col: '#7a0012', out: '#0a0612' });
  PIX.text(g, 'LUPUS', cx, y, { s, align: 'c', grad: ['#ffffff', '#d4d8e4', '#8a8ea0', '#5a5e70', '#e8ecf4'], out: '#0a0612' });
  g.fillStyle = '#c8001e'; const w = PIX.textW('LUPUS', s); const x0 = cx - w / 2;
  for (let i = 0; i < 7; i++) { const dx = x0 + 6 + i * (w / 7) + (i * 13 % 7), len = 3 + (i * 7 % 9) + Math.sin(Date.now() / 600 + i) * 1.5; g.fillRect(Math.round(dx), y + 7 * s - 2, 2, len); }
  PIX.text(g, 'REAWAKENING', cx, y + 7 * s + 8, { s: 2, align: 'c', col: '#ff2a40', out: '#2a0008' });
}
/* small "stage" for menus: floor of a stage + characters with reflections */
function menuCast(g, cast, t, n, cam) {
  const look = LOOK[n]; ART.useLook(look);
  const list = cast.map(c => Object.assign({}, c)).sort((a, b) => a.y - b.y);
  for (const c of list) { const fr = ART.frame(c.k, c.an || 'idle', Math.floor(t * 7 + (c.o || 0)), c.loop); c.fr = fr; if (look.refl) ART.reflect(g, fr, c.x, c.y, 0, c.f, look.refl, t, look.water, depthScale(c.y)); }
  for (const c of list) ART.shadow(g, c.x, c.y + 1, 16 * (window.ATLAS[c.k].h / 80), 0.6);
  g.imageSmoothingEnabled = true;
  for (const c of list) ART.draw(g, c.fr, c.x, c.y, { face: c.f, sc: depthScale(c.y), rims: ART.rimsAt(c.x + cam, c.y, window.ATLAS[c.k].h, t) });
  g.imageSmoothingEnabled = false;
}
const TITLE_CAST = [['vespera', -96, 228, 1, 0], ['lupus_h', -16, 250, 1, 2], ['triton', 74, 238, -1, 1], ['malakor', 150, 226, -1, 3]];
/* title lineup (Cosmic-Invasion style): the whole cast standing on a curved gothic ledge, backlit by a blood moon */
const TITLE_LINE = [['malakor', -232, -1, 3], ['triton', -150, 1, 1], ['lupus_f', -74, 1, 2], ['lupus_a', 0, 1, 0], ['lupus_h', 76, -1, 4], ['vespera', 152, -1, 5]];
const TITLE_LOOK = { amb: '#c4bccc', tint: '#ff1030', tintA: 0.035, refl: 0, rim: '#ff3050', rimA: 0.6, lights: [] };
const TITLE_STARS = Array.from({ length: 110 }, (_, i) => [(i * 0.618034) % 1, ((i * 0.7548777) % 1) * 0.62, 0.3 + (i * 7 % 10) / 14, i]);
function ledgeY(x) { const d = (x - VW / 2) / (VW / 2); return 200 + d * d * 16; }
function drawTitleScene(g, t) {
  const cx = VW / 2;
  /* sky */
  const sky = g.createLinearGradient(0, 0, 0, 210); sky.addColorStop(0, '#04020a'); sky.addColorStop(0.55, '#1a0614'); sky.addColorStop(1, '#3a0818'); g.fillStyle = sky; g.fillRect(0, 0, VW, VH);
  for (const [x, y, b, i] of TITLE_STARS) { const tw = 0.5 + 0.5 * Math.sin(t * (1 + i % 3) + i); g.fillStyle = 'rgba(255,230,240,' + (b * tw).toFixed(2) + ')'; g.fillRect(Math.round(x * VW), Math.round(y * 170), i % 7 ? 1 : 2, i % 7 ? 1 : 2); }
  /* blood moon */
  const my = 150, mr = 104;
  RD.glow(g, cx, my, mr * 1.9, '#ff1838', 0.35); RD.glow(g, cx, my, mr * 1.25, '#ff5060', 0.25);
  const mg = g.createRadialGradient(cx - 30, my - 34, 10, cx, my, mr); mg.addColorStop(0, '#ff8a7a'); mg.addColorStop(0.55, '#d0283a'); mg.addColorStop(1, '#5a0414');
  g.fillStyle = mg; g.beginPath(); g.arc(cx, my, mr, 0, 7); g.fill();
  g.fillStyle = 'rgba(80,0,16,0.35)'; for (const [dx, dy, r] of [[-40, -30, 16], [22, -50, 10], [38, 10, 22], [-18, 30, 12], [-62, 18, 9], [60, -20, 8]]) { g.beginPath(); g.arc(cx + dx, my + dy, r, 0, 7); g.fill(); }
  /* clouds drifting across the moon */
  g.save(); g.beginPath(); g.arc(cx, my, mr, 0, 7); g.clip(); g.fillStyle = 'rgba(30,2,14,0.45)'; for (let i = 0; i < 4; i++) { const x = cx - mr - 80 + ((i * 97 + t * (5 + i * 2)) % (mr * 2 + 160)), y = my - 60 + i * 26; g.beginPath(); g.ellipse(x, y, 50 + i * 8, 3 + i % 2 * 2, 0, 0, 7); g.fill(); } g.restore();
  /* far gothic skyline */
  const sky2 = (base, col, seed, hmul) => { g.fillStyle = col; g.beginPath(); g.moveTo(0, VH); for (let x = 0; x <= VW + 8; x += 8) { const n = Math.sin(x * 0.05 + seed) * 0.5 + Math.sin(x * 0.013 + seed * 2) * 0.5; let h = (18 + n * 16) * hmul; if (((x / 8) | 0) % 9 === seed % 9) h += 30 * hmul; g.lineTo(x, base - h); g.lineTo(x + (((x / 8) | 0) % 9 === seed % 9 ? 4 : 8), base - h - (((x / 8) | 0) % 9 === seed % 9 ? 10 : 0)); } g.lineTo(VW, VH); g.fill(); };
  sky2(196, '#1c0612', 3, 1.3); sky2(204, '#0c0309', 7, 1);
  for (let i = 0; i < 26; i++) { const x = (i * 97) % VW, y = 170 + (i * 13) % 26; g.fillStyle = i % 3 ? 'rgba(255,40,70,0.7)' : 'rgba(70,230,255,0.6)'; g.fillRect(x, y, 1, 2); }
  /* curved ledge */
  g.beginPath(); g.moveTo(0, VH); for (let x = 0; x <= VW; x += 4) g.lineTo(x, ledgeY(x)); g.lineTo(VW, VH); g.closePath();
  const lg = g.createLinearGradient(0, 196, 0, VH); lg.addColorStop(0, '#2a1622'); lg.addColorStop(0.15, '#160a14'); lg.addColorStop(1, '#050208'); g.fillStyle = lg; g.fill();
  g.strokeStyle = '#ff3a50'; g.globalAlpha = 0.85; g.lineWidth = 1; g.beginPath(); for (let x = 0; x <= VW; x += 4) x ? g.lineTo(x, ledgeY(x) + 0.5) : g.moveTo(x, ledgeY(x) + 0.5); g.stroke(); g.globalAlpha = 1;
  g.fillStyle = 'rgba(255,60,80,0.10)'; for (let x = 0; x < VW; x += 22) { const y = ledgeY(x); g.fillRect(x, y + 4, 1, 6); g.fillRect(x + 11, y + 12, 1, 6); }
  for (let x = 0; x < VW; x += 22) g.fillRect(x, ledgeY(x) + 10, 22, 1);
  /* the cast */
  ART.useLook(TITLE_LOOK); g.imageSmoothingEnabled = true;
  const k = VW / 624, csc = Math.min(1, 0.45 + 0.55 * k); const list = TITLE_LINE.map(([key, dx, f, o]) => { const x = cx + dx * k; return { key, x, y: ledgeY(x) + 2, f, o }; });
  for (const c of list) ART.shadow(g, c.x, c.y, 16 * window.ATLAS[c.key].h / 90, 0.7);
  for (const c of list) {
    const cyc = (t + c.o * 1.7) % 9, an = cyc > 7.4 ? 'win' : 'idle'; const fr = ART.frame(c.key, an, Math.floor((an === 'win' ? (cyc - 7.4) : t) * 7 + c.o), an !== 'win');
    ART.draw(g, fr, c.x, c.y, { face: c.f, sc: (c.key === 'lupus_a' ? 1.08 : 1) * csc, rims: [['#ff2a40', -2, -1, 0.75], ['#ffb0b8', 2, -1, 0.3]] });
  }
  g.imageSmoothingEnabled = false;
  RD.glow(g, cx, ledgeY(cx) - 50, 70, '#ff0a2a', 0.10 + 0.05 * Math.sin(t * 4));
}
function drawTitleLogo(g, cx, y, t) {
  const s = 6, w = PIX.textW('LUPUS', s);
  RD.glow(g, cx, y + 22, w * 0.7, '#ff1030', 0.28);
  PIX.text(g, 'LUPUS', cx + 3, y + 4, { s, align: 'c', col: '#5a000e', out: '#000' });
  PIX.text(g, 'LUPUS', cx, y, { s, align: 'c', grad: ['#ffffff', '#e4e8f0', '#9aa0b4', '#5a5e70', '#f0f2f8'], out: '#0a0612' });
  /* three claw marks ripped through the logo */
  g.save(); g.globalCompositeOperation = 'source-over';
  for (let i = 0; i < 3; i++) { const x0 = cx + w * 0.30 + i * 8, y0 = y - 3; g.strokeStyle = '#0a0612'; g.lineWidth = 3.5; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x0 - 16, y0 + 48); g.stroke(); g.strokeStyle = '#ff2a40'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x0 - 16, y0 + 48); g.stroke(); g.strokeStyle = '#ffd0d6'; g.lineWidth = 0.6; g.beginPath(); g.moveTo(x0 - 3, y0 + 9); g.lineTo(x0 - 12, y0 + 36); g.stroke(); }
  const gl = (t * 0.6) % 3; if (gl < 1) { g.globalCompositeOperation = 'lighter'; g.globalAlpha = Math.sin(gl * Math.PI) * 0.6; g.fillStyle = '#ffffff'; g.beginPath(); const gx = cx - w / 2 + gl * w; g.moveTo(gx, y); g.lineTo(gx + 8, y); g.lineTo(gx - 6, y + 7 * s); g.lineTo(gx - 14, y + 7 * s); g.fill(); }
  g.restore();
  /* red slanted banner */
  const bw = PIX.textW('REAWAKENING', 2) + 26, by = y + 7 * s + 6;
  g.fillStyle = '#000'; g.beginPath(); g.moveTo(cx - bw / 2 + 4, by - 1); g.lineTo(cx + bw / 2 + 9, by - 1); g.lineTo(cx + bw / 2 - 4, by + 18); g.lineTo(cx - bw / 2 - 9, by + 18); g.fill();
  g.fillStyle = '#c4001e'; g.beginPath(); g.moveTo(cx - bw / 2 + 6, by + 1); g.lineTo(cx + bw / 2 + 6, by + 1); g.lineTo(cx + bw / 2 - 6, by + 16); g.lineTo(cx - bw / 2 - 6, by + 16); g.fill();
  g.fillStyle = '#ff4a60'; g.fillRect(cx - bw / 2 + 6, by + 1, bw, 1);
  PIX.text(g, 'REAWAKENING', cx, by + 3, { s: 2, align: 'c', col: '#ffffff', out: '#3a0008' });
}
Scenes.title = {
  t: 0, opts: false, btns: [], sel: 0, items: [],
  enter() { this.t = 0; this.opts = false; this.langPick = false; this.sel = 0; BG.set(1); musicStart(5); },
  layout() {
    this.btns = [];
    this.items = [['start', T('menuStart')], ['story', T('menuStory')], ['opt', T('options')]].map((it, i) => ({ id: it[0], label: it[1], x: VW / 2 - 100, y: 210 + i * 19, w: 200, h: 16 }));
    if (!this.opts) return;
    if (this.langPick) { const cols = 3, bw = 120, bh = 20, x0 = VW / 2 - (cols * bw + (cols - 1) * 8) / 2; LANGS.forEach((c, i) => { const b = btn('L_' + c, x0 + (i % cols) * (bw + 8), 52 + Math.floor(i / cols) * 28, bw, bh, I18N[c].native, c === SAVE.lang ? COLR.red : COLR.cyan); this.btns.push(b); }); this.btns.push(btn('closeL', VW / 2 - 60, 52 + 4 * 28 + 6, 120, 18, T('back'), COLR.gray)); }
    else { const L = [['lang', T('lang') + ': ' + I18N[SAVE.lang].native], ['music', T('music') + ': ' + (SAVE.music ? T('on') : T('off'))], ['sfx', T('sfx') + ': ' + (SAVE.sfx ? T('on') : T('off'))], ['reset', T('newGame')], ['close', T('back')]]; L.forEach((l, i) => this.btns.push(btn(l[0], VW / 2 - 80, 74 + i * 24, 160, 18, l[1], l[0] === 'reset' ? COLR.gold : COLR.cyan))); }
  },
  update(dt) {
    this.t += dt; this.layout();
    if (!this.opts) { if (Inp.edge.u) { this.sel = (this.sel + this.items.length - 1) % this.items.length; sfx('ui'); } if (Inp.edge.d) { this.sel = (this.sel + 1) % this.items.length; sfx('ui'); } if (Inp.edge.atk) this.activate(this.items[this.sel].id); }
    Inp.edge = {};
  },
  draw(g) {
    const t = this.t; drawTitleScene(g, t);
    const ia = Math.min(1, t / 0.8); g.save(); g.globalAlpha = ia; drawTitleLogo(g, VW / 2, 8 + (1 - ia) * -20, t); g.restore();
    if (!this.opts) {
      this.items.forEach((it, i) => {
        const on = i === this.sel, cy = it.y + it.h / 2, tw = PIX.textW(it.label, 1) * 1 + 34;
        if (on) {
          const w = Math.max(tw, 120) + Math.sin(t * 6) * 2, x0 = VW / 2 - w / 2;
          g.fillStyle = '#000'; g.beginPath(); g.moveTo(x0 + 6, it.y - 1); g.lineTo(x0 + w + 8, it.y - 1); g.lineTo(x0 + w - 4, it.y + it.h + 1); g.lineTo(x0 - 8, it.y + it.h + 1); g.fill();
          const gr = g.createLinearGradient(x0, 0, x0 + w, 0); gr.addColorStop(0, '#8a0016'); gr.addColorStop(0.5, '#e0102c'); gr.addColorStop(1, '#8a0016');
          g.fillStyle = gr; g.beginPath(); g.moveTo(x0 + 8, it.y + 1); g.lineTo(x0 + w + 4, it.y + 1); g.lineTo(x0 + w - 6, it.y + it.h - 1); g.lineTo(x0 - 4, it.y + it.h - 1); g.fill();
          g.fillStyle = '#ff7080'; g.fillRect(x0 + 8, it.y + 1, w - 4, 1);
          /* claw cursor */
          const ax = x0 - 14 + Math.sin(t * 8) * 2; for (let k = 0; k < 3; k++) { g.fillStyle = '#000'; g.fillRect(ax - 1 + k * 3, cy - 5, 3, 10); } for (let k = 0; k < 3; k++) for (let s2 = 0; s2 < 8; s2++) { g.fillStyle = '#f2eef8'; g.fillRect(ax + k * 3 + Math.round(s2 * 0.3), cy - 4 + s2, 1, 1); }
        }
        PIX.text(g, it.label, VW / 2, it.y + 4, { align: 'c', col: on ? '#ffe680' : '#ffcf3a', out: '#1a0008', shadow: '#000' });
      });
      PIX.text(g, 'THORNE INDUSTRIES  MMXXVI', VW - 6, VH - 10, { align: 'r', col: '#6a6080', out: '#000' });
      PIX.text(g, 'V5', 6, VH - 10, { col: '#6a6080', out: '#000' });
    } else { dim(g, 0.82); PIX.text(g, this.langPick ? T('lang') : T('options'), VW / 2, this.langPick ? 26 : 50, { s: 2, align: 'c', col: COLR.cyan }); for (const b of this.btns) drawBtn(g, b); }
  },
  activate(id) {
    sfx('ok');
    if (id === 'start') this.start();
    else if (id === 'story') playCut('intro', () => Scene.go('title'), 5);
    else if (id === 'opt') this.opts = true;
  },
  onDown(id, x, y) {
    if (!this.opts) { const i = this.items.findIndex(it => x >= it.x - 20 && x <= it.x + it.w + 20 && y >= it.y - 2 && y <= it.y + it.h + 2); if (i >= 0) { this.sel = i; this.activate(this.items[i].id); } return; }
    const b = hitB(this.btns, x, y); if (!b) return;
    sfx('ok');
    if (b.id === 'close') this.opts = false;
    else if (b.id === 'lang') this.langPick = true; else if (b.id === 'closeL') this.langPick = false;
    else if (b.id.startsWith('L_')) { setLang(b.id.slice(2)); this.langPick = false; }
    else if (b.id === 'music') { SAVE.music = !SAVE.music; setAudioOpts(); saveGame(); }
    else if (b.id === 'sfx') { SAVE.sfx = !SAVE.sfx; setAudioOpts(); saveGame(); }
    else if (b.id === 'reset') { SAVE.unlocked = 1; SAVE.up = { dmg: 0, hp: 0, fury: 0, cd: 0 }; SAVE.best = {}; saveGame(); this.opts = false; }
  },
  start() { Scene.go('select'); },
  onKey(k) { if (k === 'ok') { if (this.opts) this.opts = false; else this.activate(this.items[this.sel].id); } }
};

/* =========================== INTRO STORY =========================== */
Scenes.intro = {
  i: 0, t: 0,
  enter() { this.i = -1; SAVE.seenIntro = true; saveGame(); this.next(); musicStart(5); },
  next() { this.i++; this.t = 0; if (this.i >= STORY.length) { Scene.go('select'); return; } BG.set(STORY[this.i].stage); sfx('ui'); },
  update(dt) { this.t += dt; if (this.t > 6.5) this.next(); },
  draw(g) {
    const s = STORY[this.i]; if (!s) return; const t = this.t, cx = VW / 2, cam = 300 + t * 10;
    BG.back(g, cam, 1 / 60);
    let cast = [];
    if (s.cast === 'lab') cast = [{ k: 'nacht', x: cx + 70, y: 214, f: -1 }, { k: 'zealot', x: cx - 96, y: 224, f: 1 }, { k: 'lupus_h', an: 'down', x: cx - 6, y: 244, f: 1 }, { k: 'zealot', x: cx + 130, y: 240, f: -1, o: 2 }];
    else if (s.cast === 'rage') { RD.glow(g, cx, 190, 150, '#ff1030', 0.25 + 0.1 * Math.sin(t * 8)); cast = [{ k: 'lupus_a', an: 'spec', x: cx, y: 244, f: 1, loop: false, o: -t * 7 + Math.min(5, t * 3) }, { k: 'zealot', an: 'down', x: cx - 110, y: 250, f: 1 }, { k: 'bulwark', an: 'knock', x: cx + 110, y: 228, f: -1 }]; }
    else if (s.cast === 'city') cast = [{ k: 'lupus_h', an: 'walk', x: cx - 80 + t * 22, y: 238, f: 1, o: t * 4 }];
    else if (s.cast === 'sigil') { const sx = cx + 90, sy = 110; g.save(); g.strokeStyle = '#c8001e'; g.lineWidth = 3; g.globalAlpha = 0.85; g.beginPath(); g.arc(sx, sy, 26, 0, 7); g.stroke(); g.fillStyle = '#c8001e'; g.fillRect(sx - 1.5, sy - 40, 3, 80); g.fillRect(sx - 18, sy - 1.5, 36, 3); g.restore(); cast = [{ k: 'hunter', an: 'down', x: cx + 60, y: 248, f: 1 }, { k: 'lupus_h', x: cx - 60, y: 238, f: 1 }]; }
    else if (s.cast === 'team') cast = TITLE_CAST.map(([k, dx, y, f, o]) => ({ k, an: t > 2.2 ? 'win' : 'idle', x: cx + dx, y, f, o }));
    for (const c of cast) c.y -= 46;
    g.save(); g.translate(0, -18); BG.back(g, cam, 0); menuCast(g, cast.map(c => Object.assign(c, { y: c.y + 18 })), t, s.stage, cam); g.restore();
    BG.atmos(g, t);
    g.fillStyle = '#05030a'; g.fillRect(0, 0, VW, 22); g.fillRect(0, VH - 64, VW, 64);
    const lines = s[SAVE.lang]; const shown = Math.floor(t * 34); let used = 0;
    lines.forEach((l, n) => { const vis = Math.max(0, Math.min(l.length, shown - used)); used += l.length + 4; PIX.text(g, l.slice(0, vis), 22, VH - 56 + n * 14, { col: n === 0 ? COLR.red : COLR.white }); });
    PIX.text(g, T('skip'), VW - 8, 8, { align: 'r', col: COLR.gray });
    PIX.text(g, (this.i + 1) + '/' + STORY.length, 8, 8, { col: '#5a5470' });
    if (t > 2.2 && Math.sin(t * 5) > 0) PIX.text(g, T('tapNext'), VW - 10, VH - 12, { align: 'r', col: '#6a6480', out: null });
  },
  onDown(id, x, y) { if (x > VW - 70 && y < 24) { sfx('ok'); Scene.go('select'); return; } this.next(); },
  onKey(k) { if (k === 'ok') this.next(); }
};

/* =========================== SELECT =========================== */
Scenes.select = {
  step: 0, sel: null, hero: null, t: 0, back: null, cards: [],
  enter() { this.step = 0; this.sel = null; this.hero = null; this.t = 0; BG.set(3); musicStart(5); },
  update(dt) {
    this.t += dt; this.back = btn('back', 6, 6, 62, 16, T('back'), COLR.gray);
    const gap = 6, cw = Math.floor((VW - 20 - gap * 3) / 4), x0 = Math.round((VW - (cw * 4 + gap * 3)) / 2);
    this.cards = ROSTER.map((id, i) => ({ id, x: x0 + i * (cw + gap), y: 30, w: cw, h: 212 }));
  },
  draw(g) {
    BG.menu(g, 3, this.t, this.t * 10); dim(g, 0.45);
    PIX.text(g, this.step === 0 ? T('selectHero') : T('selectAlly'), VW / 2, 12, { align: 'c', col: COLR.white });
    for (const c of this.cards) {
      const H = HERO[c.id], sel = this.sel === c.id, dis = this.step === 1 && c.id === this.hero;
      PIX.panel(g, c.x, c.y, c.w, c.h, { edge: sel ? H.color : PIX.shade(H.color, 0.55), bg: sel ? 'rgba(30,10,30,0.88)' : 'rgba(10,6,18,0.78)' });
      if (sel) { g.fillStyle = H.color; g.globalAlpha = 0.1 + 0.07 * Math.sin(this.t * 6); g.fillRect(c.x + 1, c.y + 1, c.w - 2, c.h - 2); g.globalAlpha = 1; }
      PIX.text(g, H.name, c.x + c.w / 2, c.y + 6, { align: 'c', col: H.color });
      const key = ROSTER_KEY[c.id]; const fr = ART.frame(key, sel ? 'win' : 'idle', Math.floor(this.t * 7));
      g.save(); g.beginPath(); g.rect(c.x + 2, c.y + 16, c.w - 4, 104); g.clip();
      RD.glow(g, c.x + c.w / 2, c.y + 80, 46, H.color, 0.28); ART.shadow(g, c.x + c.w / 2, c.y + 116, 18, 0.7);
      ART.useLook(MENU_LOOK); g.imageSmoothingEnabled = true; const s = Math.min(1, 96 / window.ATLAS[key].h);
      ART.draw(g, fr, c.x + c.w / 2, c.y + 116, { face: 1, sc: s, rims: [[H.color, -2, -1, 0.7]] }); g.imageSmoothingEnabled = false; g.restore();
      PIX.wrap(H.role, c.w - 8, 1).slice(0, 2).forEach((l, n) => PIX.text(g, l, c.x + c.w / 2, c.y + 124 + n * 9, { align: 'c', col: COLR.gray, out: null }));
      T('stats').forEach((lab, n) => { const yy = c.y + 146 + n * 12; PIX.text(g, lab.slice(0, 5), c.x + 5, yy, { col: '#c8c0d8', out: null }); PIX.bar(g, c.x + 40, yy, c.w - 46, 6, H.stats[n] / 5, H.color, '#1a0f22', 5); });
      if (dis) { g.fillStyle = 'rgba(0,0,0,0.62)'; g.fillRect(c.x, c.y, c.w, c.h); PIX.text(g, 'P1', c.x + c.w / 2, c.y + c.h / 2, { s: 2, align: 'c', col: COLR.white }); }
    }
    if (this.sel && Math.sin(this.t * 6) > -0.4) PIX.text(g, T('tapAgain'), VW / 2, VH - 20, { align: 'c', col: COLR.white });
    if (this.step === 1) PIX.text(g, 'P1: ' + HERO[this.hero].name, VW - 8, VH - 20, { align: 'r', col: HERO[this.hero].color });
    drawBtn(g, this.back);
  },
  onDown(id, x, y) {
    if (hitB([this.back], x, y)) { sfx('ui'); if (this.step === 1) { this.step = 0; this.sel = null; } else Scene.go('title'); return; }
    for (const c of this.cards) {
      if (x < c.x || x > c.x + c.w || y < c.y || y > c.y + c.h) continue;
      if (this.step === 1 && c.id === this.hero) return;
      if (this.sel === c.id) { sfx('ok'); if (this.step === 0) { this.hero = c.id; this.step = 1; this.sel = null; } else { SAVE.hero = this.hero; SAVE.ally = c.id; saveGame(); Scene.go('stages'); } }
      else { this.sel = c.id; sfx('ui'); }
      return;
    }
  }
};

/* =========================== STAGE MAP =========================== */
Scenes.stages = {
  t: 0, back: null, cards: [],
  enter() { this.t = 0; musicStart(5); },
  update(dt) {
    this.t += dt; this.back = btn('back', 6, 6, 62, 16, T('back'), COLR.gray);
    const gap = 6, cw = Math.floor((VW - 16 - gap * 4) / 5), x0 = Math.round((VW - (cw * 5 + gap * 4)) / 2);
    this.cards = STAGES.map((s, i) => ({ i, x: x0 + i * (cw + gap), y: 46, w: cw, h: 178 }));
  },
  draw(g) {
    BG.menu(g, 2, this.t, this.t * 8); dim(g, 0.6);
    PIX.text(g, T('stages'), VW / 2, 12, { s: 2, align: 'c', col: COLR.red });
    PIX.text(g, HERO[SAVE.hero].name + '  +  ' + HERO[SAVE.ally].name, VW / 2, 32, { align: 'c', col: '#c8c0d8', out: '#0a0612' });
    for (const k of this.cards) {
      const s = STAGES[k.i], lock = k.i + 1 > SAVE.unlocked, im = ART.img['s' + s.id + '_l3'];
      g.save(); g.imageSmoothingEnabled = true; const tw = k.w - 2, th = 110; const sw = th / VIEW_H * im.height * 0.0 + 0; // crop
      const srcH = im.height * 0.78, srcW = srcH * tw / th, srcX = (im.width - srcW) * (0.25 + 0.12 * k.i);
      g.drawImage(im, srcX, im.height * 0.12, srcW, srcH, k.x + 1, k.y + 1, tw, th); g.restore();
      if (lock) { g.fillStyle = 'rgba(0,0,0,0.75)'; g.fillRect(k.x + 1, k.y + 1, k.w - 2, 110); }
      PIX.panel(g, k.x, k.y + 108, k.w, 70, { edge: lock ? '#3a3448' : COLR.red });
      g.fillStyle = lock ? '#3a3448' : COLR.red; g.fillRect(k.x, k.y, k.w, 1); g.fillRect(k.x, k.y, 1, 110); g.fillRect(k.x + k.w - 1, k.y, 1, 110);
      PIX.text(g, '0' + s.id, k.x + 5, k.y + 6, { s: 2, col: lock ? '#5a5470' : COLR.red });
      PIX.wrap(s.name[SAVE.lang], k.w - 8, 1).forEach((l, n) => PIX.text(g, l, k.x + 4, k.y + 114 + n * 9, { col: lock ? '#6a6480' : COLR.white, out: null }));
      const bk = BOSS[s.boss].key; if (!lock) drawFace(g, bk, k.x + k.w - 26, k.y + 146, 22);
      if (lock) PIX.text(g, T('locked'), k.x + k.w / 2, k.y + 52, { align: 'c', col: '#8a84a0' });
      else if (SAVE.best[s.id]) { PIX.text(g, T('best'), k.x + 4, k.y + 154, { col: COLR.gold, out: null }); PIX.text(g, '' + SAVE.best[s.id], k.x + 4, k.y + 164, { col: COLR.gold, out: null }); }
    }
    drawBtn(g, this.back);
  },
  onDown(id, x, y) {
    if (hitB([this.back], x, y)) { sfx('ui'); Scene.go('select'); return; }
    for (const k of this.cards) if (x >= k.x && x <= k.x + k.w && y >= k.y && y <= k.y + k.h) { if (k.i + 1 > SAVE.unlocked) { sfx('ui'); return; } sfx('ok'); playCut('s' + STAGES[k.i].id + 'pre', () => Scene.go('play', k.i), STAGES[k.i].music); return; }
  }
};

/* =========================== PLAY =========================== */
function fxStep(dt) {
    for (const q of G.parts) { q.t += dt; q.x += q.vx * dt; q.y += (q.vy || 0) * dt; q.vz -= q.grav * dt; q.z += q.vz * dt; if (q.vr) q.rot += q.vr * dt; if (q.z < 0) { q.z = 0; if (q.bounce) { q.vz = -q.vz * q.bounce; q.vx *= 0.6; if (q.vr) q.vr *= 0.5; } else { q.vz = 0; q.vx *= 0.3; q.grav = 0; } } if (q.dust) q.vx *= 0.92; }
    G.parts = G.parts.filter(q => q.t < q.life); if (G.parts.length > 500) G.parts.splice(0, G.parts.length - 500);
    for (const arr of [G.slashes, G.rings, G.lines, G.flashes]) for (const q of arr) q.t += dt;
    G.slashes = G.slashes.filter(q => q.t < q.dur); G.rings = G.rings.filter(q => q.t < q.dur); G.lines = G.lines.filter(q => q.t < q.dur); G.flashes = G.flashes.filter(q => q.t < q.dur);
    for (const q of G.texts) { q.t += dt; q.y += q.vy * dt; q.vy *= 0.94; } G.texts = G.texts.filter(q => q.t < 0.9);
}

const BTN = () => ({ atk: { x: VW - 50, y: 222, r: 24 }, jump: { x: VW - 104, y: 246, r: 17 }, dash: { x: VW - 112, y: 202, r: 15 }, spec: { x: VW - 56, y: 170, r: 18 }, form: { x: VW - 158, y: 236, r: 15 }, tag: { x: VW - 104, y: 156, r: 15 }, assist: { x: VW - 156, y: 188, r: 13 } });
const JOY = { r: 30 };
function playerCtl() {
  const k = Inp.keys; let mx = 0, my = 0;
  if (k.l) mx -= 1; if (k.r) mx += 1; if (k.u) my -= 1; if (k.d) my += 1;
  if (Inp.joy.id != null) { const ax = Inp.joy.ax, ay = Inp.joy.ay, m = Math.hypot(ax, ay); if (m > 0.2) { const f = Math.min(1, (m - 0.2) / 0.55); mx = ax / m * f; my = ay / m * f; if (Math.abs(my) < 0.25) my = 0; } }
  const c = { mx, my, atk: !!Inp.edge.atk, atkHeld: !!Inp.held.atk, jump: !!Inp.edge.jump, jumpHeld: !!Inp.held.jump, spec: !!Inp.edge.spec, dash: !!Inp.edge.dash, form: !!Inp.edge.form, tag: !!Inp.edge.tag, assist: !!Inp.edge.assist };
  Inp.edge = {}; return c;
}
Scenes.play = {
  menu: false, btns: [],
  enter(i) { BG.set(STAGES[i].id); newGame(i); this.menu = false; musicStart(G.st.music); },
  pauseMenu() { const L = [['resume', T('resume')], ['restart', T('restart')], ['music', T('music') + ': ' + (SAVE.music ? T('on') : T('off'))], ['sfx', T('sfx') + ': ' + (SAVE.sfx ? T('on') : T('off'))], ['lang', T('lang') + ': ' + I18N[SAVE.lang].native], ['quit', T('quit')]]; this.btns = L.map((l, i) => btn(l[0], VW / 2 - 80, 62 + i * 24, 160, 18, l[1], l[0] === 'resume' ? COLR.red : l[0] === 'quit' ? COLR.gold : COLR.cyan)); },
  update(dt) {
    if (PORTRAIT) return;
    if (this.menu) { this.pauseMenu(); return; }
    const raw = dt; G.time += dt;
    if (G.hitstop > 0) { G.hitstop -= raw; G.shake *= 0.9; return; }
    if (G.cine) { G.cine.t += raw; Inp.edge = {}; updHero(G.player, raw, { mx: 0, my: 0 }); fxStep(raw); G.flashScr = Math.max(0, G.flashScr - raw * 1.6); G.shake *= Math.exp(-6 * raw); if (G.cine.t >= G.cine.dur) G.cine = null; return; }
    dt *= G.slow; if (G.slow < 1) G.slow = Math.min(1, G.slow + raw * 0.2);
    G.title = Math.max(0, G.title - raw); G.flashScr = Math.max(0, G.flashScr - raw * 1.6); G.shake *= Math.exp(-10 * raw); G.hintT -= raw;
    if (G.comboT > 0) { G.comboT -= dt; if (G.comboT <= 0) G.combo = 0; }
    if (G.lastET > 0) G.lastET -= raw;
    const pc = playerCtl(); let p = G.player;
    if (G.over > 0) { G.over += raw; updHero(p, dt, { mx: 0, my: 0 }); if (G.over > 2.2) { Scene.go('over'); return; } } else updHero(p, dt, G.autoTag > 0 ? { mx: 0, my: 0 } : pc);
    tagStep(dt, pc); p = G.player;
    for (const e of G.enemies) updEnemy(e, dt);
    separate(dt);
    G.enemies = G.enemies.filter(e => !(e.dead && e.deadT > (e.kind === 'boss' ? 99 : 1.4)));
    for (const pr of G.props) { if (pr.dead) continue; pr.flash = Math.max(0, pr.flash - dt * 5); pr.x += pr.vx * dt; friction(pr, dt, 10); }
    G.props = G.props.filter(pr => !pr.dead);
    for (const q of G.proj) updProj(q, dt); G.proj = G.proj.filter(q => q.life > 0 && q.x > G.camX - 160 && q.x < G.camX + VW + 160);
    fxStep(dt);
    for (const d of G.drops) {
      d.t += dt; if (d.z > 0 || d.vz) { d.vz -= GRAV * dt; d.z += d.vz * dt; if (d.z <= 0) { d.z = 0; d.vz = d.vz < -60 ? -d.vz * 0.4 : 0; } }
      for (const h of G.heroes) { if (h.dead || d.got) continue; if (Math.abs(h.x - d.x) < 16 && Math.abs(h.y - d.y) < 12) { d.got = true; sfx('pick'); if (d.type === 'vial') { h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.25); textFx(h.x, h.y - 90, '+HP', '#ff4060', 1); } else if (d.type === 'fury') { if (h.id === 'lupus') h.fury = Math.min(300, h.fury + 45); else h.spCd = Math.max(0, h.spCd - 3); textFx(h.x, h.y - 90, '+' + T('fury'), COLR.gold, 1); } else { G.score += 250; textFx(h.x, h.y - 90, '+250', COLR.gold, 1); } } }
    }
    G.drops = G.drops.filter(d => !d.got && d.t < 25);
    this.waves(dt);
    /* camera: smooth follow with a small look-ahead in the facing direction */
    const end = WORLD_W - VW; const goal = G.locked ? (G.bossPending || G.bossSpawned ? end : G.camX) : end;
    G.look = lerp(G.look || 0, p.face * 18 * (Math.abs(p.vx) > 20 ? 1 : 0.4), Math.min(1, dt * 2.5));
    const tgt = clamp(p.x - VW * 0.36 + G.look, G.camX, goal);
    if (!(G.locked && !(G.bossPending || G.bossSpawned))) G.camX = lerp(G.camX, tgt, Math.min(1, dt * 5));
    G.camX = Math.min(G.camX, end);
    if (G.sayQ) { G.sayDelay -= raw; if (G.sayDelay <= 0) { G.say = G.sayQ; G.sayT = 3.6; G.sayQ = null; } }
    if (G.sayT > 0) { G.sayT -= raw; if (G.sayT <= 0) G.say = null; }
    if (G.banner) { G.banner.t += raw; if (G.banner.t > 2.6) G.banner = null; }
    if (G.goT > 0) G.goT -= raw;
    if (G.boss && G.boss.dead && G.clearT > 0) { G.clearT += raw; for (const e of G.enemies) if (!e.dead && e.kind !== 'boss') kill(e, 1, p); if (G.clearT > 1.6) G.player.taunt = true; if (G.clearT > 3.6) this.finish(); }
  },
  waves(dt) {
    const st = G.st, p = G.player;
    if (!G.locked && !G.bossSpawned) {
      const w = st.waves[G.waveIdx];
      if (w && p.x > w.x) { G.locked = true; G.spawnQ = w.e.map((t, i) => ({ t: 0.2 + i * 0.5, type: t, side: i % 3 === 2 ? -1 : 1 })); sfx('alarm'); }
      else if (!w && p.x > WORLD_W - VW * 0.62) { G.locked = true; G.bossPending = true; G.bossT = 1.8; G.banner = { t: 0, boss: BOSS[st.boss] }; sfx('alarm'); musicStart(st.music); }
    }
    if (G.locked) {
      for (const s of G.spawnQ) s.t -= dt; const due = G.spawnQ.filter(s => s.t <= 0); G.spawnQ = G.spawnQ.filter(s => s.t > 0); due.forEach(s => spawnEnemy(s.type, s.side));
      if (G.bossPending) { G.bossT -= dt; if (G.bossT <= 0) { G.bossPending = false; spawnBoss(st.boss); sfx('roar'); shake(8); } }
      else if (G.spawnQ.length === 0 && !G.bossSpawned && enemiesAlive() === 0) {
        G.locked = false; G.waveIdx++; G.goT = 4; sfx('ok');
        for (const h of G.team) if (!h.dead) h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.12);
      }
    }
  },
  finish() { const st = G.st; const res = { score: Math.round(G.score), time: G.time, combo: G.maxCombo, stage: G.stage }; if (!SAVE.best[st.id] || SAVE.best[st.id] < res.score) SAVE.best[st.id] = res.score; if (G.stage + 2 > SAVE.unlocked && G.stage < 4) SAVE.unlocked = G.stage + 2; saveGame(); playCut('s' + st.id + 'post', () => Scene.go('clear', res)); },
  onKey(k) { if (k === 'pause' || k === 'hide') { if (G.over > 0 || G.clearT > 0) return; this.menu = k === 'hide' ? true : !this.menu; } },
  onDown(id, x, y) {
    if (this.menu) {
      const b = hitB(this.btns, x, y); if (!b) return; sfx('ok');
      if (b.id === 'resume') this.menu = false; else if (b.id === 'restart') Scene.go('play', G.stage); else if (b.id === 'quit') Scene.go('stages');
      else if (b.id === 'music') { SAVE.music = !SAVE.music; setAudioOpts(); saveGame(); } else if (b.id === 'sfx') { SAVE.sfx = !SAVE.sfx; setAudioOpts(); saveGame(); } else if (b.id === 'lang') { setLang(LANGS[(LANGS.indexOf(SAVE.lang) + 1) % LANGS.length]); }
      return;
    }
    if (Math.hypot(x - (VW - 14), y - 14) < 14) { this.menu = true; sfx('ui'); return; }
    const B = BTN();
    for (const n in B) { if (n === 'form' && G.player.id !== 'lupus') continue; if ((n === 'tag' || n === 'assist') && G.ally.dead) continue; const b = B[n]; if (Math.hypot(x - b.x, y - b.y) < b.r + 7) { Inp.btnIds[id] = n; Inp.held[n] = true; Inp.edge[n] = true; return; } }
    if (x < VW * 0.5 && Inp.joy.id == null) { const j = Inp.joy; j.id = id; j.ox = x; j.oy = y; j.x = x; j.y = y; j.ax = j.ay = 0; }
  },
  onMove(id, x, y) { const j = Inp.joy; if (j.id === id) { let dx = x - j.ox, dy = y - j.oy; const d = Math.hypot(dx, dy); if (d > JOY.r) { j.ox += dx / d * (d - JOY.r); j.oy += dy / d * (d - JOY.r); dx = x - j.ox; dy = y - j.oy; } j.x = x; j.y = y; j.ax = dx / JOY.r; j.ay = dy / JOY.r; } },
  onUp(id) { if (Inp.joy.id === id) { Inp.joy.id = null; Inp.joy.ax = Inp.joy.ay = 0; } const n = Inp.btnIds[id]; if (n) { Inp.held[n] = false; delete Inp.btnIds[id]; } },
  draw(g) {
    if (PORTRAIT) { g.fillStyle = '#07040d'; g.fillRect(0, 0, VW, VH); PIX.text(g, T('rotate'), VW / 2, VH / 2, { align: 'c', s: 2, col: COLR.white }); return; }
    const sx = G.shake > 0.3 ? rnd(-G.shake, G.shake) : 0, sy = G.shake > 0.3 ? rnd(-G.shake, G.shake) * 0.6 : 0;
    g.save(); g.translate(half(sx), half(sy));
    const cam = half(G.camX), look = ART.look;
    let ck = 0; if (G.cine) { const t = G.cine.t, d = G.cine.dur; ck = Math.min(1, t / 0.25, (d - t) / 0.25 + 0.0001); ck = ck * ck * (3 - 2 * ck); const h = G.cine.h, fx = h.x - cam, fy = h.y - 55; const z = 1 + 0.32 * ck; g.translate(VW / 2, VH * 0.5); g.scale(z, z); g.translate(-lerp(VW / 2, fx, ck), -lerp(VH * 0.5, fy, ck)); }
    BG.back(g, cam, G.hitstop > 0 ? 0 : 1 / 60);
    const ents = [...G.props, ...G.heroes, ...G.enemies, ...G.leaving].sort((a, b) => (a.y + (a === G.player ? 3 : 0)) - (b.y + (b === G.player ? 3 : 0)));
    /* reflections (wet floors / water) */
    if (look.refl) { g.save(); g.beginPath(); g.rect(0, WALL_Y + 4, VW, VIEW_H); g.clip(); g.imageSmoothingEnabled = true; for (const e of ents) { if (e.kind === 'prop') continue; const fr = frameOf(e); ART.reflect(g, fr, e.x - cam, e.y, e.z, e.face, look.refl * (e.dead ? 0.5 : 1), G.time, look.water, depthScale(e.y)); } g.restore(); g.imageSmoothingEnabled = false; }
    /* contact shadows */
    for (const e of ents) { const big = e.kind === 'boss' ? (e.def.wide ? 2.6 : 1.5) : e.def && e.def.heavy ? 1.3 : 1; ART.shadow(g, e.x - cam, e.y + 1, (e.kind === 'prop' ? 13 : 17) * big * depthScale(e.y) * (1 - Math.min(0.55, e.z / 150)), (e.dead ? 0.3 : 0.62) * (1 - Math.min(0.5, e.z / 200))); }
    for (const d of G.drops) { ART.shadow(g, d.x - cam, d.y, 6, 0.5); ART.item(g, d.type === 'fury' ? 'orb' : d.type, d.x - cam, d.y - d.z - 1 - Math.abs(Math.sin(d.t * 4)) * 2, { sc: 1 }); RD.glow(g, d.x - cam, d.y - d.z - 6, 12, d.type === 'vial' ? '#ff2040' : COLR.gold, 0.3); }
    for (const e of ents) drawEnt(g, e, cam);
    /* x-ray: when a body in front covers the active hero, redraw him as a glowing outline + ghost so he never vanishes */
    { const pl = G.player, fr = pl && pl._lastFr; if (fr && !pl.dead && !G.cine) {
      const H = entHeight(pl), occ = G.enemies.filter(e => !e.dead && e.y > pl.y + 3 && e.y - pl.y < 60 && Math.abs(e.x - pl.x) < (e.kind === 'boss' ? (e.def.wide ? 95 : 55) : 26) + 10);
      if (occ.length) {
        const x = pl.x - cam, y = pl.y - pl.z, sc = depthScale(pl.y), col = pl.id === 'lupus' ? (pl.form === 'a' ? '#ff2a40' : '#ffb02a') : HERO[pl.id].color;
        g.imageSmoothingEnabled = true;
        for (const [dx, dy] of [[-1.5, 0], [1.5, 0], [0, -1.5], [0, 1.5]]) ART.draw(g, fr, x + dx, y + dy, { face: pl.face, sc, tint: col, tintA: 1, alpha: 0.9 });
        ART.draw(g, fr, x, y, { face: pl.face, sc, alpha: 0.9, rims: ART.rimsAt(pl.x, pl.y, H, G.time) }); g.imageSmoothingEnabled = false;
        const ay = y - H * sc - 8 + Math.sin(G.time * 8) * 1.5; g.fillStyle = '#000'; g.beginPath(); g.moveTo(x - 5, ay - 1); g.lineTo(x + 5, ay - 1); g.lineTo(x, ay + 6); g.fill(); g.fillStyle = col; g.beginPath(); g.moveTo(x - 3.5, ay); g.lineTo(x + 3.5, ay); g.lineTo(x, ay + 4.5); g.fill();
      }
    } }
    if (ck > 0) { const h = G.cine.h, hx = h.x - cam, hy = h.y - 50; const gr = g.createRadialGradient(hx, hy, 30, hx, hy, 260); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(4,0,8,' + 0.78 * ck + ')'); g.fillStyle = gr; g.fillRect(cam - VW, -VH, VW * 3, VH * 3); g.fillStyle = gr; g.fillRect(-VW, -VH, VW * 3, VH * 3); drawEnt(g, h, cam); }
    for (const l of G.lines) { const k = l.t / l.dur, x0 = l.x - cam + l.face * 14, len = l.len * Math.min(1, k * 3); g.save(); g.globalAlpha = 1 - k; g.strokeStyle = '#c8ccd8'; g.lineWidth = 2; g.setLineDash([3, 2]); g.beginPath(); g.moveTo(x0, l.y - l.z); g.lineTo(x0 + l.face * len, l.y - l.z + Math.sin(l.t * 40) * 2); g.stroke(); g.restore(); }
    for (const p of G.proj) drawProj(g, p, cam);
    for (const s of G.slashes) drawSlash(g, s, cam);
    for (const r of G.rings) { const k = r.t / r.dur; g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = 1 - k; g.strokeStyle = r.col; g.lineWidth = 3 * (1 - k) + 0.5; g.beginPath(); g.ellipse(r.x - cam, r.y - r.z, lerp(8, r.rmax, k), lerp(8, r.rmax, k) * 0.32, 0, 0, 7); g.stroke(); g.restore(); }
    for (const f of G.flashes) drawImpact(g, f, cam);
    for (const q of G.parts) {
      if (q.img) { ART.item(g, q.img, q.x - cam, q.y - q.z, { rot: q.rot, alpha: Math.min(1, 3 * (1 - q.t / q.life)), center: true }); continue; }
      if (q.glowP) { RD.glow(g, q.x - cam, q.y - q.z, 5, q.col, 0.8 * (1 - q.t / q.life)); }
      g.globalAlpha = q.dust ? 0.55 * (1 - q.t / q.life) : Math.min(1, 2 * (1 - q.t / q.life)); g.fillStyle = q.col; const s = q.size * (q.dust ? 1.5 : 0.75); g.fillRect(q.x - cam - s / 2, q.y - q.z - s / 2, s, s);
    }
    g.globalAlpha = 1;
    BG.front(g, cam);
    for (const q of G.texts) PIX.text(g, q.s, q.x - cam, q.y, { align: 'c', s: q.size, col: q.col });
    g.restore();
    BG.atmos(g, G.time);
    if (G.flashScr > 0) { g.fillStyle = 'rgba(255,40,70,' + G.flashScr * 0.28 + ')'; g.fillRect(0, 0, VW, VH); }
    const pl = G.player; if (pl.hp < pl.maxhp * 0.25 && !pl.dead) { const v = g.createRadialGradient(VW / 2, VH / 2, VH * 0.4, VW / 2, VH / 2, VH); v.addColorStop(0, 'rgba(160,0,20,0)'); v.addColorStop(1, 'rgba(160,0,20,' + (0.25 + 0.12 * Math.sin(G.time * 6)) + ')'); g.fillStyle = v; g.fillRect(0, 0, VW, VH); }
    if (G.cine || (G.cineBar || 0) > 0) { G.cineBar = G.cine ? Math.min(1, (G.cineBar || 0) + 0.08) : Math.max(0, G.cineBar - 0.08); }
    if (!(G.cineBar > 0.5)) { drawHUD(g); drawOverlays(g); drawControls(g); }
    if (G.cineBar > 0) { const bh = 26 * G.cineBar; g.fillStyle = '#000'; g.fillRect(0, 0, VW, bh); g.fillRect(0, VH - bh, VW, bh); if (G.cine && G.cine.h.xswap) { const f = G.cine.h.form; PIX.text(g, T(FORM[f].label) + '!', VW / 2, VH - bh / 2 - 7, { s: 2, align: 'c', col: f === 'a' ? '#ff2a40' : '#ffb02a' }); } }
    if (this.menu) { dim(g, 0.8); PIX.text(g, T('paused'), VW / 2, 30, { s: 3, align: 'c', col: COLR.red }); for (const b of this.btns) drawBtn(g, b); }
  }
};
function drawSlash(g, s, cam) {
  const k = s.t / s.dur, x = s.x - cam, y = s.y - s.z; const R = s.size * (0.8 + 0.35 * k);
  g.save(); g.translate(x, y); if (s.face < 0) g.scale(-1, 1); g.rotate(s.ang); g.globalCompositeOperation = 'lighter';
  const a0 = -1.2 + k * 0.5, a1 = 1.15, th = Math.max(0.5, (1 - k) * R * 0.32);
  g.globalAlpha = (1 - k) * 0.9; g.fillStyle = s.col;
  g.beginPath(); g.arc(0, 0, R, a0, a1); g.arc(-th * 0.6, 0, R - th, a1, a0, true); g.closePath(); g.fill();
  g.globalAlpha = (1 - k); g.fillStyle = '#ffffff'; g.beginPath(); g.arc(0, 0, R, a0 + 0.2, a1 - 0.1); g.arc(-th * 0.15, 0, R - th * 0.3, a1 - 0.1, a0 + 0.2, true); g.closePath(); g.fill();
  g.restore();
}
function drawImpact(g, f, cam) {
  const k = f.t / f.dur, x = f.x - cam, y = f.y - f.z, R = (f.big ? 18 : 11) * (0.6 + k * 0.7);
  g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = 1 - k; g.strokeStyle = f.col; g.lineWidth = f.big ? 1.5 : 1;
  g.beginPath(); for (let i = 0; i < 8; i++) { const a = i / 8 * 6.28 + 0.3; const l0 = R * 0.3, l1 = i % 2 ? R * 0.6 : R; g.moveTo(x + Math.cos(a) * l0, y + Math.sin(a) * l0 * 0.8); g.lineTo(x + Math.cos(a) * l1, y + Math.sin(a) * l1 * 0.8); } g.stroke();
  g.restore(); RD.glow(g, x, y, R * 1.6, f.col === '#ffffff' ? '#ffe0c0' : f.col, 0.4 * (1 - k));
}
function drawProj(g, p, cam) {
  const x = p.x - cam, y = p.y - p.z, s = Math.sign(p.vx) || 1;
  RD.glow(g, x, y, p.r * 2 + 8, p.col, 0.4);
  g.save(); g.globalCompositeOperation = 'lighter';
  if (p.type === 'bolt') { g.fillStyle = p.col; g.fillRect(Math.min(x, x - s * 12), y - 1, 12, 2); g.fillStyle = '#fff'; g.fillRect(x - (s > 0 ? 4 : 0), y - 0.5, 4, 1); }
  else if (p.type === 'beam') { g.fillStyle = p.col; g.fillRect(Math.min(x, x - s * 70), y - 1.5, 70, 3); g.fillStyle = '#fff'; g.fillRect(Math.min(x, x - s * 66), y - 0.5, 66, 1); }
  else if (p.type === 'orb') { const r = p.r * (0.75 + 0.15 * Math.sin(p.t * 20)); const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.4, p.col); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); if (p.big) { g.strokeStyle = p.col; g.lineWidth = 1.5; g.beginPath(); g.arc(x, y, r * 1.1, p.t * 8, p.t * 8 + 4); g.stroke(); } }
  else if (p.type === 'wave') { g.translate(x, y); g.scale(s, 1); g.fillStyle = p.col; g.globalAlpha = 0.85; g.beginPath(); g.moveTo(-6, -30); g.quadraticCurveTo(22, -12, 4, 14); g.quadraticCurveTo(12, -12, -6, -30); g.fill(); g.fillStyle = '#ffffff'; g.globalAlpha = 0.7; g.beginPath(); g.moveTo(-2, -26); g.quadraticCurveTo(18, -10, 4, 10); g.quadraticCurveTo(10, -10, -2, -26); g.fill(); }
  else if (p.type === 'spike') { g.fillStyle = '#f2ece0'; g.beginPath(); g.moveTo(x + s * 9, y); g.lineTo(x - s * 6, y - 1.5); g.lineTo(x - s * 6, y + 1.5); g.fill(); g.fillStyle = '#ff1a3a'; g.fillRect(x + (s > 0 ? 5 : -7), y - 0.75, 2, 1.5); }
  else if (p.type === 'shock') { g.fillStyle = p.col; for (let i = -10; i <= 10; i++) g.fillRect(x + i * 2, p.y - Math.abs(Math.sin(p.t * 20 + i)) * 8, 1.5, 2); }
  g.restore();
}

/* ---------- HUD ---------- */
function drawHUD(g) {
  const p = G.player, a = G.ally, H = HERO[p.id];
  PIX.panel(g, 4, 4, 140, 38, { edge: H.color });
  drawFace(g, heroKey(p), 7, 7, 32);
  PIX.text(g, H.name, 42, 8, { col: COLR.white });
  PIX.bar(g, 42, 18, 98, 7, p.hp / p.maxhp, '#ff2a40', '#2a0810');
  if (p.shieldHP > 0) { g.fillStyle = COLR.lime; g.fillRect(43, 18, Math.min(96, 96 * p.shieldHP / p.maxhp), 1); }
  if (p.id === 'lupus') { PIX.text(g, T('fury'), 42, 30, { col: COLR.gold, out: null }); const full = p.fury >= (p.form === 'h' ? 100 : 200); PIX.bar(g, 76, 30, 64, 6, p.fury / 300, full && Math.sin(G.time * 10) > 0 ? '#ffe05a' : COLR.gold, '#2a1a08', 3); }
  else { PIX.text(g, T('sp_' + p.id), 42, 30, { col: H.color, out: null }); PIX.bar(g, 94, 30, 46, 6, 1 - p.spCd / Math.max(0.1, hs(p).cd), H.color, '#1a1020'); }
  if (p.id === 'lupus') { ['h', 'f', 'a'].forEach((f, i) => { const cur = p.form === f; const x = VW / 2 - 46 + i * 32; PIX.panel(g, x, 5, 28, 28, { edge: cur ? (f === 'a' ? '#ff1a3a' : f === 'f' ? '#ff8a30' : '#e8e8f0') : '#3a3448', cut: 3, bg: 'rgba(10,6,18,0.8)' }); g.save(); if (!cur) g.globalAlpha = 0.35; drawFace(g, 'lupus_' + f, x + 2, 7, 24); g.restore(); }); PIX.text(g, T(FORM[p.form].label), VW / 2, 37, { align: 'c', col: p.form === 'a' ? COLR.red : p.form === 'f' ? '#ff8a30' : '#c8c0d8' }); }
  if (a) {
    const ready = canTag(); g.save(); if (a.dead) g.globalAlpha = 0.5; PIX.panel(g, 4, 44, 108, 26, { edge: ready ? HERO[a.id].color : '#3a3448', cut: 3, bg: 'rgba(10,6,18,0.78)' }); drawFace(g, heroKey(a), 6, 46, 22); g.restore();
    PIX.text(g, HERO[a.id].name, 31, 48, { col: a.dead ? '#6a6480' : COLR.white, out: '#0c0710' }); PIX.bar(g, 31, 58, 76, 5, a.dead ? 0 : a.hp / a.maxhp, HERO[a.id].color, '#1a1020');
    if (a.dead) PIX.text(g, T('ko'), 108 - PIX.textW(T('ko'), 1), 48, { col: COLR.red }); else if (ready && Math.sin(G.time * 5) > 0) PIX.text(g, T('tag'), 108 - PIX.textW(T('tag'), 1), 48, { col: COLR.gold, out: '#0c0710' });
    if (!a.dead && G.assistCd > 0) { g.fillStyle = '#ffd23a'; g.fillRect(31, 65, Math.round(76 * (1 - G.assistCd / ASSIST_CD)), 1); }
  }
  PIX.text(g, String(Math.round(G.score)).padStart(7, '0'), VW - 30, 8, { align: 'r', col: COLR.gold });
  g.fillStyle = 'rgba(10,6,18,0.8)'; pixCircle(g, VW - 14, 14, 9); g.fillStyle = '#9a94ac'; g.fillRect(VW - 17, 10, 2, 8); g.fillRect(VW - 13, 10, 2, 8);
  PIX.text(g, T('stage') + ' ' + G.st.id + ': ' + G.st.name[SAVE.lang], VW - 30, 20, { align: 'r', col: '#c8c0d8', out: '#0c0710' });
  if (G.combo >= 3) { const rank = G.combo >= 40 ? 4 : G.combo >= 20 ? 3 : G.combo >= 10 ? 2 : G.combo >= 5 ? 1 : 0; const bump = G.comboT > 2.2 ? 1 : 0; PIX.text(g, '' + G.combo, 8, 78 - bump, { s: 3, col: '#ffb02a' }); PIX.text(g, T('hits'), 10 + PIX.textW('' + G.combo, 3) + 4, 86, { col: COLR.white }); if (rank) PIX.text(g, T('combo')[rank], 8, 104, { s: 2, col: COLR.red }); }
  const b = G.boss;
  if (b && !b.dead && b.bossIn <= 0) { const w = Math.min(230, VW - 230), x = Math.round(VW / 2 - w / 2) + 12; drawFace(g, b.key === 'nacht_big' ? 'nacht' : b.key, x - 26, 48, 22); PIX.text(g, b.def.name, VW / 2 + 12, 50, { align: 'c', col: COLR.white }); PIX.bar(g, x, 60, w, 7, b.hp / b.maxhp, '#c4001f', '#2a0810'); g.fillStyle = '#ffffff'; g.fillRect(x + Math.round(w / 2), 60, 1, 7); }
  else if (G.lastE && G.lastET > 0 && !G.lastE.dead && G.lastE.kind === 'enemy') { const e = G.lastE; PIX.text(g, e.def.name, VW - 8, 34, { align: 'r', col: '#c8c0d8' }); PIX.bar(g, VW - 88, 44, 80, 5, e.hp / e.maxhp, '#ff2a40', '#2a0810'); }
}
function drawOverlays(g) {
  if (G.title > 0) {
    const k = G.title / 2.8, a = k > 0.85 ? (1 - k) / 0.15 : k < 0.2 ? k / 0.2 : 1;
    g.save(); g.globalAlpha = a; g.fillStyle = 'rgba(6,3,12,0.72)'; g.fillRect(0, VH / 2 - 44, VW, 88);
    PIX.text(g, T('stage') + ' 0' + G.st.id, VW / 2, VH / 2 - 36, { align: 'c', col: COLR.red });
    PIX.text(g, G.st.name[SAVE.lang], VW / 2, VH / 2 - 22, { align: 'c', s: 2, grad: ['#ffffff', '#c8ccd8', '#8a8ea0'] });
    PIX.text(g, G.st.sub[SAVE.lang], VW / 2, VH / 2 + 4, { align: 'c', col: '#b8b0c8' });
    PIX.text(g, T('objective') + ': ' + G.st.obj[SAVE.lang], VW / 2, VH / 2 + 20, { align: 'c', col: COLR.cyan }); g.restore();
  }
  if (G.banner) {
    const b = G.banner, k = b.t / 2.6, a = k < 0.1 ? k / 0.1 : k > 0.85 ? (1 - k) / 0.15 : 1;
    g.save(); g.globalAlpha = a; g.fillStyle = 'rgba(70,0,10,0.8)'; g.fillRect(0, 66, VW, 72); g.fillStyle = COLR.red; g.fillRect(0, 66, VW, 1); g.fillRect(0, 137, VW, 1);
    drawFace(g, b.boss.key, VW / 2 - 140, 70, 64);
    if (Math.sin(b.t * 14) > 0) PIX.text(g, '! ' + T('bossWarn') + ' !', VW / 2 + 30, 74, { align: 'c', col: '#ff5060' });
    PIX.text(g, b.boss.name, VW / 2 + 30, 92, { align: 'c', s: 2, col: COLR.white }); PIX.text(g, b.boss.sub, VW / 2 + 30, 118, { align: 'c', col: COLR.red }); g.restore();
  }
  if (G.goT > 0 && Math.sin(G.time * 8) > -0.2) PIX.text(g, T('go') + ' >', VW - 60, 120, { s: 2, col: COLR.gold });
  if (G.say) { const s = G.say; g.save(); g.globalAlpha = Math.min(1, G.sayT * 2); PIX.panel(g, VW / 2 - 130, VH - 54, 260, 34, { edge: HERO[s.w].color }); drawFace(g, ROSTER_KEY[s.w], VW / 2 - 127, VH - 51, 28); PIX.text(g, HERO[s.w].name, VW / 2 - 94, VH - 48, { col: HERO[s.w].color }); PIX.text(g, s[SAVE.lang], VW / 2 - 94, VH - 36, { col: COLR.white }); g.restore(); }
  if (G.hintT >= 5 && G.hintT < 10 && G.stage === 0) PIX.text(g, T('hintTag'), VW / 2, 70, { align: 'c', col: COLR.gold });
  if (G.hintT > 0 && G.hintT < 5 && G.stage === 0) PIX.text(g, G.player.id === 'lupus' && G.hintT < 2.5 ? T('hint2') : T('hint1'), VW / 2, 70, { align: 'c', col: '#c8c0d8' });
  if (G.boss && G.boss.dead && G.clearT > 1.6) { g.fillStyle = 'rgba(0,0,0,' + Math.min(0.85, (G.clearT - 1.6) / 2) + ')'; g.fillRect(0, 0, VW, VH); }
  if (G.over > 0) { g.fillStyle = 'rgba(0,0,0,' + Math.min(0.9, G.over / 2) + ')'; g.fillRect(0, 0, VW, VH); }
}

/* ---------- touch controls ---------- */
const ctrlCache = {};
function ctrlDisc(r, col, held) {
  const k = r + col + held; if (ctrlCache[k]) return ctrlCache[k];
  const [c, g] = PIX.canvas(r * 2 + 4, r * 2 + 4); const o = r + 2;
  g.fillStyle = '#0a0612'; pixCircle(g, o, o, r + 1); g.fillStyle = col; pixCircle(g, o, o, r); g.fillStyle = held ? PIX.shade(col, 0.55) : 'rgba(12,8,22,1)'; pixCircle(g, o, o, r - 2);
  g.fillStyle = 'rgba(255,255,255,0.12)'; for (let yy = -r + 3; yy < -r / 3; yy++) { const w = Math.floor(Math.sqrt((r - 3) * (r - 3) - yy * yy)); g.fillRect(o - w, o + yy, w * 2, 1); }
  return ctrlCache[k] = c;
}
function icon(g, name, x, y, col) {
  g.fillStyle = col;
  if (name === 'atk') { for (let i = 0; i < 3; i++) for (let s = 0; s < 10; s++) g.fillRect(x - 6 + i * 4 + Math.round(s * 0.5), y - 5 + s, 2, 1); }
  else if (name === 'jump') { for (let s = 0; s < 6; s++) g.fillRect(x - s, y - 4 + s, s * 2 + 1, 1); g.fillRect(x - 1, y + 2, 3, 4); }
  else if (name === 'dash') { for (const o of [-4, 1]) for (let s = 0; s < 5; s++) { g.fillRect(x + o + s, y - 5 + s, 2, 1); g.fillRect(x + o + s, y + 5 - s, 2, 1); } }
  else if (name === 'spec') { for (let i = 0; i < 8; i++) { const a = i / 8 * 6.28; for (let s = 2; s < (i % 2 ? 5 : 8); s++) g.fillRect(Math.round(x + Math.cos(a) * s), Math.round(y + Math.sin(a) * s), 1, 1); } g.fillRect(x - 1, y - 1, 3, 3); }
}
function drawControls(g) {
  if (G.over > 0 || Scenes.play.menu) return; const B = BTN(); const p = G.player;
  const j = Inp.joy; const jx = j.id != null ? Math.round(j.ox) : 50, jy = j.id != null ? Math.round(j.oy) : 214;
  g.save(); g.globalAlpha = j.id != null ? 0.75 : 0.4; g.drawImage(ctrlDisc(JOY.r, '#6a6480', false), jx - JOY.r - 2, jy - JOY.r - 2);
  const kx = j.id != null ? j.x : jx, ky = j.id != null ? j.y : jy; const dx = kx - jx, dy = ky - jy, dd = Math.hypot(dx, dy) || 1, m = Math.min(dd, JOY.r);
  g.globalAlpha = j.id != null ? 0.9 : 0.5; g.drawImage(ctrlDisc(13, '#c8c0d8', true), Math.round(jx + dx / dd * m) - 15, Math.round(jy + dy / dd * m) - 15); g.restore();
  const s = hs(p);
  const one = (n, col, ic, extra) => { const b = B[n], held = Inp.held[n]; g.save(); g.globalAlpha = held ? 0.9 : 0.5; g.drawImage(ctrlDisc(b.r, col, held), b.x - b.r - 2, b.y - b.r - 2); if (ic) icon(g, ic, b.x, b.y, held ? '#ffffff' : col); if (extra) extra(b); g.restore(); };
  one('atk', '#ff2a40', 'atk'); one('jump', '#3af0ff', 'jump'); one('dash', '#c8c0d8', 'dash');
  one('spec', COLR.gold, 'spec', b => { const r = p.spCd / s.cd; if (r > 0) { g.fillStyle = 'rgba(0,0,0,0.6)'; g.beginPath(); g.moveTo(b.x, b.y); g.arc(b.x, b.y, b.r - 2, -Math.PI / 2, -Math.PI / 2 + 6.283 * r); g.closePath(); g.fill(); } });
  { const a = G.ally; if (a && !a.dead) {
      const face = (n, ok, cdk, col) => one(n, ok ? col : '#5a5470', null, b => { g.save(); g.beginPath(); g.arc(b.x, b.y, b.r - 3, 0, 7); g.clip(); if (!ok) g.globalAlpha = 0.45; drawFace(g, heroKey(a), b.x - b.r + 3, b.y - b.r + 3, (b.r - 3) * 2); g.restore(); if (cdk > 0) { g.fillStyle = 'rgba(0,0,0,0.6)'; g.beginPath(); g.moveTo(b.x, b.y); g.arc(b.x, b.y, b.r - 2, -Math.PI / 2, -Math.PI / 2 + 6.283 * cdk); g.closePath(); g.fill(); } const L = T(n); PIX.text(g, L, b.x, b.y + b.r + 1, { align: 'c', col: ok ? col : '#8a84a0', out: '#000' }); });
      face('tag', canTag(), G.tagCd / TAG_CD, HERO[a.id].color); face('assist', canAssist(), G.assistCd / ASSIST_CD, COLR.gold);
  } }
  if (p.id === 'lupus') { const ready = p.fury >= (p.form === 'h' ? 100 : 200); one('form', ready ? '#ffd23a' : '#7a6a40', null, b => { const nf = p.form === 'h' ? 'lupus_f' : p.form === 'f' ? (ready ? 'lupus_a' : 'lupus_h') : 'lupus_f'; g.save(); g.beginPath(); g.arc(b.x, b.y, b.r - 3, 0, 7); g.clip(); drawFace(g, nf, b.x - b.r + 3, b.y - b.r + 3, (b.r - 3) * 2); g.restore(); if (ready && Math.sin(G.time * 10) > 0) { g.strokeStyle = '#ffd23a'; g.lineWidth = 1; g.beginPath(); g.arc(b.x, b.y, b.r + 3, 0, 7); g.stroke(); } }); }
}

/* =========================== GAME OVER =========================== */
Scenes.over = {
  t: 0, btns: [],
  enter() { this.t = 0; sfx('die'); },
  update(dt) { this.t += dt; this.btns = [btn('retry', VW / 2 - 70, 170, 140, 18, T('retry'), COLR.red), btn('menu', VW / 2 - 70, 194, 140, 18, T('menu'), COLR.gray)]; },
  draw(g) { BG.back(g, G ? G.camX : 0, 0); dim(g, 0.78); ART.draw(g, ART.frame(heroKey(G.player), 'down', 0), VW / 2, 148, { face: 1 }); PIX.text(g, T('gameOver'), VW / 2, 44, { s: 4, align: 'c', col: COLR.red }); PIX.text(g, T('goLine'), VW / 2, 86, { align: 'c', col: '#b8b0c8' }); for (const b of this.btns) drawBtn(g, b); },
  onDown(id, x, y) { const b = hitB(this.btns, x, y); if (!b) return; sfx('ok'); if (b.id === 'retry') Scene.go('play', G.stage); else Scene.go('stages'); }
};

/* =========================== CLEAR + UPGRADE =========================== */
Scenes.clear = {
  t: 0, res: null, step: 0, cards: [], btn: null, opts: [],
  enter(res) { this.res = res; this.t = 0; this.step = res.stage >= 4 ? 1 : 0; sfx('ok'); this.opts = ['dmg', 'hp', 'fury', 'cd'].sort(() => Math.random() - 0.5).slice(0, 3); musicStart(5); },
  update(dt) { this.t += dt; const cw = 110, gap = 10, x0 = Math.round((VW - (cw * 3 + gap * 2)) / 2) + 30; this.cards = this.opts.map((o, i) => ({ id: o, x: x0 + i * (cw + gap), y: 96, w: cw, h: 100 })); this.btn = btn('go', VW / 2 - 40, 214, 140, 18, this.res.stage >= 4 ? T('theEnd') + ' >' : T('stages') + ' >', COLR.red); },
  draw(g) {
    BG.back(g, WORLD_W - VW, 1 / 60); dim(g, 0.6);
    const hk = heroKey(G.player); g.imageSmoothingEnabled = true; ART.draw(g, ART.frame(hk, 'win', Math.floor(this.t * 7)), 58, 252, { face: 1, rims: ART.rimsAt(WORLD_W - VW + 58, 252, 80, this.t) }); g.imageSmoothingEnabled = false;
    PIX.text(g, T('clear'), VW / 2, 18, { s: 3, align: 'c', grad: ['#ffffff', '#ff8090', '#ff2a40'] });
    const R = this.res, m = Math.floor(R.time / 60), s = Math.floor(R.time % 60);
    PIX.text(g, T('score') + ' ' + R.score + '   ' + T('time') + ' ' + m + ':' + String(s).padStart(2, '0') + '   ' + T('maxCombo') + ' ' + R.combo, VW / 2, 52, { align: 'c', col: COLR.white });
    if (this.step === 0) {
      PIX.text(g, T('pickUp'), VW / 2 + 30, 78, { align: 'c', col: COLR.gold });
      for (const k of this.cards) { PIX.panel(g, k.x, k.y, k.w, k.h, { edge: COLR.red }); const ic = { dmg: 'atk', hp: 'vial', fury: 'orb', cd: 'spec' }[k.id]; if (ic === 'atk' || ic === 'spec') { g.fillStyle = 'rgba(255,40,64,0.15)'; pixCircle(g, k.x + k.w / 2, k.y + 26, 15); icon(g, ic, k.x + k.w / 2, k.y + 26, COLR.red); } else ART.item(g, ic, k.x + k.w / 2, k.y + 40, { sc: 1.3 }); PIX.text(g, T('up_' + k.id), k.x + k.w / 2, k.y + 50, { align: 'c', col: COLR.white }); PIX.text(g, T('up_' + k.id + '_d'), k.x + k.w / 2, k.y + 66, { align: 'c', col: COLR.cyan, out: null }); PIX.text(g, 'LV ' + SAVE.up[k.id], k.x + k.w / 2, k.y + 84, { align: 'c', col: COLR.gray, out: null }); }
    } else drawBtn(g, this.btn, Math.sin(this.t * 5) > 0);
  },
  onDown(id, x, y) {
    if (this.step === 0) { for (const k of this.cards) if (x >= k.x && x <= k.x + k.w && y >= k.y && y <= k.y + k.h) { SAVE.up[k.id]++; saveGame(); sfx('ok'); this.step = 1; return; } }
    else if (hitB([this.btn], x, y)) { sfx('ok'); if (this.res.stage >= 4) playCut('ending', () => Scene.go('end')); else Scene.go('stages'); }
  }
};

/* =========================== ENDING =========================== */
Scenes.end = {
  t: 0,
  enter() { this.t = 0; BG.set(1); musicStart(5); },
  update(dt) { this.t += dt; },
  draw(g) {
    const cam = 200 + this.t * 6; BG.back(g, cam, 1 / 60);
    menuCast(g, TITLE_CAST.map(([k, dx, y, f, o]) => ({ k, an: 'win', x: VW / 2 + dx, y, f, o })), this.t, 1, cam);
    BG.front(g, cam); BG.atmos(g, this.t);
    const gr = g.createLinearGradient(0, 0, 0, 140); gr.addColorStop(0, 'rgba(6,3,12,0.85)'); gr.addColorStop(1, 'rgba(6,3,12,0)'); g.fillStyle = gr; g.fillRect(0, 0, VW, 140);
    PIX.text(g, T('theEnd'), VW / 2, 14, { s: 4, align: 'c', col: COLR.red });
    PIX.text(g, T('end1'), VW / 2, 56, { align: 'c', col: COLR.white }); PIX.wrap(T('end2'), VW - 40, 1).forEach((l, i) => PIX.text(g, l, VW / 2, 70 + i * 11, { align: 'c', col: '#c8c0d8' }));
    PIX.text(g, T('thanks'), VW / 2, 104, { align: 'c', col: COLR.gold });
    if (this.t > 3 && Math.sin(this.t * 4) > 0) PIX.text(g, T('tapNext'), VW / 2, VH - 12, { align: 'c', col: '#c8c0d8' });
  },
  onDown() { if (this.t > 2) { sfx('ok'); Scene.go('title'); } }
};

function setLang(c) { SAVE.lang = c; SAVE.langSet = true; saveGame(); applyLang(); }
