#!/usr/bin/env python3
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

parser = argparse.ArgumentParser(description='Aplicar uma atualização de fontes ao repositório LUPUS.')
parser.add_argument('--repo', type=Path, default=Path.cwd(), help='Pasta do repositório original')
args = parser.parse_args()
repo = args.repo.resolve()
bundle = Path(__file__).resolve().parent
manifest = json.loads((bundle / 'manifest.json').read_text())
version = str(manifest['version'])
if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*', version):
    raise SystemExit('Versão de atualização inválida.')
overlay = bundle / 'overlay'
archives = sorted(repo.glob('LupusReawakening-z*.zip'))
project = repo / 'src/LupusReawakening-Android'
if not archives and not (project / 'settings.gradle').is_file():
    raise SystemExit('Informe --repo com a pasta do repositório original, contendo os ZIPs ou o projeto Android.')
# Validate every incoming file and every required base file before writing.
for item in manifest['files']:
    source = (overlay / item['path']).resolve()
    target = (repo / item['path']).resolve()
    if not target.is_relative_to(repo) or not source.is_relative_to(overlay.resolve()) or not source.is_file():
        raise SystemExit('Caminho de atualização inválido.')
    if hashlib.sha256(source.read_bytes()).hexdigest() != item['sha256']:
        raise SystemExit('Arquivo de atualização incompleto: ' + item['path'])
for item in manifest.get('required_base_files', []):
    source = (repo / item['path']).resolve()
    if not source.is_relative_to(repo) or not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest() != item['sha256']:
        raise SystemExit('Este delta exige a atualização ' + str(manifest.get('base_version', 'anterior'))
                         + ' completa. Arquivo da base ausente ou alterado: ' + item['path']
                         + '. Use o pacote cumulativo se não tiver essa base.')
# Fill missing legacy files only; never erase local edits by unzipping over them.
for archive in archives:
    with zipfile.ZipFile(archive) as source:
        for item in source.infolist():
            target = (repo / 'src' / item.filename).resolve()
            if not target.is_relative_to((repo / 'src').resolve()):
                raise SystemExit('Caminho inválido no arquivo original.')
            if item.is_dir() or target.exists():
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read(item))
backup = repo / ('backup-lupus-' + version + '-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
for item in manifest['files']:
    source, target = overlay / item['path'], repo / item['path']
    if target.exists() and target.read_bytes() != source.read_bytes():
        saved = backup / item['path']
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, saved)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
wrapper = project / 'gradlew'
if wrapper.is_file():
    wrapper.chmod(wrapper.stat().st_mode | 0o111)
print('Atualização ' + version + ' aplicada. Projeto: ' + str(project))
if backup.exists():
    print('Cópia dos arquivos anteriores: ' + str(backup))
print('Consulte README.md para executar os testes e gerar o APK.')
