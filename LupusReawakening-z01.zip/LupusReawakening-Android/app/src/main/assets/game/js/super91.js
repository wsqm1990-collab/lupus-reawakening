'use strict';
/* =====================================================================
   v9.2 Duo Super, in the style of the Marvel vs Capcom crossover attacks.
   1. Flash: the stage goes dark and the partner leaps in.
   2. Cut-in: two portrait strips (authored art) cross the screen.
   3. Rush: both heroes take turns tearing through every enemy on screen with
      their own attack animations while the hit counter climbs.
   4. Finish: both fire their specials together and the duo's finishing art
      sweeps the field. The partner leaps out and the fight resumes.
   Every picture here is authored art: character sprite frames plus the
   Art Pack 5 cut-ins and finishing effects. No shapes are drawn as code.
   Keeps the Super90 interface used by the renderer and the controls.
   ===================================================================== */
(function () {
  const LENGTH = 4.4, T_CUT = 0.14, T_RUSH = 1.2, T_FIN = 2.9, T_BOOM = 3.1, T_OUT = 3.75, FX_LEN = 0.95;
  const BEAT = 0.105;
  const COL = { vespera: '#ff2050', triton: '#3af0ff', malakor: '#a7ff1a', echo: '#3ae6ff', brann: '#ff7a3a' };
  /* where the face sits in each cut-in picture (fraction of its height) */
  const FOCUS = { cut_lupus_h: 0.34, cut_lupus_f: 0.37, cut_lupus_a: 0.31, cut_vespera: 0.3, cut_triton: 0.36, cut_malakor: 0.37, cut_echo: 0.36, cut_brann: 0.47 };
  const IMG = {};
  function img(name) {
    let im = IMG[name];
    if (!im) { im = new Image(); im.onload = () => { im.ok = true; }; im.onerror = () => { im.bad = true; }; im.src = 'assets/super/' + name + '.webp'; IMG[name] = im; }
    return im;
  }
  const ready = im => !!(im && im.ok && im.width);
  const cutOf = h => h.id === 'lupus' ? 'cut_lupus_' + (h.form === 'f' || h.form === 'a' ? h.form : 'h') : 'cut_' + h.id;
  function preloadFor(duo) { if (!duo || !COL[duo]) return; ['cut_lupus_h', 'cut_lupus_f', 'cut_lupus_a', 'cut_' + duo, 'fx_' + duo].forEach(img); }
  const ease = k => { k = clamp(k, 0, 1); return k * k * (3 - 2 * k); };
  const active = () => G && G.superFx && G.superFx.v91 ? G.superFx : null;
  const insideX = (x, pad) => clamp(x, G.camX + pad, G.camX + VW - pad);
  const liveFoes = () => G.enemies.filter(e => !e.dead && e.x >= G.camX - 20 && e.x <= G.camX + VW + 20);
  const tick = (S, dt, step) => Math.floor(S.t / step) !== Math.floor((S.t - dt) / step);

  function power(S) {
    const form = FORM[S.L.form] || FORM.h;
    return (form.dmg + HERO[S.P.id].dmg) * upMul() * (skl(S.p.id).spc >= 4 ? 1.25 : 1) * (((SAVE.aff || {})[S.duo] || 0) >= 5 ? 1.25 : 1);
  }
  function hit(S, src, e, mult, o) {
    if (!e || e.dead) return false;
    const ok = hurt(src, e, power(S) * mult * (e.kind === 'boss' ? 0.55 : 1), Object.assign({ kx: 60, brk: true, ignoreInv: true }, o || {}));
    if (ok) { S.hits++; S.reactions.add(e); S.pop = 1; }
    return ok;
  }
  function finish(S, interrupted) {
    if (!G || G !== S.game || G.superFx !== S) return;
    G.superFx = null;
    for (const h of [S.p, S.a]) {
      delete h._s91; h.z = 0; h.vx = h.vy = h.vz = 0; h.air = false; h._trail = [];
      h.x = insideX(h.x, 38); h.y = clamp(h.y, LANE_T + 8, LANE_B - 8);
      if (!h.dead) { setSt(h, 'idle'); h.inv = 0.7; }
    }
    S.a.assist = false; S.a.bench = true; S.a.astPh = null;
    G.heroes = G.heroes.filter(h => h !== S.a);
    if (!interrupted && !S.a.dead && !G.leaving.includes(S.a)) { S.a.bench = false; S.a.assist = true; S.a.astPh = 'out'; jumpOut(S.a); }
    if (window.Flood90 && Flood90.resume) Flood90.resume({ rearm: true });
  }

  startSuper = function () {
    if (!G || !canSuper()) return false;
    const p = G.player, a = G.ally, duo = duoOf();
    if (!a || !COL[duo]) return false;
    const L = p.id === 'lupus' ? p : a, P = L === p ? a : p;
    const foes = liveFoes().sort((x, y) => Math.abs(x.x - p.x) - Math.abs(y.x - p.x));
    const face = foes[0] ? (Math.sign(foes[0].x - p.x) || p.face) : p.face;
    const cx = foes.length ? insideX(foes.reduce((s, e) => s + e.x, 0) / foes.length, 90) : insideX(p.x + face * 90, 90);
    const y = clamp(p.y, LANE_T + 14, LANE_B - 10);
    const S = { v91: true, v90: true, game: G, t: 0, p, a, L, P, duo, face, cx, y, hits: 0, pop: 0, beat: -1,
      reactions: new Set(), trails: [], fin: [], boomT: null, voiced: false, swish: false,
      from: new Map([[p, { x: p.x, y: p.y }], [a, { x: face > 0 ? G.camX - 40 : G.camX + VW + 40, y: clamp(y + 10, LANE_T + 8, LANE_B - 6) }]]) };
    G.syn = 0; G.hitstop = 0; a.bench = false; a.assist = true; a.astPh = 'super'; a.isPlayer = false;
    G.leaving = G.leaving.filter(h => h !== a);
    if (!G.heroes.includes(a)) G.heroes.push(a);
    a.x = S.from.get(a).x; a.y = S.from.get(a).y;
    for (const h of [p, a]) { h._s91 = { an: 'idle', f: 0 }; h.inv = LENGTH + 1; h.spCd = 0; h.vx = h.vy = h.vz = 0; h.z = 0; h.face = face; h._trail = []; setSt(h, 'spec', 0); h.specDur = LENGTH; h.specAt = 99; }
    G.superFx = S; Inp.edge = {};
    if (window.Flood90 && Flood90.pause) Flood90.pause();
    sfx('special'); playSting('sting_duo'); vibe(80, 170); shake(4);
    return true;
  };

  function pose(h, an, f) { h._s91.an = an; h._s91.f = f; }
  function trail(S, h) { const fr = ART.frame(heroKey(h), h._s91.an, h._s91.f, false); if (fr) S.trails.push({ fr, x: h.x, y: h.y - h.z, face: h.face, sc: depthScale(h.y), t: S.t, col: h === S.L ? '#ffd23a' : COL[S.duo] }); }
  /* when each enemy is reached by the finishing art (seconds after it starts) */
  function reachDelay(S, e) {
    const f = S.face;
    switch (S.duo) {
      case 'echo': return clamp((e.x - S.P.x) * f / 1600, 0, 0.3);
      case 'triton': return clamp(((e.x - S.cx) * f / VW + 0.4) / 0.65 * 0.55, 0.04, 0.6);
      case 'malakor': return clamp(((e.x - S.cx) * f / VW + 0.55) / 1.2 * 0.6, 0.04, 0.6);
      case 'brann': return clamp(Math.abs(e.x - S.cx) / 900, 0, 0.35);
      default: return clamp(Math.abs(e.x - S.cx) / 1300, 0, 0.3);
    }
  }

  updSuper = function (dt) {
    const S = active(); if (!S) return;
    if (G !== S.game || S.p.dead || S.a.dead || G.over > 0) { finish(S, true); return; }
    dt = clamp(Number.isFinite(dt) ? dt : 0, 0, 0.08);
    S.t += dt; const t = S.t, L = S.L, P = S.P, f = S.face, Lp = S.from.get(S.L), Pp = S.from.get(S.P);
    S.pop = Math.max(0, S.pop - dt * 4);
    for (const h of [L, P]) { h.inv = Math.max(h.inv || 0, 0.8); h.flash = 0; }
    const home = { L: { x: insideX(S.cx - f * 34, 40), y: S.y }, P: { x: insideX(S.cx - f * 82, 40), y: clamp(S.y + 10, LANE_T + 8, LANE_B - 6) } };

    if (t < T_RUSH) {
      /* flash + cut-in: Lupus braces, the partner leaps in from off-screen */
      for (const h of [L, P]) h.face = f;
      const k = clamp((t - 0.05) / 0.9, 0, 1);
      L.x = lerp(Lp.x, home.L.x, ease(t / 0.5)); L.y = lerp(Lp.y, home.L.y, ease(t / 0.5)); L.z = 0;
      P.x = lerp(Pp.x, home.P.x, ease(k)); P.y = lerp(Pp.y, home.P.y, ease(k)); P.z = Math.sin(k * Math.PI) * 46;
      pose(L, 'spec', Math.min(2, Math.floor(t * 6)));
      pose(P, P.z > 6 ? (k < 0.5 ? 'rise' : 'fall') : 'spec', P.z > 6 ? (k < 0.5 ? 1 : 0) : 1);
      if (t > T_CUT && !S.swish) { S.swish = true; sfx('slash'); }
      /* 9.3: Lupus calls the attack during the cut-in ("Together... NOW!");
         this replaced startSuper, so the old audio.js hook no longer fires */
      if (t > 0.25 && !S.called) { S.called = true; voice('lupus_super', 0); }
      if (P.z > 6 && tick(S, dt, 0.04)) trail(S, P);
    } else if (t < T_FIN) {
      /* rush: alternating beats, each one a dash and a real hit */
      const b = Math.floor((t - T_RUSH) / BEAT), bt = ((t - T_RUSH) % BEAT) / BEAT;
      if (b !== S.beat) {
        S.beat = b; const who = b % 2 ? P : L, foes = liveFoes();
        const tg = foes.length ? foes[(b >> 1) % foes.length] : null;
        const side = who === L ? -f : f;           /* Lupus strikes from the front, the partner from behind */
        who._s91.from = { x: who.x, y: who.y };
        who._s91.to = tg ? { x: insideX(tg.x + side * 24, 30), y: clamp(tg.y + (who === L ? 2 : -2), LANE_T + 6, LANE_B - 6) } : { x: insideX(S.cx + side * 30 + (b % 3 - 1) * 26, 30), y: S.y };
        who._s91.tg = tg; who._s91.struck = false; who._s91.atk = 'atk' + (1 + ((b >> 1) % 3));
        who.face = tg ? (Math.sign(tg.x - who._s91.to.x) || f) : f;
      }
      const mover = S.beat % 2 ? P : L;
      for (const h of [L, P]) {
        const s = h._s91;
        if (!s.from) { pose(h, 'idle', Math.floor(t * 7)); continue; }
        if (h === mover) {
          const k = ease(bt / 0.4);
          h.x = lerp(s.from.x, s.to.x, k); h.y = lerp(s.from.y, s.to.y, k);
          if (bt < 0.4) { pose(h, 'run', Math.floor(t * 16)); if (tick(S, dt, 0.03)) trail(S, h); }
          else { const n = ART.frameCount(heroKey(h), s.atk) || 5; pose(h, s.atk, Math.min(n - 1, Math.floor((bt - 0.4) / 0.6 * n))); }
          if (!s.struck && bt >= 0.55) {
            s.struck = true;
            if (s.tg) { const juggle = S.beat % 5 === 4 && s.tg.kind !== 'boss'; hit(S, h, s.tg, 0.42, juggle ? { launch: true, kx: 90, kz: 190 } : { kx: 40 }); }
            else sfx('slash');
          }
        } else if (s.atk) { const n = ART.frameCount(heroKey(h), s.atk) || 5; pose(h, s.atk, n - 1); }
      }
    } else {
      /* finish: both regroup and fire their specials together */
      const k = ease((t - T_FIN) / 0.22);
      for (const [h, hm] of [[L, home.L], [P, home.P]]) {
        const s = h._s91; if (!s.back) s.back = { x: h.x, y: h.y };
        h.x = lerp(s.back.x, hm.x, k); h.y = lerp(s.back.y, hm.y, k); h.z = 0; h.face = f;
        const n = ART.frameCount(heroKey(h), 'spec') || 6;
        if (t < T_OUT) pose(h, 'spec', Math.min(n - 1, Math.floor(clamp((t - T_FIN) / (T_BOOM - T_FIN + 0.2), 0, 1) * n)));
        else pose(h, h === S.p ? 'win' : 'spec', h === S.p ? Math.floor(t * 7) % 4 : n - 1);
      }
      if (t >= T_BOOM && S.boomT == null) {
        S.boomT = t;
        for (const e of liveFoes()) S.fin.push({ e, at: t + reachDelay(S, e) });
        for (const q of G.props) if (!q.dead && q.x >= G.camX && q.x <= G.camX + VW) breakProp(q);
        for (const ob of G.objs || []) if (ob.team === 'e' && !ob.dead && ob.x >= G.camX && ob.x <= G.camX + VW) objHurt(L, ob, power(S) * 3.2, {});
        if (S.duo === 'vespera') P.hp = Math.min(P.maxhp, P.hp + P.maxhp * 0.2);
        if (S.duo === 'malakor') for (const h of G.team) if (!h.dead) h.hp = Math.min(h.maxhp, h.hp + h.maxhp * 0.3);
        if (S.duo === 'triton') for (const h of [L, P]) { h.shieldHP = Math.max(h.shieldHP || 0, 300); h.shieldT = Math.max(h.shieldT || 0, 6); }
        shake(14); G.flashScr = Math.max(G.flashScr, 0.3); sfx('boom'); sfx('roar'); vibe(160, 230);
        /* 9.3: the partner names the duo attack on the blast, after Lupus's
           "Together... NOW!" (about 2 s from t = 0.25) has finished, instead
           of being cut by it; Dialogue9 keeps knockout grunts from cutting it */
        if (!S.voiced) { S.voiced = true; voice(S.duo + '_duo', 0); }
      }
      const extra = { vespera: { bleed: true }, brann: { stun: 1.2 } }[S.duo] || {};
      const mult = S.duo === 'echo' ? 6.2 : 5.4;
      for (const q of S.fin) if (!q.done && t >= q.at) { q.done = true; hit(S, L, q.e, mult, Object.assign({ launch: q.e.kind !== 'boss', kx: 220, kz: 260 }, extra)); shake(6); }
    }
    for (const h of [L, P]) { h.x = insideX(h.x, 26); h.y = clamp(h.y, LANE_T + 4, LANE_B - 4); h.z = Math.max(0, h.z); }
    /* the camera follows the middle of the pair */
    const mid = t < T_RUSH ? S.cx : (L.x + P.x) / 2;
    S.fx = S.fx == null ? mid : lerp(S.fx, mid, 1 - Math.exp(-dt * 5));
    S.trails = S.trails.filter(q => S.t - q.t < 0.24);
    /* struck enemies fall and tumble with their own animations while time is held for everyone else */
    for (const e of S.reactions) if (e.kind !== 'boss' && (e.dead || ['hurt', 'knock', 'down', 'getup'].includes(e.st))) updEnemy(e, dt);
    G.hitstop = 0;
    if (t >= LENGTH) finish(S, false);
  };

  /* the camera pushes in on the rush, opens up for the finishing art, then settles back */
  function camera(g, cam) {
    const S = active(); if (!S) return;
    const t = S.t, k = t < T_RUSH ? 0 : t < T_RUSH + 0.3 ? ease((t - T_RUSH) / 0.3) : t < T_FIN ? 1 : t < T_BOOM ? 1 - 0.75 * ease((t - T_FIN) / (T_BOOM - T_FIN)) : t < T_OUT ? 0.25 : 0.25 * (1 - ease((t - T_OUT) / (LENGTH - T_OUT)));
    const z = 1 + 0.45 * k; if (z <= 1.001) return;
    const hw = VW / (2 * z), hh = VH / (2 * z);
    const fx = clamp((S.fx == null ? S.cx : S.fx) - cam, hw, VW - hw), fy = clamp(S.y - 40, hh, VH - hh);
    g.translate(VW / 2, VH / 2); g.scale(z, z); g.translate(-fx, -fy);
  }
  function handles(e) { const S = active(); return !!(S && (e === S.p || e === S.a)); }
  function drawActor(g, e, cam) {
    const S = active(); if (!S || !handles(e) || !e._s91) return false;
    const key = heroKey(e), sc = depthScale(e.y);
    const fr = ART.frame(key, e._s91.an, e._s91.f, false) || ART.frame(key, 'idle', 0, true);
    g.imageSmoothingEnabled = Math.abs(sc - 1) > 0.01;
    if (fr) ART.draw(g, fr, e.x - cam, e.y - e.z, { pal: (SAVE.pal || {})[e.id] || 0, face: e.face, sc, rims: ART.rimsAt(e.x, e.y, entHeight(e), G.time) });
    g.imageSmoothingEnabled = false;
    return true;
  }
  /* before the characters: the stage behind them darkens, as in the arcade crossover attacks */
  function drawUnder(g, cam) {
    const S = active(); if (!S) return;
    const t = S.t, k = t < 0.12 ? t / 0.12 : t < T_RUSH ? 1 : t < T_FIN ? 0.72 : t < T_OUT ? 0.86 : Math.max(0, 1 - (t - T_OUT) / (LENGTH - T_OUT));
    g.save(); g.fillStyle = 'rgba(3,0,8,' + (0.66 * k).toFixed(3) + ')'; g.fillRect(-VW, -VH, VW * 3, VH * 3); g.restore();
  }
  /* the duo's finishing art: each one moves its own way */
  function drawFinisher(g, S, cam, fx) {
    const k = (S.t - S.boomT) / FX_LEN; if (k < 0 || k >= 1) return;
    const W = fx.width, H = fx.height, f = S.face;
    g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = clamp(k < 0.07 ? k / 0.07 : k > 0.6 ? 1 - (k - 0.6) / 0.4 : 1, 0, 1); g.imageSmoothingEnabled = true;
    if (S.duo === 'echo') {                        /* the beam grows out of Echo's cannon */
      const w = VW * 1.15, h = w * H / W, reveal = Math.max(0.02, ease(k / 0.18));
      g.translate(S.P.x - cam + f * 16, S.P.y - 46); if (f < 0) g.scale(-1, 1);
      g.drawImage(fx, 0, 0, W * reveal, H, 0, -h / 2, w * reveal, h);
    } else if (S.duo === 'triton' || S.duo === 'malakor') {  /* the tidal wave / the spectral pack sweeps across */
      const tri = S.duo === 'triton', w = VW * (tri ? 1.0 : 0.82), h = w * H / W;
      const x = S.cx - cam + f * VW * lerp(tri ? -0.4 : -0.55, tri ? 0.25 : 0.65, tri ? ease(k) : k);
      g.translate(x, Math.min(VH, S.y + 16) - h / 2); if (f < 0) g.scale(-1, 1);
      g.drawImage(fx, -w / 2, -h / 2, w, h);
    } else if (S.duo === 'brann') {                /* the ground bursts open under the enemies */
      const s = 0.45 + 0.75 * ease(k / 0.3), w = VW * 0.95 * s, h = w * H / W;
      g.translate(S.cx - cam, S.y + 8); if (f < 0) g.scale(-1, 1);
      g.drawImage(fx, -w / 2, -h * 0.68, w, h);
    } else {                                       /* the blood crescent tears through */
      const s = 0.72 + 0.42 * ease(k / 0.4), w = VW * 0.9 * s, h = w * H / W;
      g.translate(S.cx - cam, S.y - 46); if (f < 0) g.scale(-1, 1); g.rotate(lerp(-0.3, 0.08, ease(k / 0.5)));
      g.drawImage(fx, -w / 2, -h / 2, w, h);
    }
    g.restore();
  }
  /* after the characters: afterimages and the finishing art */
  function drawWorld(g, cam) {
    const S = active(); if (!S) return;
    g.save(); g.globalCompositeOperation = 'lighter';
    for (const q of S.trails) { const a = 0.4 * (1 - (S.t - q.t) / 0.24); ART.draw(g, q.fr, q.x - cam, q.y, { face: q.face, sc: q.sc, tint: q.col, tintA: 1, alpha: a }); }
    g.restore();
    const fx = img('fx_' + S.duo);
    if (S.boomT != null && ready(fx) && S.t - S.boomT < FX_LEN) {
      drawFinisher(g, S, cam, fx);
      /* the two heroes stay in front of their own attack; the enemies are swallowed by it */
      for (const h of [S.P, S.L].sort((a, b) => a.y - b.y)) drawActor(g, h, cam);
    }
  }
  /* screen space: the two portrait strips and the hit counter */
  function strip(g, im, y0, h, fromLeft, k, focus) {
    if (!ready(im) || k <= 0 || k >= 1) return;
    const slide = ease(k / 0.24), out = ease((k - 0.84) / 0.16), slant = 24;
    const dx = fromLeft ? -VW * (1 - slide) + VW * out : VW * (1 - slide) - VW * out;
    const drift = (fromLeft ? 1 : -1) * 14 * k;    /* the picture keeps moving slowly inside its strip */
    g.save(); g.translate(Math.round(dx), 0);
    g.beginPath(); g.moveTo(-slant, y0); g.lineTo(VW + slant, y0); g.lineTo(VW, y0 + h); g.lineTo(0, y0 + h); g.closePath(); g.clip();
    const dw = VW + slant * 2 + 30, sh = im.width * h / dw, sy = clamp(im.height * focus - sh / 2, 0, im.height - sh);
    g.imageSmoothingEnabled = true; g.drawImage(im, 0, sy, im.width, sh, -slant - 15 + drift, y0, dw, h);
    g.restore();
  }
  function drawHUD(g) {
    const S = active(); if (!S) return;
    const t = S.t;
    /* white flashes: as the attack starts and as the finishing art lands */
    const wf = Math.max(t < 0.16 ? 0.6 * (1 - t / 0.16) : 0, S.boomT != null && t - S.boomT < 0.24 ? 0.8 * (1 - (t - S.boomT) / 0.24) : 0);
    if (wf > 0.01) { g.save(); g.fillStyle = 'rgba(255,255,255,' + wf.toFixed(3) + ')'; g.fillRect(0, 0, VW, VH); g.restore(); }
    if (t >= T_CUT && t < T_RUSH + 0.05) {
      const back = Math.min(1, (t - T_CUT) / 0.12, (T_RUSH + 0.05 - t) / 0.15);
      g.save(); g.fillStyle = 'rgba(0,0,0,' + (0.55 * back).toFixed(3) + ')'; g.fillRect(0, 0, VW, VH); g.restore();
      const a = cutOf(S.L), b = cutOf(S.P), span = T_RUSH + 0.05 - T_CUT;
      strip(g, img(a), Math.round(VH * 0.07), Math.round(VH * 0.42), true, (t - T_CUT) / span, FOCUS[a] || 0.4);
      strip(g, img(b), Math.round(VH * 0.51), Math.round(VH * 0.42), false, (t - T_CUT - 0.08) / (span - 0.08), FOCUS[b] || 0.4);
    }
    if (S.hits > 0 && t >= T_RUSH) {
      const a = t > T_OUT ? Math.max(0, 1 - (t - T_OUT) / 0.5) : 1;
      g.save(); g.globalAlpha = a;
      PIX.text(g, String(S.hits), VW / 2 - 4, 26, { s: 3 + Math.round(S.pop), align: 'r', col: COL[S.duo], out: '#000' });
      PIX.text(g, T('hits'), VW / 2 + 4, 32, { s: 2, align: 'l', col: COLR.white, out: '#000' });
      if (S.boomT != null && DUO[S.duo]) PIX.text(g, T(DUO[S.duo].name), VW / 2, 56, { s: 2, align: 'c', col: COL[S.duo], out: '#000' });
      g.restore();
    }
  }

  drawSuperSplash = function () {};
  const baseCanSuper = canSuper;
  canSuper = function () {
    if (!G || G.nachtBeat90 || G.choice || document.hidden || Scene.name !== 'play' || Scenes.play.menu) return false;
    if (!baseCanSuper()) return false;
    const id = duoOf(); if (!COL[id]) return false;
    preloadFor(id);
    /* the attack is only offered once its pictures are ready, so nothing pops in late */
    return ready(img('cut_' + id)) && ready(img('fx_' + id)) && G.team.some(h => h.id === 'lupus') && !G.team.some(h => h.id === 'lupus' && h.form === 'x');
  };
  const newGame0 = newGame;
  newGame = function () {
    const game = newGame0.apply(this, arguments), partner = game && game.team && game.team.find(h => h.id !== 'lupus');
    if (partner) preloadFor(partner.id);
    return game;
  };
  window.Super90 = {
    handles, drawActor, drawUnder, drawWorld, drawHUD, camera,
    cancel() { const S = active(); if (S) finish(S, true); },
    snapshot() { const S = active(); return S ? { duo: S.duo, t: S.t, hits: S.hits, initiator: S.p.id, partner: S.a.id, lupus: S.L.id, boom: S.boomT != null } : null; },
    preload: preloadFor,
    ready: id => ready(img('cut_' + id)) && ready(img('fx_' + id))
  };
})();
