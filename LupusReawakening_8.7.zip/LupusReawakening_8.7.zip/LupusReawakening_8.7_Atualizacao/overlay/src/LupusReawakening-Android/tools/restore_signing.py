#!/usr/bin/env python3
"""Restore the already-published APK identity without repeating credentials in source.

Only explicit legacy archive entries are read. The key and Java properties are
written to ignored, private local files. Environment-provided CI values win.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import zipfile


def java_property(value: str) -> str:
    return (value.replace("\\", "\\\\").replace("\n", "\\n").replace("\r", "\\r")
            .replace("=", "\\=").replace(":", "\\:").replace("#", "\\#").replace("!", "\\!"))


def restore(project: Path, archives: Path) -> None:
    environment = ["LUPUS_KEYSTORE_FILE", "LUPUS_STORE_PASSWORD", "LUPUS_KEY_ALIAS", "LUPUS_KEY_PASSWORD"]
    if all(os.environ.get(name) for name in environment):
        print("Using signing supplied through the environment.")
        return
    properties = project / "signing.properties"
    key = project / "app" / "lupus.keystore"
    if properties.exists() and key.exists():
        print("Existing local signing configuration found.")
        return
    for archive in sorted(archives.glob("LupusReawakening-z*.zip")):
        with zipfile.ZipFile(archive) as bundle:
            builds = [name for name in bundle.namelist() if name.endswith("/app/build.gradle")]
            for build in builds:
                key_entry = build.removesuffix("build.gradle") + "lupus.keystore"
                if key_entry not in bundle.namelist():
                    continue
                source = bundle.read(build).decode("utf-8")
                fields = {}
                for field in ["storePassword", "keyAlias", "keyPassword"]:
                    match = re.search(r"\b" + field + r"\s+['\"]([^'\"]+)['\"]", source)
                    if not match:
                        raise SystemExit("Legacy signing configuration could not be read.")
                    fields[field] = match.group(1)
                key.parent.mkdir(parents=True, exist_ok=True)
                key.write_bytes(bundle.read(key_entry))
                key.chmod(0o600)
                content = "storeFile=app/lupus.keystore\n"
                content += "".join(name + "=" + java_property(value) + "\n" for name, value in fields.items())
                properties.write_text(content, encoding="utf-8")
                properties.chmod(0o600)
                print("APK signing restored to ignored local files.")
                return
    raise SystemExit("Provide signing.properties or LUPUS_* signing variables; no legacy signing archive was found.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=Path.cwd())
    parser.add_argument("--archives", type=Path, default=Path.cwd())
    options = parser.parse_args()
    restore(options.project.resolve(), options.archives.resolve())
