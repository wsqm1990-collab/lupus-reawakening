'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const { createRuntime } = require('./runtime.cjs');

async function main() {
  const r = createRuntime(), tests = [];
  const test = (name, fn) => tests.push({ name, fn });
  const noErrors = () => assert.deepEqual(r.json('window.__err || []'), []);
  const click = id => {
    const b = r.json(`Scenes.play.btns.find(b=>b.id===${JSON.stringify(id)})`);
    assert.ok(b, `pause action ${id} is missing`);
    r.run(`Scenes.play.onDown(71,${b.x + b.w / 2},${b.y + b.h / 2});Scenes.play.onUp(71)`);
  };
  const pad = (buttons = []) => {
    const b = Array(16).fill(false); buttons.forEach(i => b[i] = true);
    r.run(`LupusGamepad.update(${JSON.stringify({ connected: true, id: 'Pause regression pad', buttons: b, axes: [0, 0] })})`);
    r.tick();
  };
  await r.settle(); r.run('setLang("pt")');
  for (let stage = 0; stage < 16; stage++) test(`stage ${stage + 1} keeps its objective and instructions available after the intro`, async () => {
    r.run('LupusGamepad.update({connected:false});window.__err=[]');
    await r.play(stage); r.run('G.title=0;Scenes.play.onKey("pause");Scene.fade=0');
    const q = r.json('PauseUI.snapshot()'), time = r.run('G.time');
    assert.equal(q.model.objective, r.run('G.st.obj[SAVE.lang]'));
    assert.ok(q.model.instruction && q.model.instruction.length > 5);
    r.tick(20, true);
    assert.equal(r.run('G.time'), time, 'reading the paused mission advanced the world');
    assert.equal(r.run('Scenes.play.menu'), true); noErrors();
  });
  for (const [width, height] of [[480, 270], [568, 240], [568, 320], [640, 360], [960, 432], [1440, 720]]) {
    test(`pause panels and both menus fit ${width}x${height} without covering mission text`, async () => {
      r.resize(width, height); await r.play(1);
      r.run('Scenes.play.onKey("pause");Scene.fade=0');
      for (const tab of ['actions', 'settings']) {
        r.run(`Scenes.play.pauseTab=${JSON.stringify(tab)};Scenes.play.pauseMenu()`);
        const { layout: q, model } = r.json('PauseUI.snapshot()'), buttons = r.json('Scenes.play.btns');
        assert.ok(q.mission.x + q.mission.w + 10 <= q.menu.x);
        assert.ok(q.content.y + q.content.h <= q.mission.y + q.mission.h - 20);
        for (const b of buttons) {
          assert.ok(b.x >= q.menu.x + 4 && b.x + b.w <= q.menu.x + q.menu.w - 4);
          assert.ok(b.y >= q.menu.y + 20 && b.y + b.h <= q.menu.y + q.menu.h - 4, `${tab}/${b.id} extends outside the panel`);
          assert.ok(b.h * q.scale >= 47.9, `${tab}/${b.id} touch target too short`);
          assert.ok(b.w * q.scale >= 47.9, `${tab}/${b.id} touch target too narrow`);
          for (const c of buttons) {
            if (b === c) continue;
            assert.ok(b.x + b.w <= c.x || c.x + c.w <= b.x || b.y + b.h <= c.y || c.y + c.h <= b.y, `${b.id}/${c.id} overlap`);
          }
        }
        r.run('window.pauseTestWidths=PauseUI.snapshot().model.lines.map(l=>PIX.textW(l.text,l.scale))');
        assert.ok(r.json('window.pauseTestWidths').every(w => w <= q.content.w + 0.01));
        assert.ok(model.lines.length > 0); r.tick(1, true); noErrors();
        if (process.env.LUPUS_RENDER_DIR) r.snapshot(path.join(process.env.LUPUS_RENDER_DIR, `pause-${width}x${height}-${tab}.png`));
      }
    });
  }
  test('pause is rendered over panels and fresh stage briefings without advancing either', async () => {
    r.resize(640, 360); await r.play(1);
    r.run('G.panel={};G.title=2;Scenes.play.onKey("pause");Scene.fade=0');
    r.tick(2, true);
    assert.equal(r.run('G.title'), 2);
    assert.ok(r.run('!!G.panel'));
    assert.equal(r.run('Scenes.play.menu'), true); noErrors();
    r.run('G.panel=null');
  });
  test('mission dragging and page keys reach the end without activating menu actions', async () => {
    await r.play(10); r.run('Scenes.play.onKey("pause")');
    const c = r.json('PauseUI.layout().content');
    assert.ok(r.run('PauseUI.snapshot().model.maxScroll > 0'));
    r.run(`Scenes.play.onDown(88,${c.x + 20},${c.y + 100});Scenes.play.onMove(88,${c.x + 20},${c.y - 400});Scenes.play.onUp(88)`);
    assert.equal(r.run('PauseUI.snapshot().scroll'), r.run('PauseUI.snapshot().model.maxScroll'));
    assert.equal(r.run('Scenes.play.menu'), true);
    r.dispatch('keydown', { key: 'Home' }); assert.equal(r.run('PauseUI.snapshot().scroll'), 0);
    r.dispatch('keydown', { key: 'End' }); assert.equal(r.run('PauseUI.snapshot().scroll'), r.run('PauseUI.snapshot().model.maxScroll'));
  });
  test('pause settings preserve the mission and return to actions; control editor returns to the same paused game', async () => {
    await r.play(1); r.run('Scenes.play.onKey("pause");window.pauseHero=G.player');
    const objective = r.run('PauseUI.snapshot().model.objective');
    click('pauseOptions'); assert.equal(r.run('Scenes.play.pauseTab'), 'settings');
    const music = r.run('SAVE.music'); click('music'); assert.equal(r.run('SAVE.music'), !music); click('music');
    assert.equal(r.run('PauseUI.snapshot().model.objective'), objective);
    click('pauseBack'); assert.equal(r.run('Scenes.play.pauseTab'), 'actions');
    click('controls'); assert.equal(r.run('Scene.name'), 'controls'); r.run('ControlsUI.close(false)');
    assert.equal(r.run('Scene.name'), 'play'); assert.equal(r.run('G.player===window.pauseHero'), true); assert.equal(r.run('Scenes.play.menu'), true);
    click('resume'); assert.equal(r.run('Scenes.play.menu'), false);
  });
  test('controller shoulder buttons scroll the mission and Start resumes', async () => {
    await r.play(10); r.run('Scenes.play.onKey("pause")');
    pad([5]); r.tick(90);
    assert.ok(r.run('PauseUI.snapshot().scroll > 0'));
    pad([]); pad([4]); r.tick(90); assert.equal(r.run('PauseUI.snapshot().scroll'), 0);
    pad([]); pad([9]); assert.equal(r.run('Scenes.play.menu'), false);
    pad([]); r.run('LupusGamepad.update({connected:false})'); noErrors();
  });
  for (const [width, height] of [[568, 240], [960, 432]]) {
    test(`changing a paused stage from Portuguese to English refreshes text and fits both menus at ${width}x${height}`, async () => {
      r.resize(width, height); r.run('setLang("pt")'); await r.play(1);
      r.run('Scenes.play.onKey("pause");Scene.fade=0;window.pauseEnglishGame=G');
      const portuguese = r.json('PauseUI.snapshot().model'), time = r.run('G.time');
      r.run('PauseUI.scroll(1e6);setLang("en")');
      r.tick(1, true);
      const english = r.json('PauseUI.snapshot()');
      assert.equal(r.run('G===window.pauseEnglishGame'), true, 'language change restarted the phase');
      assert.equal(r.run('Scenes.play.menu'), true);
      assert.equal(r.run('G.time'), time, 'language change advanced the paused world');
      assert.equal(english.model.name, r.run('G.st.name.en'));
      assert.equal(english.model.objective, r.run('G.st.obj.en'));
      assert.equal(english.model.instruction, r.run('CT("r02a")'));
      assert.notEqual(english.model.objective, portuguese.objective, 'objective kept its previous-language text');
      assert.notEqual(english.model.instruction, portuguese.instruction, 'instruction kept its previous-language text');
      assert.ok(english.scroll <= english.model.maxScroll, 'language reflow left the card scrolled past its new end');
      r.run('PauseUI.scroll(-1e6)');
      for (const tab of ['actions', 'settings']) {
        r.run(`Scenes.play.pauseTab=${JSON.stringify(tab)};Scenes.play.pauseMenu()`);
        const q = r.json('PauseUI.snapshot().layout'), buttons = r.json('Scenes.play.btns');
        // Capture the actual draw calls, including the renderer's real wrapping.
        r.run(`(() => { const original=PIX.text, originalPanel=PIX.panel;let button=null;window.pauseEnglishDraws=[];
          PIX.panel=function(g,x,y,w,h){button=(Scenes.play.btns.find(b=>b.x===x&&b.y===y&&b.w===w&&b.h===h)||{}).id||null;return originalPanel.apply(this,arguments)};
          PIX.text=function(g,text,x,y,opts){window.pauseEnglishDraws.push({button,text:String(text),x,y,s:opts&&opts.s||1,align:opts&&opts.align||'l',w:PIX.textW(text,opts&&opts.s||1)});return original.apply(this,arguments)};
          try { PauseUI.draw(bg); } finally { PIX.text=original;PIX.panel=originalPanel; } })()`);
        const draws = r.json('window.pauseEnglishDraws');
        for (const b of buttons) {
          const compact = s => s.toUpperCase().replace(/\s/g, '');
          const labelLines = draws.filter(t => t.button === b.id && compact(b.label).includes(compact(t.text)));
          assert.ok(labelLines.length, `${tab}/${b.id} was not drawn`);
          for (const t of labelLines) {
            assert.ok(t.x - t.w / 2 >= b.x + 3 && t.x + t.w / 2 <= b.x + b.w - 3, `${tab}/${b.id} text overflows horizontally`);
            assert.ok(t.y >= b.y - 1 && t.y + 7 * t.s <= b.y + b.h + 1, `${tab}/${b.id} text overflows vertically`);
          }
          assert.ok(b.x > q.mission.x + q.mission.w, `${tab}/${b.id} covers the mission card`);
        }
        const cardLines = r.json('PauseUI.snapshot().model.lines');
        assert.ok(cardLines.every(l => r.run(`PIX.textW(${JSON.stringify(l.text)},${l.scale})`) <= q.content.w + 0.01));
        r.tick(1, true); noErrors();
        if (process.env.LUPUS_RENDER_DIR) r.snapshot(path.join(process.env.LUPUS_RENDER_DIR, `pause-en-${width}x${height}-${tab}.png`));
      }
      assert.equal(r.run('G===window.pauseEnglishGame'), true);
      assert.equal(r.run('G.time'), time);
    });
  }
  let passed = 0; console.log('TAP version 13');
  for (let i = 0; i < tests.length; i++) {
    const t = tests[i];
    try { await t.fn(); passed++; console.log(`ok ${i + 1} - ${t.name}`); }
    catch (e) { console.log(`not ok ${i + 1} - ${t.name}\n  ---\n  message: ${JSON.stringify(e.message)}\n  ...`); }
  }
  console.log(`1..${tests.length}\n# ${passed} passed, ${tests.length - passed} failed`);
  process.exitCode = passed === tests.length ? 0 : 1;
}
main().catch(e => { console.error(e); process.exitCode = 1; });
