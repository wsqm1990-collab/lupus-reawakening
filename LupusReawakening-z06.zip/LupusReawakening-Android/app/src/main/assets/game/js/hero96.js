'use strict';
/* =====================================================================
   9.6 — Thorne drawn frame by frame: the human form (js/atlas96h.js),
   the feral werewolf (js/atlas96f.js) and the alpha (js/atlas96a.js).
   The hero frame picker learns the new animations: the frame where each
   blow lands comes from the atlas, the hit reaction plays its three
   frames, a throw shows rising / falling / hitting the floor, getting up
   plays all its frames, a landing shows the drawn crouch and the victory
   pose holds. Human form: the chain special lashes on its drawn lash
   frame and reaches exactly as far as the drawn chain. Feral form: the
   dash is a wolf's lunge on all fours (the drive, the flight and the
   strike of the drawn gallop) and the howl rears up on its drawn peak.
   ===================================================================== */
(function () {
  const drawnKey = e => {
    if (!(e && e.kind === 'hero' && e.id === 'lupus')) return null;
    const k = heroKey(e), A = window.ATLAS[k];
    return A && A.v96 ? k : null;
  };
  if (!['lupus_h', 'lupus_f', 'lupus_a'].some(k => window.ATLAS[k] && window.ATLAS[k].v96)) return;
  const floorOf = e => (typeof heroFloor === 'function' ? heroFloor(e) : 0);

  /* the frame where each blow lands: from the atlas of the frames actually drawn */
  const imp0 = window.impactOf;
  window.impactOf = function (key, an) {
    const k2 = ART.extKey(key, an), B = window.ATLAS[k2 || key];
    if (B && B.v96 && B.imp && B.imp[an] != null) return B.imp[an];
    return imp0(key, an);
  };

  /* feral dash: the lunge of the gallop - hind legs drive, flight, front paws reach and strike */
  const LUNGE = [5, 6, 7, 0, 1];

  function frame96(e, KEY) {
    const A = window.ATLAS[KEY], n = an => ART.frameCount(KEY, an);
    switch (e.st) {
      case 'spec': return ['spec', phased(n('spec'), e.t / e.specDur, 0.45, A.imp.spec), false];
      case 'hurt': { const p = e.ct / Math.max(0.05, e.ct + Math.max(0, e.t)); return ['hurt', Math.min(n('hurt') - 1, Math.floor(p * n('hurt'))), false]; }
      case 'knock': return ['knock', knockFrame(e), false];
      case 'getup': { const p = e.ct / Math.max(0.05, e.ct + Math.max(0, e.t)); return ['getup', Math.min(n('getup') - 1, Math.floor(p * n('getup'))), false]; }
      case 'dead': return e.z - floorOf(e) > 1 ? ['knock', knockFrame(e), false] : ['down', 0];
      case 'air': if (e.vz > 0 && e.z - floorOf(e) < 5 && e.ct < 0.08) return ['crouch', 0]; return null;
      case 'dash': if (KEY === 'lupus_f' && n('run') >= 8) return ['run', LUNGE[Math.min(LUNGE.length - 1, Math.floor(e.ct * 22))], false]; return null;
      case 'walk': case 'tagin': case 'xform': case 'atk': case 'guard': case 'down': return null;
    }
    /* idle and the other standing states */
    if (e.landT > 0) return ['land', 0, false];
    if (e.taunt) { if (e._win96 == null) e._win96 = G.time; return ['win', Math.floor((G.time - e._win96) * 8), false]; }
    e._win96 = null;
    return null;
  }
  function knockFrame(e) {
    const hz = e.z - floorOf(e);
    if (e.ct < 0.12 || (e.vz > 60 && hz > 10)) return 0;
    return hz > 14 ? 1 : 2;
  }

  const ef0 = window.entFrame;
  window.entFrame = function (e) {
    const k = drawnKey(e);
    if (k) { const r = frame96(e, k); if (r) return r; }
    return ef0(e);
  };

  /* feral and alpha claw attacks: the claw trails are drawn in the frames themselves, so the generic
     claw-slash effect is left out (the feral diving strike keeps it: those frames have no trail; the
     alpha's X-slash dive has its trails drawn) */
  const hit0 = window.heroHit, slash0 = window.slashFx;
  let drawnTrail = false;
  window.heroHit = function (h) {
    const k = drawnKey(h);
    drawnTrail = (k === 'lupus_f' && !h.air) || k === 'lupus_a';
    try { return hit0.apply(this, arguments); } finally { drawnTrail = false; }
  };
  window.slashFx = function () { if (drawnTrail) return; return slash0.apply(this, arguments); };

  /* the human chain special: same damage, launch and stagger as before, along the drawn chain */
  const spec0 = window.heroSpecFire;
  window.heroSpecFire = function (h) {
    const A = window.ATLAS.lupus_h;
    if (drawnKey(h) === 'lupus_h' && h.form === 'h' && !humanPulse(h) && A.reach && A.reach.spec) {
      const len = A.reach.spec, dm = hs(h).dmg;
      for (const e of foes()) { if (e.dead) continue; const dx = (e.x - h.x) * h.face; if (dx < -6 || dx > len || Math.abs(e.y - h.y) > 15) continue; hurt(h, e, dm * 2.2, { launch: true, kx: 170, kz: 230, brk: true }); }
      shake(5);
      return;
    }
    return spec0.apply(this, arguments);
  };
})();
