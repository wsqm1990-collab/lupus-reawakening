'use strict';
/* =====================================================================
   v9.5 — CYBERCLAWS
   - the title is the new drawn CYBERCLAWS logo (no code-drawn lettering);
   - the last line spoken over a boss K.O. finishes before the comic cuts in;
   - a comic panel that opens in the middle of a fight ignores the taps that
     were meant for the fight for a moment;
   - Hard / Nightmare: an enemy behind a hero who is busy attacking may strike;
   - toxic gas comes out of drawn floor vents (warning lamps + skull hologram,
     then the cloud), with Malakor's radio warning the first time;
   - the Crow Mourner (replaces the Necropolis Phantom): solid, drawn frame by
     frame, appears and vanishes in a burst of crow feathers and caws after a hit.
   ===================================================================== */
(function () {
  const V95 = window.V95 = {};
  const A = window.FX95_ATLAS || null;
  const img = new Image(); let ready = false;
  if (A && A.src) { img.onload = () => { ready = true; }; img.src = A.src; }
  V95.artReady = () => ready;
  const logo = new Image(); logo.onload = () => { logo.ok = true; }; logo.src = 'assets/ui/logo95.webp';
  V95.logo = logo;

  /* ---------- texts (12 languages) ---------- */
  const TX = {
    hz95a: { en: 'TOXIC VENTS IN THE FLOOR! WHEN THE LIGHTS FLASH, GET CLEAR!', pt: 'SAÍDAS DE GÁS TÓXICO NO CHÃO! QUANDO AS LUZES PISCAREM, SAIA DE CIMA!',
      es: '¡RESPIRADEROS TÓXICOS EN EL SUELO! ¡CUANDO PARPADEEN LAS LUCES, APÁRTATE!', fr: 'ÉVENTS TOXIQUES DANS LE SOL ! QUAND LES LUMIÈRES CLIGNOTENT, ÉCARTE-TOI !',
      de: 'GIFTGAS-DÜSEN IM BODEN! WENN DIE LICHTER BLINKEN, GEH WEG!', it: 'SFIATI TOSSICI NEL PAVIMENTO! QUANDO LE LUCI LAMPEGGIANO, ALLONTANATI!',
      ru: 'ЯДОВИТЫЕ ВЫХЛОПЫ В ПОЛУ! КОГДА ЗАМИГАЮТ ОГНИ — ОТОЙДИ!', zh: '地板上有毒气喷口！灯光闪烁时，立刻离开！', ja: '床に毒ガスの噴出口！ランプが点滅したら離れろ！',
      ko: '바닥에 독가스 분출구! 불빛이 깜박이면 피해!', hi: 'फ़र्श में ज़हरीली गैस के छेद! जब बत्तियाँ झपकें, हट जाओ!', ar: 'فتحات غاز سام في الأرض! عندما تومض الأضواء، ابتعد!' },
    p95a: { en: 'CROW MOURNERS! WHEN THE FEATHERS SWIRL, ONE OF THEM IS ABOUT TO APPEAR.', pt: 'CORVOS DE LUTO! QUANDO AS PENAS GIRAREM, UM DELES VAI APARECER.',
      es: '¡CUERVOS DE LUTO! CUANDO GIREN LAS PLUMAS, UNO DE ELLOS ESTÁ POR APARECER.', fr: "DES CORBEAUX ENDEUILLÉS ! QUAND LES PLUMES TOURBILLONNENT, L'UN D'EUX VA APPARAÎTRE.",
      de: 'TRAUERKRÄHEN! WENN DIE FEDERN WIRBELN, TAUCHT GLEICH EINE AUF.', it: 'CORVI IN LUTTO! QUANDO LE PIUME TURBINANO, UNO DI LORO STA PER APPARIRE.',
      ru: 'ТРАУРНЫЕ ВОРОНЫ! КОГДА ЗАКРУЖАТСЯ ПЕРЬЯ, ОДИН ИЗ НИХ ВОТ-ВОТ ПОЯВИТСЯ.', zh: '送葬鸦人！羽毛旋转时，就有一个要现身了。', ja: '喪服の鴉だ！羽根が渦を巻いたら、奴らが現れる。',
      ko: '상복 까마귀다! 깃털이 소용돌이치면 놈들 중 하나가 나타난다.', hi: 'शोक कौए! जब पंख घूमें, उनमें से एक आने वाला है।', ar: 'غربان الحداد! عندما يدور الريش، سيظهر أحدهم.' }
  };
  const MOURNER = { en: 'CROW MOURNER', pt: 'CORVO DE LUTO', es: 'CUERVO DE LUTO', fr: 'CORBEAU ENDEUILLÉ', de: 'TRAUERKRÄHE', it: 'CORVO IN LUTTO',
    ru: 'ТРАУРНЫЙ ВОРОН', zh: '送葬鸦人', ja: '喪服の鴉', ko: '상복 까마귀', hi: 'शोक कौआ', ar: 'غراب الحداد' };
  for (const c of LANGS) {
    const L = I18N[c]; if (!L) continue;
    for (const k in TX) L.comic[k] = TX[k][c] || TX[k].en;
    const i = IDX_E.indexOf('P'); if (i >= 0 && L.enemies) L.enemies[i] = MOURNER[c] || MOURNER.en;
  }

  /* ---------- 1. title: the drawn logo ---------- */
  const LOGO_W = 270;
  window.drawTitleLogo = function (g, cx, y) {
    if (!logo.ok) return;
    const w = LOGO_W, h = w * logo.height / logo.width;
    g.save(); g.imageSmoothingEnabled = true; g.drawImage(logo, Math.round(cx - w / 2), Math.round(y - 6), w, h); g.restore();
  };
  window.drawLogo = function (g, cx, y, s) { window.drawTitleLogo(g, cx, y, 0); };
  Scenes.load.draw = function (g) {
    g.fillStyle = '#07040d'; g.fillRect(0, 0, VW, VH);
    if (logo.ok) window.drawTitleLogo(g, VW / 2, 70);
    PIX.text(g, T('loading'), VW / 2, 160, { align: 'c', col: COLR.red });
    PIX.bar(g, VW / 2 - 70, 176, 140, 5, ART.total ? ART.loaded / ART.total : 0, COLR.red);
  };

  /* ---------- 2. the last words over a K.O. are heard in full ---------- */
  /* called by the stage-clear clock when the K.O. has played out; true = wait */
  V95.holdFinish = function (dt) {
    if (!G) return false;
    const D = window.Dialogue9, speaking = !!(D && D.busy && D.busy());
    if (!G.koHush95) {
      G.koHush95 = true;                                 // no new combat barks from here on
      /* only the line already being spoken is waited for: queued radio lines do not start now */
      if (G.talkQ) G.talkQ = speaking && G.talkQ[0] && G.talkQ[0]._speechStarted ? G.talkQ.slice(0, 1) : [];
    }
    G.koWait95 = (G.koWait95 || 0) + dt;
    return speaking && G.koWait95 < 4;
  };
  const voice0 = window.voice;
  window.voice = function (name) {
    if (typeof G !== 'undefined' && G && G.koHush95 && name && name.indexOf('dlg_') !== 0 && !/_(?:defeat|victory|ko|line\w*)$/.test(name)) return false;
    return voice0.apply(this, arguments);
  };

  /* ---------- 3. a panel that opens mid-fight ignores fight taps for a moment ---------- */
  /* the player's tap / confirm button may turn the page only after 1.5 s on the first line
     (still mashing attack from the fight) and 0.45 s on the next ones */
  V95.panelTapOk = function () { const P = typeof G !== 'undefined' && G && G.panel; return !P || P.t >= (P.i === 0 ? 1.5 : 0.45); };

  /* ---------- 4. Hard / Nightmare: a hero busy attacking gets flanked ---------- */
  const getTok0 = window.getTok;
  window.getTok = function (e, max) {
    if (getTok0(e, max)) return true;
    const n = DF().flank || 0; if (!n || e.hasTok || G.mode === 'tutorial') return false;
    const h = nearestHero(e); if (!h || h.dead) return false;
    const behind = (e.x - h.x) * (h.face || 1) < 0, busy = h.st === 'atk' || h.st === 'spec';
    if (behind && busy && Math.abs(e.x - h.x) < 130 && Math.abs(e.y - h.y) < 30 && (G.flank95 || 0) < n) {
      G.flank95 = (G.flank95 || 0) + 1; G.tok++; e.hasTok = true; e.flank95 = true; return true;
    }
    return false;
  };
  function recountFlank() { let n = 0; for (const e of G.enemies) { if (e.flank95 && (!e.hasTok || e.dead)) e.flank95 = false; if (e.flank95) n++; } G.flank95 = n; }

  /* ---------- 5. drawn effects ---------- */
  function blit(g, name, i, x, y, sc, alpha, add, face) {
    const L = A.frames[name], f = L && L[Math.max(0, Math.min(L.length - 1, i))]; if (!f) return;
    const k = sc / A.k;
    g.save(); g.translate(x, y); if (face < 0) g.scale(-1, 1); g.scale(k, k);
    g.globalAlpha = alpha; if (add) g.globalCompositeOperation = 'lighter'; g.imageSmoothingEnabled = true;
    g.drawImage(img, f[0], f[1], f[2], f[3], -f[4], -f[5], f[2], f[3]); g.restore();
  }
  const fxList = [];
  V95.fx = function (name, x, y, dur, o) { if (!ready || !A.frames[name]) return false; o = o || {}; fxList.push({ name, x, y, z: o.z || 0, t: 0, dur, sc: o.sc || 1, face: o.face || 1, run: G }); return true; };

  /* toxic gas: the vent on the floor (arming 0-5, venting 6-11, shutting 12-17) and the cloud (eruption 0-5, loop 6-11, fading 12-17) */
  const shut = [];
  const gasScale = h => (h.r || 36) / 36 * depthScale(h.y);
  V95.drawHazard = function (g, h, cam) {
    if (!ready || h.kind !== 'gas') return false;
    if (h.t < 0) return true;
    const i = h.t < h.warn ? Math.min(5, Math.floor(h.t / h.warn * 6)) : 6 + Math.floor((h.t - h.warn) * 14) % 6;
    blit(g, 'vent', i, h.x - cam, h.y, gasScale(h), 1, false, 1);
    return true;
  };
  V95.drawShut = function (g, cam) {
    if (!ready) return;
    for (const s of shut) blit(g, 'vent', 12 + Math.min(5, Math.floor(s.t / 0.09)), s.x - cam, s.y, s.sc, 1, false, 1);
  };
  /* clouds go into the depth order: called before each fighter with its floor y */
  const drawn = new Set();
  V95.beginEnts = function () { drawn.clear(); };
  V95.cloudsUpTo = function (g, cam, y) {
    if (!ready || !G || !G.hz) return;
    for (const h of G.hz) {
      if (h.kind !== 'gas' || h.t < h.warn || drawn.has(h) || h.y > y) continue;
      drawn.add(h);
      const lt = h.t - h.warn, end = h.live;
      const i = lt < 0.42 ? Math.min(5, Math.floor(lt / 0.07)) : lt > end - 0.6 ? 12 + Math.min(5, Math.floor((lt - end + 0.6) / 0.1)) : 6 + Math.floor((lt - 0.42) * 10) % 6;
      blit(g, 'gas', i, h.x - cam, h.y, gasScale(h), 0.92, true, 1);
    }
    for (const q of fxList) {
      if (q.y > y || drawn.has(q)) continue; drawn.add(q);
      const n = A.frames[q.name].length;
      blit(g, q.name, Math.min(n - 1, Math.floor(q.t / q.dur * n)), q.x - cam, q.y - q.z, q.sc * depthScale(q.y), 1, false, q.face);
    }
  };

  /* ---------- 6. the Crow Mourner ---------- */
  const isM = e => e && e.kind === 'enemy' && e.def && e.def.mourner;
  const MAT = 0.62;                                      // feathers swirl, flash at 0.36 s, body in by 0.5 s
  function appearAt(e, x, y) {
    e.x = x; e.y = y; e.arrive = false; e.mat95 = MAT; e.fade = 0; e.inv = Math.max(e.inv || 0, MAT);
    e.van95 = 0; e.hid95 = 0; e.face = (nearestHero(e) || e).x >= x ? 1 : -1;
    V95.fx('fmat', x, y, 0.7, { sc: 0.9 });
    if (typeof sfx === 'function') sfx('dash');
    if (G && !G.mourTold95 && !G.mode) { G.mourTold95 = true; later(() => { if (G && !G.over) talk('malakor', 'p95a'); }, 600); }
  }
  const spawn0 = window.spawnEnemy;
  window.spawnEnemy = function (type, side) {
    const e = spawn0.apply(this, arguments);
    if (isM(e) && G && G.player) {
      const p = G.player, s = side < 0 ? -1 : 1;
      appearAt(e, clamp(p.x + s * rnd(95, 160), G.camX + 40, G.camX + VW - 110), clamp(e.y, LANE_T + 4, LANE_B - 4));
      e.tp95 = rnd(4, 7);
    }
    return e;
  };
  function teleport(e) {
    const h = nearestHero(e); if (!h || h.dead) return false;
    if (G.enemies.some(o => o !== e && isM(o) && !o.dead && (o.van95 > 0 || o.hid95 > 0 || o.mat95 > 0))) return false;
    if (e.hasTok) { G.tok--; e.hasTok = false; }
    e.van95 = 0.26; e.ai = 'move'; e.vx = 0;
    V95.fx('fvan', e.x, e.y, 0.6, { sc: 0.9, face: e.face });
    if (typeof sfx === 'function') sfx('dash');
    return true;
  }
  const upd0 = window.updEnemy;
  window.updEnemy = function (e, dt) {
    if (isM(e) && !e.dead) {
      if (e.van95 > 0) {                                 // wrapping himself in feathers
        e.van95 -= dt; e.ct += dt; e.inv = 1; e.fade = Math.max(0, e.van95 / 0.26);
        if (e.van95 <= 0) { e.hid95 = 0.45; e.fade = 0; }
        return;
      }
      if (e.hid95 > 0) {                                 // gone; the swirl shows where he will come back
        e.hid95 -= dt; e.inv = 1;
        if (!e.dest95) {
          const h = nearestHero(e) || G.player, side = -(h.face || 1);
          e.dest95 = { x: clamp(h.x + side * rnd(62, 84), G.camX + 40, G.camX + VW - 110), y: clamp(h.y + rnd(-6, 6), LANE_T + 4, LANE_B - 4) };
          V95.fx('fmat', e.dest95.x, e.dest95.y, 0.9, { sc: 0.9 });
        }
        if (e.hid95 <= 0) { const d = e.dest95; e.dest95 = null; appearAt(e, d.x, d.y); e.mat95 = 0.42; e.tp95 = rnd(5, 8) * (DF().cd || 1); e.cd = 0; }
        return;
      }
      if (e.mat95 > 0) {                                 // taking shape inside the burst
        e.mat95 -= dt; e.ct += dt;
        const done = MAT - e.mat95; e.fade = Math.max(0, Math.min(1, (done - 0.3) / 0.18));
        if (e.mat95 <= 0) { e.fade = 1; e.inv = 0; }
        const h = nearestHero(e); if (h) e.face = h.x >= e.x ? 1 : -1;
        return;
      }
      if (e.taunt95 > 0) e.taunt95 -= dt;
      /* now and then he scatters into crows and comes back behind the hero */
      if (e.ai === 'move' && e.st !== 'hurt' && e.st !== 'knock' && e.st !== 'down' && e.st !== 'getup' && !G.over && !(G.clearT > 0)) {
        e.tp95 = (e.tp95 == null ? rnd(4, 7) : e.tp95) - dt;
        const h = nearestHero(e);
        if (e.tp95 <= 0 && h && Math.abs(h.x - e.x) > 70) { if (!teleport(e)) e.tp95 = 1.2; return; }
      }
    }
    return upd0.apply(this, arguments);
  };
  /* a landed talon blow: he throws his head back and caws */
  const hurt0 = window.hurt;
  window.hurt = function (att, tg) {
    const r = hurt0.apply(this, arguments);
    if (r && isM(att) && tg && tg.kind === 'hero' && Math.random() < 0.45) { att.taunt95 = 0.55; if (att.ai === 'rec') att.t = Math.max(att.t, 0.6); }
    return r;
  };
  /* the drawn frames: 4 wind-up, 2 strike, 2 recovery; thrown / falling; feathers when he vanishes */
  const ef0 = window.entFrame;
  window.entFrame = function (e) {
    if (isM(e)) {
      if (e.van95 > 0) return ['vanish', e.van95 > 0.13 ? 0 : 1, false];
      if (e.dead) return e.z > 1 ? ['knock', e.vz > 0 ? 0 : 1, false] : ['down', 0];
      if (e.st === 'knock') return ['knock', e.vz > 0 ? 0 : 1, false];
      const P = window.ATLAS[e.key] && window.ATLAS[e.key].prof;
      if (P && !e.arrive && e.st !== 'hurt' && e.st !== 'down' && e.st !== 'getup') {
        const el = track(e, 'ai' + e.ai);
        if (e.ai === 'wind') { const dur = Math.max(0.1, (e.def.wind || 0.35) * DF().wind); return ['atk', P.wind[Math.min(P.wind.length - 1, Math.floor(el / dur * P.wind.length))], false]; }
        if (e.ai === 'hit') return ['atk', P.hit[Math.min(P.hit.length - 1, Math.floor(el / 0.12))], false];
        if (e.ai === 'rec' && e.taunt95 > 0) return ['win', Math.floor(el * 7) % 2];
        if (e.ai === 'rec' && el < 0.24) return ['atk', P.rec[Math.min(P.rec.length - 1, Math.floor(el / 0.12))], false];
      }
    }
    return ef0(e);
  };

  /* ---------- per-frame upkeep ---------- */
  const playUpdate = Scenes.play.update;
  Scenes.play.update = function (dt) {
    const r = playUpdate.apply(this, arguments);
    if (!G || this.menu || G.panel || G.choice) return r;
    recountFlank();
    const live = new Set(G.hz);
    if (V95._hz) for (const h of V95._hz) if (!live.has(h) && h.kind === 'gas' && h.run === G) shut.push({ x: h.x, y: h.y, sc: gasScale(h), t: 0 });
    V95._hz = G.hz.filter(h => h.kind === 'gas'); for (const h of V95._hz) h.run = h.run || G;
    if (!G.gasTold95 && !G.mode && V95._hz.some(h => h.t >= 0)) { G.gasTold95 = true; talk('malakor', 'hz95a'); }
    for (const s of shut) s.t += dt; for (let i = shut.length - 1; i >= 0; i--) if (shut[i].t > 0.54) shut.splice(i, 1);
    for (const q of fxList) q.t += dt; for (let i = fxList.length - 1; i >= 0; i--) if (fxList[i].t > fxList[i].dur || fxList[i].run !== G) fxList.splice(i, 1);
    return r;
  };
})();
