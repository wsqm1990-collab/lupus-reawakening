'use strict';
/* 9.6 — STAGE 10: the Leviathan rises out of the sea BEHIND the pier.

   Before, the creature was drawn on the dock itself, over the fighters (they vanished behind it),
   and its weak spot was an invisible point that did not match the picture. Now:
   - the pier ends in open sea: the stage's own sky-and-sea painting fills everything above the
     pier edge on the last screen, and the Leviathan rises out of that water, always drawn behind
     the fighters (it can never hide anybody);
   - it reaches the pier with a claw slam or a bite; then its head rests on the pier edge,
     exposed and glowing: stand on the back of the pier and hit it (a wide target, every row
     of the back half of the pier reaches it);
   - water beam along one row, a tidal wave to jump, divers climbing out of the water;
   - between attacks it sinks and comes up again behind another part of the pier.
   Frames: ATLAS.lev96, drawn for 9.6 in the cyber design (tools/lev96: guides.py lays out each pose
   on the old frames, build96.py cuts the drawings at their water line); anchor = the water line. */
(function () {
  if (typeof MECH === 'undefined' || !MECH.giant || typeof updGiant !== 'function') return;
  const PIER = 186;                       /* pier edge on screen: open sea above, deck below */
  const SC = 0.98;                         /* body scale */
  const L = window.LEV96 = { PIER };
  const key = () => (window.ATLAS.lev96 && ART.img.c_lev96 && ART.img.c_lev96.ok) ? 'lev96' : 'levgiant';
  const on = () => Scene.name === 'play' && G && G.st && !G.mode && G.st.boss === 'levgiant';
  L.seam = () => WORLD_W - VW - 40;        /* world x where the open sea starts (the last screen) */
  const WEAK = { en: 'WEAK POINT!', pt: 'PONTO FRACO!', es: '¡PUNTO DÉBIL!', fr: 'POINT FAIBLE !', de: 'SCHWACHSTELLE!', it: 'PUNTO DEBOLE!',
    ru: 'СЛАБОЕ МЕСТО!', zh: '弱点！', ja: '弱点だ！', ko: '약점이다!', hi: 'कमज़ोर जगह!', ar: 'نقطة ضعف!' };
  /* applyLang() rebuilds STR from I18N[lang].ui, so the text goes there (and into the live table) */
  if (typeof I18N !== 'undefined') for (const l in WEAK) if (I18N[l] && I18N[l].ui) I18N[l].ui.weakPoint = WEAK[l];
  if (typeof STR !== 'undefined') for (const l in WEAK) if (STR[l]) STR[l].weakPoint = WEAK[l];

  /* ------------------------------------------------------------------ loading */
  if (typeof playNeeds === 'function') {
    const _pn = playNeeds;
    playNeeds = function (o) {
      const r = _pn(o); const st = STAGES[o.stage];
      if (st && st.boss === 'levgiant' && !o.mode) { r.push('c_lev96'); const b = 's' + (st.bg || st.id) + '_l1'; if (!r.includes(b)) r.push(b); }
      return r;
    };
  }

  /* ------------------------------------------------------------------ the sea behind the pier */
  let seaC = null, seaX = null;
  function drawSea(g, cam) {
    const sx = Math.round(L.seam() - cam); if (sx >= VW) return false;
    const im = ART.img['s' + BG.n + '_l1']; if (!im || !im.ok) return false;
    const W = Math.ceil(VW * 2), H = PIER * 2;
    if (!seaC || seaC.width !== W) { seaC = document.createElement('canvas'); seaC.width = W; seaC.height = H; seaX = seaC.getContext('2d'); }
    const x = seaX; x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'source-over'; x.clearRect(0, 0, W, H);
    /* the painting: sky, offshore rigs and the night sea (parallax), lifted so the sea shows above the pier */
    const tw = im.width, th = im.height, off = (cam * 0.35) % tw;
    for (let i = -1; i <= Math.ceil(W / tw) + 1; i++) x.drawImage(im, i * tw - off, -130);
    /* soft seam where the docks give way to the open sea */
    /* the same calm-down as the rest of the scenery while the boss is fought (fix81) */
    if (G.dimK > 0) { x.fillStyle = 'rgba(4,2,10,' + (0.2 * G.dimK).toFixed(3) + ')'; x.fillRect(0, 0, W, H); }
    if (sx > -90) { x.globalCompositeOperation = 'destination-in'; const gr = x.createLinearGradient(sx * 2, 0, sx * 2 + 180, 0); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,1)'); x.fillStyle = gr; x.fillRect(0, 0, W, H); }
    g.drawImage(seaC, 0, 0, W, H, 0, 0, VW, PIER);
    return true;
  }

  /* ------------------------------------------------------------------ body */
  function bodyFrame(e) {
    const s = e.gst, k = e.gt;
    if (e.dead) return e.deadT < 1.6 ? ['crack', 0] : ['sink', 0];      /* armour shattering, then it goes under */
    if (s === 'rise') return ['rise', k < 0.8 ? 0 : 1, false];
    if (s === 'sink' || s === 'under') return ['sink', 0];
    if (s === 'claw0') return ['raise', 0, false];
    if (s === 'claw1') return ['slam', 0, false];
    if (s === 'bite0') return ['bite', 0, false];
    if (s === 'bite1') return ['bite', k < 0.12 ? 1 : 2, false];
    if (s === 'expo') return e.hurtT > 0 ? ['hurt', e.hurtT > 0.12 ? 0 : 1, false] : ['bite', 2, false];
    if (s === 'beam0') return ['roar', 0, false];
    if (s === 'beam1') return ['beam', 0, false];
    if (s === 'roar0' || s === 'roar1') return ['roar', Math.floor(G.time * 8), true];
    if (e.flash > 0.6) return ['hurt', Math.floor(G.time * 10)];
    return ['idle', Math.floor(G.time * 4)];
  }
  /* how far below the waterline the body is (0 = fully up) */
  function depth(e) {
    if (e.dead) return Math.min(1.1, Math.max(0, e.deadT - 1.4) * 0.45);
    if (e.gst === 'rise') return 1 - Math.min(1, e.gt / 1.6) * (2 - Math.min(1, e.gt / 1.6));
    if (e.gst === 'sink') return Math.min(1, e.gt / 0.7);
    if (e.gst === 'under') return 1.1;
    return 0;
  }
  L.drawBody = function (g, cam) {
    const e = G.boss; if (!e || !e.giant) return;
    if (e.dead && e.deadT > 5) return;
    const k = key(), r = bodyFrame(e), fr = ART.frame(k, r[0], r[1], r[2]); if (!fr) return;
    const A = window.ATLAS[k], lean = e.gst === 'bite1' || e.gst === 'expo' ? 10 : e.gst === 'claw1' ? 6 : 0;
    const x = e.sx - cam, y = PIER + (A && A.water ? 2 : 26) + lean + depth(e) * 150 + Math.sin(G.time * 1.3) * 1.5;
    g.save(); g.beginPath(); g.rect(-20, -60, VW + 40, PIER + 60); g.clip();
    ART.draw(g, fr, x, y, { face: e.sface, sc: SC, flash: Math.min(0.35, e.flash * 0.4), tint: e.p2 ? '#ff2040' : null, tintA: 0.07 + 0.05 * Math.sin(G.time * 5) });
    g.restore();
    /* churned water at the waterline */
    const d = depth(e); if (d < 1) { g.save(); g.globalCompositeOperation = 'lighter'; const n = 9; for (let i = 0; i < n; i++) { const wx = x - 120 + i * 30 + Math.sin(G.time * 3 + i) * 4, wy = PIER - 2 + Math.sin(G.time * 5 + i * 1.7) * 1.2; RD.glow(g, wx, wy, 12, '#9cf4ff', 0.10 * (1 - d)); } g.restore(); }
    void A;
  };

  /* ------------------------------------------------------------------ background hook */
  const _bg = MECH.giant.bg;
  MECH.giant.bg = function (g, cam) {
    BG.back(g, cam, G.hitstop > 0 ? 0 : 1 / 60);
    if (!on()) return;
    if (drawSea(g, cam) || (G.boss && G.boss.giant)) L.drawBody(g, cam);
  };
  void _bg;

  /* ------------------------------------------------------------------ fight */
  const heroNear = e => { let b = null, bd = 1e9; for (const h of G.heroes) { if (h.dead) continue; const d = Math.abs(h.x - e.sx); if (d < bd) { bd = d; b = h; } } return b || G.player; };
  const setG = (e, s) => { e.gst = s; e.gt = 0; };
  const headX = e => e.sx - 58 * e.sface * SC;
  function expose(e, on) {
    e.vuln = on;
    if (on) { e.x = headX(e); e.hr = 46; }
    else { e.x = e.sx; e.y = LANE_T - 40; e.hr = 0; }
  }
  window.giantInit = function (e) {
    e.bossIn = 2.2; e.sx = clamp(G.camX + VW * 0.62, G.camX + 150, G.camX + VW - 120); e.sface = 1; e.gst = 'rise'; e.gt = 0;
    e.inv = 0; e.atkI = 0; e.since = 0; e.hurtT = 0; expose(e, false); e.x = e.sx;
    sfx('roar'); shake(10); voice('leviathan_giant_roar', 0);
  };
  window.updGiant = function (e, dt) {
    e.gt += dt; e.ct += dt; e.flash = Math.max(0, e.flash - dt * 5); e.hurtT = Math.max(0, (e.hurtT || 0) - dt);
    if (e.dead) { e.vuln = false; return; }
    const tg = heroNear(e), W = DF().wind || 1, p2 = e.hp < e.maxhp * 0.5;
    if (e.gst === 'bite1' && !e.vuln) expose(e, true);                  /* the bite brings the head down to the pier edge */
    if (!e.vuln) { e.x = e.sx; e.y = LANE_T - 40; }
    else { const p = G.player && !G.player.dead ? G.player : tg; e.x = headX(e); e.y = clamp(p.y, LANE_T + 2, LANE_T + 28); }   /* the head spans the back half of the pier */
    if (e.gst === 'rise') { if (e.gt > 1.8) { e.bossIn = 0; setG(e, 'idle'); if (!e.told) { e.told = true; talk('nereus', 'r10n', { vo: 'nereus_line1' }); } } return; }
    if (e.p2 !== true && p2) { e.p2 = true; sfx('roar'); shake(10); textFx(e.sx, LANE_T - 120, T('p2'), '#ff3050', 2); talk('triton', 'r10b'); }
    e.sface = tg.x < e.sx ? 1 : -1;
    switch (e.gst) {
      case 'idle': {
        if (e.gt < (p2 ? 0.75 : 1.2) * DF().cd) break;
        /* every few attacks it dives and comes up behind the fighters' part of the pier */
        if (e.since >= (p2 ? 2 : 3) && Math.abs(tg.x - e.sx) > 70) { e.since = 0; setG(e, 'sink'); storySnd('splash'); break; }
        const seq = p2 ? ['claw', 'bite', 'beam', 'claw', 'roar', 'bite', 'claw', 'beam'] : ['claw', 'bite', 'claw', 'beam', 'roar'];
        const n = seq[e.atkI++ % seq.length]; e.since++;
        if (n === 'claw' || n === 'bite') {
          const tx = n === 'bite' ? headX(e) : clamp(e.sx - (60 + rnd(0, 30)) * e.sface, G.camX + 40, G.camX + VW - 40);
          const ty = n === 'bite' ? LANE_T + 12 : clamp(tg.y, LANE_T + 6, LANE_T + 18);      /* it reaches the back of the pier only: the front half is safe */
          e.tx = tx; e.ty = ty;
          G.hz.push({ kind: 'debris', boss: true, x: tx, y: ty, r: n === 'bite' ? 58 : 44, t: 0, warn: 0.95 * W + 0.15, live: 0.2, dmg: (n === 'bite' ? 70 : 60) * e.dm, quiet: true, lev: n });
          setG(e, n + '0');
        } else if (n === 'beam') { e.ty = clamp(tg.y, LANE_T + 4, LANE_B - 4); G.hz.push({ kind: 'beam', boss: true, x: G.camX, y: e.ty, r: 12, t: 0, warn: 1.1, live: 0.6, dmg: 55 * e.dm }); sfx('alarm'); setG(e, 'beam0'); }
        else setG(e, 'roar0');
        break;
      }
      case 'sink': if (e.gt > 0.7) { setG(e, 'under'); e.nx = clamp(tg.x + rnd(-50, 50), G.camX + 150, G.camX + VW - 120); } break;
      case 'under': if (e.gt > 0.6) { e.sx = e.nx; setG(e, 'rise'); e.gt = 0.6; storySnd('splash'); shake(5); } break;
      case 'claw0': case 'bite0':
        if (e.gt > 0.95 * W + 0.15) { const b = e.gst === 'bite0'; setG(e, b ? 'bite1' : 'claw1'); shake(12); sfx('boom'); dust(e.tx, e.ty, 20, '#9cf4ff'); ringFx(e.tx, e.ty, 0, 70, '#3af0ff', 0.5);
          for (let i = 0; i < 14; i++) G.parts.push({ x: e.tx + rnd(-30, 30), y: e.ty, z: 2, vx: rnd(-60, 60), vy: 0, vz: rnd(80, 200), life: 0.8, t: 0, col: '#9cf4ff', size: 2, grav: 500 }); }
        break;
      case 'claw1': case 'bite1':
        if (e.gt > 0.3) { setG(e, 'expo'); expose(e, true); e.expoDur = (p2 ? 1.6 : 2.2) * (e.gst === 'bite1' ? 1.15 : 1); sfx('roar'); }
        break;
      case 'expo': if (e.gt > (e.expoDur || 2)) { expose(e, false); setG(e, 'idle'); } break;
      case 'beam0': if (e.gt > 1.1) { setG(e, 'beam1'); sfx('special'); shake(6); } break;
      case 'beam1': if (e.gt > 0.6) setG(e, 'idle'); break;
      case 'roar0':
        if (e.gt > 0.6) { setG(e, 'roar1'); sfx('roar'); shake(10); for (const h of G.heroes) if (!h.dead) h.vx += -90 * e.sface;
          /* divers climb out of the water onto the pier edge */
          if (enemiesAlive() < 4) for (let i = 0; i < (p2 ? 2 : 1); i++) { const d = spawnEnemy('D', -1); d.x = clamp(e.sx + rnd(-140, 140), G.camX + 30, G.camX + VW - 30); d.y = LANE_T + 2; d.arrive = false; d.vz = 160; d.z = 4; dust(d.x, d.y, 10, '#9cf4ff'); }
          for (const oy of [-18, 18]) shoot({ x: e.sx - 60 * e.sface, y: clamp(tg.y + oy, LANE_T, LANE_B), z: 8, vx: -230 * e.sface, dmg: 40 * e.dm, team: 'e', r: 22, life: 2.4, type: 'wave', col: '#3af0ff', pierce: true, kx: 100 }); }
        break;
      case 'roar1': if (e.gt > 1) setG(e, 'idle'); break;
    }
  };
  /* the head flinches when it is hit, the window stays open */
  if (typeof hurt === 'function') {
    const _hurt = hurt;
    window.hurt = function (att, tg, dmg, o) {
      const weak = tg && tg.giant && tg.vuln && att && att.team === 'p';
      const r = _hurt(att, tg, weak ? dmg * 1.8 : dmg, o);            /* the exposed head is its weak point */
      if (r && weak) { tg.hurtT = 0.25; if (!tg.weakTold) { tg.weakTold = true; textFx(tg.x, LANE_T - 60, T('weakPoint'), '#ffd23a', 1.4); } }
      return r;
    };
  }
  /* the body is drawn with the scenery; in the fighters' pass only the exposed head is marked */
  window.drawGiant = function (g, e, cam) {
    if (!e.vuln || e.dead) return;
    const x = headX(e) - cam, y = PIER - 30;
    g.save(); g.globalCompositeOperation = 'lighter'; RD.glow(g, x, y, 54, '#ffd23a', 0.16 + 0.08 * Math.sin(G.time * 10)); g.restore();
    if (Math.sin(G.time * 12) > -0.3) PIX.text(g, '!', x, y - 46, { s: 2, align: 'c', col: '#ffd23a', out: '#000' });
  };
  window.giantFrame = bodyFrame;
})();
