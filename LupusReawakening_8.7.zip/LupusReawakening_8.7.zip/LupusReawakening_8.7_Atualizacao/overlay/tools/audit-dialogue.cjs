const fs=require('fs'),vm=require('vm'),path=require('path');
const args=process.argv.slice(2); const langFlag=args.indexOf('--lang');
const requested=langFlag>=0?args[langFlag+1]:'pt-BR';
if(!['en','pt','pt-BR'].includes(requested)) throw new Error('Supported audit languages: en, pt-BR');
const language=requested==='en'?'en':'pt-BR', code=language==='en'?'en':'pt';
const remaining=langFlag>=0?args.filter((_,i)=>i!==langFlag&&i!==langFlag+1):args;
const base=remaining[0]||path.resolve(__dirname,'../src/LupusReawakening-Android/app/src/main/assets/game');
const src=fs.readFileSync(base+'/js/i18n8.js','utf8');
const dictionaries=JSON.parse(src.match(/const I18N8 = (.*);\n/)[1]), dict=dictionaries[code].comic;
const voicePrefix='assets/voice/dialogue/'+(code==='en'?'en/':'');
const ctx={CUTS:{},SPK_NAME:{},CUT_MOOD:{},I18N:{pt:{comic:dictionaries.pt.comic},en:{comic:dictionaries.en.comic}},COMIC_LIST:new Set(),STAGE_PANELS:{},P:(img,beats,focus)=>({img,beats,focus}),ROSTER_KEY:{vespera:'vespera',triton:'triton',malakor:'malakor',echo:'echo',brann:'brann'},CT:k=>dict[k]||''};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(base+'/js/story8.js','utf8').split('/* ---------- loading on demand')[0]+'\nthis.output={cuts:CUTS,duoAt:DUO_AT,duoLet:DUO_LET};',ctx);
if(fs.existsSync(base+'/js/story9.js'))vm.runInContext(fs.readFileSync(base+'/js/story9.js','utf8'),ctx);
const rows=new Map();function add(k,spk,type,where,oldVoice){if(!k||!dict[k])return;if(rows.has(k)){let r=rows.get(k);r.occurrences.push(where);return;}rows.set(k,{key:k,speaker:spk||'narrator',type:type||'say',text:dict[k],file:voicePrefix+k+'.ogg',legacy_voice:oldVoice||null,occurrences:[where]});}
for(const [cut,pages]of Object.entries(ctx.output.cuts))for(const[pi,page]of pages.entries()){if(!Array.isArray(page))continue;for(const p of page)for(const b of p.beats)if(['say','think','cap'].includes(b.t))add(b.k,b.spk,b.t,cut+':'+pi+':'+p.img,b.vo);}
for(const [m,allies]of Object.entries(ctx.output.duoAt))for(const ally of Object.keys(allies))for(let i=0;i<3;i++){const k='d'+ctx.output.duoLet[ally]+m.slice(1)+'abc'[i];add(k,i%2?'lupus_h':ally,'say',allies[ally]+':duo_'+ally+'_'+m);}
for(const file of ['game8.js','fix81.js']){const s=fs.readFileSync(base+'/js/'+file,'utf8');let m;const re=/\{\s*t:\s*'(say|think|cap)'(?:\s*,\s*spk:\s*'([^']+)')?\s*,\s*k:\s*'([^']+)'[^}]*\}/g;while((m=re.exec(s)))add(m[3],m[2],m[1],file+':panel');
const re2=/talk\(\s*(?:'([^']+)'|(null))\s*,\s*'([^']+)'\s*(?:,\s*\{([^}]+)\})?/g;while((m=re2.exec(s))){if(m[3].startsWith('arT'))continue;add(m[3],m[1],'radio',file+':talk',m[4]?.match(/vo:\s*'([^']+)'/)?.[1]);}
}
for(const[key,speaker]of Object.entries({r02c:'lupus_h',r02d:'lupus_h',r02e:'lupus_h',r06c:'lupus_h',r06d:'lupus_h',r06e:'lupus_h',r08b:'narrator',r08c:'narrator',r08d:'narrator',r13b:'malakor',r13c:'malakor',r15b:'lupus_h',r15d:'lupus_h',fj_vespera:'vespera',fj_triton:'triton',fj_echo:'echo',fj_brann:'brann',fj_malakor:'malakor'}))add(key,speaker,'radio','game8.js:dynamic-talk');
const lines=[...rows.values()];console.log(JSON.stringify({version:1,language,generated_at:'2026-10-16',policy:'Exact authored lines. Existing event voice filenames are not assumed to match authored dialogue. Archive titles and menu labels remain UI-only.',stats:{lines:lines.length,characters:lines.reduce((n,r)=>n+r.text.length,0),speakers:Object.fromEntries([...new Set(lines.map(r=>r.speaker))].map(s=>[s,lines.filter(r=>r.speaker===s).length]))},lines},null,2));
