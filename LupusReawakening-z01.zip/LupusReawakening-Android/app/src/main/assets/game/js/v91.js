'use strict';
/* =====================================================================
   v9.1 / v9.2
   - "Choose your difficulty" after the 1944 prologue, first time only
   - Progress backup (export / import) in Options, now that the refuge
     and its rooms are gone
   - v9.2: the Lunarium claws page at the first feral transformation
   ===================================================================== */
(function () {
  const L = () => SAVE.lang || 'en';
  const pick = table => table[L()] || table.en;

  /* ---------- difficulty choice ---------- */
  const DIFF_PICK = {
    en: ['CHOOSE YOUR DIFFICULTY', ['Enjoy the story. Weaker enemies, more healing.', 'The balanced challenge the game was made for.', 'Stronger, faster and more numerous enemies.', 'Brutal. Little healing, no checkpoints.'], 'CONFIRM', 'You can change it later in the main menu.'],
    pt: ['ESCOLHA A DIFICULDADE', ['Para curtir a história. Inimigos mais fracos e mais cura.', 'O desafio equilibrado para o qual o jogo foi feito.', 'Inimigos mais fortes, mais rápidos e em maior número.', 'Brutal. Pouca cura e sem checkpoints.'], 'CONFIRMAR', 'Você pode mudar depois no menu principal.'],
    es: ['ELIGE LA DIFICULTAD', ['Disfruta la historia. Enemigos más débiles, más curación.', 'El desafío equilibrado para el que se hizo el juego.', 'Enemigos más fuertes, más rápidos y más numerosos.', 'Brutal. Poca curación y sin puntos de control.'], 'CONFIRMAR', 'Puedes cambiarla después en el menú principal.'],
    fr: ['CHOISIS LA DIFFICULTÉ', ["Profite de l'histoire. Ennemis plus faibles, plus de soins.", 'Le défi équilibré pour lequel le jeu a été conçu.', 'Ennemis plus forts, plus rapides et plus nombreux.', 'Brutal. Peu de soins, aucun point de contrôle.'], 'CONFIRMER', 'Tu pourras la changer plus tard dans le menu principal.'],
    de: ['WÄHLE DEN SCHWIERIGKEITSGRAD', ['Genieße die Geschichte. Schwächere Gegner, mehr Heilung.', 'Die ausgewogene Herausforderung, für die das Spiel gemacht ist.', 'Stärkere, schnellere und mehr Gegner.', 'Brutal. Wenig Heilung, keine Checkpoints.'], 'BESTÄTIGEN', 'Du kannst ihn später im Hauptmenü ändern.'],
    it: ['SCEGLI LA DIFFICOLTÀ', ['Goditi la storia. Nemici più deboli, più cure.', 'La sfida equilibrata per cui il gioco è stato creato.', 'Nemici più forti, più veloci e più numerosi.', 'Brutale. Poche cure, nessun checkpoint.'], 'CONFERMA', 'Potrai cambiarla dopo nel menu principale.'],
    ru: ['ВЫБЕРИТЕ СЛОЖНОСТЬ', ['Наслаждайтесь историей. Враги слабее, больше лечения.', 'Сбалансированный вызов, для которого создана игра.', 'Враги сильнее, быстрее и многочисленнее.', 'Жестоко. Мало лечения, без контрольных точек.'], 'ПОДТВЕРДИТЬ', 'Позже её можно изменить в главном меню.'],
    zh: ['选择难度', ['享受剧情。敌人更弱，恢复更多。', '为本作设计的均衡挑战。', '敌人更强、更快、数量更多。', '极其残酷。恢复很少，没有检查点。'], '确认', '之后可以在主菜单中更改。'],
    ja: ['難易度を選択', ['物語を楽しもう。敵が弱く、回復が多い。', 'このゲーム本来のバランスの取れた挑戦。', '敵がより強く、速く、多くなる。', '過酷。回復は少なく、チェックポイントなし。'], '決定', '後からメインメニューで変更できます。'],
    ko: ['난이도를 선택하세요', ['이야기를 즐기세요. 적이 약하고 회복이 많습니다.', '게임 본연의 균형 잡힌 도전.', '적이 더 강하고 빠르며 더 많습니다.', '잔혹함. 회복이 적고 체크포인트가 없습니다.'], '확인', '나중에 메인 메뉴에서 바꿀 수 있습니다.'],
    hi: ['कठिनाई चुनें', ['कहानी का आनंद लें। कमज़ोर दुश्मन, ज़्यादा हीलिंग।', 'वह संतुलित चुनौती जिसके लिए खेल बना है।', 'ज़्यादा ताकतवर, तेज़ और ज़्यादा दुश्मन।', 'क्रूर। कम हीलिंग, कोई चेकपॉइंट नहीं।'], 'पुष्टि करें', 'आप इसे बाद में मुख्य मेनू में बदल सकते हैं।'],
    ar: ['اختر مستوى الصعوبة', ['استمتع بالقصة. أعداء أضعف وعلاج أكثر.', 'التحدي المتوازن الذي صُممت له اللعبة.', 'أعداء أقوى وأسرع وأكثر عددًا.', 'وحشي. علاج قليل وبلا نقاط حفظ.'], 'تأكيد', 'يمكنك تغييره لاحقًا من القائمة الرئيسية.']
  };
  const DIFF_COL = { easy: '#7dff9a', normal: '#ffcf3a', hard: '#ff8a3a', nightmare: '#ff3a50' };
  /* illustrated background (Art Pack 5): four doors, one per difficulty, behind the four cards */
  const DIFF_ART = 'assets/ui/diff_bg.webp';
  const diffArt = new Image(); diffArt.onload = () => { diffArt.ok = true; };
  const loadDiffArt = () => { if (!diffArt.src) diffArt.src = DIFF_ART; };

  Scenes.diffPick = {
    btns: [],
    enter(o) { loadDiffArt(); this.t = 0; this.sel = Math.max(0, DIFFS.indexOf(SAVE.diff || 'normal')); this.after = o && o.after; this.layout(); musicStart(5); },
    layout() {
      const gap = 6, n = DIFFS.length, cw = Math.floor((VW - 24 - gap * (n - 1)) / n), x0 = Math.round((VW - (cw * n + gap * (n - 1))) / 2);
      this.cards = DIFFS.map((d, i) => ({ id: 'd' + i, i, x: x0 + i * (cw + gap), y: 50, w: cw, h: 112 }));
      this.ok = btn('ok', VW / 2 - 80, 178, 160, 28, pick(DIFF_PICK)[2], DIFF_COL[DIFFS[this.sel]]);
      this.btns = this.cards.concat([this.ok]);
    },
    update(dt) { this.t += dt; this.layout(); },
    draw(g) {
      const art = diffArt.ok;
      if (art) { g.imageSmoothingEnabled = true; g.drawImage(diffArt, 0, 0, diffArt.width, diffArt.height, 0, 0, VW, VH); g.imageSmoothingEnabled = false; dim(g, 0.18); }
      else { BG.menu(g, 2, this.t, this.t * 8); dim(g, 0.62); }
      const tx = pick(DIFF_PICK);
      PIX.text(g, tx[0], VW / 2, 18, { s: 2, align: 'c', col: COLR.white });
      for (const c of this.cards) {
        const d = DIFFS[c.i], col = DIFF_COL[d], on = c.i === this.sel;
        PIX.panel(g, c.x, c.y, c.w, c.h, { edge: on ? col : PIX.shade(col, 0.45), bg: art ? (on ? 'rgba(24,10,22,0.7)' : 'rgba(8,5,14,0.55)') : (on ? 'rgba(30,12,26,0.9)' : 'rgba(10,6,18,0.82)') });
        if (on) { g.fillStyle = col; g.globalAlpha = 0.08 + 0.05 * Math.sin(this.t * 6); g.fillRect(c.x + 1, c.y + 1, c.w - 2, c.h - 2); g.globalAlpha = 1; }
        PIX.text(g, T('d_' + d), c.x + c.w / 2, c.y + 12, { s: 2, align: 'c', col });
        const lines = PIX.wrap(tx[1][c.i], c.w - 12, 1).slice(0, 5), y0 = c.y + 38 + Math.max(0, (66 - lines.length * 12) / 2);
        lines.forEach((line, k) => PIX.text(g, line, c.x + c.w / 2, y0 + k * 12, { align: 'c', col: on ? COLR.white : '#c8c0d8', out: null }));
      }
      this.ok.col = DIFF_COL[DIFFS[this.sel]];
      drawBtn(g, this.ok, Math.sin(this.t * 5) > 0);
      PIX.text(g, tx[3], VW / 2, 222, { align: 'c', col: '#a8a0bb' });
    },
    choose(i) { if (i !== this.sel) { this.sel = i; sfx('ui'); } },
    confirm() {
      SAVE.diff = DIFFS[this.sel]; SAVE.diffChosen = true; saveGame(); sfx('ok');
      const next = this.after; this.after = null;
      if (typeof next === 'function') next(); else Scene.go('stages');
    },
    onDown(id, x, y) {
      const b = hitB(this.btns, x, y); if (!b) return;
      if (b.id === 'ok') this.confirm(); else this.choose(b.i);
    },
    onKey(k) { if (k === 'ok') this.confirm(); }
  };
  /* first time the prologue is cleared in the campaign */
  window.needsDiffPick = () => !SAVE.diffChosen;

  /* ---------- progress backup in Options ---------- */
  const BK = {
    en: ['PROGRESS BACKUP', 'EXPORT', 'IMPORT', 'CLOSE', 'COPY', 'IMPORT BACKUP', 'Copy this text and keep it somewhere safe (for example in a note or an e-mail to yourself). It moves your progress to another installation.', 'Paste the whole backup text here. Your current save is kept as a recovery copy before importing.', 'Backup copied.', 'Select the text and choose Copy on your device.', 'Backup imported.', 'This is not a valid CYBERCLAWS backup.'],
    pt: ['BACKUP DO PROGRESSO', 'EXPORTAR', 'IMPORTAR', 'FECHAR', 'COPIAR', 'IMPORTAR BACKUP', 'Copie este texto e guarde num lugar seguro (por exemplo, numa nota ou num e-mail para você mesmo). Ele leva o seu progresso para outra instalação.', 'Cole aqui o texto completo do backup. O save atual fica guardado como cópia de segurança antes de importar.', 'Backup copiado.', 'Selecione o texto e use Copiar no seu aparelho.', 'Backup importado.', 'Este não é um backup válido do CYBERCLAWS.'],
    es: ['COPIA DE SEGURIDAD', 'EXPORTAR', 'IMPORTAR', 'CERRAR', 'COPIAR', 'IMPORTAR COPIA', 'Copia este texto y guárdalo en un lugar seguro (por ejemplo, en una nota o un correo para ti). Lleva tu progreso a otra instalación.', 'Pega aquí el texto completo de la copia. Tu partida actual se guarda como respaldo antes de importar.', 'Copia copiada.', 'Selecciona el texto y elige Copiar en tu dispositivo.', 'Copia importada.', 'Esta no es una copia válida de CYBERCLAWS.'],
    fr: ['SAUVEGARDE DE LA PROGRESSION', 'EXPORTER', 'IMPORTER', 'FERMER', 'COPIER', 'IMPORTER LA SAUVEGARDE', 'Copie ce texte et garde-le en lieu sûr (par exemple dans une note ou un e-mail à toi-même). Il transfère ta progression vers une autre installation.', 'Colle ici le texte complet de la sauvegarde. Ta partie actuelle est conservée en copie avant l\'import.', 'Sauvegarde copiée.', 'Sélectionne le texte et choisis Copier sur ton appareil.', 'Sauvegarde importée.', 'Ce n\'est pas une sauvegarde CYBERCLAWS valide.'],
    de: ['FORTSCHRITTS-BACKUP', 'EXPORTIEREN', 'IMPORTIEREN', 'SCHLIESSEN', 'KOPIEREN', 'BACKUP IMPORTIEREN', 'Kopiere diesen Text und bewahre ihn sicher auf (z. B. in einer Notiz oder einer E-Mail an dich selbst). Damit überträgst du deinen Fortschritt auf eine andere Installation.', 'Füge hier den vollständigen Backup-Text ein. Dein aktueller Spielstand wird vorher als Sicherung behalten.', 'Backup kopiert.', 'Markiere den Text und wähle auf deinem Gerät Kopieren.', 'Backup importiert.', 'Dies ist kein gültiges CYBERCLAWS-Backup.'],
    it: ['BACKUP DEI PROGRESSI', 'ESPORTA', 'IMPORTA', 'CHIUDI', 'COPIA', 'IMPORTA BACKUP', 'Copia questo testo e conservalo al sicuro (per esempio in una nota o in un\'e-mail a te stesso). Porta i tuoi progressi su un\'altra installazione.', 'Incolla qui il testo completo del backup. Il salvataggio attuale viene conservato come copia prima dell\'importazione.', 'Backup copiato.', 'Seleziona il testo e scegli Copia sul tuo dispositivo.', 'Backup importato.', 'Questo non è un backup valido di CYBERCLAWS.'],
    ru: ['РЕЗЕРВНАЯ КОПИЯ', 'ЭКСПОРТ', 'ИМПОРТ', 'ЗАКРЫТЬ', 'КОПИРОВАТЬ', 'ИМПОРТИРОВАТЬ', 'Скопируйте этот текст и сохраните его в надёжном месте (например, в заметке или письме себе). Он переносит прогресс на другую установку.', 'Вставьте сюда весь текст резервной копии. Текущее сохранение будет сохранено перед импортом.', 'Копия скопирована.', 'Выделите текст и выберите «Копировать» на устройстве.', 'Копия импортирована.', 'Это не резервная копия CYBERCLAWS.'],
    zh: ['进度备份', '导出', '导入', '关闭', '复制', '导入备份', '复制这段文字并妥善保存（例如存进备忘录或发邮件给自己）。它可以把进度转移到另一个安装。', '在这里粘贴完整的备份文字。导入前会保留当前存档的副本。', '备份已复制。', '请选中文字并使用设备的复制功能。', '备份已导入。', '这不是有效的 CYBERCLAWS 备份。'],
    ja: ['進行状況のバックアップ', 'エクスポート', 'インポート', '閉じる', 'コピー', 'バックアップを読み込む', 'このテキストをコピーして安全な場所に保存してください（メモや自分宛てのメールなど）。別のインストールに進行状況を移せます。', 'バックアップの全文をここに貼り付けてください。読み込む前に現在のセーブは控えとして残ります。', 'コピーしました。', 'テキストを選択して端末のコピー機能を使ってください。', '読み込みました。', '有効な CYBERCLAWS のバックアップではありません。'],
    ko: ['진행 백업', '내보내기', '가져오기', '닫기', '복사', '백업 가져오기', '이 텍스트를 복사해 안전한 곳에 보관하세요(메모나 자신에게 보내는 이메일 등). 다른 설치본으로 진행 상황을 옮길 수 있습니다.', '백업 전체 텍스트를 여기에 붙여 넣으세요. 가져오기 전에 현재 저장은 복구용으로 보관됩니다.', '백업을 복사했습니다.', '텍스트를 선택한 뒤 기기의 복사 기능을 사용하세요.', '백업을 가져왔습니다.', '올바른 CYBERCLAWS 백업이 아닙니다.'],
    hi: ['प्रगति बैकअप', 'निर्यात', 'आयात', 'बंद करें', 'कॉपी करें', 'बैकअप आयात करें', 'इस टेक्स्ट को कॉपी करके सुरक्षित जगह रखें (जैसे किसी नोट या खुद को भेजे ई-मेल में)। इससे आपकी प्रगति दूसरे इंस्टॉलेशन में जाती है।', 'बैकअप का पूरा टेक्स्ट यहाँ पेस्ट करें। आयात से पहले आपका मौजूदा सेव सुरक्षित कॉपी के रूप में रखा जाता है।', 'बैकअप कॉपी हो गया।', 'टेक्स्ट चुनें और अपने डिवाइस पर कॉपी चुनें।', 'बैकअप आयात हो गया।', 'यह CYBERCLAWS का मान्य बैकअप नहीं है।'],
    ar: ['نسخة احتياطية للتقدم', 'تصدير', 'استيراد', 'إغلاق', 'نسخ', 'استيراد النسخة', 'انسخ هذا النص واحفظه في مكان آمن (مثل ملاحظة أو رسالة بريد لنفسك). ينقل تقدمك إلى تثبيت آخر.', 'الصق نص النسخة الاحتياطية كاملًا هنا. يُحفظ تقدمك الحالي كنسخة استرداد قبل الاستيراد.', 'تم نسخ النسخة الاحتياطية.', 'حدد النص واختر نسخ على جهازك.', 'تم استيراد النسخة الاحتياطية.', 'هذه ليست نسخة احتياطية صالحة من CYBERCLAWS.']
  };
  const finite = (v, a, b) => Number.isFinite(+v) ? Math.max(a, Math.min(b, +v)) : a;
  function safeTree(value, depth = 0, count = { n: 0 }) {
    if (depth > 12 || ++count.n > 16000) throw new Error('too large');
    if (value == null || typeof value === 'boolean' || typeof value === 'string' && value.length <= 10000 || typeof value === 'number' && Number.isFinite(value)) return value;
    if (Array.isArray(value)) { if (value.length > 1000) throw new Error('array'); return value.map(v => safeTree(v, depth + 1, count)); }
    if (typeof value === 'object') { const out = {}; for (const key of Object.keys(value)) { if (['__proto__', 'prototype', 'constructor'].includes(key)) throw new Error('unsafe'); out[key] = safeTree(value[key], depth + 1, count); } return out; }
    throw new Error('invalid');
  }
  /* same format as the 9.0 refuge backup, so earlier exports still import */
  function exportSave() { return JSON.stringify({ format: 'lupus-reawakening-save', version: 1, gameVersion: '9.5.1', savedAt: new Date().toISOString(), save: JSON.parse(JSON.stringify(SAVE)) }, null, 2); }
  function importSave(text) {
    const tx = pick(BK);
    if (typeof text !== 'string' || text.length > 512000) return { ok: false, error: tx[11] };
    try {
      const payload = safeTree(JSON.parse(text));
      if (payload.format !== 'lupus-reawakening-save' || payload.version !== 1 || !payload.save || typeof payload.save !== 'object' || Array.isArray(payload.save)) throw new Error(tx[11]);
      const next = payload.save;
      if (!Number.isInteger(next.unlocked) || next.unlocked < 1 || next.unlocked > STAGES.length + 1 || !next.up || typeof next.up !== 'object' || Array.isArray(next.up)) throw new Error(tx[11]);
      next.hero = 'lupus'; next.ally = HERO[next.ally] && next.ally !== 'lupus' ? next.ally : 'vespera';
      if (!I18N[next.lang]) next.lang = 'en';
      if (!DIFFS.includes(next.diff)) next.diff = 'normal';
      next.shards = Math.floor(finite(next.shards, 0, 999999));
      for (const key of ['dmg', 'hp', 'fury', 'cd']) next.up[key] = Math.floor(finite(next.up[key], 0, 999));
      for (const key of ['stars', 'best', 'arch', 'owned', 'xp', 'pal', 'skins', 'skinOn', 'aff', 'sk']) if (!next[key] || typeof next[key] !== 'object' || Array.isArray(next[key])) next[key] = {};
      if (window.ControlsUI && ControlsUI.normalize) next.controls = ControlsUI.normalize(next.controls);
      const archives = {}; for (const key of Object.keys(next.arch)) { const id = Number(key); if (Number.isInteger(id) && id >= 0 && id < ARCH_N && next.arch[key]) archives[id] = 1; } next.arch = archives;
      for (const key of Object.keys(next.stars)) { const id = Number(key); if (!Number.isInteger(id) || id < 1 || id > STAGES.length) delete next.stars[key]; else next.stars[key] = Math.floor(finite(next.stars[key], 0, 7)); }
      const before = JSON.stringify(SAVE), previous = SAVE;
      try { localStorage.setItem('lupus_reawakening_v2_backup90', before); } catch (e) { }
      try { SAVE = next; localStorage.setItem(SAVE_KEY, JSON.stringify(SAVE)); } catch (writeError) { SAVE = previous; throw writeError; }
      applyLang();
      if (window.Dialogue9) Dialogue9.stop();
      return { ok: true, message: tx[10] };
    } catch (e) { return { ok: false, error: tx[11] }; }
  }
  let dom = null;
  function close() { if (dom && dom.remove) dom.remove(); dom = null; Inp.reset(); }
  function open(kind) {
    if (dom || !document.body || !document.createElement) return false;
    const tx = pick(BK), rtl = L() === 'ar';
    const host = document.createElement('div'); host.id = 'lupus-backup';
    host.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(7,4,13,.97);color:#f0e8ff;font:16px system-ui;padding:16px;display:flex;flex-direction:column;gap:10px;box-sizing:border-box;touch-action:auto;overflow:auto' + (rtl ? ';direction:rtl' : '');
    host.addEventListener('keydown', e => { if (e.stopPropagation) e.stopPropagation(); if (e.key === 'Escape') close(); });
    const title = document.createElement('strong'); title.textContent = tx[0]; title.style.cssText = 'font-size:18px;color:#ffcf3a;letter-spacing:1px'; host.appendChild(title);
    const tabs = document.createElement('div'); tabs.style.cssText = 'display:flex;gap:10px;flex-wrap:wrap'; host.appendChild(tabs);
    const note = document.createElement('p'); note.style.margin = '0'; host.appendChild(note);
    const area = document.createElement('textarea'); area.style.cssText = 'flex:1;min-height:150px;width:100%;box-sizing:border-box;background:#120a1e;color:#f0e8ff;border:1px solid #ff3a50;border-radius:8px;padding:12px;font:12px monospace;user-select:text;-webkit-user-select:text;touch-action:auto'; host.appendChild(area);
    const result = document.createElement('p'); result.style.margin = '0'; result.setAttribute('role', 'status'); host.appendChild(result);
    const row = document.createElement('div'); row.style.cssText = 'display:flex;gap:10px;flex-wrap:wrap'; host.appendChild(row);
    const button = (parent, label, fn, hot) => { const b = document.createElement('button'); b.textContent = label; b.style.cssText = 'min-height:48px;min-width:120px;background:' + (hot ? '#531529' : '#1a1028') + ';color:#f0e8ff;border:1px solid #ff3a50;border-radius:8px;font:700 16px system-ui;padding:8px 16px'; b.onclick = fn; parent.appendChild(b); return b; };
    const show = k => {
      kind = k; result.textContent = ''; row.innerHTML = '';
      note.textContent = k === 'import' ? tx[7] : tx[6];
      area.readOnly = k !== 'import'; area.value = k === 'export' ? exportSave() : '';
      if (k === 'export') button(row, tx[4], async () => {
        try { if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(area.value); result.textContent = tx[8]; } else { area.focus(); area.select(); result.textContent = document.execCommand && document.execCommand('copy') ? tx[8] : tx[9]; } }
        catch (_) { result.textContent = tx[9]; }
      }, true);
      else button(row, tx[5], () => { const r = importSave(area.value); result.textContent = r.ok ? r.message : r.error; if (r.ok) { close(); Scene.go('title'); } }, true);
      button(row, tx[3], close);
    };
    button(tabs, tx[1], () => show('export')); button(tabs, tx[2], () => show('import'));
    show(kind || 'export');
    document.body.appendChild(host); dom = host; Inp.reset();
    return true;
  }
  window.Backup9 = { open, close, exportSave, importSave, isOpen: () => !!dom };

  /* ---------- v9.2: the first time the Lunarium claws come out ----------
     In the 1944 prologue, the moment John first turns feral, one comic page
     shows the silver claws tearing through his skin (once per run). */
  if (typeof galleryPages === 'function') {
    const pages0 = galleryPages;
    galleryPages = function () {
      const out = pages0.apply(this, arguments);
      if ((SAVE.unlocked || 1) > 1 && !out.includes('cs89')) { const i = out.indexOf('cs84'); out.splice(i < 0 ? out.length : i + 1, 0, 'cs89'); }
      return out;
    };
  }
  const playUpdate92 = Scenes.play.update;
  Scenes.play.update = function (dt) {
    const r = playUpdate92.apply(this, arguments);
    const p = G && G.player;
    if (p && G.stage === 0 && !G.mode && !G.lu02 && p.id === 'lupus' && p.form === 'f' && p.st !== 'xform' && !p.dead &&
        !G.cine && !G.panel && !G.choice && !G.superFx && !(G.over > 0) && !G.clearT && !this.menu && typeof showPanel === 'function') {
      G.lu02 = true;
      showPanel('cs89', [{ t: 'cap', k: 'lu02a' }, { t: 'think', spk: 'lupus44', k: 'lu02b' }]);
      if (window.storySnd) storySnd('rip');
    }
    return r;
  };
})();
