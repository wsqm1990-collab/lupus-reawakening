package com.thorneindustries.lupus;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioAttributes;
import android.media.SoundPool;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Lupus: Reawakening — o jogo roda em HTML5 Canvas dentro de um WebView,
 * 100% offline a partir de app/src/main/assets/game/.
 */
public class MainActivity extends Activity {

    private WebView web;
    private NativeAudio audio;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);              // salva progresso (localStorage)
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        web.addJavascriptInterface(new Haptics(this), "LupusNative");
        audio = new NativeAudio(this);
        web.addJavascriptInterface(audio, "LupusAudio");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        hideSystemUi();
        web.loadUrl("file:///android_asset/game/index.html");
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            web.evaluateJavascript("Scene.cur && Scene.cur.onKey && Scene.cur.onKey('hide')", null);
            web.onPause();
        }
        if (audio != null) audio.pauseAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        if (audio != null) audio.resumeAll();
        hideSystemUi();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.androidBack ? window.androidBack() : 'exit'", value -> {
            if (value != null && value.contains("exit")) finish();
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.destroy(); web = null; }
        if (audio != null) { audio.release(); audio = null; }
        super.onDestroy();
    }

    /**
     * som de baixa latência: efeitos, vozes e vinhetas tocam pelo SoundPool do Android,
     * bem mais rápido que o áudio do WebView. O jogo chama window.LupusAudio.play(caminho, volume, velocidade);
     * se o som ainda não carregou, play() devolve false e o jogo usa o áudio do WebView naquela vez.
     */
    static class NativeAudio {
        private final SoundPool pool;
        private final AssetManager assets;
        private final Map<String, Integer> ids = new HashMap<>();
        private final Set<Integer> ready = new HashSet<>();

        NativeAudio(Context c) {
            assets = c.getAssets();
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            pool = new SoundPool.Builder().setMaxStreams(16).setAudioAttributes(aa).build();
            pool.setOnLoadCompleteListener((sp, id, status) -> { if (status == 0) synchronized (ready) { ready.add(id); } });
        }

        @JavascriptInterface
        public void preload(String csv) {
            if (csv == null) return;
            for (String p : csv.split(",")) {
                p = p.trim();
                if (p.isEmpty()) continue;
                synchronized (ids) { if (ids.containsKey(p)) continue; }
                int id = -1;
                try (AssetFileDescriptor fd = assets.openFd("game/" + p)) { id = pool.load(fd, 1); } catch (Exception e) { id = -1; }
                synchronized (ids) { ids.put(p, id); }
            }
        }

        @JavascriptInterface
        public boolean play(String p, float vol, float rate) {
            Integer id;
            synchronized (ids) { id = ids.get(p); }
            if (id == null) { preload(p); return false; }
            if (id < 0) return false;
            synchronized (ready) { if (!ready.contains(id)) return false; }
            vol = Math.max(0f, Math.min(1f, vol));
            rate = Math.max(0.5f, Math.min(2f, rate));
            return pool.play(id, vol, vol, 1, 0, rate) != 0;
        }

        @JavascriptInterface
        public void unload(String csv) {
            if (csv == null) return;
            for (String p : csv.split(",")) {
                Integer id;
                synchronized (ids) { id = ids.remove(p.trim()); }
                if (id != null && id >= 0) { pool.unload(id); synchronized (ready) { ready.remove(id); } }
            }
        }

        void pauseAll() { pool.autoPause(); }
        void resumeAll() { pool.autoResume(); }
        void release() { pool.release(); }
    }

    /** vibração chamada pelo jogo: window.LupusNative.vibrate(ms, força 1-255) */
    static class Haptics {
        private final Vibrator vib;
        Haptics(Context c) { vib = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE); }
        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public void vibrate(int ms, int amp) {
            if (vib == null || !vib.hasVibrator()) return;
            ms = Math.max(5, Math.min(ms, 600)); amp = Math.max(1, Math.min(amp, 255));
            if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createOneShot(ms, amp));
            else vib.vibrate(ms);
        }
    }
}
