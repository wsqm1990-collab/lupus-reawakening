'use strict';
/* 8.4 fallback: use the authored sprite art; no procedural wrist equipment. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { createRuntime } = require('./runtime.cjs');

async function main() {
  const r = createRuntime(); await r.settle();
  const pristine = r.run('JSON.stringify(SAVE)'); let count = 0;
  console.log('TAP version 13');
  const pass = name => console.log(`ok ${++count} - ${name}`);
  async function enter(stage, skin=false, args={}) {
    r.run(`SAVE=${pristine};SAVE.music=false;SAVE.sfx=false;SAVE.skinOn={};SAVE.skins={};Inp.reset();window.__err=[]`);
    if(skin)r.run('SAVE.skins.lupus=true;SAVE.skinOn.lupus=true');
    await r.play(stage,args);r.run('G.props=[];G.enemies=[];G.title=0');
  }
  assert(!fs.readFileSync(path.join(r.root,'index.html'),'utf8').includes('js/chains9.js'));
  assert(!fs.readFileSync(path.join(r.root,'js/ui.js'),'utf8').includes('LupusChains'));
  assert.match(fs.readFileSync(path.join(r.root,'js/chains9.js'),'utf8'),/Retired in 8\.4/);
  assert.equal(r.run('typeof window.LupusChains'),'undefined');
  pass('procedural accessories are inert, unloaded and absent from the entity renderer');
  for(const face of [1,-1]){
    await enter(1);
    const result=r.json(`(() => {
      const h=G.player;h.face=${face};h.form='h';
      const make=(x,y=0)=>newE({kind:'enemy',team:'e',type:'S',def:ENEMY.S,x:h.x+h.face*x,y:h.y+y,hp:1000,maxhp:1000,hr:13,arrive:false});
      G.enemies=[make(84),make(85),make(-7),make(70,16)];const expected=Math.round(hs(h).dmg*2.2);heroSpecFire(h);
      return {hp:G.enemies.map(e=>e.hp),expected,lines:G.lines.length,slashes:G.slashes.length,key:heroKey(h)};
    })()`);
    assert.equal(result.key,'lupus_h');assert.deepEqual(result.hp,[1000-result.expected,1000,1000,1000]);assert.equal(result.lines,0);assert.equal(result.slashes,0);
    assert(r.json('[45,46].map(i=>{const f=ATLAS.lupus_h.f[i];return (f[2]-f[4])/2})').every(x=>x>=80&&x<=85));
    r.run('startSpec(G.player)');assert.equal(r.run('G.player.spCd'),5);
    pass(`modern special facing ${face>0?'right':'left'} keeps damage, matches native reach 84 and has no floating extension`);
  }
  for(const {stage,skin,name} of [{stage:0,skin:false,name:'1944 prologue'},{stage:1,skin:true,name:'1944 skin in a future stage'}])for(const face of [1,-1]){
    await enter(stage,skin);
    const result=r.json(`(() => {
      const h=G.player;h.face=${face};h.form='h';
      const make=(x,y=0)=>newE({kind:'enemy',team:'e',type:'S',def:ENEMY.S,x:h.x+x,y:h.y+y,hp:1000,maxhp:1000,hr:13,arrive:false});
      G.enemies=[make(70),make(-70),make(71),make(-71),make(0,42)];const expected=Math.round(hs(h).dmg*1.2);heroSpecFire(h);
      const hits=G.enemies.map(e=>({hp:e.hp,st:e.st,t:e.t}));startSpec(h);
      return {key:heroKey(h),pulse:humanPulse(h),hits,expected,cd:h.spCd,lines:G.lines.length,proj:G.proj.length,slashes:G.slashes.length};
    })()`);
    assert.equal(result.key,'lupus44');assert(result.pulse);assert.equal(result.cd,5);
    assert.deepEqual(result.hits.map(e=>e.hp),[1000-result.expected,1000-result.expected,1000,1000,1000]);
    assert(result.hits.slice(0,2).every(e=>e.st==='hurt'&&e.t===0.8));assert.equal(result.lines,0);assert.equal(result.proj,0);assert.equal(result.slashes,0);
    pass(`${name} facing ${face>0?'right':'left'} uses pulse 70, damage 1.2x, stun 0.8s and cooldown 5s`);
  }
  for(const [lang,label] of [['pt','URRO'],['en','ROAR']]){
    await enter(0);
    r.run(`setLang('${lang}');window.drawnLabels=[];window.originalPixelText=PIX.text;PIX.text=function(g,txt,...rest){drawnLabels.push(String(txt));return originalPixelText.call(this,g,txt,...rest)};drawHUD(bg);drawControls(bg);PIX.text=originalPixelText`);
    assert.equal(r.run('heroSpecLabel(G.player)'),label);assert(r.json('window.drawnLabels').includes(label));
    assert(r.run(`PIX.textW('${label}',1)<=BTN().spec.r*2-6`),'label exceeds button width');
    r.run(`SAVE.controls.preset='compact';SAVE.controls.buttons.spec={size:0.8,opacity:1};window.specialButtonText=[];PIX.text=function(g,txt,x,y,...rest){const b=BTN().spec;if(x===b.x&&y===b.y+8)specialButtonText.push({text:String(txt),width:PIX.textW(String(txt),1),usable:b.r*2-6});return originalPixelText.call(this,g,txt,x,y,...rest)};drawControls(bg);PIX.text=originalPixelText`);
    const buttonText=r.json('window.specialButtonText');assert(buttonText.length>0);assert(buttonText.every(t=>t.width<=t.usable),'small preset overflows special label');
    await enter(1,true,{mode:'tutorial'});
    r.run(`setLang('${lang}');G.tut.i=G.tut.steps.indexOf('spec');window.drawnLabels=[];PIX.text=function(g,txt,...rest){drawnLabels.push(String(txt));return originalPixelText.call(this,g,txt,...rest)};drawHUD(bg);drawOverlays(bg);PIX.text=originalPixelText`);
    const prompt=r.run("T('tut_spec')");assert(r.json('window.drawnLabels').some(t=>t.includes(label)&&t.includes(prompt)));
    pass(`${lang} HUD, button and tutorial use ${label} with a width-safe button label`);
  }
  for(const {stage,boss,skin} of [{stage:0,boss:'kreutz44',skin:false},{stage:1,boss:'vesp_mb',skin:true},{stage:6,boss:'echo_mb',skin:true}]){
    await enter(stage,skin);
    r.run(`G.locked=true;G.duelHold=${boss==='kreutz44'?'false':'true'};G.testBoss=${boss==='kreutz44'?"spawnBoss('kreutz44')":`spawnMini('${boss}')`};G.testBoss.bossIn=0;G.testBoss.inv=0;G.testBoss.x=G.player.x+30;G.testBoss.y=G.player.y;G.testBoss.hp=1;heroSpecFire(G.player)`);
    assert.equal(r.run('G.testBoss.dead'),false);assert(r.run('G.testBoss.fleeing>0||G.testBoss.yielding>0'));
    for(let i=0;i<300;i++){
      r.tick();if(r.run('!!(G&&G.panel)&&G.panel.t>=0.4'))r.run('panelAdvance()');
      if(boss!=='kreutz44'&&r.run('!G.duelHold&&G.mini===null'))break;
      if(boss==='kreutz44'&&r.run('G.testBoss.dead&&G.clearT>0'))break;
    }
    if(boss==='kreutz44')assert(r.run('G.testBoss.dead&&G.clearT>0'));else{assert.equal(r.run('G.duelHold'),false);assert.equal(r.run('G.mini'),null);}
    pass(`1944 pulse preserves ${boss} escape/surrender and releases progression`);
  }
  for(const stage of [0,1]){
    await enter(stage);
    for(const face of [1,-1])for(const state of ['idle','walk','dash','air','atk','spec']){
      r.run(`Object.assign(G.player,{face:${face},st:'${state}',form:'h',x:220,y:240,z:${state==='air'?35:0},vz:100,ct:0.1,t:0.26,specDur:0.55,idx:1,air:false,atkT:0.14,atkDur:0.24,landT:0.03});G.title=0`);r.tick(1,true);
    }assert.deepEqual(r.json('window.__err||[]'),[]);
  }
  pass('both native human atlases render mirrored movement, jump and combat without accessory hooks');
  console.log(`1..${count}\n# ${count} passed, 0 failed`);
}
main().catch(e=>{console.error(e.stack);process.exitCode=1});
