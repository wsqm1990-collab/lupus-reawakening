'use strict';
/* Mandatory story beats use the active game clock and the shared speech channel.
   No timeout can fire into a restarted stage or while the application is hidden. */
(function () {
  const P = Scenes.play;
  const paths = COMIC.paths = COMIC.paths || {};
  const art = { cs90_nacht_before: 'nacht_before', cs90_nacht_after: 'nacht_after', cs90_glove: 'glove', cs90_act2: 'act2' };
  for (const key in art) {
    paths[key] = 'assets/comic/' + key + '.webp';
    COMIC_LIST.add(key);
  }
  STAGE_PANELS[5] = [...new Set((STAGE_PANELS[5] || []).concat(['cs90_nacht_before', 'cs90_nacht_after']))];
  const expected = key => {
    const rows = /^pt/i.test(SAVE.lang || '') ? window.LUPUS_DIALOGUE : window.LUPUS_DIALOGUE_EN;
    return Math.max(0, Number(rows && rows[key] && rows[key].duration) || 0);
  };
  const reading = key => Math.max(2, 1.8 + CT(key).length * 0.055, expected(key) + 0.35);
  const speaking = () => !!(window.Dialogue9 && Dialogue9.busy());
  const firstFlee = () => !!(G && !G.mode && G.stage === 0 && G.boss && G.boss.type === 'kreutz44' && G.boss.fleeing);
  const exitKey = key => key === 'r01h' || key === 'r01f';
  function exitPending() {
    if (!G) return false;
    const active = window.Dialogue9 && Dialogue9.state.active;
    return (G.talkQ || []).some(q => exitKey(q.k)) || !!(active && exitKey(active.key) && speaking());
  }
  function settleActors() {
    for (const h of G.heroes || []) {
      if (h.dead) continue;
      h.vx = h.vy = h.vz = 0; h.z = 0; h.queued = false; h.atkT = h.chainT = 0;
      h.formPress = null; h._trail = []; h._xf = null; h.air = false;
      h.inv = Math.max(h.inv || 0, 0.75); setSt(h, 'idle');
    }
    Inp.reset();
  }
  function keepNacht(b) {
    const e = b.e;
    e.hp = b.hp; e.dead = false; e.deadT = 0; e.inv = 99; e.duelBeat = true;
    e.bleedT = e.bleedD = 0; e.vx = e.vy = e.vz = 0; e.z = 0;
    e.guard = e.charging = e.windup = false; e.pat = null; e.fade = 1;
  }
  function beginNacht(e) {
    const run = G;
    e._nachtStory90 = true;
    const b = run.nachtBeat90 = { e, run, hp: e.maxhp * 0.5, phase: 'wait', t: 0, swaps: 0, panels: 0 };
    keepNacht(b); run.hitstop = 0;
    // A super already in flight finishes its own actor cleanup. The protected
    // boss cannot take another hit or skip the threshold in those remaining frames.
    if (window.Flood90 && Flood90.pause) Flood90.pause();
    return b;
  }
  function resumeNacht(b) {
    if (G !== b.run || G.nachtBeat90 !== b) return;
    const e = b.e;
    keepNacht(b); e.duelBeat = false; e.inv = 0.65; e.p2 = true; e.morph = 0;
    e.key = e.def.big || 'nacht_big';
    e.def = Object.assign({}, e.def, { pats: e.def.pats2 || e.def.pats, reach: 64 });
    e.hr = 26; e.pi = 0; e.cd = 0.85; e.frame = 'idle'; e.ct = 0; e.windup = false;
    settleActors();
    G.nachtBeat90 = null; G.hitstop = 0; G.slow = 1; G.flashScr = 0; G.shake = 0;
    if (window.Flood90 && Flood90.resume) Flood90.resume({ rearm: true });
    else { G.hz = []; G.hzT = Math.max(G.hzT || 0, 1.4); }
  }
  function panelNacht(b, phase) {
    if (G !== b.run || G.nachtBeat90 !== b) return;
    b.phase = phase; b.t = 0; b.panels++;
    const before = phase === 'before';
    showPanel(before ? 'cs90_nacht_before' : 'cs90_nacht_after', [{ t: 'say', spk: 'nacht', k: before ? 'n05a' : 'n05b' }], () => {
      if (G !== b.run || G.nachtBeat90 !== b || Scene.cur !== P) return;
      if (before) {
        b.phase = 'morph'; b.t = 0;
        b.e.p2 = true; b.e.morph = b.e.morphDur = 1.9; b.e.frame = 'spec'; b.e.ct = 0;
        sfx('transform'); G.flashScr = 0.16;
      } else resumeNacht(b);
    });
    G.panel._cinema90 = b;
  }
  const oldHold = window.holdBossExit;
  window.holdBossExit = function (e) {
    if (G && G.nachtBeat90 && G.nachtBeat90.e === e) { keepNacht(G.nachtBeat90); return true; }
    if (G && !G.mode && G.stage === 4 && e && e.kind === 'boss' && e.type === 'nacht' && !e._nachtStory90 && !e.p2 && e.bossIn <= 0 && e.hp <= e.maxhp * 0.5) {
      beginNacht(e); return true;
    }
    return oldHold.apply(this, arguments);
  };
  const oldHurt = window.hurt;
  window.hurt = function () {
    if (G && G.nachtBeat90) return false;
    return oldHurt.apply(this, arguments);
  };
  const oldFinish = P.finish;
  P.finish = function () {
    if (firstFlee() && !G._flee90Done) {
      if (!G.fleeWait90) G.fleeWait90 = { run: G, t: 0, quiet: 0, fade: null, limit: reading('r01h') + reading('r01f') + 12 };
      return;
    }
    return oldFinish.apply(this, arguments);
  };
  const oldFade = window.bossClearFade;
  window.bossClearFade = function () {
    if (firstFlee() && !G._flee90Done) {
      const b = G.fleeWait90;
      return b && b.fade != null ? Math.min(0.85, b.fade / 0.7 * 0.85) : 0;
    }
    return oldFade.apply(this, arguments);
  };
  function tickFlee(dt) {
    const b = G.fleeWait90;
    if (!b || b.run !== G) return;
    G.time += dt; G.shake *= Math.exp(-10 * dt); G.flashScr = Math.max(0, G.flashScr - dt * 1.6);
    Inp.reset(); talkStep(dt); fxStep(dt); b.t += dt;
    if (b.fade == null) {
      if (exitPending() && b.t < b.limit) { b.quiet = 0; return; }
      if (b.t >= b.limit && exitPending()) {
        // A failed native completion callback must not trap the player forever.
        // This bounded clock is frozen by pause/background and targets only this exit.
        const a = window.Dialogue9 && Dialogue9.state.active;
        if (a && exitKey(a.key)) Dialogue9.stop();
        G.talkQ = (G.talkQ || []).filter(q => !exitKey(q.k));
      }
      b.quiet += dt; if (b.quiet >= 0.25) b.fade = 0;
      return;
    }
    b.fade += dt;
    if (b.fade >= 0.7) {
      G._flee90Done = true; G.fleeWait90 = null;
      oldFinish.call(P);
    }
  }
  function tickMorph(b, dt) {
    keepNacht(b); settleActors();
    G.time += dt; b.t += dt; b.e.ct += dt; b.e.morph = Math.max(0, 1.9 - b.t);
    G.flashScr = Math.max(0, G.flashScr - dt * 1.2); G.shake *= Math.exp(-8 * dt);
    if (Math.random() < dt * 15) sparks(b.e.x, b.e.y, rnd(30, 70), 2, '#a7ff1a');
    if (b.t >= 0.95 && !b.swaps) {
      b.swaps = 1; b.e.key = b.e.def.big || 'nacht_big'; b.e.hr = 26; b.e.frame = 'idle'; b.e.ct = 0;
      ringFx(b.e.x, b.e.y, 24, 110, '#a7ff1a', 0.65); sfx('roar'); G.shake = 3; G.flashScr = 0.2;
    }
    fxStep(dt);
    if (b.t >= 1.9) panelNacht(b, 'after');
  }
  const oldUpdate = P.update;
  P.update = function (dt) {
    if (!G || Scene.cur !== this) return oldUpdate.apply(this, arguments);
    const b = G.nachtBeat90;
    if ((b || G.fleeWait90 || firstFlee()) && document.hidden) { Inp.reset(); return; }
    if (this.menu || PORTRAIT) return oldUpdate.apply(this, arguments);
    if (b) {
      if (b.phase === 'wait') {
        keepNacht(b);
        if (G.superFx || G.cine) return oldUpdate.apply(this, arguments);
        // Finish an already-started tag-out before the world freezes. Otherwise
        // the super's departing partner would hang in the air behind the morph.
        if (G.leaving && G.leaving.length) {
          G.time += dt; Inp.reset(); updLeaving(dt); fxStep(dt); return;
        }
        G.proj = []; G.hz = []; G.hitstop = 0; G.flashScr = 0; G.shake = 0;
        settleActors(); panelNacht(b, 'before'); return;
      }
      if (b.phase === 'morph') { tickMorph(b, dt); return; }
      if (b.phase === 'before' || b.phase === 'after') {
        const result = oldUpdate.apply(this, arguments);
        if (G === b.run && G.panel && G.panel._cinema90 === b && SAVE.comicAuto) {
          const line = G.panel.beats[G.panel.i], required = reading(line.k);
          if (G.panel.t >= required && (!speaking() || G.panel.t >= required + 8)) {
            if (speaking() && G.panel.t >= required + 8 && window.Dialogue9) Dialogue9.stop();
            panelAdvance();
          }
        }
        return result;
      }
    }
    if (G.fleeWait90) { tickFlee(dt); return; }
    return oldUpdate.apply(this, arguments);
  };
  function replayInterrupted() {
    if (!G) return;
    if (firstFlee()) {
      let replay = false;
      for (const line of G.talkQ || []) if (exitKey(line.k) && line._speechStarted) { line._speechStarted = false; line.t = 0; replay = true; }
      if (replay && G.fleeWait90) { G.fleeWait90.t = 0; G.fleeWait90.quiet = 0; G.fleeWait90.fade = null; }
    }
    if (G.nachtBeat90 && G.panel && G.panel._cinema90 === G.nachtBeat90) G.panel.t = 0;
  }
  document.addEventListener('visibilitychange', () => { if (document.hidden) replayInterrupted(); });
  window.addEventListener('lupus:pause', replayInterrupted);
  window.Cinema90 = { exitPending, active: () => !!(G && (G.nachtBeat90 || G.fleeWait90)), art };
})();
