'use strict';
const assert = require('node:assert/strict');
const { createRuntime } = require('./runtime.cjs');

/* Narrative contracts for the 8.6 opening. These tests check the sequence the
 * player actually receives and its authored text. Visual continuity of cuffs,
 * chains, people and locations must also be reviewed in the illustrations.
 */
async function main() {
  const r = createRuntime();
  await r.settle();
  const tests = [], results = [];
  const test = (name, fn) => tests.push({ name, fn });
  const images = id => r.json(`COMIC.pages(${JSON.stringify(id)}).flatMap(pg=>pg.map(p=>p.img))`);

  test('the opening introduces restraints before injection and releases them before gameplay', () => {
    const intro = images('intro');
    for (const id of ['cs39', 'cs83', 'cs78', 'cs40', 'cs84']) assert.equal(intro.filter(k=>k===id).length,1,`${id} must occur once in the opening`);
    assert.ok(intro.indexOf('cs39')<intro.indexOf('cs83'),'chair confinement must precede the explanation of the experimental chains');
    assert.ok(intro.indexOf('cs83')<intro.indexOf('cs78'),'the restraints must be introduced before the injection');
    assert.ok(intro.indexOf('cs78')<intro.indexOf('cs40'),'the cell scene must follow the experiment');
    assert.ok(intro.indexOf('cs40')<intro.indexOf('cs84'),'the chained cell must precede the breakout');
    assert.equal(intro.at(-1),'cs84','the breakout must be the last illustration before the playable escape');
  });
  test('the breakout text describes cell-wall chains in English and Portuguese', () => {
    const en=r.run('I18N.en.comic.ch02b'),pt=r.run('I18N.pt.comic.ch02b');
    assert.match(en,/\bcell wall\b/i);
    assert.doesNotMatch(en,/\bchair\b/i);
    assert.match(pt,/parede da cela/i);
    assert.doesNotMatch(pt,/cadeira/i);
    const breakout=r.json("COMIC.pages('intro').flat().find(p=>p.img==='cs84')");
    assert.ok(breakout.beats.some(b=>b.k==='ch02a' && b.t==='say' && b.spk==='lupus44'),'the breakout vow must still be spoken by John');
    assert.doesNotMatch(r.run('I18N.en.comic.ch02a'),/obey/i,'the breakout vow still describes obedience');
    assert.doesNotMatch(r.run('I18N.pt.comic.ch02a'),/obede[cç]/i,'the Portuguese breakout vow still describes obedience');
    assert.match(r.run('I18N.en.comic.ch01a'),/obey/i,'the earlier narrator caption was changed with the breakout vow');
    assert.match(r.run('I18N.pt.comic.ch01a'),/obede[cç]/i,'the earlier Portuguese narrator caption was changed with the breakout vow');
    assert.ok(r.run("I18N.en.comic.ch01b && I18N.pt.comic.ch01b"),'the neural-restraint explanation disappeared');
    assert.ok(r.run("I18N.en.comic.ch03a && I18N.pt.comic.ch03a"),'the present-day use of the chains disappeared');
  });
  test('after the playable escape the story proceeds to the burning lab and then 2242', () => {
    const after=images('s1post');
    assert.ok(!after.includes('cs84'),'the post-stage story jumps back to the moment of breaking the restraints');
    assert.ok(after.indexOf('cs41')>=0 && after.indexOf('cs41')<after.indexOf('cs05'),'the burning laboratory must precede the time jump');
    assert.match(r.run('I18N.en.comic.p01c'),/2242/);
  });
  test('the opening preserves John Thorne, Thule and the stated timeline', () => {
    assert.match(r.run('I18N.en.comic.i01a'),/1944/);
    assert.doesNotMatch(r.run('I18N.en.comic.ch01a'),/1944/,'the restraint caption repeats the year already established by the opening');
    assert.doesNotMatch(r.run('I18N.pt.comic.ch01a'),/1944/,'the Portuguese restraint caption repeats the opening year');
    assert.match(r.run('I18N.en.comic.i01b'),/JOHN THORNE/i);
    assert.match(r.run('SPK_NAME.lupus44'),/JOHN THORNE/i);
    assert.match(r.run('SPK_NAME.thule44'),/ALBRECHT THULE/i);
    assert.equal(r.run('window.LUPUS_STORY_VERSION'),'8.6');
  });
  test('a fresh game opens in English while an explicitly saved language is preserved', async () => {
    assert.equal(r.run('SAVE.lang'),'en');
    const saved=createRuntime({storage:{lupus_reawakening_v2:JSON.stringify({lang:'pt',langV5:true,langSet:true,v8:true,unlocked:1,hero:'lupus',ally:'vespera'})}});
    await saved.settle();
    assert.equal(saved.run('SAVE.lang'),'pt','the primary language default should not overwrite a player choice');
  });
  test('the first-launch comic reaches stage one only after showing the cell breakout', async () => {
    r.run("SAVE.music=false; SAVE.sfx=false; SAVE.seenIntro=false; SAVE.tutDone=true; Scene.go('select',{stage:0})");
    const shown=[];
    for(let frame=0;frame<6000;frame++) {
      await r.settle();
      const scene=r.run('Scene.name');
      if(scene==='play')break;
      if(scene==='comic' && r.run('!!Scenes.comic.pages')) {
        const image=r.run("Scenes.comic.pg && Scenes.comic.pg[Scenes.comic.ci] && Scenes.comic.pg[Scenes.comic.ci].img");
        if(image && shown.at(-1)!==image)shown.push(image);
        r.run("if(Scenes.comic.mode!=='panel'||Scenes.comic.bt>=.35)Scenes.comic.onKey('ok')");
      }
      r.tick();
    }
    assert.equal(r.run('Scene.name'),'play','the first launch did not reach gameplay');
    assert.equal(r.run('G.stage'),0);
    assert.deepEqual(shown,images('intro'),'the first launch skipped or reordered a story illustration');
    assert.equal(shown.at(-1),'cs84');
    assert.deepEqual(r.json('window.__err||[]'),[]);
  });

  console.log('TAP version 13');
  for(const t of tests) {
    try {await t.fn();results.push({name:t.name,pass:true});console.log(`ok ${results.length} - ${t.name}`);}
    catch(e){results.push({name:t.name,pass:false,message:e.message});console.log(`not ok ${results.length} - ${t.name}\n  ---\n  message: ${JSON.stringify(e.message)}\n  ...`);}
  }
  console.log(`1..${results.length}`);
  console.log(`# ${results.filter(t=>t.pass).length} passed, ${results.filter(t=>!t.pass).length} failed`);
  if(results.some(t=>!t.pass))process.exitCode=1;
}
main().catch(e=>{console.error(e.stack);process.exitCode=1;});
