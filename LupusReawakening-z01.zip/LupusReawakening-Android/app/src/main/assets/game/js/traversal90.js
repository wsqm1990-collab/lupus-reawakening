'use strict';
/* Rooftop detours use authored tiles, real support planes and the same input
 * snapshot as combat. The street remains open underneath every route. */
(function () {
  const EPS = 0.55, LANE = () => LANE_T + 14;
  const art = key => window.Q90 ? Q90.image(key) : null;
  const text = (pt, en) => window.Q90 ? Q90.t(pt, en) : /^pt/.test(SAVE.lang || '') ? pt : en;
  function enabled() {
    return !!(G && G.stage === 2 && G.mech === 'chase' && !G.mode && !G.bossPending && !G.bossSpawned &&
      !(G.duel90 && G.duel90.active));
  }
  function state() { return enabled() ? G.roof90 : null; }
  function blocked() {
    return !enabled() || G.panel || G.choice || G.cine || G.superFx || G.nachtBeat90 || G.vesperaBeat ||
      G.over > 0 || G.clearT > 0 || G.title > 0 || Scenes.play.menu || document.hidden;
  }
  function records() {
    const old = SAVE.roofRecords90;
    if (!old || old.version !== 1 || !old.orbs || !old.intercepts) SAVE.roofRecords90 = { version: 1, orbs: {}, intercepts: {} };
    return SAVE.roofRecords90;
  }
  function makeRoute(id, starts, heights) {
    const surfaces = starts.map((x, i) => ({ id: id + '-' + i, route: id, x, y: LANE(), z: heights[i], w: 104, depth: 14, grapple: i === starts.length - 1 }));
    const last = surfaces[surfaces.length - 1];
    return { id, surfaces, left: starts[0] - 52, right: last.x + 52, anchor: { x: last.x, y: last.y, z: last.z + 44, surface: last },
      orb: { x: last.x + 12, y: last.y, z: last.z, got: !!records().orbs[id] }, seen: false, hinted: false, intercepted: !!records().intercepts[id] };
  }
  function init() {
    if (!G || G.stage !== 2 || G.mode) return;
    const routes = [makeRoute('west-roof', [650, 730, 810], [18, 36, 36]),
      makeRoute('chapel-roof', [1290, 1370, 1450], [18, 36, 48]),
      makeRoute('east-roof', [2510, 2590, 2670], [18, 36, 48])];
    G.roof90 = { routes, surfaces: routes.flatMap(r => r.surfaces), input: null, grapple: null, route: null };
    G.mvPlats = G.roof90.surfaces;
    G.mvGrappleFx = null;
    ['roof_module', 'roof_anchor', 'chain_link'].forEach(art);
  }
  function inside(f, s, margin = 0) { return Math.abs(f.x - s.x) <= s.w / 2 - 5 + margin && Math.abs(f.y - s.y) <= s.depth + margin; }
  function support(f) {
    const S = state();
    if (!S || !f || f.kind !== 'hero' || f.dead || !f._surface90) return null;
    const s = S.surfaces.find(s => s.id === f._surface90);
    if (!s || !inside(f, s, 1) || f.z < s.z - EPS) { f._surface90 = null; return null; }
    return s;
  }
  function floor(f) { const s = support(f); return s ? s.z : 0; }
  function detach(f) {
    if (!f) return;
    f._surface90 = null; f._grapple90 = null;
    if (G && G.mvGrappleFx && G.mvGrappleFx.hero === f) G.mvGrappleFx = null;
  }
  function grounded(f) { return !!f && Math.abs(f.z - floor(f)) <= EPS && f.vz === 0; }
  function airborne(f) { return !!f && f.z > floor(f) + EPS; }
  function stepLanding(f, previousZ) {
    const S = state();
    if (!S || !f || f.kind !== 'hero' || f.dead || f.vz > 0) return;
    let best = null;
    for (const s of S.surfaces) if (inside(f, s) && previousZ >= s.z - EPS && f.z <= s.z + EPS && (!best || s.z > best.z)) best = s;
    if (best) { f._surface90 = best.id; f.z = best.z; }
  }
  function consumeInput(c) { const S = state(); if (S) S.input = c; }
  function nearestAnchor(f) {
    const S = state(); if (!S || !f) return null;
    let best = null;
    for (const r of S.routes) {
      const a = r.anchor, dx = Math.abs(f.x - a.x);
      if (dx > 105 || Math.abs(f.y - a.y) > 19 || a.x < G.camX + 16 || a.x > G.camX + VW - 98) continue;
      if (!best || dx < Math.abs(f.x - best.anchor.x)) best = r;
    }
    return best;
  }
  function beginGrapple(h, route) {
    const a = route.anchor;
    h._grapple90 = { route: route.id, from: { x: h.x, y: h.y, z: h.z }, target: a.surface, t: 0, dur: 0.42 };
    h._surface90 = null; h._grappleCd = G.time; h.vx = h.vy = 0; h.vz = 0; h.air = true; setSt(h, 'air');
    route.hinted = true;
    G.mvGrappleFx = { hero: h, anchor: a, t: 0.42 };
    sfx('dash');
  }
  function stepHero(h, dt) {
    const p = h && h._grapple90;
    if (!p) return false;
    if (blocked() || h !== G.player || h.dead || !['air', 'walk', 'idle'].includes(h.st)) {
      h._grapple90 = null; if (G) G.mvGrappleFx = null; return false;
    }
    const beforeX = h.x, beforeZ = h.z;
    p.t += dt; const u = Math.min(1, p.t / p.dur), k = u * u * (3 - 2 * u);
    h.x = lerp(p.from.x, p.target.x, k); h.y = lerp(p.from.y, p.target.y, k);
    h.z = lerp(p.from.z, p.target.z, k) + Math.sin(u * Math.PI) * 34;
    h.vx = (h.x - beforeX) / Math.max(0.0001, dt); h.vy = 0; h.vz = (h.z - beforeZ) / Math.max(0.0001, dt);
    setSt(h, 'air'); h.air = true;
    if (G.mvGrappleFx) G.mvGrappleFx.t = Math.max(0, p.dur - p.t);
    if (u >= 1) {
      h._surface90 = p.target.id; h.z = p.target.z; h.vx = h.vy = h.vz = 0; h.air = false;
      h._grapple90 = null; G.mvGrappleFx = null; setSt(h, 'idle'); sfx('land');
    }
    bounds(h); return true;
  }
  function claim(route, h) {
    if (route.orb.got || records().orbs[route.id]) return;
    route.orb.got = true; records().orbs[route.id] = 1;
    if (h.id === 'lupus') h.fury = Math.min(300, (h.fury || 0) + 45); else h.spCd = Math.max(0, h.spCd - 3);
    h.hp = Math.min(h.maxhp, h.hp + 25); G.score += 300;
    sfx('pick');
    textFx(h.x, h.y - h.z - 76, text('ESCONDERIJO DO MENSAGEIRO', 'COURIER CACHE'), '#3af0ff', 1);
    if (route.id === 'east-roof' && window.World90 && typeof World90.unlockShortcut === 'function') {
      World90.unlockShortcut('rooftop-courier', { stage: 2, entry: 'roof-east', fromWave: 4 });
    }
    saveGame();
  }
  function update(dt) {
    const S = state(); if (!S || blocked()) return;
    const h = G.player, c = S.input || {};
    if (!h || h.dead) return;
    const route = nearestAnchor(h);
    if ((c.jump || c.spec) && route && airborne(h) && h.z - floor(h) > 10 && !h._grapple90 &&
      ['air', 'walk', 'idle'].includes(h.st) && (h._grappleCd == null || G.time - h._grappleCd > 0.85)) {
      c.jump = false; c.spec = false; beginGrapple(h, route);
    }
    for (const r of S.routes) {
      if (!r.seen && !G.locked && h.x > r.left - 58 && h.x < r.right) {
        r.seen = true;
        const courier = G.courier;
        if (courier && !courier.gone) {
          courier.offscreen = false; courier.state = 'taunt'; courier.tauntT = 0.7; courier.trail = [];
          courier.x = clamp(h.x + 118, G.camX + 100, WORLD_W - 80); courier.y = r.anchor.y;
        }
      }
      if (!r.orb.got && Math.abs(h.x - r.orb.x) < 23 && Math.abs(h.y - r.orb.y) < 17 && Math.abs(h.z - r.orb.z) < 15) claim(r, h);
      const courier = G.courier;
      if (!r.intercepted && courier && !courier.offscreen && courier.state === 'flee' &&
        h.x > r.left && h.x < r.right + 60 && h.z > 16 && Math.abs(h.x - courier.x) < 50 && Math.abs(h.y - courier.y) < 20) {
        r.intercepted = true; records().intercepts[r.id] = 1; G.score += 500;
        textFx(h.x, h.y - h.z - 90, text('MENSAGEIRO ALCANÇADO! +500', 'COURIER INTERCEPTED! +500'), '#ffd23a', 1);
        courier._burst90 = G.time + 0.55; courier.state = 'flee'; sfx('dash'); saveGame();
      }
    }
  }
  function courierSpeed(c, fallback) {
    if (!enabled() || G.locked || !G.player) return fallback;
    if (c && c._burst90 > G.time) return Math.max(fallback, 330);
    return support(G.player) || G.player._grapple90 ? Math.min(fallback, 105) : fallback;
  }
  function hint() {
    if (blocked()) return null;
    const h = G.player, r = nearestAnchor(h);
    if (!r || r.hinted || h._grapple90 || h.dead || h.z > r.anchor.surface.z + 8) return null;
    return { ready: true, x: r.anchor.x, y: r.anchor.y - r.anchor.z - 16,
      text: text('PULE E TOQUE PULAR NO AR', 'JUMP, THEN TAP JUMP IN AIR') };
  }
  function drawBack(g, cam) {
    const S = state(); if (!S) return;
    const tile = art('roof_module'), anchor = art('roof_anchor'), link = art('chain_link');
    g.save(); g.imageSmoothingEnabled = false;
    for (const r of S.routes) {
      for (const s of r.surfaces) {
        if (s.x - cam < -70 || s.x - cam > VW + 70) continue;
        // Align the physical floor to the authored deck, after its transparent top margin.
        if (tile && tile.ok) g.drawImage(tile, Math.round(s.x - cam - 52), Math.round(s.y - s.z - 233 / 1044 * 72), 104, 72);
      }
      const a = r.anchor;
      // The chain attaches through the ring opening rather than through the gargoyle's face.
      if (anchor && anchor.ok && a.x - cam > -40 && a.x - cam < VW + 40) g.drawImage(anchor, Math.round(a.x - cam - 674.3 / 1349 * 44), Math.round(a.y - a.z - 837.9 / 1166 * 38), 44, 38);
      if (!r.orb.got && r.orb.x - cam > -30 && r.orb.x - cam < VW + 30) {
        ART.item(g, 'orb', r.orb.x - cam, r.orb.y - r.orb.z - 9 - Math.sin(G.time * 4) * 2, { sc: 0.6 });
      }
    }
    const fx = G.mvGrappleFx;
    if (fx && fx.hero && fx.hero._grapple90 && link && link.ok) {
      const h = fx.hero, x0 = h.x + h.face * 11 - cam, y0 = h.y - h.z - 27;
      const x1 = fx.anchor.x - cam, y1 = fx.anchor.y - fx.anchor.z;
      const dx = x1 - x0, dy = y1 - y0, len = Math.hypot(dx, dy), angle = Math.atan2(dy, dx) - Math.PI / 2;
      const n = Math.max(1, Math.ceil(len / 7));
      for (let i = 0; i < n; i++) {
        const t = (i + 0.5) / n; g.save(); g.translate(x0 + dx * t, y0 + dy * t); g.rotate(angle);
        g.drawImage(link, -2.5, -4.5, 5, 9); g.restore();
      }
    }
    g.restore();
  }
  function checkpoint(opt) {
    if (!enabled()) return;
    if (!G.roof90) init();
    for (const h of G.team) { h._surface90 = null; h._grapple90 = null; }
    for (const r of G.roof90.routes) { r.orb.got = !!records().orbs[r.id]; if (r.right < G.player.x - 40) r.seen = true; }
  }
  function enterShortcut(entry) {
    if (entry !== 'roof-east' || !enabled() || G.waveIdx < 4 || G.locked || blocked()) return false;
    const h = G.player; h.x = 2460; h.y = LANE(); h.z = h.vx = h.vy = h.vz = 0; h._surface90 = h._grapple90 = null;
    G.camX = clamp(h.x - VW * 0.38, 0, WORLD_W - VW); setSt(h, 'idle'); return true;
  }
  window.Traversal90 = { init, checkpoint, enabled, consumeInput, floor, floorY: floor, detach, grounded, airborne, stepLanding, stepHero, update, courierSpeed, hint, drawBack, enterShortcut,
    snapshot() { return state() ? { routes: G.roof90.routes.map(r => ({ id: r.id, left: r.left, right: r.right, orb: r.orb.got, intercepted: r.intercepted })), support: G.player._surface90 || null, grappling: !!G.player._grapple90 } : null; } };
})();
