'use strict';
/* =====================================================================
   v8.1 — fixes from the first phone test
   - sound on time: inside the APK every short sound (effects, voices,
     stingers, comic one-shots) plays through Android's native low-latency
     player (SoundPool, window.LupusAudio). WebView audio stays only for
     music and ambience loops, where a few ms do not matter.
   - clues that can always be found (visible glint, walk over to pick up,
     the camera can go back, an arrow points to the missing one)
   - a block that reads as a block (energy shield + guard sound)
   - the player is marked on the floor; boss fights dim the scenery
   - John in 1944: olive uniform in the feral form, no rifle in his combo
   - Vespera's truce is now a real cutscene
   - automatic low-quality mode when the phone cannot hold the frame rate
   ===================================================================== */

/* ---------- guard pose: frame 26 (arms up in front) reads as a block; frame 41 looked like an idle/attack ---------- */
['lupus_h', 'lupus_f', 'lupus_a'].forEach(k => { const A = window.ATLAS[k]; if (A && A.a.atk1 && A.f[26] && !A.v96) A.a.guard = [26]; });   /* 9.6 sheets carry their own guard frame */
/* ---------- 1944 look ---------- */
if (window.ATLAS.lupus_f && !window.ATLAS.lupus44_f) window.ATLAS.lupus44_f = Object.assign({}, window.ATLAS.lupus_f);
FACE_ALIAS.lupus44_f = 'lupus_f';
/* the 1944 sheet's second hit swung a rifle he never picked up: it is now a straight punch (9.7: the 1944 forms
   drawn frame by frame have their own right cross) */
if (window.ATLAS.lupus44 && !window.ATLAS.lupus44.v96) window.ATLAS.lupus44.a = Object.assign({}, window.ATLAS.lupus44.a, { atk2: [26, 23, 24, 25, 22] });

/* ---------- native audio ---------- */
const NAT = { on: !!(window.LupusAudio && window.LupusAudio.play), req: new Set(), keep: new Set() };
const SFXN = new Set(['hit', 'hit2', 'slash', 'jump', 'land', 'dash', 'hurt', 'shot', 'special', 'howl', 'transform', 'pick', 'boom', 'die', 'ui', 'ok', 'roar', 'heal', 'sting', 'stingBoss', 'heart', 'impact', 'alarm', 'guard']);
const VOX_FILES = new Set(["beast_defeat", "beast_intro", "brann_assist", "brann_atk1", "brann_atk2", "brann_duo", "brann_hurt", "brann_john", "brann_ko", "brann_special", "brann_tagin", "brann_victory", "construct_intro", "construct_ko", "echo_assist", "echo_atk1", "echo_atk2", "echo_duo", "echo_hurt", "echo_john", "echo_ko", "echo_special", "echo_tagin", "echo_victory", "fenrir_atk", "fenrir_hurt", "fenrir_special", "fenrir_transform", "fenrir_victory", "firstwolf_defeat", "firstwolf_intro", "kane_defeat", "kane_intro", "kreutz44_defeat", "kreutz44_intro", "kreutz44_line", "kreutz_defeat", "kreutz_intro", "leviathan_defeat", "leviathan_giant_roar", "leviathan_intro", "lupus44_atk1", "lupus44_atk2", "lupus44_hurt", "lupus44_ko", "lupus44_line1", "lupus44_line2", "lupus44_special", "lupus_assist", "lupus_atk1", "lupus_atk2", "lupus_hurt", "lupus_ko", "lupus_line_final", "lupus_line_rage", "lupus_line_remember", "lupus_senses", "lupus_special", "lupus_super", "lupus_tagin", "lupus_transform", "lupus_victory", "malakor_assist", "malakor_atk1", "malakor_atk2", "malakor_duo", "malakor_hurt", "malakor_john", "malakor_ko", "malakor_special", "malakor_tagin", "malakor_victory", "morrigan_defeat", "morrigan_intro", "nacht_defeat", "nacht_intro", "narrator_act2", "narrator_act3", "narrator_end", "narrator_open", "nereus_line1", "nereus_line2", "nereus_roar", "prime_defeat", "prime_intro", "soldier_alert", "soldier_ko", "thule_laugh", "thule_line1", "thule_line2", "thule_line3", "thule_reveal", "triton_assist", "triton_atk1", "triton_atk2", "triton_duo", "triton_hurt", "triton_john", "triton_ko", "triton_special", "triton_tagin", "triton_victory", "vespera_assist", "vespera_atk1", "vespera_atk2", "vespera_duo", "vespera_hurt", "vespera_john", "vespera_ko", "vespera_special", "vespera_tagin", "vespera_victory", "voss_defeat", "voss_intro", "warden_defeat", "warden_intro"]);
const STINGS = ['sting_boss', 'sting_clear', 'sting_duo', 'sting_fenrir', 'sting_impact', 'sting_reveal', 'sting_transform', 'sting_wave'];
const pSfx = n => 'assets/sfxn/' + n + '.ogg', pVox = n => 'assets/voice/' + n + '.ogg', pSnd = n => 'assets/sfx/' + n + '.ogg', pSting = n => 'assets/music/' + n + '.ogg';
function natPre(paths, keep) {
  if (!NAT.on) return; const want = [];
  for (const p of paths) { if (keep) NAT.keep.add(p); if (!NAT.req.has(p)) { NAT.req.add(p); want.push(p); } }
  if (want.length) try { window.LupusAudio.preload(want.join(',')); } catch (e) { }
}
/* free the voices and one-shots the next scene does not use (effects and stingers stay loaded) */
function natOnly(paths) {
  if (!NAT.on) return; const need = new Set(paths), drop = [];
  for (const p of NAT.req) if (!NAT.keep.has(p) && !need.has(p)) drop.push(p);
  drop.forEach(p => NAT.req.delete(p));
  if (drop.length) try { window.LupusAudio.unload(drop.join(',')); } catch (e) { }
  natPre(paths);
}
function natPlay(path, vol, rate) {
  if (!NAT.on) return false;
  if (!NAT.req.has(path)) { natPre([path]); return false; }
  try { return !!window.LupusAudio.play(path, vol, rate || 1); } catch (e) { return false; }
}
if (NAT.on) natPre([...SFXN].map(pSfx).concat(STINGS.map(pSting)), true);

/* v8.1: a short shimmer when the guard goes up */
SFX.guard = function () { tone(300, 0.09, 'triangle', 0.13, 220); noise(0.07, 0.16, 5200, null, null, 'highpass'); };
const _sfx0 = window.sfx;
window.sfx = function (n) {
  if (!SAVE.sfx) return;
  if (NAT.on && SFXN.has(n)) { const r = (n === 'hit' || n === 'hit2' || n === 'slash') ? 0.94 + Math.random() * 0.12 : 1; if (natPlay(pSfx(n), 1, r)) return; }
  _sfx0(n);
};
const _voice0 = window.voice;
window.voice = function (n, gap) {
  if (!n || !SAVE.sfx || VOX.ok[n] === false) return;
  if (NAT.on && VOX_FILES.has(n)) {
    const now = performance.now(), who = n.split('_')[0];
    if (now - (VOX.last[who] || -1e9) < (gap || 900)) return;
    if (natPlay(pVox(n), 0.9)) { VOX.last[who] = now; return; }
  }
  _voice0(n, gap);
};
const _sting0 = window.playSting;
window.playSting = function (n) { if (!SAVE.music) return; if (NAT.on && STINGS.includes(n) && natPlay(pSting(n), 0.8)) return; _sting0(n); };
const _story0 = window.storySnd;
window.storySnd = function (n) { if (!n || !SAVE.sfx) return; if (NAT.on && SFX_FILES.has(n) && !n.startsWith('amb_') && natPlay(pSnd(n), 0.65)) return; _story0(n); };

/* what each scene will need, loaded ahead of time */
(function () {
  const C = Scenes.comic, pre = C.preSnd;
  C.preSnd = function () {
    if (NAT.on) { const L = []; for (const pg of this.pg0) for (const p of pg) for (const b of p.beats) { if (b.vo && VOX_FILES.has(b.vo)) L.push(pVox(b.vo)); if (b.snd && SFX_FILES.has(b.snd)) L.push(pSnd(b.snd)); } natOnly(L); }
    return pre.call(this);
  };
  const P = Scenes.play, enter = P.enter;
  P.enter = function (arg) {
    const r = enter.apply(this, arguments);
    if (NAT.on && G) {
      const L = [], add = n => VOX_FILES.has(n) && L.push(pVox(n));
      const ids = new Set(G.team.map(h => h.id)); if (G.st && G.st.id === 2) ids.add('vespera');
      for (const id of ids) {
        const sets = id === 'lupus' ? ['lupus', 'lupus44', 'fenrir'] : [id];
        for (const s of sets) ['atk', 'atk1', 'atk2', 'hurt', 'ko', 'special', 'tagin', 'assist', 'victory', 'transform', 'super', 'senses', 'john', 'duo', 'line1', 'line2', 'line_rage', 'line_final', 'line_remember'].forEach(l => add(s + '_' + l));
      }
      const B = G.st && BOSS[G.st.boss]; if (B) { const v = B.vox || G.st.boss; add(v + '_intro'); add(v + '_defeat'); add(v + '_ko'); }
      ['soldier_alert', 'soldier_ko', 'kreutz44_defeat', 'kreutz44_intro', 'leviathan_giant_roar', 'nereus_roar', 'warden_intro', 'warden_defeat'].forEach(add);
      natOnly(L);
    }
    return r;
  };
})();

/* ---------- the player is always easy to spot; the guard reads as a guard ---------- */
const _setSt0 = window.setSt;
window.setSt = function (e, st, t) { if (st === 'guard' && e && e.kind === 'hero' && e.st !== 'guard' && e.isPlayer) sfx('guard'); return _setSt0(e, st, t); };
/* v9.2: the marker under the player and the guard shield are authored art (Art Pack 5), not shapes drawn in code */
const FX92 = {};
function fx92(name) {
  let im = FX92[name];
  if (!im) { im = new Image(); im.onload = () => { im.ok = true; }; im.onerror = () => { im.bad = true; }; im.src = 'assets/fx/' + name + '.webp'; FX92[name] = im; }
  return im.ok && im.width ? im : null;
}
function drawPlayerMark(g, e, cam) {
  const im = fx92('player_ring'); if (!im) return;
  const k = 0.5 + 0.5 * Math.sin(G.time * 5), sc = depthScale(e.y), w = (44 + k * 2) * sc, h = w * im.height / im.width;
  g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = ((G.boss && !G.boss.dead) || G.mini || G.locked ? 0.95 : 0.72) * (0.82 + 0.18 * k);
  g.imageSmoothingEnabled = true; g.drawImage(im, e.x - cam - w / 2, e.y + 1 - h / 2, w, h); g.restore(); g.imageSmoothingEnabled = false;
}
function drawGuard(g, e, cam) {
  const im = fx92('guard'); if (!im) return;
  const sc = depthScale(e.y), H = entHeight(e) * sc, hit = e.guardHitT && G.time - e.guardHitT < 0.2, k = 0.5 + 0.5 * Math.sin(G.time * 12);
  const h = H * 0.95 * (hit ? 1.08 : 1), w = h * im.width / im.height;
  g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = hit ? 1 : 0.72 + 0.22 * k;
  g.translate(e.x - cam + e.face * H * 0.1, e.y - e.z - H * 0.52); if (e.face < 0) g.scale(-1, 1);
  g.imageSmoothingEnabled = true; g.drawImage(im, -w * 0.5, -h / 2, w, h);
  if (hit) { g.globalAlpha = 0.6; g.drawImage(im, -w * 0.5, -h / 2, w, h); }  /* a blocked hit flares the same shield brighter */
  g.restore(); g.imageSmoothingEnabled = false;
}
/* a hero under a protective shield: the same authored shield art, front and back, closing around the body */
const SHIELD92 = {};
function shieldArt(hue) {
  const im = fx92('guard'); if (!im) return null; if (!hue) return im;
  let c = SHIELD92[hue];
  if (!c) { c = document.createElement('canvas'); c.width = im.width; c.height = im.height; const x = c.getContext('2d'); x.filter = 'hue-rotate(' + hue + 'deg)'; x.drawImage(im, 0, 0); SHIELD92[hue] = c; }
  return c;
}
window.drawShield92 = function (g, e, x, y) {
  /* 9.7: not over the drawn frames of a special (the shield it gives shows once the move is done); Brann's stone
     skin glows ember red like his cracks */
  if (e.kind === 'hero' && e.st === 'spec') { const A = window.ATLAS[heroKey(e)]; if (A && A.v96) return; }
  const im = shieldArt(e.id === 'triton' ? -30 : e.id === 'malakor' ? -130 : e.id === 'brann' ? 150 : 0); if (!im) return;
  const sc = depthScale(e.y), H = entHeight(e) * sc, h = H * 1.12, w = h * im.width / im.height, cy = y - H * 0.5, R = H * 0.36;
  g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = 0.3 + 0.1 * Math.sin(G.time * 10); g.imageSmoothingEnabled = true;   /* 9.7: lighter, so the hero drawn inside still reads */
  /* the crescent's outer edge sits at 80% of the picture's width: two of them, back to back, close into an oval */
  for (const side of [1, -1]) { g.save(); g.translate(x, cy); g.scale(side, 1); g.drawImage(im, R - w * 0.8, -h / 2, w, h); g.restore(); }
  g.restore(); g.imageSmoothingEnabled = false;
};
const _drawEnt0 = window.drawEnt;
window.drawEnt = function (g, e, cam) {
  if (Scene.name === 'play' && G && e === G.player && e.kind === 'hero' && !e.dead && !G.superFx) drawPlayerMark(g, e, cam);
  const r = _drawEnt0(g, e, cam);
  if (Scene.name === 'play' && G && e.kind === 'hero' && e.st === 'guard' && !e.dead) drawGuard(g, e, cam);
  return r;
};

/* ---------- boss fights: calmer scenery so the fighters stand out ---------- */
const fightOn = () => Scene.name === 'play' && G && ((G.boss && !G.boss.dead && G.boss.bossIn <= 0) || (G.mini && !G.mini.dead));
const _bgBack0 = BG.back;
BG.back = function (g, camX, dt) {
  _bgBack0.call(this, g, camX, dt);
  if (Scene.name !== 'play' || !G) return;
  G.dimK = clamp((G.dimK || 0) + (fightOn() ? 0.025 : -0.025), 0, 1);
  if (G.dimK > 0) { g.save(); g.fillStyle = 'rgba(4,2,10,' + (0.28 * G.dimK).toFixed(3) + ')'; g.fillRect(-40, -40, VW + 80, VH + 80); g.restore(); }
};
BG.front = function (g, camX) {
  const n = BG.n; let c = BG.frontC[n];
  if (!c) { const im = ART.img['s' + n + '_l4']; if (!im || !im.ok) return; c = document.createElement('canvas'); c.width = im.width; c.height = im.height; const x = c.getContext('2d'); x.drawImage(im, 0, 0);
    x.globalCompositeOperation = 'destination-out'; const gr = x.createLinearGradient(0, im.height * 0.8, 0, im.height); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,1)'); x.fillStyle = gr; x.fillRect(0, im.height * 0.8, im.width, im.height * 0.2);
    x.globalCompositeOperation = 'source-atop'; x.fillStyle = 'rgba(4,2,10,0.55)'; x.fillRect(0, 0, im.width, im.height); BG.frontC[n] = c; }
  /* foreground pillars fade out while a fight is on, so they never hide the action */
  const fight = Scene.name === 'play' && G && (G.locked || fightOn());
  if (G) G.frontA = lerp(G.frontA == null ? 0.9 : G.frontA, fight ? 0.22 : 0.9, 0.06);
  drawTiled(g, c, camX, 1.35, 0, TILE_W, VIEW_H, G ? G.frontA : 0.9, 2);
};

/* ---------- stage 2: clues ---------- */
(function () {
  const M = MECH.investigate; if (!M) return;
  const nextClue = () => { const p = G.player; let best = null, bd = 1e9; for (const c of G.clues || []) { if (c.got) continue; const d = Math.abs(c.x - p.x); if (d < bd) { bd = d; best = c; } } return best; };
  M.update = function () {
    const p = G.player;
    for (const c of G.clues) {
      if (c.got || p.dead) continue;
      /* walking over it is enough; the senses show the way */
      if (Math.abs(p.x - c.x) < 30 && Math.abs(p.y - c.y) < 22) { c.got = true; G.clueN++; sfx('ok'); ringFx(c.x, c.y, 6, 60, '#ff2040', 0.5); textFx(c.x, c.y - 60, T('clue') + ' ' + G.clueN + '/3', '#ff4060', 2); talk('lupus_h', ['r02c', 'r02d', 'r02e'][G.clueN - 1]); }
    }
    if (G.clueN === 1 && !G.wingHint) { G.wingHint = true; later(() => talk('lupus_h', 'r02b'), 2500); }
  };
  /* the evidence itself (authored art), floating and glinting where it can be found */
  function drawClues(g, cam, a) {
    for (const c of G.clues) {
      if (c.got) continue; const x = c.x - cam; if (x < -40 || x > VW + 40) continue;
      const im = fx92('clue' + (((c.i || 0) % 3 + 3) % 3)); if (!im) continue;
      const tw = 0.5 + 0.5 * Math.sin(G.time * 4 + (c.i || 0) * 2.1), h = 22, w = h * im.width / im.height, by = c.y - 4 - Math.sin(G.time * 3 + (c.i || 0)) * 2;
      g.save(); g.globalAlpha = a; g.imageSmoothingEnabled = true; g.drawImage(im, x - w / 2, by - h, w, h);
      g.globalCompositeOperation = 'lighter'; g.globalAlpha = a * (0.15 + 0.45 * tw); g.drawImage(im, x - w / 2, by - h, w, h);
      g.restore(); g.imageSmoothingEnabled = false;
    }
  }
  M.drawBack = function (g, cam) { drawClues(g, cam, 1); };
  /* Wolf senses grey the world out; the blood trail and the evidence stay in full colour above it */
  const drawSenses0 = drawSenses;
  drawSenses = function (g, cam) {
    drawSenses0(g, cam);
    const k = G.senseK || 0; if (k < 0.05 || G.mech !== 'investigate' || !G.clues) return;
    const next = nextClue(), p = G.player;
    g.save(); g.globalAlpha = k;
    if (next) { const n = 18, dx = next.x - p.x, dy = next.y - p.y; for (let i = 1; i <= n; i++) { const q = i / n, x = p.x + dx * q - cam, y = p.y + dy * q + Math.sin(i * 1.7) * 3; if (i % 2) { g.fillStyle = '#c0001c'; g.fillRect(x - 1.5, y - 0.5, 3, 1.5); } } }
    g.restore();
    drawClues(g, cam, k);
  };
  M.hud = function (g) { PIX.text(g, T('clue') + ' ' + G.clueN + '/3', VW - 8, 56, { align: 'r', col: '#ff4060', out: '#0c0710' }); };
  /* The misunderstanding resolves on the street before the alliance comic.
     Health gates also catch a lethal hit, bleed or a piercing super, so none
     can skip the two exchanges or turn recruitment into a boss K.O. */
  function settleDuel(e) {
    e.hp = Math.max(1, e._duelHP || e.hp); e.inv = 99; e.pat = null;
    e.bleedT = e.bleedD = 0; e.windup = e.guard = e.charging = false;
    e.vx = e.vy = e.vz = 0; e.z = 0; e.fade = 1; e._trail = []; e._xf = null;
    e.frame = 'idle'; setSt(e, 'idle');
  }
  function startDuelBeat(e, phase) {
    if (G.vesperaBeat || e.duelBeat) return;
    e._duelPhase = phase + 1; e.duelBeat = true;
    e._duelHP = e.maxhp * [0.7, 0.45, e.def.yieldAt || 0.3][phase];
    settleDuel(e);
    G.vesperaBeat = { e, phase, t: 0, ready: false, line: null, after: 0 };
    G.locked = G.duelHold = true; G.goT = 0;
    G.proj = []; G.hz = []; G.hitstop = 0;
    Inp.reset();
  }
  M.holdDuel = function (e) {
    if (G.mode || G.mech !== 'investigate' || e.type !== 'vesp_mb') return false;
    if (e.duelBeat) { settleDuel(e); return true; }
    const phase = e._duelPhase || 0, at = [0.7, 0.45, e.def.yieldAt || 0.3][phase];
    if (at != null && e.bossIn <= 0 && e.hp <= e.maxhp * at) {
      startDuelBeat(e, phase); return true;
    }
    return false;
  };
  function alliancePanel(e) {
    const run = G;
    showPanel('cs82', [{ t: 'cap', k: 'r02x' }, { t: 'say', spk: 'lupus_h', k: 'r02g' }, { t: 'say', spk: 'vespera', k: 'r02h' }], () => {
      if (G !== run || !G || G.mech !== 'investigate' || e._duelJoined) return;
      e._duelJoined = true; e.duelBeat = false; e.dead = true; e.deadT = 100; e.hp = 0;
      G.mini = null; G.vesperaBeat = null; ringFx(e.x, e.y, 10, 60, '#ff3ad0', 0.5);
      if (!G.team.some(h => h.id === 'vespera')) {
        const a = makeHero('vespera', false, e.x, e.y); a.bench = true; G.ally = a; G.team.push(a);
      }
      G.duelHold = false; G.banner2 = { t: 0, txt: T('joined').replace('{n}', 'VESPERA') };
      Inp.reset(); sfx('ok');
    });
  }
  M.stepDuelBeat = function (dt) {
    const b = G.vesperaBeat; if (!b) return;
    const e = b.e, p = G.player;
    if (!b.ready) {
      b.ready = true; const dir = e.x >= p.x ? 1 : -1;
      b.px = p.x; b.ex = e.x;
      // Place the pair together: independent edge clamps can swap their sides.
      const gap = clamp(Math.abs(e.x - p.x) + 28, 112, 152);
      const mid = clamp((p.x + e.x) / 2, G.camX + 40 + gap / 2, G.camX + VW - 150 - gap / 2);
      b.pt = mid - dir * gap / 2; b.et = mid + dir * gap / 2;
      b.dir = dir;
      p.vx = p.vy = p.vz = 0; p.z = 0; p.air = false; p.hitDone = true;
      p.queued = false; p.atkT = p.chainT = 0; p.formPress = null; p._trail = []; p._xf = null;
      setSt(p, 'idle'); p.face = dir; e.face = -dir;
      if (b.phase < 2) { dust(e.x, e.y, 4); sfx('dash'); }
    }
    b.t += dt;
    const k = clamp(b.t / 0.45, 0, 1), ease = k * k * (3 - 2 * k);
    p.x = lerp(b.px, b.pt, ease); e.x = lerp(b.ex, b.et, ease);
    p.ct += dt; e.ct += dt;
    p.flash = Math.max(0, p.flash - dt * 5); e.flash = Math.max(0, e.flash - dt * 5);
    p.inv = Math.max(0, p.inv - dt); p.landT = Math.max(0, (p.landT || 0) - dt);
    e.frame = b.phase < 2 && b.t < 0.6 ? 'block' : 'idle';
    G.shake *= Math.exp(-10 * dt); G.flashScr = Math.max(0, G.flashScr - dt * 1.6);
    if (b.phase < 2) {
      if (b.t < (b.phase === 0 ? 1.15 : 1.4)) return;
      e.duelBeat = false; e._duelHP = null; e.inv = 0.45; e.cd = 0.65;
      e.frame = 'idle'; e.guard = false; p.inv = Math.max(p.inv, 0.65);
      G.vesperaBeat = null; Inp.reset(); return;
    }
    // Let any earlier radio line finish; the recognition is voiced once, in-world.
    const speaking = window.Dialogue9 && Dialogue9.busy();
    if (!b.line && b.t >= 0.7 && !G.talkQ.length && !speaking) {
      talk('vespera', 'r02f'); b.line = G.talkQ[G.talkQ.length - 1];
    }
    if (!b.line || G.talkQ.includes(b.line) || speaking) return;
    b.after += dt;
    if (b.after >= 0.5) { G.vesperaBeat = null; alliancePanel(e); }
  };
  M.yieldMini = function (e) { startDuelBeat(e, 2); };
  // Native backgrounding stops the shared speech channel. Replay the interrupted
  // subtitle on return instead of silently timing it out into the alliance comic.
  function resetDuelSpeech() {
    if (!G || !G.vesperaBeat || !G.talkQ.length) return;
    const line = G.talkQ[0]; line._speechStarted = false; line.t = 0;
  }
  document.addEventListener('visibilitychange', () => { if (document.hidden) resetDuelSpeech(); });
  window.addEventListener('lupus:pause', resetDuelSpeech);
  const duelUpdate = Scenes.play.update;
  Scenes.play.update = function (dt) {
    if (G && G.vesperaBeat && document.hidden) { Inp.reset(); return; }
    if (!this.menu && !PORTRAIT && G && G.vesperaBeat && !G.panel && !G.choice && !G.over && !G.superFx && !G.cine) {
      G.time += dt; Inp.reset(); talkStep(dt); M.stepDuelBeat(dt); fxStep(dt); return;
    }
    return duelUpdate.apply(this, arguments);
  };
})();

/* ---------- every stage whose exit needs 3 things (clues, incubators, towers, reactors):
   while one is missing the camera can scroll back, and an arrow at the screen edge points to it ---------- */
(function () {
  const LEFT = {
    investigate: [() => (G.clues || []).filter(c => !c.got), 'clue', '#ff4060'],
    sabotage: [() => (G.incubs || []).filter(o => !o.dead), 'obj_incub', '#a7ff1a'],
    siege: [() => (G.towers || []).filter(o => !o.dead), 'obj_tower', '#ff8a3a'],
    reactors: [() => (G.reacts || []).filter(o => !o.dead), 'obj_reactor', '#ff5a2a']
  };
  /* v9.1: the hint lives next to the objective counter (top right), away from the
     touch buttons: "<<<" or ">>>" blinks toward the nearest missing objective. */
  function edgeArrow(g, list, label, col) {
    if (!list.length || G.locked || G.bossSpawned) return; const p = G.player;
    let c = list[0]; for (const o of list) if (Math.abs(o.x - p.x) < Math.abs(c.x - p.x)) c = o;
    const sx = c.x - G.camX; if (sx > 12 && sx < VW - 12) return;
    if (Math.sin(G.time * 7) < -0.2) return;
    PIX.text(g, sx <= 12 ? '<<< ' + T(label) : T(label) + ' >>>', VW - 8, 66, { align: 'r', col, out: '#000' });
  }
  for (const k in LEFT) {
    const M = MECH[k]; if (!M) continue; const [list, label, col] = LEFT[k], hud0 = M.hud;
    M.backtrack = () => list().length > 0;
    M.hud = function (g) { if (hud0) hud0.call(this, g); edgeArrow(g, list(), label, col); };
  }
})();

/* ---------- keep the frame rate: drop the heaviest effects on slow phones ---------- */
const PERF = { last: 0, ema: 1 / 60, slowT: 0, low: !!SAVE.perfLow };
if (PERF.low) { window.DPR_CAP = 2; resize(); }
const _reflect0 = ART.reflect;
ART.reflect = function () { if (PERF.low) return; return _reflect0.apply(this, arguments); };
(function () {
  const P = Scenes.play, up = P.update;
  P.update = function (dt) {
    const now = performance.now(), d = PERF.last ? (now - PERF.last) / 1000 : 1 / 60; PERF.last = now;
    if (d < 0.25) { PERF.ema += (d - PERF.ema) * 0.05; if (!PERF.low && G && !G.panel && PERF.ema > 1 / 42) { PERF.slowT += d; if (PERF.slowT > 4) { PERF.low = true; SAVE.perfLow = true; saveGame(); window.DPR_CAP = 2; resize(); } } else PERF.slowT = Math.max(0, PERF.slowT - d * 0.5); }
    return up.call(this, dt);
  };
})();
