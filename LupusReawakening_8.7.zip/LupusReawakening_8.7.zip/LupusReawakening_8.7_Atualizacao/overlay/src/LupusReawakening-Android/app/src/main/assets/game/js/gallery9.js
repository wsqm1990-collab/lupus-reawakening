'use strict';
/* v9: the gallery keeps small previews for nearby rows and at most three
   full-size panels. A drag scrolls; releasing a tap opens the chosen panel. */
(function () {
  COMIC.installCache();
  const L = Scenes.lair, TOP = 52, BOTTOM = VH - 12, ROW = 54, COLS = 6;
  const thumbs = new Map(), pending = new Map(), failed = new Set();
  let wanted = new Set(), queue = [], drag = null;

  /* This is a catalogue only. Loading belongs to the visible gallery window. */
  galleryPages = function () {
    const out = [], u = SAVE.unlocked || 1;
    const ok = id => { let m; if (id === 'intro') return true;
      if ((m = /^s(\d+)pre$/.exec(id))) return u >= +m[1];
      if ((m = /^s(\d+)post$/.exec(id))) return u > +m[1];
      if (id === 'act2') return u > 6; if (id === 'act3') return u > 11;
      return id === 'finale' && !!SAVE.cleared;
    };
    for (const id in CUTS) if (ok(id)) for (const pg of CUTS[id]) {
      if (pg.duo) continue;
      for (const p of pg) if (COMIC.has(p.img) && !out.includes(p.img) && !(p.trueEnd && archCount() < ARCH_N)) out.push(p.img);
    }
    for (const p of PARTNERS) for (const m in DUO_AT) {
      const at = DUO_AT[m][p]; if (!at) continue;
      const sid = at === 'finale' ? 17 : +/\d+/.exec(at)[0];
      if (u > sid || (at.endsWith('pre') && u >= sid)) {
        const id = 'duo_' + p + '_' + m; if (!out.includes(id)) out.push(id);
      }
    }
    return out;
  };
  function disposeThumb(id) { const c = thumbs.get(id); if (c) { thumbs.delete(id); c.width = c.height = 0; } }
  function cancelImage(id) { const im = pending.get(id); if (!im) return;
    pending.delete(id); im.onload = im.onerror = null; im.src = '';
  }
  function release() {
    queue = []; wanted.clear(); drag = null;
    for (const id of [...pending.keys()]) cancelImage(id);
    for (const id of [...thumbs.keys()]) disposeThumb(id);
    failed.clear(); COMIC.free([]);
  }
  function pump() {
    while (pending.size < 2 && queue.length) {
      const id = queue.shift();
      if (!wanted.has(id) || thumbs.has(id) || pending.has(id) || failed.has(id)) continue;
      const im = new Image(); pending.set(id, im);
      im.onload = () => {
        if (pending.get(id) !== im) return;
        pending.delete(id);
        if (wanted.has(id) && im.width && im.height) {
          const c = document.createElement('canvas'); c.width = 160; c.height = 96;
          const g = c.getContext('2d'), sc = Math.max(c.width / im.width, c.height / im.height);
          g.imageSmoothingEnabled = true;
          g.drawImage(im, (c.width - im.width * sc) / 2, (c.height - im.height * sc) / 2, im.width * sc, im.height * sc);
          thumbs.set(id, c);
        }
        im.onload = im.onerror = null; im.src = ''; pump();
      };
      im.onerror = () => { if (pending.get(id) !== im) return;
        pending.delete(id); failed.add(id); im.onload = im.onerror = null; im.src = ''; pump();
      };
      im.src = 'assets/comic/' + id + '.webp';
    }
  }
  function maxScroll() { const n = (L.pages || []).length;
    return Math.max(0, Math.max(0, Math.ceil(n / COLS) - 1) * ROW + (n ? 48 : 0) - (BOTTOM - TOP));
  }
  function setScroll(value) {
    const prev = L.scroll || 0; L.scroll = clamp(value, 0, maxScroll());
    for (const it of L.items || []) if (it.kind === 'gal') it.y += prev - L.scroll;
    refresh();
  }
  function refresh() {
    if (Scene.name !== 'lair' || L.tab !== 4) return;
    const pages = L.pages || [], start = Math.max(0, Math.floor((L.scroll || 0) / ROW) - 1);
    const end = Math.ceil(((L.scroll || 0) + BOTTOM - TOP) / ROW) + 1;
    const visible = [], adjacent = [];
    for (let i = start * COLS; i < Math.min(pages.length, end * COLS); i++) {
      const y = TOP + Math.floor(i / COLS) * ROW - (L.scroll || 0);
      (y + 48 >= TOP && y < BOTTOM ? visible : adjacent).push(pages[i]);
    }
    wanted = new Set(visible.concat(adjacent));
    for (const id of [...thumbs.keys()]) if (!wanted.has(id)) disposeThumb(id);
    for (const id of [...pending.keys()]) if (!wanted.has(id)) cancelImage(id);
    queue = visible.concat(adjacent).filter(id => !thumbs.has(id) && !pending.has(id) && !failed.has(id)); pump();
    if (L.view >= 0) {
      L.view = clamp(L.view, 0, Math.max(0, pages.length - 1));
      const full = pages.slice(Math.max(0, L.view - 1), L.view + 2); COMIC.free(full); COMIC.need(full);
    } else COMIC.free([]);
  }
  function open(index) {
    if (Scene.name !== 'lair' || L.tab !== 4 || !(L.pages || [])[index]) return;
    L.view = index; drag = null; refresh();
  }
  const enter = L.enter, layout = L.layout, draw = L.draw, down = L.onDown, move = L.onMove, up = L.onUp;
  L.enter = function () { release(); this.scroll = 0; this.view = -1; return enter.apply(this, arguments); };
  L.layout = function () {
    layout.call(this);
    if (this.tab === 4) { const before = this.scroll || 0; this.scroll = clamp(before, 0, maxScroll());
      if (before !== this.scroll) for (const it of this.items) if (it.kind === 'gal') it.y += before - this.scroll;
      refresh();
    }
  };
  L.draw = function (g) {
    if (this.tab !== 4) { draw.call(this, g); return; }
    BG.menu(g, 3, this.t, this.t * 8); dim(g, 0.72);
    PIX.text(g, T('lair'), VW / 2, 8, { s: 2, align: 'c', col: COLR.red });
    drawShard(g, VW - 70, 13); PIX.text(g, '' + (SAVE.shards || 0), VW - 60, 10, { col: '#b8e8ff' });
    for (const b of this.btns) drawBtn(g, b);
    g.save(); g.beginPath(); g.rect(12, TOP - 2, VW - 24, BOTTOM - TOP + 2); g.clip();
    for (const it of this.items) {
      if (it.kind !== 'gal' || it.y + it.h < TOP || it.y > BOTTOM) continue;
      g.fillStyle = '#08060e'; g.fillRect(it.x - 1, it.y - 1, it.w + 2, it.h + 2);
      const im = thumbs.get(it.img);
      if (im) { g.imageSmoothingEnabled = true; g.drawImage(im, it.x, it.y, it.w, it.h); g.imageSmoothingEnabled = false; }
      else PIX.text(g, failed.has(it.img) ? '?' : '...', it.x + it.w / 2, it.y + 20, { align: 'c', col: '#8a84a0' });
    }
    g.restore();
    const max = maxScroll();
    if (max > 0) { const h = Math.max(18, (BOTTOM - TOP) * (BOTTOM - TOP) / (max + BOTTOM - TOP));
      g.fillStyle = '#30283c'; g.fillRect(VW - 9, TOP, 3, BOTTOM - TOP);
      g.fillStyle = COLR.red; g.fillRect(VW - 9, TOP + (BOTTOM - TOP - h) * (this.scroll || 0) / max, 3, h);
    }
    if (!this.pages.length) PIX.text(g, T('locked'), VW / 2, 140, { align: 'c', col: COLR.gray });
    if (this.view >= 0) {
      const im = COMIC.img[this.pages[this.view]];
      g.fillStyle = 'rgba(0,0,0,0.97)'; g.fillRect(0, 0, VW, VH);
      if (im && im.ok && im.width && im.height) { const sc = Math.min((VW - 32) / im.width, (VH - 26) / im.height);
        g.imageSmoothingEnabled = true; g.drawImage(im, (VW - im.width * sc) / 2, (VH - im.height * sc) / 2, im.width * sc, im.height * sc); g.imageSmoothingEnabled = false;
      } else PIX.text(g, im && im.bad ? '?' : T('loading'), VW / 2, VH / 2, { align: 'c', col: COLR.gray });
      PIX.text(g, (this.view + 1) + '/' + this.pages.length, VW / 2, VH - 10, { align: 'c', col: COLR.gray });
      PIX.text(g, '<', 8, VH / 2, { s: 2, col: COLR.white }); PIX.text(g, '>', VW - 18, VH / 2, { s: 2, col: COLR.white });
    }
  };
  L.onDown = function (id, x, y) {
    if (this.tab !== 4 || this.archView != null) return down.call(this, id, x, y);
    if (this.view >= 0) { sfx('ui'); if (x < VW * 0.25) this.view = Math.max(0, this.view - 1);
      else if (x > VW * 0.75) this.view = Math.min(this.pages.length - 1, this.view + 1);
      else this.view = -1; refresh(); return;
    }
    if (hitB(this.btns, x, y)) { const r = down.call(this, id, x, y); if (this.tab !== 4 || Scene.name !== 'lair') release(); return r; }
    if (y < TOP || y >= BOTTOM || drag) return;
    const it = this.items.find(it => it.kind === 'gal' && x >= it.x && x <= it.x + it.w && y >= it.y && y <= it.y + it.h);
    drag = { id, x, y, scroll: this.scroll || 0, item: it && it.img, moved: false };
  };
  L.onMove = function (id, x, y) {
    if (!drag || drag.id !== id) { if (move) move.call(this, id, x, y); return; }
    if (Math.hypot(x - drag.x, y - drag.y) > 5) drag.moved = true;
    if (drag.moved) setScroll(drag.scroll + drag.y - y);
  };
  L.onUp = function (id, x, y) {
    if (!drag || drag.id !== id) { if (up) up.call(this, id, x, y); return; }
    const tap = drag; drag = null;
    if (!tap.moved && x >= 0 && y >= TOP && y < BOTTOM) {
      const it = this.items.find(it => it.kind === 'gal' && it.img === tap.item && x >= it.x && x <= it.x + it.w && y >= it.y && y <= it.y + it.h);
      if (it) { sfx('ok'); open(it.i); }
    }
  };
  L.onWheel = function (delta) { if (this.tab === 4 && this.view < 0) setScroll((this.scroll || 0) + delta); };
  cv.addEventListener('wheel', e => { if (Scene.name !== 'lair' || L.tab !== 4 || L.view >= 0) return;
    e.preventDefault(); const units = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? VH : cv._dpr / SCALE;
    L.onWheel(e.deltaY * units);
  }, { passive: false });
  const go = Scene.go;
  Scene.go = function (name) { if (Scene.name === 'lair' && name !== 'lair') release(); return go.apply(this, arguments); };
  window.LupusGallery = { open, scroll: delta => L.onWheel(delta),
    stats: () => ({ thumbnails: thumbs.size, loading: pending.size, queued: queue.length,
      fullPanels: Object.keys(COMIC.img).filter(k => k !== '@duo').length, scroll: L.scroll || 0, maxScroll: maxScroll() }) };
})();
