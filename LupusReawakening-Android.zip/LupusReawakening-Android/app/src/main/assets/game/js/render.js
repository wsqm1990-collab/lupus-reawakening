'use strict';
/* =====================================================================
   RENDER helpers: sprite placement, dithered shadows, wet reflections,
   slash smears, pixel particles, low-res buffer -> screen upscale.
   ===================================================================== */
const RD = {};
/* dithered ellipse shadow */
const shadowCache = new Map();
RD.shadow = function (g, x, y, rx, a) {
  rx = Math.max(4, Math.round(rx)); const ry = Math.max(2, Math.round(rx * 0.3)); const key = rx + '|' + ry;
  let c = shadowCache.get(key);
  if (!c) {
    const [cv, cg] = PIX.canvas(rx * 2 + 2, ry * 2 + 2); cg.fillStyle = '#06030a';
    for (let yy = -ry; yy <= ry; yy++) for (let xx = -rx; xx <= rx; xx++) { const d = (xx * xx) / (rx * rx) + (yy * yy) / (ry * ry); if (d > 1) continue; if (d > 0.55 && ((xx + yy) & 1)) continue; cg.fillRect(xx + rx + 1, yy + ry + 1, 1, 1); }
    shadowCache.set(key, c = cv);
  }
  g.save(); g.globalAlpha = a == null ? 0.55 : a; g.drawImage(c, Math.round(x - rx - 1), Math.round(y - ry - 1)); g.restore();
};
/* draw a frame with feet anchor at (x, y). o: {face, alpha, flash, tint, sx, sy} */
RD.sprite = function (g, f, x, y, o) {
  if (!f) return; o = o || {};
  const face = o.face || 1; x = Math.round(x); y = Math.round(y);
  g.save(); if (o.alpha != null) g.globalAlpha = o.alpha;
  g.translate(x, y); if (face < 0) g.scale(-1, 1);
  if (o.sx || o.sy) g.scale(o.sx || 1, o.sy || 1);
  g.drawImage(f.cv, -f.ax, -f.ay);
  if (o.flash) { g.globalAlpha = (o.alpha != null ? o.alpha : 1) * Math.min(1, o.flash); g.drawImage(SPRITES.flash(f, o.flashCol || '#ffffff'), -f.ax, -f.ay); }
  if (o.tint) { g.globalAlpha = (o.alpha != null ? o.alpha : 1) * (o.tintA || 0.45); g.drawImage(SPRITES.flash(f, o.tint), -f.ax, -f.ay); }
  g.restore();
};
/* reflection under the feet on wet / water floors */
RD.reflect = function (g, f, x, y, z, face, a) {
  if (!f || !a) return; x = Math.round(x); y = Math.round(y);
  g.save(); g.globalAlpha = a * Math.max(0, 1 - z / 60); g.translate(x, y + z); if (face < 0) g.scale(-1, 1); g.scale(1, -0.55);
  g.drawImage(f.cv, -f.ax, -f.ay); g.restore();
};
/* crescent smear (pixel) */
RD.slash = function (g, x, y, face, r, ang, col, t) {
  const k = Math.min(1, t); const R = Math.round(r * (0.75 + 0.35 * k));
  g.save(); g.translate(Math.round(x), Math.round(y)); if (face < 0) g.scale(-1, 1); g.rotate(ang);
  const a0 = -1.25 + k * 0.6, a1 = 1.15;
  const thick = Math.max(1, Math.round((1 - k) * r * 0.28));
  for (let a = a0; a < a1; a += 0.045) {
    const w = Math.max(1, Math.round(thick * Math.sin((a - a0) / (a1 - a0) * Math.PI)));
    const px = Math.round(Math.cos(a) * R), py = Math.round(Math.sin(a) * R);
    g.fillStyle = col; g.fillRect(px - w, py, w, 1); g.fillRect(px - w, py - 1, w, 1);
    g.fillStyle = '#ffffff'; g.fillRect(px - 1, py, 1, 1);
  }
  g.restore();
};
/* additive glow (cheap radial) */
RD.glow = function (g, x, y, r, col, a) {
  const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, col); gr.addColorStop(1, 'rgba(0,0,0,0)');
  g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = a == null ? 0.6 : a; g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2); g.restore();
};
/* ring shockwave (pixel ellipse outline) */
RD.ring = function (g, x, y, r, col, a) {
  g.save(); g.globalAlpha = a; g.fillStyle = col; const ry = r * 0.32;
  for (let i = 0; i < 64; i++) { const t = i / 64 * Math.PI * 2; g.fillRect(Math.round(x + Math.cos(t) * r), Math.round(y + Math.sin(t) * ry), 2, 1); }
  g.restore();
};
