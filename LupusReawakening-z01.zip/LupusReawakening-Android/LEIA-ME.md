# CYBERCLAWS — projeto Android

Versão 9.9.1. O jogo fica em `app/src/main/assets/game/` (HTML5 + Canvas) e roda dentro de um WebView.

## Novidades da 9.9.1 (as correções que o Walter marcou nos quadrinhos)
- As 23 páginas marcadas pelo Walter foram corrigidas com desenhos novos (nada de remendo por código):
  - asas presas nas costas, uma de cada lado: Vespera e Brann nas cs23, cs36, cs38, cs69, cs71, cs74 e cs80;
    a Vespera sem a asa a mais na duo_vespera_m3;
  - mãos e dedos: as duas mãos do lobisomem na cs89 (5 dedos, 1 garra por dedo), a garra no lugar certo na cs41,
    a mão do Malakor com 4 dedos e o polegar escondido na cs54, sem o polegar a mais na cs16, a mão esquerda
    certa do Malakor na duo_malakor_m4, o polegar do Thorne embaixo da mão na duo_echo_m2, a Vespera segurando
    o pulso do Thorne na cs42, as mãos da Echo e do Triton na cs74, a mão do Triton na cs36, a luva sem unha na cs90_glove;
  - o tridente reto na duo_triton_m4, a magia saindo da palma do Malakor na duo_malakor_m5, as correntes presas
    na cs84, o Thorne sentado de verdade na duo_echo_m3, a Vespera e o Triton olhando para o Leviatã na cs80;
  - a cs30 foi desenhada de novo: os seis heróis iguais às fichas, num elevador bem maior;
  - a cs60 voltou para a versão anterior (como o Walter pediu).
- O canhão da Echo é sempre o braço DIREITO dela (como na ficha): corrigido nas cs26, cs36, cs51, cs55, cs69,
  cs71, cs74, cs80 e duo_echo_m5. Na duo_echo_m4, na duo_echo_m3 e na cs38 ele já estava certo.
- Registro dos pedidos e das versões escolhidas: `tools/comic98/fixes991.json`.

## Novidades da 9.9 (todos os quadrinhos redesenhados)
- As 107 páginas de quadrinhos do jogo foram redesenhadas com o visual aprovado de cada personagem:
  - John Thorne em 2242 com os dois braços cibernéticos de Lunarium (sem garras na forma humana);
    em 1944, braços humanos até a fusão e as manoplas de Lunarium depois dela.
  - Vespera, Triton, Malakor, Echo, Brann, Kreutz, Thule e os chefes exatamente como nas fichas.
  - A Echo usa o olho cibernético até arrancá-lo; daí em diante, o tapa-olho.
  - As 25 cenas de dupla (5 por parceiro) ganharam desenhos novos.
- Inclui as 8 páginas que aparecem no meio das fases e os 2 quadros do Doktor Nacht no metrô.
- Cada página foi conferida com zoom: dedos, mãos no braço certo, poses e física da cena.
  Depois, revisores independentes conferiram de novo as páginas refeitas, e o que eles acharam
  foi redesenhado (aperto de mão do Triton com a mão direita, punhos da Vespera, as duas asas e
  as duas pernas do Brann, o tapa-olho da Echo no olho esquerdo, entre outros).
- Ferramentas: `tools/comic98/pages.py` (a descrição de cada página e as fichas usadas) e
  `tools/comic98/fixes.py` (os pedidos de correção de uma página já desenhada).

## Novidades da 9.8 (a fase 1 inteira desenhada quadro a quadro)
- Os inimigos e o chefe da fase 1 foram redesenhados quadro a quadro, no mesmo visual dos heróis:
  - Soldado de 1944: marcha, estocada de baioneta, reação ao golpe, voo, chão e levantada.
  - Cão da peste: trote, bote (agacha, salta, morde no ar, aterrissa), reação, voo, chão e
    levantada (ele se sacode).
  - Experimento fracassado (mutante): andar arrastado, rasgo com as duas garras, reação, voo, chão e
    levantada.
  - Tenente Kreutz (1944): combo de sabre, golpe pesado, investida com o sabre erguido (e fica
    tonto ao bater na parede), e a pistola: ele saca, mira para baixo no John, atira e guarda a
    arma. As balas saem do cano desenhado e voam como traçantes até o peito do John (o dano e o
    acerto são os mesmos de antes).
- Os ataques mostram a preparação inteira, o golpe e a recuperação; quando um inimigo recua de
  frente para o John, ele anda de costas (sem deslizar).
- Golpes com o movimento desenhado não ganham o risco genérico por cima.
- Código da 9.8: `js/enemy98.js`. Quadros: `js/atlas98t.js`, `js/atlas98m.js`, `js/atlas98h.js` e
  `js/atlas98k.js`. Ferramentas: `tools/anim96/` (o boneco de quatro patas para o cão está em
  `poses.py`).

## Novidades da 9.7 (todos os heróis desenhados quadro a quadro)
- Os cinco parceiros foram redesenhados quadro a quadro no visual cyberpunk aprovado (cerca de 70
  quadros cada), com golpes próprios:
  - Vespera: garra de sangue, chute alto, corte giratório com as asas e a espiral de sangue — a bola
    sai da mão desenhada.
  - Triton: estocada com o tridente, varrida, golpe por cima e o especial da maré — a onda é
    desenhada à parte e nasce onde o tridente bate no chão.
  - Malakor: magia com uma mão, com as duas mãos, a caveira em chamas e a barreira — os raios e a
    caveira saem da mão desenhada.
  - Echo: tiro rápido, golpe com o braço-canhão, rajada para cima e o canhão de trilho — o raio sai
    da ponta do canhão desenhado e acompanha o coice.
  - Brann: soco acorrentado, martelo duplo, uppercut e o tremor de pedra — as ondas de choque são
    pontas de pedra desenhadas.
- John Thorne em 1944 (fase 1), desenhado quadro a quadro nas duas formas:
  - Humano, com os braços de Lunarium: jab, direto, uppercut e o Rugido Lunar com o círculo de
    energia vermelho.
  - Lobisomem, com garras de prata: três golpes de garra, o uivo com os símbolos da lua, e corre de
    quatro como um lobo (também na esquiva).
- Fenrir Desperto (fase 16), desenhado quadro a quadro: estocada de garra, rasgo para cima, duplo
  corte, mergulho em X e o Uivo do Ragnarok, com a juba virando uma coluna de fogo. A
  transformação agora brilha dourada.
- Alfa e Fenrir: o brilho fica atrás do corpo e os golpes não deixam mais cópias fantasma da pose
  anterior.
- Código da 9.7: `js/hero96.js` (regras de cada herói). Quadros: `js/atlas97v.js`,
  `js/atlas97t.js`, `js/atlas97m.js`, `js/atlas97e.js`, `js/atlas97b.js`, `js/atlas97j.js`,
  `js/atlas97w.js` e `js/atlas97x.js`. Ferramentas: `tools/anim96/`.

## Novidades da 9.6 (Thorne desenhado quadro a quadro)
- As três formas do Thorne foram redesenhadas no visual cyberpunk aprovado, quadro a quadro, como
  num desenho animado: humano (71 quadros), lobisomem (70) e Alfa (70). Cada forma tem golpes
  próprios:
  - Humano: jab, direto, gancho com pistão, especial da corrente, ataque aéreo de martelo duplo.
  - Lobisomem: anda curvado, corre de quatro como um lobo (também na esquiva), três golpes de garra
    com o rastro desenhado, mergulho com as garras e o especial do uivo.
  - Alfa: estocada de garra, garra subindo, martelo duplo que racha o chão, mergulho em X e o
    especial da explosão de espinhos.
  - Todas: andar, correr, pulo, defesa, dano, voar longe, cair, levantar e pose de vitória.
- O Leviatã foi redesenhado no visual novo (16 quadros) e ganhou retrato novo.
- Cinco páginas de quadrinho corrigidas: a Torre Thorne no tamanho certo (cs30), a Echo arrancando
  o olho-transmissor (cs57), as docas com as duas asas do Brann (cs79), o Thule ligado às máquinas
  (cs81) e a fuga de 1944 com as correntes (cs89).
- Código da 9.6: `js/hero96.js` e `js/lev96.js`. Quadros: `js/atlas96h.js`, `js/atlas96f.js`,
  `js/atlas96a.js` e `js/atlas96.js`. Ferramentas: `tools/anim96/` (guias de pose, textos e
  montagem), `tools/lev96/` e `tools/comic96/`.

## Novidades da 9.5 (o jogo agora se chama CyberClaws)
- Nome novo: o jogo se chama **CyberClaws** e o herói é **Thorne** (John Thorne) em todos os 12
  idiomas, nos menus, legendas e quadrinhos. Logo novo desenhado na tela de título e na tela de
  carregamento (`assets/ui/logo95.webp`).
- Falas regravadas com o nome novo, em inglês e português: o "Sargento Thorne" de 1944 (i05a), o
  final "Thorne vai voltar" (f01m) e a chegada do caçador Kane (`kane_intro`).
- Fase 4 (defesa): a última fala no nocaute do chefe termina antes de o quadrinho começar; falas
  novas de combate ficam em silêncio nesse momento.
- Fase 5 (metrô alagado): a transformação do chefe ganhou uma pausa dramática antes do quadrinho, e
  os toques que eram para a luta não pulam mais o quadrinho.
- Sem cambalhota artificial: o inimigo lançado não gira mais feito por código.
- Difícil e Pesadelo bem mais duros: chefes com mais vida e mais resistência, menos cura e menos
  itens, golpes mais rápidos e inimigos que atacam pelas costas quando o herói está ocupado
  batendo em outro.
- Fase 6 (sabotagem): o gás tóxico sai de saídas desenhadas no chão — luzes e uma caveira avisam,
  depois a nuvem verde sobe e se espalha (`assets/fx/fx95.webp`, lista em `js/fx95-atlas.js`).
  Na primeira vez, o Malakor avisa pelo rádio (fala nova, inglês e português).
- Fase 7 (Necrópole de Neon): inimigo novo, o **Corvo de Luto**, desenhado quadro a quadro
  (`assets/chars/mourner.webp`, `js/atlas95.js`). Ele aparece e some numa nuvem de penas, reaparece
  atrás do herói e solta um grito de corvo quando acerta. O Malakor avisa na primeira vez.
- A névoa da fase 7 fica atrás dos lutadores: ninguém mais aparece apagado.
- Código da 9.5: `js/v95.js`. Artes geradas: `tools/art95/build95.py`. Vozes: `tools/voice95.py`
  (registro em `tools/voice95-production.json`).

## Vozes
- Falas da história: `assets/voice/dialogue/` (português) e `assets/voice/dialogue/en/` (inglês).
- Gritos de combate gravados com a voz de cada personagem: `assets/voice/pt/` e `assets/voice/en/`
  (lista em `js/voice-manifest93.js`). Jogo em português usa `pt/`; os outros idiomas usam `en/`.
- Vozes de monstros e soldados ficam em `assets/voice/`.

## Como o APK é gerado
O GitHub gera o APK sozinho. No repositório ficam as partes `LupusReawakening-zNN.zip`; o
GitHub Actions junta todas, compila e publica em **Releases** como "CyberClaws 9.x - APK N".

## Instalação
- ID do app: `com.thorneindustries.lupus.preview` (o mesmo desde a 9.0), assinado com `app/lupus.keystore`.
  Por isso a 9.9.1 instala por cima da 9.0 a 9.9 e mantém o progresso.
- Nome no celular: "CyberClaws".
- Antes de publicar na Play Store, crie uma chave nova e particular: esta chave está visível no repositório.
