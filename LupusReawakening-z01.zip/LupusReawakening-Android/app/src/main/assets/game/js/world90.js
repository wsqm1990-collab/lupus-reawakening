'use strict';
/* Connected field refuge, optional districts and portable save state.
 * Rooms are separate scenes: a parked street never keeps simulating behind one. */
(function () {
  const VERSION = 1, ROOM_IDS = ['alley', 'cistern', 'relay'];
  const tr = (pt, en) => window.Q90 ? Q90.t(pt, en) : /^pt/i.test(SAVE.lang || '') ? pt : en;
  const finite = (v, a, b, d = a) => Number.isFinite(+v) ? Math.max(a, Math.min(b, +v)) : d;
  const own = (v, k) => Object.prototype.hasOwnProperty.call(v, k);
  const clone = v => JSON.parse(JSON.stringify(v));
  const DEF = {
    alley: { id: 'alley', art: 'alley', stage: 1, unlock: 2, x: 570, y: 226, archive: 3, reward: 8,
      name: () => tr('Beco das Testemunhas', 'Witness Alley'), district: () => tr('Hallowgate', 'Hallowgate'),
      task: () => tr('Cruze os vestígios com o depoimento e decifre a maleta.', 'Connect the evidence to the witness and decode the case.') },
    cistern: { id: 'cistern', art: 'cistern', stage: 4, unlock: 5, x: 550, y: 230, archive: 12, reward: 10,
      name: () => tr('Estação de Bombeamento', 'Pumping Station'), district: () => tr('Metrô Alagado', 'Flooded Metro'),
      task: () => tr('Leia a placa, controle a pressão e recupere o manifesto.', 'Read the plate, stabilize the pressure and recover the manifest.') },
    relay: { id: 'relay', art: 'relay', stage: 6, unlock: 7, x: 560, y: 226, archive: 18, reward: 12,
      name: () => tr('Torre de Retransmissão', 'Relay Tower'), district: () => tr('Distrito da Névoa', 'Fog District'),
      task: () => tr('Grave o pulso, alinhe a frequência e localize a Cabala.', 'Record the pulse, align the frequency and trace the Cabala.') }
  };
  let parked = null, hubReturn = null, backupDom = null, backupOwner = null;

  function ensure() {
    const old = SAVE.world90;
    if (!old || typeof old !== 'object' || Array.isArray(old)) SAVE.world90 = {};
    const w = SAVE.world90;
    w.version = VERSION;
    for (const key of ['rooms', 'quests', 'shortcuts', 'seenDoors']) if (!w[key] || typeof w[key] !== 'object' || Array.isArray(w[key])) w[key] = {};
    for (const id of ROOM_IDS) {
      const q = w.rooms[id];
      if (!q || typeof q !== 'object' || Array.isArray(q)) w.rooms[id] = {};
      const s = w.rooms[id];
      s.visited = !!s.visited; s.completed = !!s.completed; s.rewarded = !!s.rewarded;
      if (!s.progress || typeof s.progress !== 'object' || Array.isArray(s.progress)) s.progress = {};
      if (typeof s.outcome !== 'string') s.outcome = '';
    }
    if (w.checkpoint && (!Number.isInteger(w.checkpoint.stage) || w.checkpoint.stage < 0 || w.checkpoint.stage >= STAGES.length)) w.checkpoint = null;
    if(w.checkpoint){const c=w.checkpoint,st=STAGES[c.stage];c.wave=Math.floor(finite(c.wave,0,st.waves.length));c.x=finite(c.x,14,st.w-14,70);c.y=finite(c.y,LANE_T,LANE_B,232);c.cam=finite(c.cam,0,Math.max(0,st.w-VW));c.fury=finite(c.fury,0,300);c.form=['h','f','a'].includes(c.form)?c.form:'h';c.clues=Array.isArray(c.clues)?c.clues.slice(0,3).map(v=>v===true):[];}
    return w;
  }
  const persist = () => { ensure(); saveGame(); };
  function room(id) { return DEF[id] || null; }
  function canEnter(id) { const d = room(id); return !!(d && (SAVE.unlocked || 1) >= d.unlock); }
  function canHub() {
    if ((SAVE.unlocked || 1) < 2) return false;
    if (Scene.name !== 'play') return true;
    return !!(G && !G.mode && !G.st.l44 && !G.locked && enemiesAlive() === 0 && !(G.spawnQ && G.spawnQ.length) && !G.bossPending && !G.bossSpawned && !G.over && !G.clearT && !G.panel && !G.choice && !G.cine && !G.superFx && !G.vesperaBeat && !G.nachtBeat90 && G.player && G.player.id === 'lupus' && G.player.form === 'h' && !G.player.dead && G.player.z <= 1);
  }
  function capture(scene = Scene.cur, name = Scene.name) {
    return { scene, name, game: typeof G !== 'undefined' ? G : null, menu: !!(scene && scene.menu) };
  }
  function releaseRoomArt(keep = []) { for(const key of ['hub','alley','cistern','relay']){if(keep.includes(key))continue;const im=Q90.art[key];if(im){try{im.src='';}catch(_){}delete Q90.art[key];}} }
  function restore(target) {
    if (!target || !target.scene) { Scene.go('title'); return; }
    if (window.Dialogue9) Dialogue9.stop();
    if (target.game) G = target.game;
    Scene.cur = target.scene; Scene.name = target.name; Scene.fade = 0.35;
    if (own(target, 'menu')) target.scene.menu = target.menu;
    Inp.reset();
    if (window.RoomInput90) RoomInput90.reset();
    if (G && target.name === 'play' && G.talkQ && G.talkQ[0]) { G.talkQ[0]._speechStarted = false; G.talkQ[0].t = 0; }
  }
  function checkpoint(force) {
    if (!G || G.mode || !G.st || G.over || G.clearT || G.player.dead || (G.locked && !force)) return null;
    const w = ensure(), p = G.player, ck = Math.max(0, G.ck | 0);
    w.checkpoint = { stage: G.stage, wave: ck, x: finite(p.x, 14, WORLD_W - 14, 70), y: finite(p.y, LANE_T, LANE_B, 232), cam: finite(G.camX, 0, Math.max(0, WORLD_W - VW)),
      form: ['h','f','a'].includes(p.form) ? p.form : 'h', fury: finite(p.fury, 0, 300), clues: (G.clues || []).map(c=>!!c.got), safe: !G.locked, room: '', savedAt: Date.now() };
    persist(); return clone(w.checkpoint);
  }
  function resumeCheckpoint() {
    const c = ensure().checkpoint;
    if (!c || c.stage + 1 > (SAVE.unlocked || 1)) return false;
    parked = null; hubReturn = null;
    Scene.go('play', { stage: c.stage, fromWave: c.wave, restore90: clone(c) }); return true;
  }
  function openHub() {
    if (!canHub()) return false;
    if (Scene.name === 'world90') return true;
    parked = capture();
    if (Scene.name === 'play') checkpoint();
    hubReturn = parked;
    Scene.go('world90', { returnTo: parked }); return true;
  }
  function openMap() { if (!openHub()) return false; Scenes.world90.openMap(); return true; }
  function returnToField() { const target = hubReturn || parked; hubReturn = parked = null; restore(target); }
  function enterRoom(id, options = {}) {
    if (!canEnter(id) || !window.Investigation90) return false;
    const q = ensure().rooms[id]; q.visited = true; persist();
    return Investigation90.open(id, options);
  }
  function updateRoom(id, progress) {
    if (!room(id) || !progress || typeof progress !== 'object') return;
    ensure().rooms[id].progress = clone(progress); persist();
  }
  function completeRoom(id, outcome, suppliedField) {
    if (!room(id) || !canEnter(id)) return { ok: false, fresh: false };
    const d = room(id), w = ensure(), q = w.rooms[id];
    const fresh = !q.rewarded;
    q.completed = true; q.outcome = typeof outcome === 'string' ? outcome.slice(0, 60) : q.outcome;
    if (fresh) {
      q.rewarded = true;
      const reward=d.reward+(id==='alley'&&q.outcome==='statement-recorded'?2:0);
      SAVE.shards = finite(SAVE.shards, 0, 999999, 0) + reward;
      SAVE.arch = SAVE.arch || {};
      const newArchive = !SAVE.arch[d.archive]; SAVE.arch[d.archive] = 1;
      const field = suppliedField || (parked && parked.name === 'play' ? parked.game : null);
      if (field && field.player && field.stage === d.stage) {
        field.player.fury = Math.min(300, Math.max(0, field.player.fury || 0) + 25);
        for (const a of field.archs || []) if (a.id === d.archive) a.got = true;
        if (id === 'alley' && field.clues && field.clues[0] && !field.clues[0].got) { field.clues[0].got = true; field.clueN = (field.clueN || 0) + 1; }
      }
      w.quests[id] = { complete: true, outcome: q.outcome };
      if (id === 'alley') w.shortcuts['hallowgate-backdoor'] = true;
      if (id === 'cistern') w.shortcuts['drained-conduit'] = true;
      if (id === 'relay') w.shortcuts['cathedral-signal'] = true;
      if (archCount() >= ARCH_N) { SAVE.skins = SAVE.skins || {}; SAVE.skins.lupus = true; }
      persist(); return { ok: true, fresh: true, shards: reward, archive: d.archive, newArchive, fury: 25 };
    }
    persist(); return { ok: true, fresh: false, shards: 0, fury: 0 };
  }
  function unlockShortcut(id, info) {
    if (!['rooftop-courier','hallowgate-backdoor','drained-conduit','cathedral-signal'].includes(id)) return false;
    const w = ensure(); if (w.shortcuts[id]) return false;
    w.shortcuts[id] = info && typeof info === 'object' ? clone(info) : true; persist(); return true;
  }
  const hasShortcut = id => !!ensure().shortcuts[id];
  function travel(stage) {
    if (!Number.isInteger(stage) || stage < 0 || stage >= STAGES.length || stage + 1 > (SAVE.unlocked || 1)) return false;
    parked = hubReturn = null; Scene.go('select', { stage }); return true;
  }
  function routes() {
    const w = ensure();
    return STAGES.map((s, i) => ({ id: 'chapter-' + s.id, stage: i, act: s.act, name: s.name[SAVE.lang] || s.name.en || ('Chapter ' + s.id), unlocked: i + 1 <= (SAVE.unlocked || 1), complete: i + 1 < (SAVE.unlocked || 1), flashback: i === 0,
      archives: (s.arch || []).filter((_, j) => (SAVE.arch || {})[archId(s.id, j)]).length,
      links: [i > 0 ? 'chapter-' + i : null, i < STAGES.length - 1 ? 'chapter-' + (i + 2) : null].filter(Boolean), rooms: ROOM_IDS.filter(id => DEF[id].stage === i).map(id => ({ id, complete: w.rooms[id].completed, unlocked: canEnter(id) })) }));
  }
  function canUseShortcut() {
    if(!hasShortcut('rooftop-courier')||!window.Traversal90)return false;
    const f=parked&&parked.name==='play'?parked.game:null,c=ensure().checkpoint;
    return !!(f&&f.stage===2&&f.waveIdx>=4&&!f.locked&&!f.over&&!f.clearT||!f&&c&&c.stage===2&&c.wave>=4);
  }
  function useShortcut() {
    if(!canUseShortcut())return false;
    const target=parked&&parked.name==='play'?parked:null;
    if(target){parked=hubReturn=null;restore(target);Scenes.play.menu=false;const ok=Traversal90.enterShortcut('roof-east');if(ok)checkpoint();return ok;}
    const c=clone(ensure().checkpoint);parked=hubReturn=null;Scene.go('play',{stage:2,fromWave:c.wave,restore90:c,entry90:'roof-east'});return true;
  }
  function graph(){const main=routes(),w=ensure(),nodes=main.map(n=>Object.assign({kind:'chapter'},n)).concat([{id:'refuge',kind:'hub',name:tr('Refúgio de campo','Field refuge'),unlocked:(SAVE.unlocked||1)>=2}]).concat(ROOM_IDS.map(id=>({id:'room:'+id,kind:'room',name:DEF[id].name(),unlocked:canEnter(id),complete:w.rooms[id].completed})));const edges=[];for(let i=1;i<main.length-1;i++)edges.push({from:main[i].id,to:main[i+1].id,open:main[i+1].unlocked});for(const id of ROOM_IDS){edges.push({from:'chapter-'+DEF[id].unlock,to:'room:'+id,open:canEnter(id)});edges.push({from:'refuge',to:'room:'+id,open:canEnter(id),fastTravel:true});edges.push({from:'room:'+id,to:'refuge',open:w.rooms[id].completed,shortcut:true});}for(const n of main)if(!n.flashback)edges.push({from:'refuge',to:n.id,open:n.unlocked,fastTravel:true});return {nodes,edges,flashback:'chapter-1'};}
  function exportSave() { ensure(); return JSON.stringify({ format: 'lupus-reawakening-save', version: VERSION, gameVersion: '9.0', savedAt: new Date().toISOString(), save: clone(SAVE) }, null, 2); }
  function safeTree(value, depth = 0, count = { n: 0 }) {
    if (depth > 12 || ++count.n > 16000) throw new Error(tr('Arquivo grande ou complexo demais.', 'Save is too large or complex.'));
    if (value == null || typeof value === 'boolean' || typeof value === 'string' && value.length <= 10000 || typeof value === 'number' && Number.isFinite(value)) return value;
    if (Array.isArray(value)) { if (value.length > 1000) throw new Error('Invalid array.'); return value.map(v => safeTree(v, depth + 1, count)); }
    if (typeof value === 'object') { const out = {}; for (const key of Object.keys(value)) { if (['__proto__','prototype','constructor'].includes(key)) throw new Error('Unsafe property.'); out[key] = safeTree(value[key], depth + 1, count); } return out; }
    throw new Error('Invalid save data.');
  }
  function importSave(text) {
    if (typeof text !== 'string' || text.length > 512000) return { ok: false, error: tr('Backup inválido ou grande demais.', 'Invalid or oversized backup.') };
    try {
      const payload = safeTree(JSON.parse(text));
      if (payload.format !== 'lupus-reawakening-save' || payload.version !== VERSION || !payload.save || typeof payload.save !== 'object' || Array.isArray(payload.save)) throw new Error(tr('Este não é um backup compatível de LUPUS.', 'This is not a compatible LUPUS backup.'));
      const next = payload.save;
      if (!Number.isInteger(next.unlocked) || next.unlocked < 1 || next.unlocked > STAGES.length + 1 || !next.up || typeof next.up !== 'object' || Array.isArray(next.up)) throw new Error(tr('O progresso do backup é inválido.', 'Backup progress is invalid.'));
      next.hero = 'lupus'; next.ally = HERO[next.ally] && next.ally !== 'lupus' ? next.ally : 'vespera';
      if (!I18N[next.lang]) next.lang = 'en';
      next.shards = Math.floor(finite(next.shards, 0, 999999));
      for (const key of ['dmg','hp','fury','cd']) next.up[key] = Math.floor(finite(next.up[key], 0, 999));
      for (const key of ['stars','best','arch','owned','xp','pal','skins','skinOn','aff','sk']) if (!next[key] || typeof next[key] !== 'object' || Array.isArray(next[key])) next[key] = {};
      next.controls = window.ControlsUI ? ControlsUI.normalize(next.controls) : next.controls;
      const archives={};for(const key of Object.keys(next.arch)){const id=Number(key);if(Number.isInteger(id)&&id>=0&&id<ARCH_N&&next.arch[key])archives[id]=1;}next.arch=archives;
      for(const key of Object.keys(next.stars)){const id=Number(key);if(!Number.isInteger(id)||id<1||id>STAGES.length)delete next.stars[key];else next.stars[key]=Math.floor(finite(next.stars[key],0,7));}
      const before = JSON.stringify(SAVE), previous=SAVE;
      localStorage.setItem('lupus_reawakening_v2_backup90', before);
      try{SAVE=next;ensure();localStorage.setItem(SAVE_KEY,JSON.stringify(SAVE));}catch(writeError){SAVE=previous;throw writeError;}
      applyLang();
      if (document.documentElement) document.documentElement.lang = /^pt/i.test(SAVE.lang) ? 'pt-BR' : SAVE.lang;
      parked = hubReturn = null; if (window.Dialogue9) Dialogue9.stop();
      return { ok: true, message: tr('Backup importado. O save anterior foi preservado para recuperação.', 'Backup imported. The previous save was retained for recovery.') };
    } catch (e) { return { ok: false, error: String(e.message || e).slice(0, 220) }; }
  }
  function restoreBackup() {
    try { const raw = localStorage.getItem('lupus_reawakening_v2_backup90'); if (!raw) return false; const previous = safeTree(JSON.parse(raw)); if (!previous || !Number.isInteger(previous.unlocked)) return false; SAVE = previous; ensure(); saveGame(); applyLang(); parked = hubReturn = null; return true; } catch (_) { return false; }
  }
  function closeBackup() { if (backupDom && backupDom.remove) backupDom.remove(); backupDom = null; Inp.reset();if(window.RoomInput90)RoomInput90.reset();if(backupOwner&&Scene.cur===backupOwner&&!backupOwner.paused){if(window.Dialogue9&&Dialogue9.state.active)Dialogue9.resume();else if(backupOwner.introKey)backupOwner.introT=0;else if(backupOwner.dialog){backupOwner.dialog.started=false;backupOwner.dialog.t=0;}}backupOwner=null; }
  function openBackup(kind = 'export') {
    if (backupDom || !document.body || !document.createElement || !(Scene.cur && Scene.cur.freeInput90)) return false;
    const host = document.createElement('div'); host.id = 'lupus-save90';
    host.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(3,6,14,.98);color:#e8f4ff;font:16px system-ui;padding:16px;display:flex;flex-direction:column;gap:10px;box-sizing:border-box;touch-action:auto;overflow:auto';
    host.addEventListener('keydown',e=>{if(e.stopPropagation)e.stopPropagation();if(e.key==='Escape'){if(e.preventDefault)e.preventDefault();closeBackup();}});host.addEventListener('keyup',e=>{if(e.stopPropagation)e.stopPropagation();});
    const title = document.createElement('strong'); title.textContent = kind === 'import' ? tr('IMPORTAR PROGRESSO', 'IMPORT PROGRESS') : tr('EXPORTAR PROGRESSO', 'EXPORT PROGRESS'); host.appendChild(title);
    const note = document.createElement('p'); note.style.margin = '0'; note.textContent = kind === 'import' ? tr('Cole o backup completo. O save atual será guardado antes de importar.', 'Paste the complete backup. The current save will be backed up before import.') : tr('Copie este texto e guarde em um arquivo .json. Ele transfere o progresso entre instalações compatíveis.', 'Copy this text and keep it in a .json file. It transfers progress between compatible installations.'); host.appendChild(note);
    const area = document.createElement('textarea'); area.id = 'lupus-save90-text'; area.setAttribute('aria-label', title.textContent); area.style.cssText = 'flex:1;min-height:150px;width:100%;box-sizing:border-box;background:#0b1424;color:#e8f4ff;border:1px solid #48e6d4;border-radius:8px;padding:12px;font:12px monospace;user-select:text;-webkit-user-select:text;touch-action:auto'; area.value = kind === 'export' ? exportSave() : ''; area.readOnly = kind !== 'import'; host.appendChild(area);
    const result = document.createElement('p'); result.style.margin = '0'; result.setAttribute('role','status'); host.appendChild(result);
    const row = document.createElement('div'); row.style.cssText = 'display:flex;gap:10px;flex-wrap:wrap';
    const button = (label, fn) => { const b = document.createElement('button'); b.textContent = label; b.style.cssText = 'min-height:48px;min-width:120px;background:#172c42;color:#e8f4ff;border:1px solid #48e6d4;border-radius:8px;font:700 16px system-ui;padding:8px 16px'; b.onclick = fn; row.appendChild(b); return b; };
    if (kind === 'export') button(tr('COPIAR', 'COPY'), async () => { try { if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(area.value); result.textContent = tr('Backup copiado.', 'Backup copied.'); } else { if (area.focus) area.focus(); if (area.select) area.select(); const ok = document.execCommand && document.execCommand('copy'); result.textContent = ok ? tr('Backup copiado.', 'Backup copied.') : tr('Selecione o texto e use Copiar no seu aparelho.', 'Select the text and choose Copy on your device.'); } } catch (_) { result.textContent = tr('Selecione e copie o texto manualmente.', 'Select and copy the text manually.'); } });
    else button(tr('IMPORTAR BACKUP', 'IMPORT BACKUP'), () => { const r = importSave(area.value); result.textContent = r.ok ? r.message : r.error; if (r.ok) { closeBackup(); Scene.go('title'); } });
    button(tr('FECHAR', 'CLOSE'), closeBackup); host.appendChild(row); document.body.appendChild(host); backupDom = host; backupOwner = Scene.cur;
    if (window.Dialogue9) Dialogue9.pause(); Inp.reset(); return true;
  }

  function outcomeText(id) {const q=ensure().rooms[id];if(!q)return '';const labels={ 'witness-protected':tr('Testemunha protegida. O contato fornece uma pista para as válvulas.','Witness protected. The contact provides a valve-route hint.'), 'statement-recorded':tr('Depoimento arquivado. Mais dois fragmentos pela prova documentada.','Statement filed. Two extra shards for the documented evidence.'), 'conduit-drained':tr('Passagem de manutenção aberta. Arquivo de Nacht recuperado.','Maintenance passage opened. Nacht’s file recovered.'), 'signal-masked':tr('Sinal decifrado. Presenças na névoa ficam mais visíveis.','Signal decoded. Presences in the fog are easier to see.')};return labels[q.outcome]||tr('A prova foi guardada no diário.','The evidence was kept in the journal.');}
  const W = window.World90 = { version: VERSION, ensure, state: ensure, outcomeText, room, roomDefs: () => ROOM_IDS.map(id => DEF[id]), canEnter, canHub, capture, restore, enterRoom, updateRoom, completeRoom, checkpoint, resumeCheckpoint,
    openHub, openMap, resume: returnToField, returnToField, travel, routes, graph, canUseShortcut, useShortcut, unlockShortcut, hasShortcut, hasQuest: id => !!ensure().rooms[id] && !!ensure().rooms[id].completed,
    exportSave, importSave, restoreBackup, openBackup, closeBackup, releaseRoomArt, isBackupOpen: () => !!backupDom, snapshot: () => ({ state: clone(ensure()), routes: routes(), canHub: canHub(), parked: parked && parked.name || null, graph: graph() }) };

  function hubModal(kind) {
    const s = Scenes.world90; s.modal = kind; s.focus = 0; s.page = 0;
    if (window.RoomInput90) RoomInput90.reset();
  }
  const hubPoints = [
    { id: 'map', x: 115, y: 112, label: () => tr('DISTRITOS', 'DISTRICTS') },
    { id: 'rest', x: 350, y: 112, label: () => tr('RECUPERAR', 'RECOVER') },
    { id: 'archives', x: 125, y: 190, label: () => tr('ARQUIVOS', 'ARCHIVES') },
    { id: 'journal', x: 350, y: 180, label: () => tr('CASOS', 'CASES') },
    { id: 'exit', x: 240, y: 246, label: () => tr('VOLTAR', 'RETURN') }
  ];
  Scenes.world90 = {
    freeInput90: true, t: 0, paused: false, modal: null, focus: 0, page: 0, btns: [],
    enter(o) {
      ensure(); this.returnTo = o && o.returnTo || capture(Scenes.title, 'title'); this.x = 240; this.y = 190; this.dir = 1; this.walk = 0; this.t = 0; this.modal = null; this.paused = false; this.focus = this.page = 0; this.toast = ''; this.toastT = 0;
      releaseRoomArt(['hub']);Q90.image('hub'); Q90.image('rpg_john'); if (window.RoomInput90) RoomInput90.reset();
      if (!ensure().hubSeen) { this.introKey = 'w90_hub_entry'; this.introT = 0; }
      else this.introKey = '';
    },
    openMap() { hubModal('map'); },
    update(dt) {
      if (document.hidden || backupDom) return;
      this.moving=false;
      const input = window.RoomInput90 ? RoomInput90.sample(dt) : { x: 0, y: 0 };
      if (this.paused || this.modal) { this.layout(); this.menuInput(input); return; }
      this.t += dt; this.toastT = Math.max(0, this.toastT - dt);
      if (input.back) { this.paused = true; this.focus = 0; if(window.Dialogue9)Dialogue9.pause(); return; }
      if (!Q90.ready(['hub','rpg_john'])) return;
      if (this.introKey && window.RoomUI90) {
        if (!this.introT) { RoomUI90.speak(this.introKey);ensure().hubSeen=true;persist(); } this.introT += dt;
        if (input.act || this.introT > RoomUI90.duration(this.introKey) + 0.5) { this.introKey = ''; if (window.Dialogue9) Dialogue9.stop(); }
        return;
      }
      const n = Math.hypot(input.x, input.y); if (n > 0.1) { this.moving=true;this.walk += dt * 7; this.dir = Math.abs(input.x) > Math.abs(input.y) ? input.x > 0 ? 2 : 3 : input.y > 0 ? 0 : 1; const nx=this.x+input.x*80*dt,ny=this.y+input.y*80*dt;if(!this.collide(nx,this.y))this.x=nx;if(!this.collide(this.x,ny))this.y=ny; }
      if (input.act) { const p = this.nearest(); if (p) this.activate(p.id); }
    },
    collide(x,y){if(x<45||x>435||y<90||y>246)return true;const rects=[{x:12,y:75,w:56,h:133},{x:64,y:155,w:75,h:52},{x:350,y:140,w:85,h:67},{x:345,y:66,w:82,h:40},{x:84,y:73,w:65,h:38},{x:44,y:234,w:151,h:20},{x:285,y:234,w:151,h:20}];return rects.some(o=>x+8>o.x&&x-8<o.x+o.w&&y+5>o.y&&y-5<o.y+o.h);},
    nearest() { let best = null, d = 48; for (const p of hubPoints) { const v = Math.hypot(this.x - p.x, this.y - p.y); if (v < d) { d = v; best = p; } } return best; },
    activate(id) {
      if (id === 'exit') returnToField();
      else if (id === 'rest') {
        const game = hubReturn && hubReturn.name === 'play' ? hubReturn.game : null;
        if (game && game.team) { for (const h of game.team) if (!h.dead) h.hp = h.maxhp; checkpoint(true); this.toast = tr('Ferimentos tratados. Sua fúria foi preservada.', 'Wounds treated. Fury preserved.'); }
        else this.toast = tr('O refúgio está pronto para sua próxima missão.', 'The refuge is ready for your next mission.');
        this.toastT = 3; sfx('pick');
      } else hubModal(id);
    },
    layout() {
      const list = [], x = VW / 2 - 168, y = 53;
      const add = (id, label, yy, disabled) => list.push({ id, label, x, y: yy, w: 336, h: 25, disabled: !!disabled });
      if (this.paused) {
        add('resume', tr('CONTINUAR', 'RESUME'), 72); add('export', tr('EXPORTAR PROGRESSO', 'EXPORT PROGRESS'), 103); add('import', tr('IMPORTAR PROGRESSO', 'IMPORT PROGRESS'), 134); add('field', tr('VOLTAR À ORIGEM', 'RETURN TO ORIGIN'), 165);
      } else if (this.modal === 'map') {
        add('checkpoint', tr('RETOMAR CHECKPOINT SALVO', 'RESUME SAVED CHECKPOINT'), y, !ensure().checkpoint);
        const next = Math.min(STAGES.length - 1, (SAVE.unlocked || 1) - 1), st = STAGES[next];
        add('next', tr('CAPÍTULO ', 'CHAPTER ') + st.id + ': ' + (st.name[SAVE.lang] || st.name.en || ''), y + 26);
        ROOM_IDS.forEach((id, i) => add('room:' + id, (ensure().rooms[id].completed ? '✓ ' : '') + DEF[id].district() + ' • ' + DEF[id].name() + (!canEnter(id) ? tr(' [CAP. ', ' [CH. ') + DEF[id].unlock + ']' : ''), y + 52 + i * 26, !canEnter(id)));
        const roof=canUseShortcut();if(roof)add('shortcut',tr('ATALHO: TELHADOS DO LESTE','SHORTCUT: EAST ROOFTOPS'),y+130);
        add('chapters', tr('MAPA DA CAMPANHA', 'CAMPAIGN MAP'), y + (roof?156:130)); add('close', tr('VOLTAR AO REFÚGIO', 'BACK TO REFUGE'), y + (roof?182:156));for(const b of list)b.h=24;
      } else if (this.modal === 'journal') {
        ROOM_IDS.forEach((id, i) => add('case:' + id, (ensure().rooms[id].completed ? '✓ ' : '○ ') + DEF[id].name(), y + i * 32));
        add('export', tr('EXPORTAR PROGRESSO', 'EXPORT PROGRESS'), y + 104); add('import', tr('IMPORTAR PROGRESSO', 'IMPORT PROGRESS'), y + 134); add('close', tr('VOLTAR AO REFÚGIO', 'BACK TO REFUGE'), y + 166);
      } else if (this.modal === 'archives') {
        const ids = Object.keys(SAVE.arch || {}).map(Number).filter(n => Number.isInteger(n) && n >= 0 && n < ARCH_N && SAVE.arch[n]).sort((a,b) => a-b);
        this.archiveIds = ids; if (ids.length) { this.page = clamp(this.page, 0, ids.length - 1); add('prev', tr('◀ ARQUIVO ANTERIOR', '◀ PREVIOUS FILE'), 196); add('nextArch', tr('PRÓXIMO ARQUIVO ▶', 'NEXT FILE ▶'), 225); }
        add('close', tr('VOLTAR', 'BACK'), ids.length ? 15 : 196);
      } else if (this.modal && this.modal.indexOf('case:') === 0) add('closeCase', tr('VOLTAR AOS CASOS', 'BACK TO CASES'), 215);
      this.btns = list; this.focus = clamp(this.focus, 0, Math.max(0, list.length - 1)); return list;
    },
    choose(b) {
      if (!b || b.disabled) { sfx('ui'); return; }
      const id = b.id;
      if (id === 'resume') { this.paused = false; if(this.introKey){this.introT=0;if(window.Dialogue9)Dialogue9.stop();} }
      else if (id === 'export' || id === 'import') openBackup(id);
      else if (id === 'field') returnToField();
      else if (id === 'checkpoint') resumeCheckpoint();
      else if (id === 'shortcut') useShortcut();
      else if (id === 'next') travel(Math.min(STAGES.length - 1, (SAVE.unlocked || 1) - 1));
      else if (id.startsWith('room:')) enterRoom(id.slice(5), { source: 'hub' });
      else if (id === 'chapters') { parked = hubReturn = null; Scene.go('stages'); }
      else if (id === 'close') { this.modal = null; this.focus = 0; }
      else if (id === 'closeCase') hubModal('journal');
      else if (id.startsWith('case:')) { this.modal = id; this.focus = 0; }
      else if (id === 'prev') this.page--;
      else if (id === 'nextArch') this.page++;
      Inp.edge = {}; sfx('ui');
    },
    menuInput(input) {
      if (input.back) { this.paused = false; this.modal = null; this.focus = 0; if(this.introKey)this.introT=0; return; }
      if (input.navY) this.focus = (this.focus + input.navY + this.btns.length) % Math.max(1, this.btns.length);
      if (this.modal === 'archives' && input.navX) this.page += input.navX;
      if (input.act) this.choose(this.btns[this.focus]);
    },
    draw(g) {
      g.fillStyle = '#030812'; g.fillRect(0,0,VW,VH);
      const b = window.RoomUI90 ? RoomUI90.mapBox() : { x: (VW - 480) / 2, y: 0 };
      const im = Q90.image('hub'); if (im && im.ok) g.drawImage(im, b.x, b.y, 480,270);
      if (window.RoomUI90) { for (const p of hubPoints) RoomUI90.marker(g, b.x + p.x, p.y, p.id === 'exit' ? '#d9b7ff' : '#55e4d2', this.t, this.nearest() === p); RoomUI90.actor(g, b.x + this.x, this.y, this.dir, this.moving?this.walk:0); }
    },
    drawHD(c) {
      if (!window.RoomUI90) return;
      const U = RoomUI90; U.begin(c);
      U.header(c, tr('REFÚGIO DE CAMPO', 'FIELD REFUGE'), tr('Descubra caminhos. Guarde evidências.', 'Discover routes. Keep the evidence.'));
      if (!Q90.ready(['hub','rpg_john'])) U.loading(c, ['hub','rpg_john']);
      else if (this.paused || this.modal) {
        this.layout(); U.modal(c, this.paused ? tr('PAUSA • REFÚGIO', 'PAUSED • REFUGE') : this.modal === 'map' ? tr('DISTRITOS CONECTADOS', 'CONNECTED DISTRICTS') : this.modal === 'archives' ? tr('ARQUIVOS • ', 'ARCHIVES • ') + Object.keys(SAVE.arch || {}).length + '/' + ARCH_N : tr('DIÁRIO DE CASOS', 'CASE JOURNAL'));
        if (this.modal === 'archives' && this.archiveIds && this.archiveIds.length) { const id = this.archiveIds[clamp(this.page,0,this.archiveIds.length-1)]; U.text(c, CT('arT' + id), 48, 65, VW-96, 11, '#ffda83', 2); U.text(c, CT('arB' + id), 48, 97, VW-96, 8.7, '#e4edf5', 8); }
        else if (this.modal === 'archives') U.text(c, tr('Encontre os arquivos da Thule durante as missões e investigações.', 'Find Thule files during missions and investigations.'), 62,92,VW-124,10,'#c8d8e8',5);
        if (this.modal && this.modal.startsWith('case:')) { const id = this.modal.slice(5), d=DEF[id], q=ensure().rooms[id]; U.text(c,d.name(),48,65,VW-96,12,'#ffda83',2); U.text(c,d.task(),48,102,VW-96,9,'#e4edf5',3); U.text(c,q.completed ? tr('CONCLUÍDO • ', 'COMPLETE • ') + outcomeText(id) : canEnter(id) ? tr('Investigue a entrada no distrito ou viaje pelo mapa do refúgio.', 'Investigate the district entrance or travel using the refuge map.') : tr('Disponível após alcançar o capítulo ', 'Available after reaching chapter ') + d.unlock,48,151,VW-96,9,'#77ead0',3); }
        this.btns.forEach((b,i)=>U.button(c,b,i===this.focus));
      } else if (this.introKey) U.dialog(c, { key: this.introKey }, []);
      else { const p=this.nearest(); U.controls(c,p ? p.label() : tr('APROXIME-SE DE UM PONTO', 'APPROACH A POINT')); U.pauseButton(c); }
      if (this.toastT > 0) U.toast(c,this.toast);
      U.end(c);
    },
    onDown(id,x,y) {
      if (backupDom) return;
      if (!window.RoomUI90 || !window.RoomInput90) return;
      if (this.paused || this.modal) { this.layout(); const b=this.btns.find(v=>RoomUI90.inside(v,x,y)); if(b)this.choose(b); return; }
      if (this.introKey) { this.introKey = ''; if(window.Dialogue9)Dialogue9.stop(); return; }
      if(RoomUI90.pauseHit(x,y)){this.paused=true;this.focus=0;return;}
      RoomInput90.down(id,x,y);
    },
    onMove(id,x,y){if(window.RoomInput90)RoomInput90.move(id,x,y);}, onUp(id){if(window.RoomInput90)RoomInput90.up(id);},
    onKey(key) { if(backupDom){if(key==='hide'){this.paused=true;if(window.Dialogue9)Dialogue9.pause();}else if(key==='pause')closeBackup();return;} if(key==='hide'){this.paused=true;if(window.Dialogue9)Dialogue9.pause();return;} if(key==='pause'){this.paused=!this.paused;this.modal=null;this.focus=0;if(window.Dialogue9){if(this.paused)Dialogue9.pause();else if(this.introKey){this.introT=0;Dialogue9.stop();}}if(window.RoomInput90)RoomInput90.reset();return;} if(key==='ok'){if(this.introKey){this.introKey='';if(window.Dialogue9)Dialogue9.stop();}else if(this.paused||this.modal){this.layout();this.choose(this.btns[this.focus]);}else {const p=this.nearest();if(p)this.activate(p.id);}} }
  };

  // Game-bound delayed story callbacks stop with the field, including side rooms,
  // the protected Nacht beat, pause and application backgrounding.
  let timerId90 = 0;
  later = function (fn, ms) {
    const target = G;
    if (!target) return setTimeout(fn, ms);
    const q = target._timers90 || (target._timers90 = []), token = ++timerId90;
    q.push({ id: token, left: Math.max(0, (+ms || 0) / 1000), fn }); return token;
  };
  const enterPlay = Scenes.play.enter, updatePlay = Scenes.play.update;
  Scenes.play.enter = function (arg) {
    const r = enterPlay.apply(this, arguments), c = arg && arg.restore90;
    ensure();
    if (c && G && c.stage === G.stage) { const p=G.player; p.x=finite(c.x,14,WORLD_W-14,70);p.y=finite(c.y,LANE_T,LANE_B,232);G.camX=finite(c.cam,0,Math.max(0,WORLD_W-VW));p.fury=finite(c.fury,0,300);if(['h','f','a'].includes(c.form)&&!G.st.l44)p.form=c.form;if(G.clues&&Array.isArray(c.clues)){G.clues.forEach((q,i)=>q.got=c.clues[i]===true);G.clueN=G.clues.filter(q=>q.got).length;}G._restored90=true; }
    if(arg&&arg.entry90==='roof-east'&&window.Traversal90&&hasShortcut('rooftop-courier')&&G&&G.stage===2&&G.waveIdx>=4)Traversal90.enterShortcut('roof-east');
    if(G&&G.stage===1&&ensure().rooms.alley.completed&&G.clues&&G.clues[0]&&!G.clues[0].got){G.clues[0].got=true;G.clueN=(G.clueN||0)+1;}
    return r;
  };
  Scenes.play.update = function (dt) {
    if (document.hidden || backupDom) return;
    const before = G;
    if (G && !this.menu && !G.panel && !G.choice && !G.nachtBeat90 && !G.vesperaBeat && !G.over && !G.clearT) {
      const list=G._timers90 || []; for(const t of list)t.left-=dt;
      const due=list.filter(t=>t.left<=0);G._timers90=list.filter(t=>t.left>0);
      for(const t of due){if(G!==before||Scene.cur!==this)break;try{t.fn();}catch(e){console.error(e);}}
    }
    const r = updatePlay.apply(this, arguments);
    if (G === before && Scene.cur === this && !this.menu && !G.mode && !G.locked && !G.over && !G.clearT && !G.panel && !G.choice && G.title <= 0 && G._checkpoint90 !== G.ck) { G._checkpoint90=G.ck; checkpoint(); }
    return r;
  };
  const fogAlpha = MECH.fog && MECH.fog.entAlpha;
  if (fogAlpha) MECH.fog.entAlpha = function (e) { const a=fogAlpha.apply(this,arguments);return a!=null && e.type==='P' && hasShortcut('cathedral-signal') ? Math.max(a,0.45) : a; };
  ensure();
})();
