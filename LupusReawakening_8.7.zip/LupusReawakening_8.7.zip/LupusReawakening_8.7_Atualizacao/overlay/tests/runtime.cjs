/* A headless WebView-like host for the unbundled game scripts.
 * Real @napi-rs/canvas images and rendering; deterministic clock and RNG.
 * Audio is deliberately mocked: these tests cannot measure audible timing.
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const moduleRoot = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
let canvasModule;
try { canvasModule = require('@napi-rs/canvas'); }
catch (e) {
  if (!moduleRoot) throw new Error('Install @napi-rs/canvas, or set CODEX_PRIMARY_RUNTIME_NODE_MODULES.');
  canvasModule = require(path.join(moduleRoot, '@napi-rs/canvas'));
}
const { createCanvas, Image: NativeImage } = canvasModule;
const DEFAULT_GAME = path.resolve(__dirname, '../src/LupusReawakening-Android/app/src/main/assets/game');

function createRuntime(options = {}) {
  const root = options.root || process.env.LUPUS_GAME_ROOT || DEFAULT_GAME;
  const pending = new Set(), missing = new Set(), errors = [], listeners = {};
  const storage = new Map(Object.entries(options.storage || {})), timers = new Map();
  const audioEvents = [], audioObjects = [], gamepads = [];
  let timerId = 1, randomState = options.seed || 71942;
  const math = Object.create(Math);
  math.random = () => { randomState = (1664525 * randomState + 1013904223) >>> 0; return randomState / 4294967296; };
  class Image extends NativeImage {
    constructor() { super(); this.listeners = {}; this._src = ''; }
    addEventListener(n, f) { (this.listeners[n] ||= []).push(f); }
    removeEventListener(n, f) { this.listeners[n] = (this.listeners[n] || []).filter(fn => fn !== f); }
    get src() { return this._src; }
    set src(v) {
      // Browsers cancel an in-flight request when src is cleared/replaced.
      // Release its waiter as well, so a scene's intentional eviction is not a hang.
      this._finishPending?.(); this._finishPending = null;
      this._src = v;
      if (!v) return;
      const target = path.resolve(root, v);
      if (!fs.existsSync(target)) missing.add(v);
      const onload = this.onload, onerror = this.onerror;
      let resolve;
      const p = new Promise(r => resolve = r); pending.add(p);
      let finished = false;
      const finish = () => { if (!finished) { finished = true; pending.delete(p); resolve(); } };
      this._finishPending = finish;
      this.onload = () => { try { onload?.(); for (const f of this.listeners.load || []) f(); } catch (e) { errors.push(e); } finally { finish(); } };
      this.onerror = e => { try { onerror?.(e); for (const f of this.listeners.error || []) f(e); } catch (e) { errors.push(e); } finally { finish(); } };
      try { super.src = target; } catch (e) { this.onerror(e); }
    }
  }
  function canvas() {
    const c = createCanvas(1, 1);
    c.style = {};
    c.addEventListener = (n, f) => (listeners['canvas:' + n] ||= []).push(f);
    c.removeEventListener = () => {};
    c.setPointerCapture = c.releasePointerCapture = () => {};
    c.getBoundingClientRect = () => ({ left: 0, top: 0, width: s.innerWidth, height: s.innerHeight });
    return c;
  }
  class Audio {
    constructor(src) { this.src = src || ''; this.paused = true; this.volume = 1; this.currentTime = 0; this.duration = 3; this.readyState = 4; this.listeners = {}; audioObjects.push(this); }
    play() { this.paused = false; audioEvents.push({ event: 'play', src: this.src, time: s.time }); return Promise.resolve(); }
    pause() { this.paused = true; audioEvents.push({ event: 'pause', src: this.src, time: s.time }); }
    load() {}
    addEventListener(n, f) { (this.listeners[n] ||= []).push(f); }
    removeEventListener(n, f) { this.listeners[n] = (this.listeners[n] || []).filter(fn => fn !== f); }
    emit(n) { if (n === 'ended') this.paused = true; for (const f of this.listeners[n] || []) f(); if (this['on' + n]) this['on' + n](); }
  }
  // Minimal structural DOM for the control editor. Layout, CSS and native
  // accessibility still need browser/device testing; event wiring is exercised.
  class Element {
    constructor(tag) { this.tagName = tag.toUpperCase(); this.style = {}; this.dataset = {}; this.children = []; this.attributes = {}; this.listeners = {}; this.value = ''; this.textContent = ''; }
    appendChild(child) { child.parentNode = this; this.children.push(child); return child; }
    append(...children) { children.forEach(child => this.appendChild(child)); }
    remove() { if (this.parentNode) this.parentNode.children = this.parentNode.children.filter(child => child !== this); this.parentNode = null; }
    setAttribute(name, value) { this.attributes[name] = String(value); }
    addEventListener(name, fn) { (this.listeners[name] ||= []).push(fn); }
    removeEventListener(name, fn) { this.listeners[name] = (this.listeners[name] || []).filter(f => f !== fn); }
    querySelectorAll(selector) {
      const match = element => {
        const data = /^\[data-([a-z-]+)="([^"]+)"\]$/.exec(selector);
        if (data) return element.dataset[data[1].replace(/-([a-z])/g, (_, c) => c.toUpperCase())] === data[2];
        if (selector.startsWith('#')) return element.id === selector.slice(1);
        return element.tagName.toLowerCase() === selector.toLowerCase();
      };
      const out = [];
      for (const child of this.children) { if (match(child)) out.push(child); out.push(...child.querySelectorAll(selector)); }
      return out;
    }
    querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
    click() { this.onclick?.({ target: this }); }
  }
  const cv = canvas();
  const s = {
    console, Math: math, Image, Audio, time: 0, innerWidth: options.width || 960, innerHeight: options.height || 540,
    devicePixelRatio: options.dpr || 1,
    performance: { now: () => s.time },
    navigator: { vibrate: () => {}, getGamepads: () => gamepads },
    getComputedStyle: () => ({ paddingLeft: '0px', paddingRight: '0px', paddingTop: '0px', paddingBottom: '0px' }),
    localStorage: { getItem: k => storage.has(k) ? storage.get(k) : null, setItem: (k, v) => storage.set(k, String(v)), removeItem: k => storage.delete(k), clear: () => storage.clear() },
    addEventListener: (n, f) => (listeners[n] ||= []).push(f),
    requestAnimationFrame: () => 1, cancelAnimationFrame: () => {},
    setTimeout: (f, ms) => { const id = timerId++; timers.set(id, { f, at: s.time + (ms || 0) }); return id; },
    clearTimeout: id => timers.delete(id),
    setInterval: () => timerId++, clearInterval: () => {},
  };
  const body = new Element('body');
  s.document = { hidden: false, body, getElementById: id => id === 'c' ? cv : body.querySelector('#' + id), createElement: t => t === 'canvas' ? canvas() : new Element(t), addEventListener: (n, f) => (listeners['document:' + n] ||= []).push(f), documentElement: new Element('html') };
  s.window = s;
  vm.createContext(s);
  const run = code => vm.runInContext(code, s);
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  for (const m of html.matchAll(/src="(js\/[^\"]+)"/g)) vm.runInContext(fs.readFileSync(path.join(root, m[1]), 'utf8'), s, { filename: m[1] });
  async function settle() {
    for (let i = 0; i < 40 && pending.size; i++) await Promise.all([...pending]);
    if (pending.size) throw new Error('Image load did not settle.');
    if (errors.length) throw errors.shift();
  }
  function tick(n = 1, draw = false) {
    for (let i = 0; i < n; i++) {
      s.time += 1000 / 60;
      for (const [id, t] of [...timers]) if (t.at <= s.time) { timers.delete(id); t.f(); }
      run(draw ? `frame(${s.time})` : 'Scene.cur.update(1/60)');
    }
  }
  function dispatch(name, event = {}, target = '') {
    const e = { preventDefault() {}, ...event };
    for (const f of listeners[target + name] || []) f(e);
  }
  function resize(width, height = 540) { s.innerWidth = width; s.innerHeight = height; dispatch('resize'); }
  function snapshot(file) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, cv.toBuffer('image/png')); }
  const json = code => JSON.parse(run(`JSON.stringify(${code})`));
  async function play(stage, args = {}) {
    run(`Scene.go('play',${JSON.stringify({ stage, ...args })})`);
    await settle();
    for (let i = 0; i < 90 && run('Scene.name') === 'prep'; i++) { tick(); await settle(); }
    if (run('Scene.name') !== 'play') throw new Error(`Failed to enter stage ${stage + 1}: ${run('Scene.name')}`);
  }
  return { root, s, run, json, settle, tick, dispatch, resize, snapshot, play, missing, errors, listeners, storage, timers, cv, gamepads, audioEvents, audioObjects };
}
module.exports = { createRuntime, DEFAULT_GAME };
