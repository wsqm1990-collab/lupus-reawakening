# LUPUS: REAWAKENING — Projeto Android

Beat 'em up / Action RPG 2D feito em HTML5 Canvas, empacotado num app Android nativo (WebView), 100% offline.
O jogo fica em `app/src/main/assets/game/`, com as artes do pacote #1–#77 já recortadas, alinhadas e convertidas em atlas WebP.

## Gerar o APK — opção 1: Android Studio (mais simples)
1. Instale o Android Studio (Koala ou mais novo).
2. File ▸ Open ▸ selecione esta pasta `LupusReawakening-Android`.
3. Aguarde o Gradle sincronizar (ele baixa o SDK/plugins na primeira vez).
4. Build ▸ Build App Bundle(s) / APK(s) ▸ **Build APK(s)**.
5. O APK sai em `app/build/outputs/apk/debug/app-debug.apk` — copie para o celular e instale
   (habilite "Instalar apps de fontes desconhecidas").

## Gerar o APK — opção 2: linha de comando
Com JDK 17 e o Android SDK instalados (variável `ANDROID_HOME` ou arquivo `local.properties` com `sdk.dir=...`):
```
./gradlew assembleDebug      # APK de teste
./gradlew assembleRelease    # APK release, com a mesma assinatura das versões anteriores
```

## Gerar o APK — opção 3: GitHub (sem instalar nada)
1. O projeto editável fica em `src/LupusReawakening-Android`, no repositório principal.
2. A aba **Actions** roda o workflow `Build APK` nos pushes da branch principal e nas pull requests. O workflow usa os fontes editáveis; os ZIPs antigos são apenas uma alternativa de importação quando essa pasta não existe.
3. Baixe o APK em Actions ▸ (execução mais recente) ▸ Artifacts ▸ `LupusReawakening-apk`.
4. Publicar em **Releases** é uma opção separada em **Run workflow**, disponível somente na branch principal. A compilação normal não publica uma versão.

Antes de compilar, o workflow roda os testes de regressão, campanha e diálogos disponíveis no repositório, usando Node 20 e `@napi-rs/canvas` 0.1.100. O APK entregue pelo workflow é **release**, assinado e sem modo de depuração, após `assembleRelease` e `lintRelease`. O pacote de artefatos inclui a soma SHA-256.

## Publicar na Play Store
Configure a assinatura de publicação em `app/build.gradle` e gere um `.aab`.
Para atualizar as instalações atuais por APK e manter o progresso, preserve a chave já usada pelo projeto e o mesmo `applicationId`. A versão 8.7 usa `versionCode 23` e pode atualizar a 8.6 sem remover o aplicativo.

As senhas não ficam no código. A assinatura lê um arquivo local `signing.properties` (ignorado pelo Git), com `storeFile`, `storePassword`, `keyAlias` e `keyPassword`, ou as variáveis de ambiente `LUPUS_KEYSTORE_FILE`, `LUPUS_STORE_PASSWORD`, `LUPUS_KEY_ALIAS` e `LUPUS_KEY_PASSWORD`. O caminho da chave é relativo à raiz deste projeto Android. Para recuperar a assinatura da instalação existente a partir dos arquivos ZIP históricos deste repositório, execute `python3 tools/restore_signing.py --project . --archives ../..`; o workflow já faz essa recuperação sem exibir credenciais. APKs release exigem a assinatura configurada. Sem ela, APKs debug usam apenas a chave de desenvolvimento local do Android.

## Controles
- Analógico virtual (lado esquerdo), ATK, ▲ pular, » esquiva, ESPECIAL, FORMA (só Lupus).
- Botões em vidro translúcido HD com ícones vetoriais dedicados e visibilidade contextual inteligente (botões secundários como FORMA, SENTIDOS, TROCA, AJUDA e SUPER aparecem apenas quando estão prontos ou quando há pista/arquivo por perto).
- Em **Opções → Controles** (ou na Pausa), ajuste a **Visibilidade Geral (Transparência)** com presets rápidos (`28%`, `48%` padrão ou `78%`), além da opacidade e tamanho individual de cada botão.
- Segure ATK para combo automático. Esquivar através de um golpe com o Lupus = CONTRA-ATAQUE (+Fúria).
- Teclado (emulador/Chromebook): setas/WASD, J ataque, K pulo, L especial, Espaço esquiva, E forma, P pausa.
- Controle Bluetooth/USB: a camada Android encaminha os eixos, gatilhos, direcional e botões no mapeamento padrão para `window.LupusGamepad.update`. Desconectar ou deixar o app em segundo plano limpa os botões pressionados.
- Na pausa (renderizada em alta definição nativa), objetivo, instruções e desafios têm rolagem própria: arraste, use a roda do mouse, PgUp/PgDown ou LB/RB. Start continua alternando entre pausa e jogo; ações e configurações ficam separadas do texto da missão.

## Vozes e ciclo de vida no Android

As falas usam um canal exclusivo de `MediaPlayer`, que aceita narrações longas e permite interromper a gravação ao avançar um diálogo. Efeitos curtos continuam no `SoundPool`.

O JavaScript dispõe de `LupusAudio.playVoice(caminho, volume)`, `stopVoices()`, `pauseVoices()`, `resumeVoices()` e `isVoicePlaying()`; a última retorna verdadeiro também enquanto uma fala está sendo preparada ou pausada. Ao deixar o app em segundo plano, o Android interrompe a fala e dispara o evento `lupus:pause` para o jogo.

## Idioma e narração — 8.7

A fala da libertação foi atualizada para “Ninguém vai fazer isso comigo de novo.” em português brasileiro e “No one will ever do this to me again.” em inglês, com novas gravações nos dois idiomas.

Instalações novas começam com interface e narração em inglês. Em **Settings → Language → Português**, o jogador seleciona interface em português e narração em português brasileiro. Os outros dez idiomas disponíveis mantêm suas traduções de interface e usam a narração inglesa. As gravações dos dois idiomas narrados ficam no APK e funcionam offline; as vozes curtas originais de combate continuam em inglês.

Uma escolha explícita de idioma é preservada ao atualizar. A preferência antiga de português que era apenas o padrão automático da 8.2 migra uma única vez para o novo padrão inglês. Trocar o idioma interrompe a gravação anterior, e a próxima fala usa o idioma selecionado.

Os testes automatizados do jogo simulam a ponte de áudio e os controles Android. Para verificar reprodução, interrupções, toque, desempenho e controle Bluetooth, é necessário testar o APK em um aparelho.

## Sistema de transformação (Lupus)
- **Humano moderno**: rápido, combos e Corrente no especial, usando a animação desenhada no atlas e um alcance de dano alinhado ao desenho. Acumula Fúria ao bater/apanhar.
- **Humano de 1944**: usa Urro de curto alcance no especial, com breve atordoamento dos inimigos próximos. Essa habilidade também vale para a aparência de 1944 usada em outras fases. As correntes e algemas sobrepostas da 8.3 foram retiradas.
- **Feral** (Fúria ≥ 1/3): mais dano, 25% de armadura, regeneração, Urro Sangrento (atordoa em área). Gasta Fúria devagar.
- **Ascendido** (Fúria ≥ 2/3): golpes velozes com sangramento, 50% de armadura, sem recuo,
  Dilaceração (dispara espinhos em área). Consome a Fúria rápido.
