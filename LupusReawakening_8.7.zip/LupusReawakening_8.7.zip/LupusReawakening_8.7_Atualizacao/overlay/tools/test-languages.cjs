'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { createRuntime } = require('../tests/runtime.cjs');
const SAVE_KEY = 'lupus_reawakening_v2';

async function runtime(saved) {
  const r = createRuntime(saved ? { storage: { [SAVE_KEY]: JSON.stringify(saved) } } : {});
  await r.settle(); return r;
}
async function main() {
  const cases = [
    ['fresh install', null, 'en'],
    ['8.2 unchosen Portuguese default', { lang: 'pt', langV5: true, v8: true }, 'en'],
    ['explicit Portuguese choice', { lang: 'pt', langSet: true, v8: true }, 'pt'],
    ['explicit English choice', { lang: 'en', langSet: true, v8: true }, 'en'],
    ['older non-default language', { lang: 'it', v8: true }, 'it'],
    ['already migrated save', { lang: 'pt', langV9: true, v8: true }, 'pt'],
    ['unsupported saved language', { lang: 'xx', langSet: true, v8: true }, 'en'],
  ];
  for (const [name, saved, expected] of cases) {
    const r = await runtime(saved);
    assert.equal(r.run('SAVE.lang'), expected, name);
    assert.equal(r.run('SAVE.langV9'), true, name + ': migration marker');
    assert.equal(r.run('document.documentElement.lang'), expected === 'pt' ? 'pt-BR' : expected, name + ': document language');
    assert.equal(r.run('LANGS[0]'), 'en');
  }
  const r = await runtime();
  r.run("Scene.go('title'); Scenes.title.opts=true; Scenes.title.langPick=true; Scenes.title.layout(); {const b=Scenes.title.btns.find(b=>b.id==='L_pt'); Scenes.title.onDown(1,b.x+b.w/2,b.y+b.h/2);}");
  assert.equal(r.run('SAVE.lang'), 'pt'); assert.equal(r.run('SAVE.langSet'), true);
  assert.equal(r.run("CT('i01a')"), '1944. UMA GUERRA QUE NENHUM LIVRO DE HISTÓRIA LEMBRA.');
  assert.equal(r.run('Dialogue9.language'), 'pt-BR');
  assert.equal(r.run("Dialogue9.lines.i01a.file"), 'assets/voice/dialogue/i01a.ogg');
  r.run('resetProgress()'); assert.equal(r.run('SAVE.lang'), 'pt'); assert.equal(r.run('SAVE.langSet'), true);
  const restarted = await runtime(JSON.parse(r.storage.get(SAVE_KEY)));
  assert.equal(restarted.run('SAVE.lang'), 'pt', 'a selected Portuguese preference survives reset and app restart');
  r.run("Scenes.title.opts=true; Scenes.title.langPick=true; Scenes.title.layout(); {const b=Scenes.title.btns.find(b=>b.id==='L_en'); Scenes.title.onDown(2,b.x+b.w/2,b.y+b.h/2);}");
  assert.equal(r.run('Dialogue9.language'), 'en');
  assert.equal(r.run("CT('i01a')"), '1944. A WAR NO HISTORY BOOK REMEMBERS.');
  const englishLines = r.run('Object.keys(Dialogue9.lines).length');
  if (process.env.LUPUS_ALLOW_INCOMPLETE_EN !== '1') assert.equal(englishLines, 296, 'all English recordings must be integrated before release');
  if (englishLines) assert.equal(r.run("Dialogue9.lines.i01a.file"), 'assets/voice/dialogue/en/i01a.ogg');
  const packaged = {};
  for (const lang of ['en', 'pt']) {
    r.run(`setLang('${lang}')`); const bank = r.json('Dialogue9.lines'); packaged[lang] = Object.keys(bank).length;
    if (process.env.LUPUS_ALLOW_INCOMPLETE_EN !== '1') assert.equal(packaged[lang], 296);
    for (const [key, line] of Object.entries(bank)) {
      assert.equal(line.file, 'assets/voice/dialogue/' + (lang === 'en' ? 'en/' : '') + key + '.ogg', lang + ': wrong language path');
      assert.ok(line.duration > 0.15 && line.speaker, lang + ': missing timing or speaker for ' + key);
      assert.ok(fs.statSync(path.join(r.root, line.file)).size > 100, lang + ': missing packaged recording ' + key);
    }
  }
  for (const lang of r.json('LANGS')) {
    r.run(`setLang('${lang}')`);
    assert.equal(r.run('Dialogue9.language'), lang === 'pt' ? 'pt-BR' : 'en', lang + ': wrong narration language');
  }
  r.run("setLang('es')"); assert.equal(r.run('SAVE.lang'), 'es'); assert.equal(r.run('Dialogue9.language'), 'en');
  assert.equal(r.run("setLang('xx')"), false); assert.equal(r.run('SAVE.lang'), 'es');
  console.log(JSON.stringify({ languageMigrationCases: cases.length, selectedPreferenceSurvivesResetAndRestart: true,
    dynamicSubtitleAndVoiceSelection: true, packagedEnglishLines: englishLines, packagedAudioBanks: packaged }));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
