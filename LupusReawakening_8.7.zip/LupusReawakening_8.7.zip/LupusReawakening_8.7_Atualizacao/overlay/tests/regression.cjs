'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const { createRuntime } = require('./runtime.cjs');

async function main() {
  const r = createRuntime();
  const tests = [], results = [];
  const test = (name, fn) => tests.push({ name, fn });
  const checkErrors = () => assert.deepEqual(r.json('window.__err || []'), [], 'frame caught a rendering/update exception');
  await r.settle();
  const pristineSave = r.run('JSON.stringify(SAVE)');
  function resetSave() { r.gamepads.length = 0; r.run(`SAVE = ${pristineSave}; Inp.reset(); window.__err = []; if(window.LupusGamepad) LupusGamepad.update({connected:false});`); }
  function pointer(type, id, x, y) {
    const q = r.json('({scale:SCALE,ox:OX,oy:OY,dpr:cv._dpr})');
    r.dispatch(type, { pointerId: id, clientX: (x * q.scale + q.ox) / q.dpr, clientY: (y * q.scale + q.oy) / q.dpr }, 'canvas:');
  }
  function pad(buttons = [], axes = [0, 0]) {
    const b = Array(16).fill(false); buttons.forEach(i => b[i] = true);
    r.run(`LupusGamepad.update(${JSON.stringify({ connected: true, id: 'Regression pad', buttons: b, axes })})`); r.tick();
  }
  function drainPanels() {
    for (let i = 0; i < 20 && r.run('!!G.panel'); i++) { r.run('G.panel.t = 1; panelAdvance()'); }
    assert.equal(r.run('!!G.panel'), false, 'comic panel did not finish');
  }
  async function enter(stage, args) { resetSave(); await r.play(stage, args); }

  test('startup renders the title with all campaign stages', async () => {
    r.run("Scene.go('title')"); r.tick(5, true);
    assert.equal(r.run('Scene.name'), 'title');
    assert.equal(r.run('STAGES.length'), 16);
    assert.equal(r.run('ART.loaded >= ART.total'), true);
    assert.equal(r.run('SAVE.lang'), 'en', 'a fresh installation should open in English');
    checkErrors();
  });
  for (let i = 0; i < 16; i++) test(`stage ${String(i + 1).padStart(2, '0')} starts, updates and renders`, async () => {
    await enter(i); r.tick(120); await r.settle(); r.tick(1, true);
    assert.equal(r.run('Scene.name'), 'play');
    assert.equal(r.run('G.stage'), i);
    assert.ok(r.run('G.player.hp > 0'), 'player should survive an idle two-second startup');
    assert.ok(r.run('G.team.length >= 1 && G.team.every(h => h.hp > 0)'), 'team not initialized');
    checkErrors();
    if (process.env.LUPUS_RENDER_DIR) r.snapshot(path.join(process.env.LUPUS_RENDER_DIR, `stage-${String(i + 1).padStart(2, '0')}.png`));
  });
  for (const stage of [0, 1]) test(`solo stage ${stage + 1} restores its checkpoint`, async () => {
    await enter(stage, { fromWave: 1 }); r.tick(2);
    assert.equal(r.run('G.team.length'), 1);
    assert.equal(r.run('G.ally'), null);
    assert.equal(r.run('G.ck'), 1);
    assert.equal(r.run('G.waveIdx'), 1);
    assert.ok(r.run('G.player.x > 70'), 'checkpoint did not move the solo hero forward');
    checkErrors();
  });
  test('the last solo checkpoint resumes near the boss instead of restarting the stage', async () => {
    resetSave();
    const last = r.run('STAGES[0].waves.length');
    await r.play(0,{fromWave:last});
    assert.equal(r.run('G.ck'),last);
    assert.equal(r.run('G.waveIdx'),last);
    assert.ok(r.run('G.player.x > WORLD_W - VW'), 'last checkpoint restarted behind the completed waves');
  });
  test('a checkpoint after the Vespera duel restores the recruited partner', async () => {
    resetSave();
    const afterDuel = r.run("STAGES[1].waves.findIndex(w=>w.duel==='vesp_mb')+1");
    await r.play(1,{fromWave:afterDuel});
    assert.equal(r.run('G.ally && G.ally.id'),'vespera');
    assert.equal(r.run('G.team.length'),2);
    assert.equal(r.run('G.ally.bench'),true);
    assert.equal(r.run('G.player.id'),'lupus');
  });
  test('Leviathan rises, rejects damage while submerged and exposes a damage window', async () => {
    await enter(9);
    r.run("G.testBoss = spawnBoss('levgiant')");
    assert.equal(r.run('G.testBoss.giant'), true);
    assert.equal(r.run('G.testBoss.gst'), 'rise');
    r.run('G.testBoss.bossIn = 0; G.testBoss.inv = 0; G.testBoss.vuln = false; G.testHP = G.testBoss.hp; hurt(G.player, G.testBoss, 30, {ignoreInv:true})');
    assert.equal(r.run('G.testBoss.hp'), r.run('G.testHP'), 'submerged Leviathan took damage');
    r.run('for (let i = 0; i < 150; i++) updEnemy(G.testBoss, 1/60)');
    assert.equal(r.run('G.testBoss.gst'), 'idle');
    r.run("G.testBoss.gst='bite1'; G.testBoss.gt=0; updEnemy(G.testBoss,1/60); G.testHP=G.testBoss.hp; hurt(G.player,G.testBoss,30,{ignoreInv:true})");
    assert.ok(r.run('G.testBoss.hp < G.testHP'), 'exposed head did not receive damage');
  });
  for (const { stage, boss, ally } of [{ stage: 1, boss: 'vesp_mb', ally: 'vespera' }, { stage: 6, boss: 'echo_mb' }]) {
    for (const damageMode of ['hit', 'bleed']) test(`${boss} completes surrender after lethal ${damageMode} damage`, async () => {
      await enter(stage);
      r.run(`G.duelHold = true; G.locked = true; G.testBoss = spawnMini('${boss}'); G.testBoss.bossIn = 0; G.testBoss.inv = 0;`);
      if (damageMode === 'hit') r.run('hurt(G.player,G.testBoss,G.testBoss.maxhp*3,{ignoreInv:true,brk:true})');
      else r.run('G.testBoss.hp = 1; G.testBoss.bleedT = 2; G.testBoss.bleedD = 999; updEnemy(G.testBoss,1/60)');
      assert.equal(r.run('G.testBoss.dead'), false, 'scripted surrender boss was killed');
      assert.ok(r.run('G.testBoss.hp > 0 && G.testBoss.yielding > 0'), 'surrender did not start');
      r.run('G.testHP=G.testBoss.hp; hurt(G.player,G.testBoss,999999,{ignoreInv:true,brk:true})');
      assert.equal(r.run('G.testBoss.hp'), r.run('G.testHP'), 'surrendering boss accepted another hit');
      r.run('for(let i=0;i<60;i++) updEnemy(G.testBoss,1/60)');
      r.tick(65); drainPanels(); r.tick(2); drainPanels();
      assert.equal(r.run('G.duelHold'), false, 'duel still blocks wave progress after surrender');
      assert.equal(r.run('G.mini'), null, 'mini boss still registered');
      if (ally) assert.equal(r.run(`G.ally && G.ally.id`), ally, 'Vespera did not join the team');
    });
  }
  test('Kreutz escapes after a lethal hit and the stage can finish', async () => {
    await enter(0);
    r.run("G.testBoss=spawnBoss('kreutz44'); G.testBoss.bossIn=0; G.testBoss.inv=0; G.testBoss.x=G.camX+100; hurt(G.player,G.testBoss,999999,{ignoreInv:true,brk:true})");
    assert.equal(r.run('G.testBoss.dead'), false);
    assert.ok(r.run('G.testBoss.fleeing > 0'));
    r.run('for(let i=0;i<240 && !G.testBoss.dead;i++) updEnemy(G.testBoss,1/60)');
    assert.equal(r.run('G.testBoss.dead'), true);
    assert.ok(r.run('G.clearT > 0'), 'escaped boss did not release stage completion');
  });
  for (const width of [960, 1248]) test(`arena archives can all be collected at ${width / 2} logical pixels`, async () => {
    r.resize(width);
    for (const stage of [8, 12]) {
      await enter(stage);
      assert.equal(r.run('G.arena'), true);
      r.run('G.sensing = true');
      const n = r.run('G.archs.length');
      for (let j = 0; j < n; j++) {
        r.run(`G.player.x=G.archs[${j}].x; G.player.y=G.archs[${j}].y; bounds(G.player); archStep()`);
        assert.equal(r.run(`G.archs[${j}].got`), true, `stage ${stage + 1}, archive ${j + 1} outside playable bounds`);
      }
    }
    r.resize(960);
  });
  test('all 48 archives are collectible and unlock the archive reward', async () => {
    resetSave(); r.run('SAVE.arch={}; SAVE.skins={}');
    for (let stage = 0; stage < 16; stage++) {
      await r.play(stage);
      r.run('G.sensing=true; G.locked=!!G.arena; G.title=0;');
      for (let j = 0; j < r.run('G.archs.length'); j++) {
        r.run(`if(!G.arena) G.camX=clamp(G.archs[${j}].x-VW/2,0,WORLD_W-VW); G.player.x=G.archs[${j}].x; G.player.y=G.archs[${j}].y; bounds(G.player); archStep()`);
        assert.equal(r.run(`G.archs[${j}].got`), true, `stage ${stage + 1}, archive ${j + 1} not collectible`);
      }
    }
    assert.equal(r.run('archCount()'), 48);
    assert.equal(r.run('SAVE.skins.lupus'), true);
  });
  test('new game clears campaign rewards but keeps player preferences', async () => {
    resetSave();
    r.run(`Object.assign(SAVE,{unlocked:17,cleared:16,ngp:true,seenIntro:true,nereus:'end',tutDone:true,shards:999,stars:{16:7},xp:{lupus:9999},owned:{rush:true},pal:{lupus:3},best:{16:2000},arch:{0:1},skins:{lupus:true},skinOn:{lupus:true},sk:{lupus:{atk:4}},aff:{vespera:5},lang:'pt',music:false,sfx:false,vib:false}); Scene.go('title'); Scenes.title.opts=true; Scenes.title.update(0);`);
    const reset = r.json("Scenes.title.btns.find(b=>b.id==='reset')");
    assert.ok(reset, 'new game button absent');
    r.run(`Scenes.title.onDown(1,${reset.x + reset.w / 2},${reset.y + reset.h / 2})`);
    assert.equal(r.run('Scene.name'), 'confirmReset', 'new game should request confirmation before erasing progress');
    assert.equal(r.run('SAVE.unlocked'), 17, 'progress erased before confirmation');
    r.tick();
    const erase = r.json("Scenes.confirmReset.btns.find(b=>b.id==='erase')");
    pointer('pointerdown',31,erase.x+erase.w/2,erase.y+erase.h/2); pointer('pointerup',31,erase.x+erase.w/2,erase.y+erase.h/2);
    assert.equal(r.run('SAVE.unlocked'), 1);
    for (const name of ['stars', 'xp', 'owned', 'pal', 'best', 'arch', 'skins', 'skinOn', 'sk', 'aff']) assert.equal(r.run(`Object.keys(SAVE.${name} || {}).length`), 0, `${name} retained after reset`);
    for (const name of ['cleared', 'ngp', 'seenIntro', 'tutDone', 'nereus']) assert.ok(!r.run(`SAVE.${name}`), `${name} retained after reset`);
    assert.equal(r.run('SAVE.shards || 0'), 0);
    assert.equal(r.run('SAVE.lang'), 'pt');
    assert.equal(r.run('SAVE.music'), false);
    assert.equal(r.run('SAVE.sfx'), false);
    assert.equal(r.run('SAVE.vib'), false);
    const disk = JSON.parse(r.storage.get(r.run('SAVE_KEY')));
    assert.equal(disk.unlocked, 1, 'new game was not persisted');
    assert.deepEqual(disk.arch || {}, {});
  });
  test('cancelling new game preserves campaign progress', async () => {
    resetSave(); r.run("SAVE.unlocked=12; SAVE.arch={3:1}; Scene.go('title'); Scenes.title.opts=true; Scenes.title.update(0)");
    const reset = r.json("Scenes.title.btns.find(b=>b.id==='reset')");
    r.run(`Scenes.title.onDown(1,${reset.x + reset.w / 2},${reset.y + reset.h / 2})`);
    assert.equal(r.run('Scene.name'), 'confirmReset');
    r.dispatch('keydown', { key: 'Escape' });
    assert.equal(r.run('SAVE.unlocked'), 12);
    assert.equal(r.run('SAVE.arch[3]'), 1);
    assert.equal(r.run('Scene.name'), 'title');
  });
  test('sprite caches stay within their memory budgets during repeated look changes', () => {
    r.run(`ART.free([]); for(let pass=0;pass<3;pass++) for(const look of Object.values(LOOK)) for(let p=0;p<4;p++) {
      ART.grade('lupus_h',look,p);
      for(let i=0;i<4;i++) { const f=ART.frame('lupus_h','run',i); ART.gradeFrame(f,look,p); ART.silhouette(f,['#ff2040','#40e0ff','#ffffff','#a7ff00'][p]); }
    }`);
    const caches = r.json('ART.cacheStats()');
    assert.ok(caches.atlasBytes <= 96 * 1024 * 1024, 'full atlas cache exceeds 96 MiB');
    assert.ok(caches.frameBytes <= 12 * 1024 * 1024, 'palette frame cache exceeds 12 MiB');
    assert.ok(caches.silhouetteBytes <= 16 * 1024 * 1024, 'silhouette cache exceeds 16 MiB');
    assert.ok(caches.atlases <= 24 && caches.frames <= 128 && caches.silhouettes <= 192);
    assert.equal(r.run('ART.gradeBytes'), r.run('Object.values(ART.graded).reduce((n,c)=>n+c.width*c.height*4,0)'), 'atlas budget disagrees with retained canvas memory');
    r.run('ART.free([])');
    assert.equal(r.run('ART.cacheStats().atlasBytes + ART.cacheStats().frameBytes + ART.cacheStats().silhouetteBytes'), 0);
  });
  test('gallery drag reaches the last row, tap opens it, and image memory stays bounded', async () => {
    resetSave();
    r.run("SAVE.unlocked=17; SAVE.cleared=16; SAVE.arch=Object.fromEntries(Array.from({length:48},(_,i)=>[i,1])); Scene.go('lair'); Scenes.lair.tab=4; Scenes.lair.layout()");
    await r.settle(); r.tick(1, true);
    assert.ok(r.run('LupusGallery.stats().maxScroll > 0'), 'unlocked gallery should have more than one screen');
    pointer('pointerdown',71,50,200); pointer('pointermove',71,50,-10000); pointer('pointerup',71,50,-10000);
    await r.settle(); r.tick(1, true);
    let stats = r.json('LupusGallery.stats()');
    assert.equal(stats.scroll, stats.maxScroll);
    assert.equal(r.run('Scenes.lair.view'), -1, 'drag opened a thumbnail accidentally');
    assert.ok(stats.thumbnails <= 36 && stats.loading <= 2 && stats.fullPanels === 0, 'gallery preloaded excessive image memory');
    const last = r.json('Scenes.lair.items.filter(it=>it.kind===\'gal\').at(-1)');
    assert.ok(last.y >= 52 && last.y + last.h <= 259, 'last row is not fully visible');
    pointer('pointerdown',72,last.x+last.w/2,last.y+last.h/2); pointer('pointerup',72,last.x+last.w/2,last.y+last.h/2);
    await r.settle(); r.tick(1,true);
    assert.equal(r.run('Scenes.lair.view'), last.i);
    assert.ok(r.run('COMIC.img[Scenes.lair.pages[Scenes.lair.view]].ok'), 'last full-size image did not load');
    assert.ok(r.run('LupusGallery.stats().fullPanels <= 3'));
    r.run("Scene.go('title')"); await r.settle();
    stats = r.json('LupusGallery.stats()');
    assert.equal(stats.thumbnails + stats.loading + stats.fullPanels, 0, 'gallery images retained after exit');
    checkErrors();
  });
  test('touch targets stay on screen and retain a 48 CSS-pixel hit area after resize', async () => {
    await enter(3);
    for (const [width,height] of [[960,540],[800,360],[1440,720]]) {
      r.resize(width,height);
      const m = r.json('ControlsUI.metrics()'), B = r.json('ControlsUI.buttons()'), vw = r.run('VW');
      for (const [name,b] of Object.entries(B)) {
        assert.ok(2*b.hit*m.scale >= 48-0.01, `${name} touch area too small at ${width}x${height}`);
        assert.ok(b.x-b.hit>=0 && b.y-b.hit>=0 && b.x+b.hit<=vw && b.y+b.hit<=270, `${name} outside safe screen`);
      }
    }
    r.resize(960,540);
  });
  test('contextual buttons keep their positions when abilities become available', async () => {
    await enter(0);
    assert.equal(r.run("ControlsUI.visible('tag')"),false,'solo prologue shows partner controls');
    assert.equal(r.run("ControlsUI.visible('assist')"),false);
    assert.equal(r.run("ControlsUI.visible('sense')"),false,'locked senses should not appear in prologue');
    await enter(3);
    const before=r.json('ControlsUI.buttons()');
    assert.equal(r.run("ControlsUI.visible('super')"),false);
    r.run('G.syn=100');
    assert.equal(r.run("ControlsUI.visible('super')"),true);
    assert.deepEqual(r.json('ControlsUI.buttons()'),before,'super readiness moved other touch controls');
    r.run("G.player.form='f';G.player.fury=0");
    assert.equal(r.run("ControlsUI.visible('form')"),true,'empty fury must not hide revert-to-human');
    r.run("G.player=G.ally");
    assert.equal(r.run("ControlsUI.visible('form')"),false,'partner shows Lupus transformation control');
  });
  test('multitouch and keyboard maintain a held attack until every source releases', async () => {
    await enter(3);
    const b = r.json('ControlsUI.buttons().atk');
    pointer('pointerdown',10,b.x,b.y); pointer('pointerdown',11,b.x,b.y);
    pointer('pointerup',10,b.x,b.y);
    assert.equal(r.run('playerCtl().atkHeld'), true, 'first pointer release cancelled second pointer');
    r.dispatch('keydown',{key:'j'}); pointer('pointerup',11,b.x,b.y);
    assert.equal(r.run('playerCtl().atkHeld'), true, 'touch release cancelled keyboard');
    r.dispatch('keyup',{key:'j'});
    assert.equal(r.run('playerCtl().atkHeld'), false, 'attack stuck after all sources released');
    const joy = r.json('ControlsUI.joystick()');
    pointer('pointerdown',12,joy.x,joy.y); pointer('pointermove',12,joy.x+30,joy.y-15);
    assert.ok(r.run('playerCtl().mx > 0.4'), 'joystick did not move');
    pointer('pointercancel',12,joy.x,joy.y);
    assert.equal(r.run('playerCtl().mx'), 0, 'cancelled joystick is stuck');
  });
  test('holding Form reverts a transformed Lupus even with an empty fury meter', async () => {
    await enter(3);
    r.run("G.title=0; G.player.form='f'; G.player.fury=0; G.player.st='idle'; G.player.t=0; G.player.formPress=null");
    const b = r.json('ControlsUI.buttons().form');
    pointer('pointerdown',14,b.x,b.y); r.tick(110); pointer('pointerup',14,b.x,b.y);
    assert.equal(r.run('G.player.form'), 'h', 'held form input could not return to human');
  });
  test('control editor saves dragging, size and joystick changes, and cancels drafts', async () => {
    await enter(3);
    r.run('ControlsUI.open()'); r.tick(1,true);
    assert.equal(r.run('Scene.name'), 'controls');
    const b = r.json('ControlsUI.buttons().atk');
    pointer('pointerdown',21,b.x,b.y); pointer('pointermove',21,b.x-25,b.y-20); pointer('pointerup',21,b.x-25,b.y-20);
    r.run(`{const el=document.body.querySelector('[data-control="size"]');el.value='120';el.oninput(); const mode=document.body.querySelector('[data-control="mode"]');mode.value='fixed';mode.onchange();} ControlsUI.close(true)`);
    assert.equal(r.run('Scene.name'),'play');
    assert.equal(r.run('SAVE.controls.buttons.atk.size'),1.2);
    assert.equal(r.run('SAVE.controls.joystick'),'fixed');
    assert.ok(r.run('SAVE.controls.buttons.atk.x > 0 && SAVE.controls.buttons.atk.x < 1'));
    const saved = r.run('JSON.stringify(SAVE.controls)');
    r.run('ControlsUI.open()');
    r.run(`{const el=document.body.querySelector('[data-control="size"]');el.value='150';el.oninput();} ControlsUI.close(false)`);
    assert.equal(r.run('JSON.stringify(SAVE.controls)'),saved,'cancelled editor draft changed the saved controls');
    assert.equal(r.run('document.getElementById("lupus-control-editor")'),null,'editor overlay was not removed');
    checkErrors();
  });
  test('control presets preserve preferences and left-handed mode mirrors custom positions', async () => {
    await enter(3);
    r.run("SAVE.controls.opacity=.55; SAVE.controls.joystick='fixed'; SAVE.controls.buttons.atk={x:.75,y:.7,size:1.2,opacity:.8}; SAVE.controls.joy={x:.15,y:.8,size:1.1,opacity:.9}; ControlsUI.flipHandedness()");
    assert.equal(r.run('SAVE.controls.left'),true);
    assert.equal(r.run('SAVE.controls.buttons.atk.x'),.25);
    assert.equal(r.run('SAVE.controls.joy.x'),.85);
    assert.equal(r.run('SAVE.controls.buttons.atk.size'),1.2);
    assert.equal(r.run('SAVE.controls.buttons.atk.opacity'),.8);
    for(const preset of ['standard','compact','large','tablet']) {
      assert.equal(r.run(`ControlsUI.applyPreset('${preset}')`),true);
      assert.equal(r.run('SAVE.controls.preset'),preset);
      assert.equal(r.run('SAVE.controls.opacity'),.55);
      assert.equal(r.run('SAVE.controls.joystick'),'fixed');
      assert.equal(r.run('SAVE.controls.left'),true);
      assert.equal(r.run('SAVE.controls.buttons.atk.opacity'),.8);
      for(const [width,height] of [[960,540],[800,360],[568,240]]) {
        r.resize(width,height);
        const m=r.json('ControlsUI.metrics()'),B=Object.values(r.json('ControlsUI.buttons()')),vw=r.run('VW');
        for(const b of B) {
          assert.ok(2*b.hit*m.scale>=48-.01,`${preset}/${b.name} target below48px`);
          assert.ok(b.x-b.hit>=0 && b.x+b.hit<=vw && b.y-b.hit>=0 && b.y+b.hit<=270,`${preset}/${b.name} target outside screen`);
        }
        for(let i=0;i<B.length;i++)for(let j=i+1;j<B.length;j++) assert.ok(Math.hypot(B[i].x-B[j].x,B[i].y-B[j].y)>=B[i].hit+B[j].hit+m.gap-1.1,`${preset}: ${B[i].name}/${B[j].name} targets overlap`);
      }
    }
    r.resize(960,540);
  });
  test('native controller navigates menus, moves, attacks and toggles pause', async () => {
    resetSave(); r.run("Scene.go('title')"); r.tick();
    pad([0]);
    assert.equal(r.run('Scene.name'),'select','controller A did not activate Start');
    // The prologue deliberately skips partner selection; use a team stage for B.
    r.run("Scene.go('select',{stage:3})"); r.tick();
    pad(); pad([1]);
    assert.equal(r.run('Scene.name'),'stages','controller B did not leave selection');
    pad(); pad([1]);
    assert.equal(r.run('Scene.name'),'title','controller B did not leave stage map');
    pad(); await r.play(3); r.run('G.title=0');
    const before = r.run('G.player.x');
    pad([], [1,0]); r.tick(30);
    assert.ok(r.run('G.player.x')>before+10,'controller stick did not move the hero');
    pad(); pad([2]);
    assert.equal(r.run('G.player.st'),'atk','controller X did not attack');
    pad(); pad([9]);
    assert.equal(r.run('Scenes.play.menu'),true,'Start did not pause');
    pad(); pad([9]);
    assert.equal(r.run('Scenes.play.menu'),false,'Start did not resume');
    r.run('LupusGamepad.update({connected:false})');r.tick();
    assert.equal(r.run('ControlsUI.state().connected'),false);
    assert.deepEqual(r.json('ControlsUI.state().axes'),[0,0]);
  });
  test('browser Gamepad API input releases cleanly on blur and disconnect', async () => {
    await enter(3);
    r.gamepads.push({connected:true,id:'Browser pad',axes:[0.8,0],buttons:Array(16).fill(false)});
    r.tick();
    assert.equal(r.run('ControlsUI.state().connected'),true);
    assert.ok(r.run('ControlsUI.state().axes[0] > 0.5'));
    r.dispatch('blur'); r.tick();
    assert.deepEqual(r.json('ControlsUI.state().axes'),[0,0]);
    r.dispatch('focus'); r.gamepads.length=0;r.tick();
    assert.equal(r.run('ControlsUI.state().connected'),false);
    assert.deepEqual(r.json('ControlsUI.state().held'),{});
  });
  test('a native controller tap between animation frames is still received', () => {
    resetSave();r.run("Scene.go('title')");r.tick();
    const down=Array(16).fill(false);down[0]=true;
    r.run(`LupusGamepad.update(${JSON.stringify({connected:true,id:'Fast pad',axes:[0,0],buttons:down})}); LupusGamepad.update(${JSON.stringify({connected:true,id:'Fast pad',axes:[0,0],buttons:Array(16).fill(false)})});`);
    r.tick();
    assert.equal(r.run('Scene.name'),'select','native controller tap was lost between frames');
    r.run('LupusGamepad.update({connected:false})');
  });
  test('all partner and ending paths use unique illustrations for distinct story moments', async () => {
    resetSave();
    r.run('window.__panelAudit=[];window.__savedShowPanel=showPanel;showPanel=function(img,beats){__panelAudit.push({img,key:beats.map(b=>b.k||b.sfx||b.txt||b.t).join("|")});}');
    const scenes=[];
    try {
      const hooks=[
        [1,'vespera_encounter','MECH.investigate.duel()'],
        [1,'vespera_alliance',"MECH.investigate.yieldMini(spawnMini('vesp_mb'))"],
        [2,'voss_encounter','MECH.chase.boss()'],
        [6,'echo_encounter','MECH.fog.duel()'],
        [6,'echo_alliance',"MECH.fog.yieldMini(spawnMini('echo_mb'))"],
        [10,'kreutz_encounter','MECH.train.boss()'],
        [15,'fenrir_awakening',"startFenrir(spawnBoss('firstwolf'))"]
      ];
      for(const [stage,event,hook]of hooks) {
        await r.play(stage);r.run('__panelAudit=[];'+hook);r.tick(90);
        const captured=r.json('__panelAudit');
        assert.equal(captured.length,1,`${event} did not expose exactly one narrative illustration`);
        scenes.push({...captured[0],event:`stage${stage+1}:${event}`});
      }
    } finally {r.run('showPanel=__savedShowPanel;delete window.__savedShowPanel;delete window.__panelAudit');}
    const allImages=new Set();
    for(const partner of r.json('PARTNERS'))for(const choice of ['spare','end'])for(const archives of [0,48]) {
      r.run(`SAVE.ally=${JSON.stringify(partner)};SAVE.nereus=${JSON.stringify(choice)};SAVE.arch=Object.fromEntries(Array.from({length:${archives}},(_,i)=>[i,1]))`);
      const panels=r.json('Object.entries(CUTS).flatMap(([id])=>COMIC.pages(id).flatMap((pg,n)=>pg.map((p,j)=>({img:p.img,event:id+":"+n+":"+j}))))');
      const used=new Map();
      for(const panel of panels.concat(scenes)) {
        assert.ok(!used.has(panel.img),`${partner}/${choice}/${archives} reuses ${panel.img} for ${used.get(panel.img)} and ${panel.event}`);
        used.set(panel.img,panel.event);allImages.add(panel.img);
      }
    }
    const fs=require('node:fs'),crypto=require('node:crypto'),hashes=new Map();
    for(const id of allImages) {
      const file=path.join(r.root,'assets/comic',id+'.webp');
      assert.ok(fs.existsSync(file),`${id} story illustration missing`);
      const hash=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
      assert.ok(!hashes.has(hash),`${id} contains the same image bytes as ${hashes.get(hash)}`);hashes.set(hash,id);
    }
  });
  test('every declared comic panel exists in the packaged assets', () => {
    const fs=require('node:fs');
    const missing = r.json('[...COMIC_LIST]').filter(id=>!fs.existsSync(path.join(r.root,'assets/comic',id+'.webp')));
    assert.deepEqual(missing,[],'declared story illustrations absent from the game package');
  });
  test('every authored Portuguese dialogue has a real packaged recording', () => {
    const fs=require('node:fs'),lines=r.json('window.LUPUS_DIALOGUE || {}');
    assert.ok(Object.keys(lines).length>=296,'authored dialogue manifest is incomplete');
    for(const key of ['ch01a','ch01b','ch02a','ch02b','ch03a','ch03b']) assert.ok(lines[key],`${key} chain-origin voice missing from manifest`);
    const problems=[];
    for(const [key,line] of Object.entries(lines)) {
      if(typeof line.file!=='string' || !line.file || !(line.duration>0) || !line.speaker) {problems.push(`${key}: recording not finalized`);continue;}
      const file=path.resolve(r.root,line.file);
      if(!file.startsWith(r.root+path.sep) || !fs.existsSync(file)) {problems.push(`${key}: packaged audio missing`);continue;}
      const data=fs.readFileSync(file);
      if(data.length<64 || data.subarray(0,4).toString()!=='OggS') problems.push(`${key}: invalid or empty Ogg recording`);
      if(!r.run(`!!I18N.pt.comic[${JSON.stringify(key)}]`)) problems.push(`${key}: authored Portuguese subtitle missing`);
    }
    assert.deepEqual(problems,[],`${problems.length} dialogue recordings are incomplete`);
  });
  test('asset loading has no missing image files', () => assert.deepEqual([...r.missing], []));

  console.log('TAP version 13');
  for (const t of tests) {
    try { await t.fn(); console.log(`ok ${results.length + 1} - ${t.name}`); results.push({ name: t.name, pass: true }); }
    catch (e) { console.log(`not ok ${results.length + 1} - ${t.name}\n  ---\n  message: ${JSON.stringify(e.message)}\n  ...`); results.push({ name: t.name, pass: false, message: e.message }); }
  }
  console.log(`1..${results.length}`);
  console.log(`# ${results.filter(t => t.pass).length} passed, ${results.filter(t => !t.pass).length} failed`);
  if (results.some(t => !t.pass)) process.exitCode = 1;
  if (process.env.LUPUS_TEST_REPORT) require('node:fs').writeFileSync(process.env.LUPUS_TEST_REPORT, JSON.stringify({ timestamp: new Date().toISOString(), host: 'Node vm + @napi-rs/canvas; audio mocked', results }, null, 2));
}
main().catch(e => { console.error(e.stack); process.exitCode = 1; });
